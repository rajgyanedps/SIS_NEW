function isNumberKey(evt)
				{
				var charCode = (evt.which) ? evt.which : event.keyCode
				if (charCode > 31 && (charCode < 48 || charCode > 57))
				return false;

				return true;
				}

function enquiry_save_details() {
	var myself = document.getElementById("myself").value;
	var fname = document.getElementById("fname").value;
	var email = document.getElementById("email").value;
	var mobile = document.getElementById("mobile").value;
	var city = document.getElementById("city").value;
	var state = document.getElementById("state").value;
	var reference = document.getElementById("reference").value;
	var admission = document.getElementById("admission").value;
	var letters_code = document.getElementById("letters_code").value;
	if (myself == ''){
		$('#myself').css({"color":"red","border":"2px solid red"});
	}if (fname == ''){
		$('#fname').css({"color":"red","border":"2px solid red"});
	}if (email == ''){
		$('#email').css({"color":"red","border":"2px solid red"});
	}if (mobile == ''){
		$('#mobile').css({"color":"red","border":"2px solid red"});
	}if (city == '' ){
		$('#city').css({"color":"red","border":"2px solid red"});
	}if (state == ''){
		$('#state').css({"color":"red","border":"2px solid red"});
	}if (reference == ''){
		$('#reference').css({"color":"red","border":"2px solid red"});
	} if (admission == '') {
		$('#admission').css({"color":"red","border":"2px solid red"});
	} if (letters_code == '') {
		$('#letters_code').css({"color":"red","border":"2px solid red"});
	}else{
	    var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
		if (filter.test(email)) {
			$.ajax({
    			url: 'https://www.thedpsgint.in/ajax_enquiry_savedetails.php',
    			type: 'POST',
    			data: {
    				myself : myself, fname : fname, email : email,  mobile : mobile, city : city, state : state, reference : reference, admission : admission, letters_code : letters_code
    			},
    			success: function(data){
    				success_data = $.parseJSON(data);
    				var fdata = success_data.data;
    				error_data = $.parseJSON(data);
    				var ferr = error_data.err;
    				//alert(fdata);
    				if(fdata == '1'){
    					alert("Your details have been saved successfully!! We will contact you shortly.");
    					window.location.href = 'https://www.thedpsgint.in/';
    			//	window.setTimeout(function(){window.location.href = 'https://www.thedpsgint.in/'; })
    				}else if(ferr == '1'){
    				   // alert("Please match your captcha code");
				    	//var img = document.images['captchaimg'];
        	            //img.src = img.src.substring(0,img.src.lastIndexOf("?"))+"?rand="+Math.random()*1000;
    				}
    			}
    		});
		} else {
			alert('Invalid Email Address');
		} 
	}

	$("input").keyup(function(){
		$("input").css({"color":"","border":""});
		$("select").css({"color":"","border":""});
	});

	$("select").on('change', function(){
		$("input").css({"color":"","border":""});
		$("select").css({"color":"","border":""});
	});
	
	$("#reused_form").removeClass().addClass('shake animated').one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
        $(this).removeClass();
    });
}