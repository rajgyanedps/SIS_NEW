<?php
 $phone = $_POST['phone'];
 $code = $_POST['code'];

if(!empty($phone)){

    $username = urlencode("dpsg-selaqui");
    $password = urlencode("selaqui1");
  	$type = "0";
	$dlr = "1";
	$source = 'SELAQI';
	$destination = $phone;
	// create a new cURL resource
	$ch = curl_init();
	$url = "https://103.16.101.52/sendsms/bulksms";
	$message = "Your%20OTP%20is%20".$code.".%20%0AUse%20the%20above%20One%20Time%20Password%20to%20verify%20your%20identity.";
	// set URL and other appropriate options
    
	$postData = "username=$username&password=$password&type=$type&dlr=$dlr&destination=$destination&source=$source&message=$message"; 
//	console.log($url+$postData);
    //echo $url.$postData;
    //die;
    //DPSGFB
    $url2= "http://125.16.147.178/VoicenSMS/webresources/CreateSMSCampaignGet?";
    $postData2 = "ukey=yqFNIzcKUn7lR5LION5I1fE6MnC7m5U0cJxErrLo0&msisdn=".$destination."&language=0&credittype=2&senderid=DPSGFB&templateid=0&message=".$message."&filetype=2&isschd=false";
    curl_setopt($ch, CURLOPT_URL, $url2.$postData2);
	//curl_setopt($ch, CURLOPT_HEADER, 0);
	//curl_setopt($ch,CURLOPT_POSTFIELDS, $postData2);
	// grab URL and pass it to the browser
 	$curl_res = curl_exec($ch);
	 
	curl_close($ch);
	if(!empty($curl_res)){
		$response = 'true';
	} else {
		$response = 'false';
	}
}

?>


<?php
/* $phone = $_REQUEST['phone'];
 $code = $_REQUEST['code'];

if(!empty($phone)){
 //echo 'Hi';
    $username = urlencode("dpsg-selaqui");
    $password = urlencode("selaqui1");
  	$type = "0";
	$dlr = "1";
	$source = 'SELAQI';
	$destination = $phone;
	// create a new cURL resource
	$ch = curl_init();
	$url = "http://103.16.101.52/sendsms/bulksms";
	$message = "Your%20OTP%20is%20".$code.".%20%0AUse%20the%20above%20One%20Time%20Password%20to%20verify%20your%20identity.";
	// set URL and other appropriate options
    
	$postData = "username=$username&password=$password&type=$type&dlr=$dlr&destination=$destination&source=$source&message=$message"; 
	//echo $postData;
    //die;
    curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch,CURLOPT_POSTFIELDS, $postData);
	// grab URL and pass it to the browser
 	$curl_res = curl_exec($ch);
	 
	curl_close($ch);
	if(!empty($curl_res)){
		$response = 'true';
	} else {
		$response = 'false';
	}
}
*/
?>