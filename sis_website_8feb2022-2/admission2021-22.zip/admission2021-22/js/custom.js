
/* -------------------------------	
		 LOADER JS START
/* ----------------------------- */
 
var $preloader = $('.loader'),
        $spinner   = $preloader.find('.nothing');
    $spinner.fadeOut();
    $preloader.delay('1500').fadeOut('slow');

/* -------------------------------  
        SILDER UPDATES
/* ----------------------------- */

$("#heroo").owlCarousel({
        items: 1,
        nav: false,
        dots: true,
        autoplay: true,
        loop: true,

         //dots: true,
        navText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"],
        mouseDrag: true,
        touchDrag: true
    });
    // This js codes are for repeating slider text animations
    var heroSection = $(".hero-section");
    var heroSectionText = $(".hero-section-slide h2, .hero-section-slide p");
    var heroSectionButton = $(".hero-section-slide a"); 
    heroSection.on("translate.owl.carousel", function(){
        heroSectionText.removeClass("animated fadeInUp").css("opacity", "0");
        heroSectionButton.removeClass("animated fadeInDown").css("opacity", "0");
    });
    heroSection.on("translated.owl.carousel", function(){
        heroSectionText.addClass("animated fadeInUp").css("opacity", "1");
        heroSectionButton.addClass("animated fadeInDown").css("opacity", "1");
    }); 



/* ---------------------    

        STICKY NAV

/* --------------------- */

var stickyNavTop = $('#header').offset().top;
var stickyNav = function(){
var scrollTop = $(window).scrollTop();
if (scrollTop > stickyNavTop) { 

    $('#header').addClass('sticky');

} else {

    $('#header').removeClass('sticky'); 

}

};

stickyNav();

 

$(window).scroll(function() {

    stickyNav();

});



/* ---------------------    

        back-top

/* --------------------- */

if ($('#back-top').length) {

    var scrollTrigger = 100, // px

        backToTop = function () {

            var scrollTop = $(window).scrollTop();

            if (scrollTop > scrollTrigger) {

                $('#back-top').addClass('show');

            } else {

                $('#back-top').removeClass('show');

            }

        };

    backToTop();

    $(window).on('scroll', function () {

        backToTop();

    });	
	

    $('#back-top').on('click', function (e) {

        e.preventDefault();

        $('html,body').animate({

            scrollTop: 0

        }, 700);

    });

}
   		

/* -------------------------------	

		 WOW ANIMATED JS START

/* ----------------------------- */

new WOW().init();


/* -------------------------------	

		INPUT PLACEHOLDER

/* ----------------------------- */

$('input,textarea').focus(function(){

   $(this).data('placeholder',$(this).attr('placeholder'))

          .attr('placeholder','');

}).blur(function(){

   $(this).attr('placeholder',$(this).data('placeholder'));

});


//Client Carousel
$("#client-slider").owlCarousel({
        //autoPlay: 5000, //Set AutoPlay to 5 seconds
        autoplay: true,
        //smartSpeed: 2000, // Default is 250
        items: 5, //Set Testimonial items
        loop: true,
        margin: 10,
        singleItem: true,
        touchDrag: true,
        mouseDrag: true,
        pagination: false,
        nav: true,
        dots: false,
        navText: ["<i class='fa fa-angle-right'></i>", "<i class='fa fa-angle-right'></i>"],
    responsiveClass:true,
    responsive:{
        0:{
            items:1,
        },
        568:{
            items:2,
        },
        600:{
            items:3,
        },
        667:{
            items:3,
        },
        1000:{
            items:5,
        }
    }   
        
    }); 



//Client Carousel
$("#testimonial-slider").owlCarousel({
        //autoPlay: 5000, //Set AutoPlay to 5 seconds
        autoplay: true,
        //smartSpeed: 2000, // Default is 250
        items: 1, //Set Testimonial items
        loop: true,
        margin: 10,
        singleItem: true,
        touchDrag: true,
        mouseDrag: true,
        pagination: false,
        nav: false,
        dots: true,
        navText: ["<i class='fa fa-chevron-left'></i>", "<i class='fa fa-chevron-right'></i>"],
    responsiveClass:true,
    responsive:{
        0:{
            items:1,
        },
        568:{
            items:1,
        },
        600:{
            items:1,
        },
        667:{
            items:1,
        },
        1000:{
            items:1,
        }
    }   
        
    }); 


/* =======================================
           Testimonial Section 
       =======================================*/
    $("#gallery-memeber").owlCarousel({
        //autoPlay: 5000, //Set AutoPlay to 5 seconds
        autoplay: true,
        //smartSpeed: 2000, // Default is 250
        items: 4, //Set Testimonial items
        loop: true,
        margin: 10,
        singleItem: true,
        touchDrag: true,
        mouseDrag: true,
        pagination: true,
        nav: true,
        dots: false,
        navText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"],
        responsiveClass:true,
    responsive:{
        0:{
            items:1,
        },
        
        568:{
            items:2,
        },
        600:{
            items:2,
        },
        667:{
            items:2,
        },
        768:{
            items:3,
        },
        1000:{
            items:4,
        }
    }
    });


/* -------------------------------  
         POP JS START
/* ----------------------------- */
 $('.popup-gallery').magnificPopup({
        delegate: 'a',
        type: 'image',
        tLoading: 'Loading image #%curr%...',
        mainClass: 'mfp-img-mobile',
        gallery: {
            enabled: true,
            navigateByImgClick: true,
            preload: [0,1] // Will preload 0 - before current, and 1 after the current image
        },
        image: {
            tError: '<a href="%url%">The image #%curr%</a> could not be loaded.',
            titleSrc: function(item) {
                
            }
        }
    });  


    /* -------------------------------  
         POP JS START
/* ----------------------------- */

$('.popup-youtube').magnificPopup({
        disableOn: 320,
        type: 'iframe',
        mainClass: 'mfp-fade',
        removalDelay: 160,
        preloader: false,

        fixedContentPos: false
    });

 /*=================================
    =            Custom JS            =
    =================================*/
        
        //banner form show on click
        jQuery('.banner_form_wrapper .form_open_btn').click(function(e){
            e.preventDefault();
                jQuery('.form_header_fields_wrapper').fadeIn();
                jQuery('.banner_form_wrapper .form_header').hide();
        });

        //banner form hide on click
        jQuery('.form_header_fields_wrapper .form_close_btn').click(function(e){
			//alert('test');
            e.preventDefault();

            jQuery('.banner_form_wrapper .form_header').fadeIn();
            jQuery('.form_header_fields_wrapper').hide();

        });


        //CTA 1 Form Show
        jQuery('#cta_1 .cta_form_header .cta_form_header_btn').click(function(e){
            e.preventDefault();
            jQuery('#cta_1 .cta_form_fields').fadeIn();
            jQuery('#cta_1 .cta_form_header').hide();

        });

        //CTA 1 Form Hide
        jQuery('#cta_1 .cta_close_form_btn').click(function(e){
            e.preventDefault();
            jQuery('#cta_1 .cta_form_header').fadeIn();
            jQuery('#cta_1 .cta_form_fields').hide();
            
        });


        //CTA 2 Form Show
        jQuery('#cta_2 .cta_form_header .cta_form_header_btn').click(function(e){
            e.preventDefault();
            jQuery('#cta_2 .cta_form_fields').fadeIn();
            jQuery('#cta_2 .cta_form_header').hide();

        });

        //CTA 2 Form Hide
        jQuery('#cta_2 .cta_close_form_btn').click(function(e){
            e.preventDefault();
            jQuery('#cta_2 .cta_form_header').fadeIn();
            jQuery('#cta_2 .cta_form_fields').hide();
            
        });


        //CTA 3 Form Show
        jQuery('#cta_3 .cta_form_header_btn').click(function(e){
            e.preventDefault();
            jQuery('#cta_3 .cta_form_fields').fadeIn();
            jQuery(this).hide();
        });

        //CTA 3 Form Hide
        jQuery('#cta_3 .cta_close_form_btn').click(function(e){
            e.preventDefault();
            jQuery('#cta_3 .cta_form_header_btn').fadeIn();
            jQuery('#cta_3 .cta_form_fields').hide();
            
        });
             
             
        
        jQuery(window).scroll(function(e){
            if (jQuery(this).scrollTop() > 100) {
                jQuery('#hero .banner_form_wrapper').css('z-index','9');
            }else{
                jQuery('#hero .banner_form_wrapper').css('z-index','999999');
            }

        });


    
    /*=====  End of Custom JS  ======*/