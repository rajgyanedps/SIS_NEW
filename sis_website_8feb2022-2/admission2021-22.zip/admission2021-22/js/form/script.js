jQuery(document).ready(function(){
    jQuery("#formID").validationEngine();
     jQuery("#formID1").validationEngine();
    $("#formID").bind("jqv.field.result", function(event, field, errorFound, prompText){ console.log(errorFound) })
});