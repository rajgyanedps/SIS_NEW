<div id="applyBox" class="form_header_fields_wrapper">
    <!--<a href="" class="form_close_btn">Close <i class="fa fa-close"></i></a>-->
   
	<h3 class="requset-head">Request a Call Back</h3>
	<div class="form-title">
		<form  onSubmit="return verify_mobile(this);" id="formID" class="register-form" name="contact-form" method="post" role="form">
			<div class="contact-fild-box">
				<div class="col-md-12 col-xs-12 no-padding-left">
					<input name="name" id="name12" class="register-input white-input" placeholder="Name*" type="text" onBlur="addRemoveClasses(this.id);" onkeyup="addRemoveClasses(this.id);" />
				</div>
				<div class="col-md-12 col-xs-12 no-padding-left">
					<input name="phone" id="phone" maxlength="12" placeholder="Contact Number*" class="register-input white-input validate[custom[phone]]" type="text" onBlur="addRemoveClasses(this.id);" onkeyup="addRemoveClasses(this.id);" />
					<span style="color:green; display:none;" id="otp_span">You will receive an OTP on this no.</span>
                    <input type="text" name="otp" style="display:none;" id="otp" class="register-input white-input mrtop15 text-input" placeholder="OTP*" maxlength="6" onBlur="addRemoveClasses(this.id);" onkeyup="addRemoveClasses(this.id);" />
				</div>
			</div>
			<div class="contact-fild-box">
				<div class="col-md-12 col-xs-12 no-padding-left">
					<input name="email" id="email12" class="register-input white-input validate[custom[email]]" placeholder="Email*" maxlength="100" type="text" onBlur="addRemoveClasses(this.id);" onkeyup="addRemoveClasses(this.id);" />
				</div>
				<div class="col-md-12 col-xs-12 no-padding-left">
					<select name="grade" id="grade12" class="register-input white-input" placeholder="Admissions for required" onBlur="addRemoveClasses(this.id);" onkeyup="addRemoveClasses(this.id);">
						<option value="">Class Applying For*</option>
						<option value="V">V</option>
						<option value="VI">VI</option>
						<option value="VII">VII</option>
						<option value="VIII">VIII</option>
						<option value="IX">IX</option>
						<option value="XI">XI</option>
					</select>
				</div>
			</div>
			<div class="contact-fild-box">
				<div class="col-md-6 col-xs-12 no-padding-left">
					<select name="state" onchange="select_state_func()" id="stateid" class="register-input white-input" placeholder="Select Your State*" onBlur="addRemoveClasses(this.id);" onkeyup="addRemoveClasses(this.id);">
						<option value="">State*</option>
						<option value="Andaman & Nicobar Islands" type="1">Andaman &amp; Nicobar Islands</option>
    					<option value="Andhra Pradesh" type="2">Andhra Pradesh</option>
						<option value="Arunachal Pradesh" type="3">Arunachal Pradesh</option>
						<option value="Assam"type="4">Assam</option>
						<option value="Bihar" type="5">Bihar</option>
						<option value="Chandigarh" type="6">Chandigarh</option>
						<option value="Chhattisgarh" type="7">Chhattisgarh</option>
						<option value="Dadra & Nagar Haveli" type="32">Dadra &amp; Nagar Haveli</option>
						<option value="Daman & Diu" type="33">Daman &amp; Diu</option>
						<option value="Delhi & NCR" type="8">Delhi &amp; NCR</option>
						<option value="Goa" type="9">Goa</option>
						<option value="Gujarat" type="10">Gujarat</option>
						<option value="Haryana" type="11">Haryana</option>
						<option value="Himachal Pradesh" type="12">Himachal Pradesh</option>
						<option value="Jammu and Kashmir" type="13">Jammu and Kashmir</option>
						<option value="Jharkhand" type="14">Jharkhand</option>
						<option value="Karnataka" type="15">Karnataka</option>
						<option value="Kerala" type="16">Kerala</option>
						<option value="Madhya Pradesh" type="17">Madhya Pradesh</option>
						<option value="Maharashtra" type="18">Maharashtra</option>
						<option value="Manipur" type="19">Manipur</option>
						<option value="Meghalaya" type="20">Meghalaya</option>
						<option value="Mizoram" type="21">Mizoram</option>
						<option value="Nagaland" type="22">Nagaland</option>
						<option value="Orissa" type="23">Orissa</option>
						<option value="Pondicherry" type="24">Pondicherry</option>
						<option value="Punjab" type="25">Punjab</option>
						<option value="Rajasthan" type="26">Rajasthan</option>
						<option value="Sikkim" type="34">Sikkim</option>
						<option value="Tamil Nadu" type="27">Tamil Nadu</option>
						<option value="Telangana" type="36">Telangana</option>
						<option value="Tripura" type="28">Tripura</option>
						<option value="Uttar Pradesh" type="29">Uttar Pradesh</option>
						<option value="Uttaranchal" type="30">Uttaranchal</option>
						<option value="West Bengal" type="31">West Bengal</option>
					</select>
				</div>
				<div id="citypid" class="col-md-6 col-xs-12 no-padding-left">
					<select name="city" class="register-input white-input formbg1" placeholder="Select Your City*" id="cityid" onBlur="addRemoveClasses(this.id);" onkeyup="addRemoveClasses(this.id);">
						<option value="">City*</option>
					</select>
				</div>
			</div>			
			<div class="contact-fild-box">								
				<div class="col-md-12 col-xs-12 no-padding-left">
					<select name="income" id="income12" class="register-input white-input" placeholder="Income required" onBlur="addRemoveClasses(this.id);" onkeyup="addRemoveClasses(this.id);">
						<option value="">Family Annual Income*</option>
						<option value="0 - 5 Lac P.A.">0 - 5 Lac P.A.</option>
						<option value="5 - 10 Lac P.A.">5 - 10 Lac P.A.</option>
						<option value="Above 10 Lac P.A.">Above 10 Lac P.A.</option>
					</select>
				</div>
				<div class="col-md-12 no-padding-right">
					<textarea name="message" id="message12" placeholder="Query" maxlength="200" class="contact-commnent  white-input ht" rows="2" cols="20" onBlur="addRemoveClasses(this.id);" onkeyup="addRemoveClasses(this.id);"></textarea>
				</div>
			</div>
			<div class="contact-fild-box text-center">
				<div class="form-group">
					<button id="btnSubmit" name="enquiry_submit" type="submit" class="btn btn_submit">Submit</button>
				</div>
			</div>
		</form>
	</div>
</div>