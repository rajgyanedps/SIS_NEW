<?php
    $subject = 'Thank you for Contacting SelaQui International School.';
    $txt = '
    <p>Dear <strong>'.$first_name.',</strong></p>
    <br>
    <p>Thank you for contacting <strong>SelaQui International School, Dehradun!</strong>  <br><br>We appreciate your interest in our school. Your enquiry request has been submitted to our admission counselor and you will receive a call shortly. <br><br>
    In the meantime if you would like to speak with us or if your enquiry is urgent then please <strong>call us on 91- 7669040404</strong>. <br />
    <br />
    You can also visit our website <a href="http://selaqui.org">http://selaqui.org</a>
    <br><br>
    We look forward to speaking to you soon.
    <br><br><br><strong>Warm Regards,<br>Admissions Team<br>SelaQui International School </strong></p>';
    
    $headers  = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    $headers .= "From:  SelaQui International School<admissions@selaqui.org>". "\r\n";
    $headers .= "CC:  Deepak<deepak@finessse.digital>". "\r\n";
    $headers .= "Return-Path: <admissions@selaqui.org>". "";

?>