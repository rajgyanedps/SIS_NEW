<?php 
date_default_timezone_set('Asia/Calcutta'); 
//mysql_connect("selaquicrm.db.5227155.hostedresource.com", "selaquicrm", "Siscrm1#") or die(mysql_error());

//mysql_select_db("selaquicrm") or die(mysql_error());
mysql_connect("localhost", "sisschoo_selaquicrm", "sisschoo_selaquicrm") or die(mysql_error());
mysql_select_db("sisschoo_selaquicrm") or die(mysql_error());




if (isset($_POST["enquiry_submit"])) {
    if(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
		$ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
    } elseif(!empty($_SERVER['REMOTE_ADDR'])) { 
		$ip = $_SERVER['REMOTE_ADDR']; 
	} else { 
		$ip="Not Set"; 
	} 
    $first_name = isset($_POST['name']) ? mysql_real_escape_string($_POST['name']) : "";    
    $email = isset($_POST['email']) ? mysql_real_escape_string($_POST['email']) : "";
    $phone_no = isset($_POST['phone']) ? mysql_real_escape_string($_POST['phone']) : "";
    $message = isset($_POST['message']) ? mysql_real_escape_string($_POST['message']) : "";
    $state = isset($_POST['state']) ? mysql_real_escape_string($_POST['state']) : "";
    $city = isset($_POST['city']) ? mysql_real_escape_string($_POST['city']) : "";
    $class_name = isset($_POST['grade']) ? mysql_real_escape_string($_POST['grade']) : "";
    $annual_income = isset($_POST['income']) ? mysql_real_escape_string($_POST['income']) : "";
    $date = date('Y-m-d H:i:s');
    //end of newly added parameters 
    if($first_name!='') {
        $query = "INSERT INTO student (`stud_name`,`joined`,`emp_id`,`state`,`city`,`email`,`phone_no`,`message`,`grade`,`annual_income`,`v_type`,`ip_address`)
          VALUES('$first_name','$date','100100','$state','$city','$email','$phone_no','$message','$class_name','$annual_income','Paid','$ip')";
        $result = mysql_query($query);
        if ($result == 1) {
            include("email-content.php");
            $mail= mail($email,$subject,$txt,$headers);
            header("Location: thankyou.php");
        } else {
            $message = "data not saved";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-4634742-2"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-4634742-2');
  gtag('config', 'AW-1040837567');
</script>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SelaQui</title>
<link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">
<!-- custom CSS -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/reset.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link rel="stylesheet" href="js/3dSlider/3dGallery.css">
<link href="css/responsive.css" rel="stylesheet">
<link rel="stylesheet" href="css/carousel/owl.carousel.min.css">
<link rel="stylesheet" href="css/carousel/owl.theme.default.min.css">
<!-- TABS CSS START -->
<link rel="stylesheet" type="text/css" href="fonts/styles.css" />
<!-- Animate CSS START -->
<link rel="stylesheet" href="css/popup/magnific-popup.css">
<link href="css/animate.css" rel="stylesheet">
<link rel="stylesheet" href="js/form/validationEngine.jquery.css" />
<!-- FONTS AWSMA FONTS -->
<link rel="stylesheet" href="fonts/fonticon/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Poppins:700&display=swap" rel="stylesheet">
<script src="js/jquery.min.js"></script>
<script>
/*
var code = Math.floor(100000 + Math.random() * 900000);
jQuery(document).ready(function()
{
    jQuery("#phone").change(function()
	{
		var phone = jQuery("#phone").val();
		//alert(phone);
	    $.ajax({
            type : 'POST',
            url : 'smsCode.php',
            crossDomain: true,
			data: {
                phone : phone,
				code : code
            },
            success : function(data){
                //alert(data);
				
            }
        });
		jQuery("#otp_span").show('fast');
		jQuery("#otp").show('fast');
   });
});
*/
function addRemoveClasses(id){
    var value=$('#'+id).val();
    if(value==''){
        $('#'+id).addClass('active')
    }
    else {
        $('#'+id).removeClass('active');
    }
}
function verify_mobile(form)
{
	//var otpField = jQuery('#otp').val();
	var name=jQuery('#name12').val();
	var phone=jQuery('#phone').val();
	var email=jQuery('#email12').val();
	var applyclass=jQuery('#grade12').val();
	var state=jQuery('#stateid').val();
	var city=jQuery('#cityid').val();
	var income=jQuery('#income12').val();
	var message=jQuery('#message12').val();
	
	if(name=='')
	{
      $('#name12').addClass('active');
	}
	if(name!='')
	{
	    $('#name12').removeClass('active');
	}
	if(phone=='')
	{
	    $('#phone').addClass('active');
	}
	if(phone!='')
	{
	    $('#phone').removeClass('active');
	}
/*	if(otpField=='')
	{
	  $('#otp').addClass('active');  
	}
	if(otpField!='')
	{
	    $('#otp').removeClass('active');
	}
	*/
	if(email=='')
	{
	    $('#email12').addClass('active');
	}
	if(email!='')
	{
	    $('#email12').removeClass('active');
	    
	}
	if(applyclass=='')
	{
      $('#grade12').addClass('active');
	}
	if(applyclass!='')
	{
       $('#grade12').removeClass('active');
	}
	if(state=='')
	{
	   $('#stateid').addClass('active'); 
	}
	if(state!='')
	{
	    $('#stateid1').removeClass('active');
	}
	if(city=='')
	{
	   $('#cityid').addClass('active');  
	}
	if(city!='')
	{
      $('#cityid').removeClass('active');
	}
	if(income=='')
	{
	    $('#income12').addClass('active');
	}
	if(income!='')
	{
	    $('#income12').removeClass('active');
	}
	if(message=='')
	{
	    $('#message12').addClass('active');
	}
	if(message!='')
	{
	    $('#message12').removeClass('active');
	}
	
	if(name=='')
	{
	    alert('Enter Name !!');
	    return false;
	}
	else if(phone=='')
	{
	    alert('Enter Contact No !!');
	    return false;
	}
/*	else if(otpField=='')
	{
	    alert('Enter OTP !!');
	    return false;
	}*/
	else if(email=='')
	{
	    alert('Enter Valid Email !!');
	    return false;
	}
	else if(applyclass=='')
	{
	    alert('Select Applying Class !!');
	    return false;
	}
	else if(state=='')
	{
      alert('Select State !!');
	    return false;
	    
	}
	else if(city=='')
	{
      alert('Select City !!');
	    return false;
	    
	}
	else if(income=='')
	{
      alert('Select Family Annual Income !!');
	    return false;
	    
	}
	else if(message=='')
	{
      alert('Insert Query !!');
	    return false;
	    
	}
/*	else if(otpField == code)
	{
		return true;
	}
	else if(otpField != code)
	{
		alert('OTP did not match');
		return false;
	}*/
	
}
jQuery(document).ready(function()
{
    jQuery("#phone1").change(function()
    {
		var phone = jQuery("#phone1").val();
		    $.ajax({
            type : 'POST',
            url : 'smsCode.php',
			crossDomain: true,
			dataType: 'json',
			
            data: {
                phone : phone,
				code : code
            },
            success : function(data){
				
            }
        });
		jQuery("#otp_span1").show('fast');
		jQuery("#otp1").show('fast');
   });
});


function addRemoveClasses1(id){
    var value=$('#'+id).val();
    if(value==''){
        $('#'+id).addClass('active');
    }
    else {
        $('#'+id).removeClass('active');
    }
}
function verify_mobile1(form)
{
//	var otpField = jQuery('#otp1').val();
	var name=jQuery('#name2').val();
	var phone=jQuery('#phone1').val();
	var email=jQuery('#email2').val();
	var applyclass=jQuery('#grade2').val();
	var state=jQuery('#stateid1').val();
	var city=jQuery('#cityid1').val();
	var income=jQuery('#income2').val();
	var message=jQuery('#message2').val();
	if(name=='')
	{
      $('#name2').addClass('active');
	}
	if(name!='')
	{
	    $('#name2').removeClass('active');
	}
	if(phone=='')
	{
	    $('#phone1').addClass('active');
	}
	if(phone!='')
	{
	    $('#phone1').removeClass('active');
	}
/*	if(otpField=='')
	{
	  $('#otp1').addClass('active');  
	}
	if(otpField!='')
	{
	    $('#otp1').removeClass('active');
	}*/
	if(email=='')
	{
	    $('#email2').addClass('active');
	}
	if(email!='')
	{
	    $('#email2').removeClass('active');
	    
	}
	if(applyclass=='')
	{
      $('#grade2').addClass('active');
	}
	if(applyclass!='')
	{
       $('#grade2').removeClass('active');
	}
	if(state=='')
	{
	   $('#stateid1').addClass('active'); 
	}
	if(state!='')
	{
	    $('#stateid1').removeClass('active');
	}
	if(city=='')
	{
	   $('#cityid1').addClass('active');  
	}
	if(city!='')
	{
      $('#cityid1').removeClass('active');
	}
	if(income=='')
	{
	    $('#income2').addClass('active');
	}
	if(income!='')
	{
	    $('#income2').removeClass('active');
	}
	if(message=='')
	{
	    $('#message2').addClass('active');
	}
	if(message!='')
	{
	    $('#message2').removeClass('active');
	}
	
	if(name=='')
	{
	    alert('Enter Name !!');
	    return false;
	}
	else if(phone=='')
	{
	    alert('Enter Contact No !!');
	    return false;
	}
/*	else if(otpField=='')
	{
	    alert('Enter OTP !!');
	    return false;
	}*/
	else if(email=='')
	{
	    alert('Enter Valid Email !!');
	    return false;
	}
	else if(applyclass=='')
	{
	    alert('Select Applying Class !!');
	    return false;
	}
	else if(state=='')
	{
      alert('Select State !!');
	    return false;
	    
	}
	else if(city=='')
	{
      alert('Select City !!');
	    return false;
	    
	}
	else if(income=='')
	{
      alert('Select Family Annual Income !!');
	    return false;
	    
	}
	else if(message=='')
	{
      alert('Insert Query !!');
	    return false;
	    
	}
	
/*	else if(otpField == code)
	{
		return true;
	}
	else if(otpField != code)
	{
		alert('OTP did not match');
		return false;
	}*/
	
}
</script>
</head>
<body>
<header id="header" class="header">
  <div class="headertop">
    <div class="container">
      <div class="col-sm-12 col-xs-12 logo"> <img src="images/logo.png" alt="" /> </div>
    </div>
  </div>
</header>

<!-- Hero section start (Slider) -->
<section id="hero" class="container-fluid hero-section" style="position: relative;">
  <div class="row">
    <div id="heroo" class="owl-carousel owl-theme"> 
      <!-- Slide item #1-->
      <div class="item hero-section-slide bc-img01"></div>
    </div>
  </div>
  <div class="dsu-intro">
    <div class="container">
      <div class="row">
        <div class="col-sm-8 leftsec_content">
          <div class="dsu-addmission">
            <div class="banner-heading">
              <h1>Best Co-ed Boarding School in Dehradun</h1>
              <h2>Admissions Open <span>(Session 2021-22)</span></h2>
              <p>For Class V<sup>th</sup> - IX<sup>th</sup> & XI<sup>th</sup></p>
            </div>
            <div class="breakingBlock">
              <table class="table">
                <thead>
                  <tr>
                    <th colspan="2">Record breaking results of class X and XII (2019-20)</th>
                  </tr>
                  <tr>
                    <th scope="col">Class X</th>
                    <th scope="col">Class XII</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Batch Average</td>
                    <td>Batch Average</td>
                  </tr>
                  <tr>
                    <td>84%</td>
                    <td>91.9%</td>
                  </tr>
                  <tr>
                    <td>23 Students</td>
                    <td>63 Students</td>
                  </tr>
                  <tr>
                    <td>2/3 of batch scored above 90%</td>
                    <td>2/3 of batch scored above 90%</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        <div class="col-sm-4">
          <?php include('request-form.php'); ?>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- Hero section end (Slider) -->
<section class="sec1">
  <div class="fullwidth">
    <div class="container">
      <div class="widget-title title-white">
        <h3> About Us </h3>
      </div>
      <p>SelaQui International School is a co-ed CBSE boarding school nestled in a 52 acres campus with a natural spring running through it providing an ideal setting for education in a country setting. Ranked among the best CBSE residential schools in Dehradun, it is open to boys and girls from class 5 onward, irrespective of their backgrounds. The School vision statement underlines a commitment to values, excellence and leadership, and is in the forefront of all pedagogical practices and ranks among top international schools in Uttarakhand. Students’ involvement in decision making is at the core of SelaQui education and the institution believes in nurturing a student community that is committed to nation building.</p>
      <!--<p><a href="#" class="more">More +</a></p>--> 
      <a href="#" class="registerlink"> Register for Admissions Test
      <div>(21<sup>st</sup> August’ 2021)</div>
      </a> </div>
  </div>
</section>
<section class="achievements">
  <div class="container">
    <div class="sec1head">
      <div class="col-sm-12 col-xs-12 since_content">
        <div class="widget-title">
          <h3> Our Latest Achievement </h3>
        </div>
        <div class="aaward text-center"> <span><img src="images/aaward.png" alt="" style="margin-bottom:15px;"/> "Best Co-ed Boarding School in Academic Reputation" - Zee Business, 2018</span> <span><img src="images/aaward1.png" alt="" style="margin-bottom:15px;"/> "Best Co-ed Boarding school" awarded by Worldwide Achievers and Zee Business - Aug 2018.</span> <span><img src="images/aaward2.png" alt=""/> Ranked #1 Co-ed Boarding school in Uttarakhand by Education World, India School Ranking Awards, 2020-21.</span> </div>
      
      </div>
    </div>
  </div>
</section>
<section class="sec2 padding">
  <div class="container">
    <div class="widget-title title-white">
      <h3> Why SelaQui </h3>
    </div>
    <div class="sec2Head" style="margin-top: 30px;">
      <div class="col-sm-3 col-xs-6 infraicon"> <a href="#applyBox">
        <div class="ser-icon"> <img src="images/uemicon1.png"> </div>
        <div class="content">
          <p>Pollution Free 52 Acres<br/>
            Lush Green Campus </p>
        </div>
        </a> </div>
      <div class="col-sm-3 col-xs-6 infraicon"> <a href="#applyBox">
        <div class="ser-icon"> <img src="images/uemicon2.png"> </div>
        <div class="content">
          <p>International Exchange<br/>
            Program For Students</p>
        </div>
        </a> </div>
      <div class="col-sm-3 col-xs-6 infraicon"> <a href="#applyBox">
        <div class="ser-icon"> <img src="images/uemicon3.png"> </div>
        <div class="content">
          <p>Research Based<br/>
            Experiential Learning</p>
        </div>
        </a> </div>
      <div class="col-sm-3 col-xs-6 infraicon"> <a href="#applyBox">
        <div class="ser-icon"> <img src="images/uemicon4.png"> </div>
        <div class="content">
          <p>Air Conditioned<br/>
            Boarding Houses</p>
        </div>
        </a> </div>
      <div class="col-sm-3 col-xs-6 infraicon bornone"> <a href="#applyBox">
        <div class="ser-icon"> <img src="images/uemicon10.png"> </div>
        <div class="content">
          <p>Integrated Gurukul Programme for IIT/NEET Aspirants</p>
        </div>
        </a> </div>
      <div class="col-sm-3 col-xs-6 infraicon"> <a href="#applyBox">
        <div class="ser-icon"> <img src="images/uemicon9.png"> </div>
        <div class="content">
          <p>Excellent College Placements for Graduating Batch</p>
        </div>
        </a> </div>
      <div class="col-sm-3 col-xs-6 infraicon"> <a href="#applyBox">
        <div class="ser-icon"> <img src="images/uemicon5.png"> </div>
        <div class="content">
          <p>Wi-Fi, Smart Classrooms,<br/>
            Monitored and Secure<br/>
            Campus</p>
        </div>
        </a> </div>
      <div class="col-sm-3 col-xs-6 infraicon"> <a href="#applyBox">
        <div class="ser-icon"> <img src="images/uemicon6.png"> </div>
        <div class="content">
          <p>Career Information<br/>
            and Guidance<br/>
            Department </p>
        </div>
        </a> </div>
      <div class="col-sm-3 col-xs-6 infraicon"> <a href="#applyBox">
        <div class="ser-icon"> <img src="images/uemicon7.png"> </div>
        <div class="content">
          <p>Golf Course, Horse<br/>
            Riding and Shooting<br/>
            Range</p>
        </div>
        </a> </div>
      <div class="col-sm-3 col-xs-6 infraicon bornone"> <a href="#applyBox">
        <div class="ser-icon"> <img src="images/uemicon8.png"> </div>
        <div class="content">
          <p>Qualified Resident Medical Team</p>
        </div>
        </a> </div>
        <div class="col-sm-3 col-xs-6 infraicon bornone"> <a href="#applyBox">
        <div class="ser-icon"> <img src="images/uemicon8.png"> </div>
        <div class="content">
          <p>Prepared to Fight Covid</p>
        </div>
        </a> </div>
    </div>
  </div>
</section>
<section class="banner-table">
  <div class="container">
    <div class="mobile-667">
      <div class="widget-title title-white">
        <h3>Annual Fee Structure</h3>
      </div>
      <div class="banner-table-content">
        <div class="col-sm-6">
          <div class="banner-table-item">
            <p><img src="images/tick.png"> Indian Students</p>
            <p>Approx. 5.5 Lac – 6.5 Lac (INR) depending upon the age group</p>
          </div>
        </div>
        <div class="col-sm-6">
          <div class="banner-table-item">
            <p><img src="images/tick.png"> International Students</p>
            <p>Approx. 8500 – 10500 US Dollars depending upon the age group</p>
          </div>
        </div>
        <div class="col-sm-12 text-center">
          <div class="banner-table-item">
            <p class="terms">*Terms and Conditions Apply</p>
          </div>
        </div>
      </div>
    </div>
    <div class="annual-itemBlock">
      <div class="col-sm-6 col-xs-12">
        <div class="infraicon"> <a href="#applyBox">
          <div class="ser-icon"> <img src="images/scholarship-icon1.png"> </div>
          <div class="content">
            <p>Preparing students for competitive IIT/NEET<br/>
              exams under Gurukul Flagship programme</p>
          </div>
          </a> </div>
      </div>
      <div class="col-sm-6 col-xs-12">
        <div class="infraicon"> <a href="#applyBox">
          <div class="ser-icon"> <img src="images/scholarship-icon2.png"> </div>
          <div class="content">
            <p>Scholarship available Based on the merit</p>
          </div>
          </a> </div>
      </div>
    </div>
  </div>
</section>
<section class="sec3">
  <div class="col-sm-12 col-xs-6 since_content-center">
    <div class="video-block">
      <div class="video-box">
      <img src="images/since_pichtace.jpg" alt="Video"> <a class="popup-youtube" href="https://www.youtube.com/watch?v=XO9WsDD14RA">
        
        <i class="fa fa-play-circle-o" aria-hidden="true" style="top: -250px; position: relative;"></i> </a> </div>
    </div>
  </div>
</section>
<section class="galleryBox">
  <div class="container-fluid">
    <div class="widget-title">
      <h3> Gallery </h3>
    </div>
    <div class="slider">
     
        <img src="images/gallery/1.jpg" alt="">
        <img src="images/gallery/2.jpg" alt="">
        <img src="images/gallery/3.jpg" alt="">
        <img src="images/gallery/4.JPG" alt="">
        <img src="images/gallery/5.JPG" alt="">
        <img src="images/gallery/6.JPG" alt="">
        <img src="images/gallery/7.JPG" alt="">
        <img src="images/gallery/8.JPG" alt="">
        <img src="images/gallery/9.jpg" alt="">
        <img src="images/gallery/10.JPG" alt="">
        <img src="images/gallery/11.JPG" alt="">
        <img src="images/gallery/12.JPG" alt="" class="left">
        <img src="images/gallery/aissce_banner.jpg" alt="" class="center">
        <img src="images/gallery/results-popup.jpg" alt="" class="center">
        <img src="images/gallery/01.jpg" alt="" class="center">
        <img src="images/gallery/13.JPG" alt="" class="right">
        <img src="images/gallery/14.JPG" alt="">
        <img src="images/gallery/15.JPG" alt="">
        <img src="images/gallery/16.JPG" alt="">
        <img src="images/gallery/17.JPG" alt="">
        <img src="images/gallery/18.jpg" alt=""> </div>
  </div>
</section>
<section class="sec2 testimonial-slider">
  <div class="half testicon">
    <div class="container-fluid">
      <div class="col-sm-12">
        <div class="widget-title title-white">
          <h3> WHAT OUR STUDENTS HAVE TO SAY! </h3>
        </div>
        <div class="testimonial-slider-row" style="margin-top: 30px;">
          <div class="owl-carousel owl-theme" id="testimonial-slider">
            <div class="single-client">
              <div class="client-content">
                <div class="testimonial-img">
                  <div class="" align="center"> <img src="images/muskal.png"/> </div>
                  <div class="headName">
                    <h2>Muskal Rijal</h2>
                    <br>
                    <p>Mahatma Gandhi Institute of medical sciences (MGIMS), Wardha, Maharashtra</p>
                  </div>
                  <hr>
                </div>
                <p>I once thought that teaching was always professional. But at SelaQui, I learned that teaching can also be for the love of teaching. I met many wonderful people in SelaQui. Teachers who are always there when you need them be it for any reason. It has given me friends I can always rely on. The best thing about SelaQui was that the school gave me a tremendous amount of freedom to pursue knowledge and experiences far beyond that of a typical school, and challenged me to explore my interest in great depth. It has given me platforms for personal improvement and the freedom to excel in one’s own talents. The infrastructure was far beyond imaginable by any ordinary school. It has been a wonderful experience here.</p>
              </div>
            </div>
            <div class="single-client">
              <div class="client-content">
                <div class="testimonial-img">
                  <div class="" align="center"> <img src="images/amir.png"/> </div>
                  <div class="headName">
                    <h2>Mohammad Amir Faisal</h2>
                    <br>
                    <p>Andaman and Nicobar Island institute of Medical sciences(ANIIMS), Port Blair</p>
                  </div>
                  <hr>
                </div>
                <p> There are only few schools that offer the platform of invention and innovation. SelaQui is one of those. Joining SelaQui has been a turning point of my life. SelaQui not only teaches you subjects but also the slice of life. It teaches one to introspect and learn from one’s experiences. SelaQui teaches one to stand out among others and to think outside the box. One of the best things about SelaQui is that it gave me the freedom to explore the extent of my limits and to surpass it, which was only possible due to all the teachers’ efforts and perseverance. It provides one with leadership experience. SelaQui emphasis on creating the creamy layer of tomorrow. It has provided me a platform where I can build a strong base for creating a building of my achievements. The zeal of learning and the ecstasy of the environment is what one gets to experience in SelaQui. One shall say,”I have graduated from SelaQui not literate, but educated.”</p>
              </div>
            </div>
            <div class="single-client">
              <div class="client-content">
                <div class="testimonial-img">
                  <div class="" align="center"> <img src="images/ramachandra.png"/> </div>
                  <div class="headName">
                    <h2>Meghna Bordoloi</h2>
                    <br>
                    <p>Shri Ramachandra medical college, Chennai</p>
                  </div>
                  <hr>
                </div>
                <p> Thinking for the time spent at SIS, I realize how it has changed me to become a better version of myself. It prepared me to face the challenges that the bigger school called world offers once we are out of the smaller one. It was great opportunity studying here. I met many different people each of whom helped me in their own ways. My teachers have never failed once to encourage and support me. Adding to it, the lush green environment has always bestowed it’s positivity upon me. SelaQui has lots of knowledge and experience to offer if one get it correct. I took the best out of it and it helped me reach here today.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="half"> <img src="images/testimonial.jpg"> </div>
</section>
<section class="sec5">
  <div class="container">
    <div class="widget-title">
      <h3>Affiliations</h3>
    </div>
    <div class="sec5Head">
      <div class="owl-carousel owl-theme" id="client-slider"> 
        <!--<div class="text-center"> <img src="images/client/plc1.png" alt="alt" /></div>-->
        <div class="text-center"> <img src="images/client/plc2.png" alt="alt" /></div>
        <div class="text-center"> <img src="images/client/plc3.png" alt="alt" /></div>
        <div class="text-center"> <img src="images/client/AFS_Logo-India.png" alt="alt" /></div>
        <div class="text-center"> <img src="images/client/plc4.png" alt="alt" /></div>
        <div class="text-center"> <img src="images/client/plc5.png" alt="alt" /></div>
        <div class="text-center"> <img src="images/client/plc6.png" alt="alt" /></div>
        <div class="text-center"> <img src="images/client/plc7.png" alt="alt" /></div>
        <div class="text-center"> <img src="images/client/plc8.png" alt="alt" /></div>
      </div>
    </div>
  </div>
</section>
<section class="sec6">
  <?php include('footer-form.php'); ?>
</section>
<section class="banner-table address">
  <div class="container">
    <div class="mobile-667">
      <div class="widget-title title-white">
        <h3>Contact</h3>
      </div>
      <div class="banner-table-content">
        <div class="col-sm-6">
          <div class="banner-table-item">
            <p><img src="images/gps.png"> School Campus</p>
            <p>Chakrata Road, Dehradun-248011, INDIA</p>
          </div>
        </div>
        <div class="col-sm-6">
          <div class="banner-table-item">
            <p><img src="images/gps.png"> Delhi Office</p>
            <p>A-Block, 3rd Floor, MGF Metropolitan Mall
              District Centre Saket, New Delhi - 110017, INDIA</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<footer class="footer">
  <div class="container">
    <div class="col-md-12 col-sm-12 col-xs-12"> Copyright 2019, All Rights Reserved </div>
  </div>
</footer>
<a href="#" id="back-top" title="Back To Top"></a> 

<!--<script src="js/jquery.min.js"></script>--> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/wow.min.js"></script> 
<script src="css/popup/jquery.magnific-popup.min.js"></script> 
<script src="js/form/jquery.validationEngine.js"></script> 
<script src="js/form/jquery.validationEngine-en.js"></script> 
<script src="js/form/script.js"></script> 
<script src="js/form/state.js"></script> 
<!-- Silder Owl Carousel JS --> 
<script type="text/javascript" src="css/carousel/owl.carousel.min.js"></script> 
<!-- counting js satrt --> 
<script src="css/counting/jquery.inview.min.js"></script> 
<script src="css/counting/main.js"></script> 
<script src="js/custom.js"></script> 
<script src="js/3dSlider/3dGallery.js"></script> 
<script type="text/javascript">
$('a[href^="#applyBox"]').on('click', function(event) {
    var target = $(this.getAttribute('href'));
    if( target.length ) {
        event.preventDefault();
        $('html, body').stop().animate({
            scrollTop: target.offset().top
        }, 1000);
    }
});
</script>
</body>
</html>