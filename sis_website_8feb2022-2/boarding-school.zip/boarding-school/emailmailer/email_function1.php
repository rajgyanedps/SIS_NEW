<?php
require 'class.phpmailer.php';
require 'class.smtp.php';
class Email extends PHPMailer  {
	public $mail;

	 public function __construct()
    {	
		$this->mail = new PHPMailer();
		$this->mail->IsSMTP();
		$this->mail->Mailer = 'smtp';
		$this->mail->SMTPAuth = true;
		$this->mail->Host = 'smtp.office365.com'; // "ssl://smtp.gmail.com" didn't worked
		$this->mail->Port = 587;
		$this->mail->SMTPSecure = 'tls';
		$this->mail->Username = "ajay.pal@dpsgs.org";
		$this->mail->Password = "ajay123!@#";
		$this->mail->IsHTML(true); // if you are going to send HTML formatted emails
		$this->mail->SingleTo = true; // if you want to send a same email to multiple users. multiple emails will be sent one-by-one.
		$this->mail->From = "ajay.pal@dpsgs.org";
		$this->mail->FromName = "tip"; 
		//$this->mail->addCC("user.3@ymail.com","User 3");
		//$this->mail->addBCC("user.4@in.com","User 4");
    }
	
function test(){
	
$this->mail->addAddress("ajay.pal@dpsgs.org","User 1");

 
$this->mail->Subject = "Testing PHPMailer with localhost";
$this->mail->Body = "Hi,<br /><br />This system is working perfectly.";
 
if(!$this->mail->Send())
    echo "Message was not sent <br />PHPMailer Error: " . $mail->ErrorInfo;
else
    echo "1";
}


function email_send_candidate_on_leave_apply($candidateid,$leavtype){
	
	if($leavtype=='OD'){
	$leave = "OD";
	}else{
	$leave = "Leave";
	}
	$empdetails = $this->employee_details($candidateid);
	
	$to=$empdetails['email_address'];
	$name=$empdetails['name'];
    $from = "tipintranet@dpsgs.org";
	$subject = "TIP-Leave Request";
	$email_message = '<html>
						<table cellspacing="0"   cellpadding="10" border="0"	align="center" style="border:5px #eeeeee solid; background:#f9f9f9; padding:20px; width:500px; margin:0 auto; font-family:cambria; font-size:14px; color:#444444;">
						  <tr>
						 <td>Dear '.$name.',</td></tr>
						 <tr>
						  <td>
						 <p>You have Successfully Applied for '.$leave.'. Your applied leave(s) are currently pending for approvals from your Reporting Manager.</p>

<p>For details, Login to TIP portal at http://tip.dpsgs.org >> Applications >> LMS >> Leave History
</p>

						  </td></tr>
						  <tr>
							 <td><strong>Warm Wishes,<br/><br/>
							  Tip Team</strong></br>
							   </td>
						   </tr>
						  </table>	 
						  </html>';

	$headers  = "From: TIP Intranet < ".$from." >\n";
    $headers .= "X-Sender: ".$from." < ".$from." >\n";
    $headers .= 'X-Mailer: PHP/' . phpversion();
    $headers .= "X-Priority: 1\n"; // Urgent message!
    $headers .= "Return-Path: ".$from."\n"; // Return path for errors
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=iso-8859-1\n";
		
	$sentmail = mail($to, $subject, $email_message, $headers);
	
	//echo $to.",". $subject.",".$email_message.$headers;die;
	//die();
	if($sentmail!=''){
	$status = "Send";
		return $status;
	}else{
		$status = "Not Send";
		return $status;
	}
}
function email_send_RM_on_leave_apply($rmid,$candidateid,$leavtype){
if($leavtype=='OD'){
	$leave = " OD ";
	}else{
	$leave = " Leave ";
	}
	$candiate = $this->employee_details($candidateid);
	$empdetails = $this->employee_details($rmid);
	$to=$empdetails['email_address'];
	$name=$empdetails['name'];
    $from = "tipintranet@dpsgs.org";
	$subject = "TIP-Leave Apply";
	$email_message = '<html>
						<table cellspacing="0"   cellpadding="10" border="0"	align="center" style="border:5px #eeeeee solid; background:#f9f9f9; padding:20px; width:500px; margin:0 auto; font-family:cambria; font-size:14px; color:#444444;">
						  <tr>
						 <td>Dear '.$name.',</td></tr>
						 <tr>
						  <td>
						 <p>Your team member '.$candiate['name'].', have submitted a '.$leave.' request which is pending for your approvals. Request you to take desired action by login to TIP portal.</p> 
						<p>Login to TIP portal at http://tip.dpsgs.org >> Applications >> LMS >> Team Requests</p>

						  </td></tr>
						  <tr>
							 <td><strong>Warm Wishes,<br/><br/>
							  Tip Team</strong></br>
							   </td>
						   </tr>
						  </table>	 
						  </html>';

	$headers  = "From: TIP Intranet < ".$from." >\n";
    $headers .= "X-Sender: ".$from." < ".$from." >\n";
    $headers .= 'X-Mailer: PHP/' . phpversion();
    $headers .= "X-Priority: 1\n"; // Urgent message!
    $headers .= "Return-Path: ".$from."\n"; // Return path for errors
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=iso-8859-1\n";
		
	$sentmail = mail($to, $subject, $email_message, $headers);
	//echo $to.",". $subject.",".$email_message.$headers;die;
	if($sentmail!=''){
	$status = "Send";
		return $status;
	}else{
		$status = "Not Send";
		return $status;
	}
}
function email_send_candidate_on_leave_approve($candidateid,$leavtype){
if($leavtype=='OD'){
	$leave = " OD ";
	}else{
	$leave = " Leave ";
	}
	$empdetails = $this->employee_details($candidateid);
	$to=$empdetails['email_address'];
	$name=$empdetails['name'];
    $from = "tipintranet@dpsgs.org";
	$subject = "TIP-Leave Request - Approved";
	$email_message = '<html>
						<table cellspacing="0"   cellpadding="10" border="0"	align="center" style="border:5px #eeeeee solid; background:#f9f9f9; padding:20px; width:500px; margin:0 auto; font-family:cambria; font-size:14px; color:#444444;">
						  <tr>
						 <td>Dear '.$name.',</td></tr>
						 <tr>
						  <td>
						<p>Your '.$leave.' request has been approved by your reporting manager.</p>

<p>For details, Login to TIP portal at http://tip.dpsgs.org >> Applications >> LMS >> Leave History</p>

						  </td></tr>
						  <tr>
							 <td><strong>Warm Wishes,<br/><br/>
							  Tip Team</strong></br>
							   </td>
						   </tr>
						  </table>	 
						  </html>';

	$headers  = "From: TIP Intranet < ".$from." >\n";
    $headers .= "X-Sender: ".$from." < ".$from." >\n";
    $headers .= 'X-Mailer: PHP/' . phpversion();
    $headers .= "X-Priority: 1\n"; // Urgent message!
    $headers .= "Return-Path: ".$from."\n"; // Return path for errors
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=iso-8859-1\n";
		
	$sentmail = mail($to, $subject, $email_message, $headers);
	//echo $to.",". $subject.",".$email_message.$headers;die;
	if($sentmail!=''){
	$status = "Send";
		return $status;
	}else{
		$status = "Not Send";
		return $status;
	}
}
function email_send_candidate_on_leave_rejaect($candidateid,$leavtype){
if($leavtype=='OD'){
	$leave = " OD ";
	}else{
	$leave = " Leave ";
	}
	$empdetails = $this->employee_details($candidateid);
	$to=$empdetails['email_address'];
	$name=$empdetails['name'];
    $from = "tipintranet@dpsgs.org";
	$subject = "TIP-Leave Request - Reject";
	$email_message = '<html>
						<table cellspacing="0"   cellpadding="10" border="0"	align="center" style="border:5px #eeeeee solid; background:#f9f9f9; padding:20px; width:500px; margin:0 auto; font-family:cambria; font-size:14px; color:#444444;">
						  <tr>
						 <td>Dear '.$name.',</td></tr>
						 <tr>
						  <td>
						 <p>Your '.$leave.' request has been rejected by your reporting manager.</p>

<p>For details, Login to TIP portal at http://tip.dpsgs.org >> Applications >> LMS >> Leave History</p>

						  </td></tr>
						  <tr>
							 <td><strong>Warm Wishes,<br/><br/>
							  Tip Team</strong></br>
							   </td>
						   </tr>
						  </table>	 
						  </html>';

	$headers  = "From: TIP Intranet < ".$from." >\n";
    $headers .= "X-Sender: ".$from." < ".$from." >\n";
    $headers .= 'X-Mailer: PHP/' . phpversion();
    $headers .= "X-Priority: 1\n"; // Urgent message!
    $headers .= "Return-Path: ".$from."\n"; // Return path for errors
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=iso-8859-1\n";
		
	$sentmail = mail($to, $subject, $email_message, $headers);
	//echo $to.",". $subject.",".$email_message.$headers;die;die();
	if($sentmail!=''){
	$status = "Send";
		return $status;
	}else{
		$status = "Not Send";
		return $status;
	}
	
}
function email_send_candidate_on_Manual_attendance($candidateid,$leavtype){
if($leavtype=='OD'){
	$leave = " OD ";
	}else{
	$leave = " Leave ";
	}
	$empdetails = $this->employee_details($candidateid);
	$to=$empdetails['email_address'];
	$name=$empdetails['name'];
    $from = "tipintranet@dpsgs.org";
	$subject = "TIP-Manual Attendance Request ";
	$email_message = '<html>
						<table cellspacing="0"   cellpadding="10" border="0"	align="center" style="border:5px #eeeeee solid; background:#f9f9f9; padding:20px; width:500px; margin:0 auto; font-family:cambria; font-size:14px; color:#444444;">
						  <tr>
						 <td>Dear '.$name.',</td></tr>
						 <tr>
						  <td>
						 <p>You have Successfully Applied for Manual Attendance Request. Your request is currently pending for approvals from your Reporting Manager.</p>
<p>For details, Login to TIP portal at http://tip.dpsgs.org >> My Page >> Attendance >> My Attendance 
</p>

						  </td></tr>
						  <tr>
							 <td><strong>Warm Wishes,<br/><br/>
							  Tip Team</strong></br>
							   </td>
						   </tr>
						  </table>	 
						  </html>';

	$headers  = "From: TIP Intranet < ".$from." >\n";
    $headers .= "X-Sender: ".$from." < ".$from." >\n";
    $headers .= 'X-Mailer: PHP/' . phpversion();
    $headers .= "X-Priority: 1\n"; // Urgent message!
    $headers .= "Return-Path: ".$from."\n"; // Return path for errors
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=iso-8859-1\n";
		
	$sentmail = mail($to, $subject, $email_message, $headers);
	//echo $to.",". $subject.",".$email_message.$headers;die;
	if($sentmail!=''){
	$status = "Send";
		return $status;
	}else{
		$status = "Not Send";
		return $status;
	}
}
function email_send_rm_on_Manual_attendance($rmid,$candidateid,$leavtype){
if($leavtype=='OD'){
	$leave = " OD ";
	}else{
	$leave = " Leave ";
	}
	$candiate = $this->employee_details($candidateid);
	$empdetails = $this->employee_details($rmid);
	$to=$empdetails['email_address'];
	$name=$empdetails['name'];
    $from = "tipintranet@dpsgs.org";
	$subject = "TIP-Manual Attendance Request";
	$email_message = '<html>
						<table cellspacing="0"   cellpadding="10" border="0"	align="center" style="border:5px #eeeeee solid; background:#f9f9f9; padding:20px; width:500px; margin:0 auto; font-family:cambria; font-size:14px; color:#444444;">
						  <tr>
						 <td>Dear '.$name.',</td></tr>
						 <tr>
						  <td>
						 <p>Your team member '.$candiate['name'].', have submitted for Manual Attendance request which is pending for your approvals. Request you to take desired action by login to TIP portal.</p> 
						<p>Login to TIP portal at http://tip.dpsgs.org >> My Page >> Attendance >> Manual Attendance</p>

						  </td></tr>
						  <tr>
							 <td><strong>Warm Wishes,<br/><br/>
							  Tip Team</strong></br>
							   </td>
						   </tr>
						  </table>	 
						  </html>';

	$headers  = "From: TIP Intranet < ".$from." >\n";
    $headers .= "X-Sender: ".$from." < ".$from." >\n";
    $headers .= 'X-Mailer: PHP/' . phpversion();
    $headers .= "X-Priority: 1\n"; // Urgent message!
    $headers .= "Return-Path: ".$from."\n"; // Return path for errors
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=iso-8859-1\n";
		
	$sentmail = mail($to, $subject, $email_message, $headers);
	//echo $to.",". $subject.",".$email_message.$headers;die;
	if($sentmail!=''){
	$status = "Send";
		return $status;
	}else{
		$status = "Not Send";
		return $status;
	}
}
function email_send_candidate_on_Manual_approve($candidateid,$leavtype){

	$empdetails = $this->employee_details($candidateid);
	$to=$empdetails['email_address'];
	$name=$empdetails['name'];
    $from = "tipintranet@dpsgs.org";
	$subject = "TIP-Manual Attendance Request - Approved";
	$email_message = '<html>
						<table cellspacing="0"   cellpadding="10" border="0"	align="center" style="border:5px #eeeeee solid; background:#f9f9f9; padding:20px; width:500px; margin:0 auto; font-family:cambria; font-size:14px; color:#444444;">
						  <tr>
						 <td>Dear '.$name.',</td></tr>
						 <tr>
						  <td>
						<p>Your  Manual Attendance request has been approved by your reporting manager.</p>

<p>For details, Login to TIP portal at http://tip.dpsgs.org >> My Page >> Attendance >> My Attendance </p>

						  </td></tr>
						  <tr>
							 <td><strong>Warm Wishes,<br/><br/>
							  Tip Team</strong></br>
							   </td>
						   </tr>
						  </table>	 
						  </html>';

	$headers  = "From: TIP Intranet  < ".$from." >\n";
    $headers .= "X-Sender: ".$from." < ".$from." >\n";
    $headers .= 'X-Mailer: PHP/' . phpversion();
    $headers .= "X-Priority: 1\n"; // Urgent message!
    $headers .= "Return-Path: ".$from."\n"; // Return path for errors
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=iso-8859-1\n";
		
	$sentmail = mail($to, $subject, $email_message, $headers);
	//echo $to.",". $subject.",".$email_message.$headers;die;
	if($sentmail!=''){
	$status = "Send";
		return $status;
	}else{
		$status = "Not Send";
		return $status;
	}
}
function email_send_candidate_on_Manual_rejaect($candidateid){

	$empdetails = $this->employee_details($candidateid);
	$to=$empdetails['email_address'];
	$name=$empdetails['name'];
    $from = "tipintranet@dpsgs.org";
	$subject = "TIP-Manual Attendance Request - Reject";
	$email_message = '<html>
						<table cellspacing="0"   cellpadding="10" border="0"	align="center" style="border:5px #eeeeee solid; background:#f9f9f9; padding:20px; width:500px; margin:0 auto; font-family:cambria; font-size:14px; color:#444444;">
						  <tr>
						 <td>Dear '.$name.',</td></tr>
						 <tr>
						  <td>
						 <p>Your  Manual Attendance request has been rejected by your reporting manager.</p>

<p>For details, Login to TIP portal at http://tip.dpsgs.org >> My Page >> Attendance >> My Attendance </p>

						  </td></tr>
						  <tr>
							 <td><strong>Warm Wishes,<br/><br/>
							  Tip Team</strong></br>
							   </td>
						   </tr>
						  </table>	 
						  </html>';

	$headers  = "From: TIP Intranet < ".$from." >\n";
    $headers .= "X-Sender: ".$from." < ".$from." >\n";
    $headers .= 'X-Mailer: PHP/' . phpversion();
    $headers .= "X-Priority: 1\n"; // Urgent message!
    $headers .= "Return-Path: ".$from."\n"; // Return path for errors
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=iso-8859-1\n";
		
	$sentmail = mail($to, $subject, $email_message, $headers);
	//echo $to.",". $subject.",".$email_message.$headers;die;
	if($sentmail!=''){
	$status = "Send";
		return $status;
	}else{
		$status = "Not Send";
		return $status;
	}
}
function email_send_responsible_on_rod_publish($candidateid){
	$empdetails = $this->employee_details($candidateid);
	$to=$empdetails['email_address'];
	$name=$empdetails['name'];
    $from = "tipintranet@dpsgs.org";
	$subject = "TIP-New RODs";
	$email_message = '<html>
						<table cellspacing="0"   cellpadding="10" border="0"	align="center" style="border:5px #eeeeee solid; background:#f9f9f9; padding:20px; width:500px; margin:0 auto; font-family:cambria; font-size:14px; color:#444444;">
						  <tr>
						 <td>Dear '.$name.',</td></tr>
						 <tr>
						  <td>
						 <p> There is new RODs created for you.<p>

						<p>For details, Login at TIP website. <a href="tip.teachersity.org">tip.teachersity.org</a></p>

						  </td></tr>
						  <tr>
							 <td><strong>Warm Wishes,<br/><br/>
							  Tip Team</strong></br>
							   </td>
						   </tr>
						  </table>	 
						  </html>';

	$headers  = "From: TIP Intranet < ".$from." >\n";
    $headers .= "X-Sender: ".$from." < ".$from." >\n";
    $headers .= 'X-Mailer: PHP/' . phpversion();
    $headers .= "X-Priority: 1\n"; // Urgent message!
    $headers .= "Return-Path: ".$from."\n"; // Return path for errors
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=iso-8859-1\n";
		
	//$sentmail = mail($to, $subject, $email_message, $headers);
	//echo $to.",". $subject.",".$email_message.$headers;die;
	if($sentmail!=''){
	$status = "Send";
		return $status;
	}else{
		$status = "Not Send";
		return $status;
	}
}
function email_send_CVCS_on_create($candidateid){
	$empdetails = $this->employee_details($candidateid);
	$to=$empdetails['email_address'];
	$name=$empdetails['name'];
    $from = "tipintranet@dpsgs.org";
	$subject = "TIP-New CVCS";
	$email_message = '<html>
						<table cellspacing="0"   cellpadding="10" border="0"	align="center" style="border:5px #eeeeee solid; background:#f9f9f9; padding:20px; width:500px; margin:0 auto; font-family:cambria; font-size:14px; color:#444444;">
						  <tr>
						 <td>Dear '.$name.',</td></tr>
						 <tr>
						  <td>
						 <p> There is new CVCS created .<p>

						<p>For details, Login at TIP website. <a href="tip.teachersity.org">tip.teachersity.org</a></p>

						  </td></tr>
						  <tr>
							 <td><strong>Warm Wishes,<br/><br/>
							  Tip Team</strong></br>
							   </td>
						   </tr>
						  </table>	 
						  </html>';

	$headers  = "From: TIP Intranet < ".$from." >\n";
    $headers .= "X-Sender: ".$from." < ".$from." >\n";
    $headers .= 'X-Mailer: PHP/' . phpversion();
    $headers .= "X-Priority: 1\n"; // Urgent message!
    $headers .= "Return-Path: ".$from."\n"; // Return path for errors
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=iso-8859-1\n";
		
	//$sentmail = mail($to, $subject, $email_message, $headers);
	//echo $to.",". $subject.",".$email_message.$headers;die;
	if($sentmail!=''){
	$status = "Send";
		return $status;
	}else{
		$status = "Not Send";
		return $status;
	}
}
function email_send_CVCS_on_status_change($candidateid, $status){
	$empdetails = $this->employee_details($candidateid);
	$to=$empdetails['email_address'];
	$name=$empdetails['name'];
    $from = "tipintranet@dpsgs.org";
	$subject = "TIP-New CVCS Status Change";
	$email_message = '<html>
						<table cellspacing="0"   cellpadding="10" border="0"	align="center" style="border:5px #eeeeee solid; background:#f9f9f9; padding:20px; width:500px; margin:0 auto; font-family:cambria; font-size:14px; color:#444444;">
						  <tr>
						 <td>Dear '.$name.',</td></tr>
						 <tr>
						  <td>
						 <p> Added CVCS has been '.$status.' .<p>

						<p>For details, Login at TIP website. <a href="tip.teachersity.org">tip.teachersity.org</a></p>

						  </td></tr>
						  <tr>
							 <td><strong>Warm Wishes,<br/><br/>
							  Tip Team</strong></br>
							   </td>
						   </tr>
						  </table>	 
						  </html>';

	$headers  = "From: TIP Intranet < ".$from." >\n";
    $headers .= "X-Sender: ".$from." < ".$from." >\n";
    $headers .= 'X-Mailer: PHP/' . phpversion();
    $headers .= "X-Priority: 1\n"; // Urgent message!
    $headers .= "Return-Path: ".$from."\n"; // Return path for errors
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=iso-8859-1\n";
		
	//$sentmail = mail($to, $subject, $email_message, $headers);
	//echo $to.",". $subject.",".$email_message.$headers;die;
	if($sentmail!=''){
	$status = "Send";
		return $status;
	}else{
		$status = "Not Send";
		return $status;
	}
}
function email_send_salery_hold_on_status_change($candidateid,$empid, $status){
	$empdetails = $this->employee_details($candidateid);
	
	$to=$empdetails['email_address'];
	$name=$empdetails['name'];
	$empdetailsfor = $this->employee_details($empid);
	$empname=$empdetailsfor['name'] ;
    $from = "tipintranet@dpsgs.org";
	$subject = "TIP-New CVCS Status Change";
	$email_message = '<html>
						<table cellspacing="0"   cellpadding="10" border="0"	align="center" style="border:5px #eeeeee solid; background:#f9f9f9; padding:20px; width:500px; margin:0 auto; font-family:cambria; font-size:14px; color:#444444;">
						  <tr>
						 <td>Dear '.$name.',</td></tr>
						 <tr>
						  <td>
						 <p> '.$empname.' Salary has been '.$status.' .<p>

						<p>For details, Login at TIP website. <a href="tip.teachersity.org">tip.teachersity.org</a></p>

						  </td></tr>
						  <tr>
							 <td><strong>Warm Wishes,<br/><br/>
							  Tip Team</strong></br>
							   </td>
						   </tr>
						  </table>	 
						  </html>';

	$headers  = "From: TIP Intranet < ".$from." >\n";
    $headers .= "X-Sender: ".$from." < ".$from." >\n";
    $headers .= 'X-Mailer: PHP/' . phpversion();
    $headers .= "X-Priority: 1\n"; // Urgent message!
    $headers .= "Return-Path: ".$from."\n"; // Return path for errors
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=iso-8859-1\n";
		
	//$sentmail = mail($to, $subject, $email_message, $headers);
	//echo $to.",". $subject.",".$email_message.$headers;die();
	if($sentmail!=''){
	$status = "Send";
		return $status;
	}else{
		$status = "Not Send";
		return $status;
	}
}
function email_send_on_password_change($candidateid,$pass){
	$empdetails = $this->employee_details($candidateid);
	$to=$empdetails['email_address'];
	$name=$empdetails['name'];
	
    $from = "tipintranet@dpsgs.org";
	$subject = "TIP-Password Changed";
	$email_message = '<html>
						<table cellspacing="0"   cellpadding="10" border="0"	align="center" style="border:5px #eeeeee solid; background:#f9f9f9; padding:20px; width:500px; margin:0 auto; font-family:cambria; font-size:14px; color:#444444;">
						  <tr>
						 <td>Dear '.$name.',</td></tr>
						 <tr>
						  <td>
						 <p> Your password has been changed.<p>
						<p> Your new password : '.$pass.'<p>
						<p>For details, Login at TIP website. <a href="tip.teachersity.org">tip.teachersity.org</a></p>

						  </td></tr>
						  <tr>
							 <td><strong>Warm Wishes,<br/><br/>
							  Tip Team</strong></br>
							   </td>
						   </tr>
						  </table>	 
						  </html>';

	$headers  = "From: TIP Intranet < ".$from." >\n";
    $headers .= "X-Sender: ".$from." < ".$from." >\n";
    $headers .= 'X-Mailer: PHP/' . phpversion();
    $headers .= "X-Priority: 1\n"; // Urgent message!
    $headers .= "Return-Path: ".$from."\n"; // Return path for errors
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=iso-8859-1\n";
		
	//$sentmail = mail($to, $subject, $email_message, $headers);
	//echo $to.",". $subject.",".$email_message.$headers;die;
	if($sentmail!=''){
	$status = "Send";
		return $status;
	}else{
		$status = "Not Send";
		return $status;
	}
}
function email_send_on_travel_request_create_candidate($candidateid){
	$empdetails = $this->employee_details($candidateid);
	$to=$empdetails['email_address'];
	$name=$empdetails['name'];
	
    $from = "tipintranet@dpsgs.org";
	$subject = "TIP-Travel Request";
	$email_message = '<html>
						<table cellspacing="0"   cellpadding="10" border="0"	align="center" style="border:5px #eeeeee solid; background:#f9f9f9; padding:20px; width:500px; margin:0 auto; font-family:cambria; font-size:14px; color:#444444;">
						  <tr>
						 <td>Dear '.$name.',</td></tr>
						 <tr>
						  <td>
						 <p> Your request has been created. Approval is in pending <p>
						
						<p>For details, Login at TIP website. <a href="tip.teachersity.org">tip.teachersity.org</a></p>

						  </td></tr>
						  <tr>
							 <td><strong>Warm Wishes,<br/><br/>
							  Tip Team</strong></br>
							   </td>
						   </tr>
						  </table>	 
						  </html>';

	$headers  = "From: TIP Intranet < ".$from." >\n";
    $headers .= "X-Sender: ".$from." < ".$from." >\n";
    $headers .= 'X-Mailer: PHP/' . phpversion();
    $headers .= "X-Priority: 1\n"; // Urgent message!
    $headers .= "Return-Path: ".$from."\n"; // Return path for errors
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=iso-8859-1\n";
		
	$sentmail = mail($to, $subject, $email_message, $headers);
	//echo $to.",". $subject.",".$email_message.$headers;die;
	if($sentmail!=''){
	$status = "Send";
		return $status;
	}else{
		$status = "Not Send";
		return $status;
	}
}
function email_send_on_travel_request_create_rm($rm,$candidateid){
	$empdetails = $this->employee_details($rm);
	$to=$empdetails['email_address'];
	$name=$empdetails['name'];
	$otheremp = $this->employee_details($candidateid);
	$othername=$otheremp['name'];
    $from = "tipintranet@dpsgs.org";
	$subject = "TIP-Travel Request";
	$email_message = '<html>
						<table cellspacing="0"   cellpadding="10" border="0"	align="center" style="border:5px #eeeeee solid; background:#f9f9f9; padding:20px; width:500px; margin:0 auto; font-family:cambria; font-size:14px; color:#444444;">
						  <tr>
						 <td>Dear '.$name.',</td></tr>
						 <tr>
						  <td>
						 <p> '.$othername.' has created request for travel. <p>
						
						<p>For details, Login at TIP website. <a href="tip.teachersity.org">tip.teachersity.org</a></p>

						  </td></tr>
						  <tr>
							 <td><strong>Warm Wishes,<br/><br/>
							  Tip Team</strong></br>
							   </td>
						   </tr>
						  </table>	 
						  </html>';

	$headers  = "From: TIP Intranet < ".$from." >\n";
    $headers .= "X-Sender: ".$from." < ".$from." >\n";
    $headers .= 'X-Mailer: PHP/' . phpversion();
    $headers .= "X-Priority: 1\n"; // Urgent message!
    $headers .= "Return-Path: ".$from."\n"; // Return path for errors
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=iso-8859-1\n";
		
	//$sentmail = mail($to, $subject, $email_message, $headers);
	//echo $to.",". $subject.",".$email_message.$headers;die;
	if($sentmail!=''){
	$status = "Send";
		return $status;
	}else{
		$status = "Not Send";
		return $status;
	}
}
function email_send_on_travel_request_status($rm,$candidateid,$status){
if($status=='0'){
$stat = 'in Pendding';
}elseif($status=='1'){
$stat = ' Accepted';
}elseif($status=='2'){
$stat = 'Rejected';
}
	$empdetails = $this->employee_details($rm);
	$to=$empdetails['email_address'];
	$name=$empdetails['name'];
	$otheremp = $this->employee_details($candidateid);
	$othername=$otheremp['name'];
    $from = "tipintranet@dpsgs.org";
	$subject = "TIP-Travel Request";
	$email_message = '<html>
						<table cellspacing="0"   cellpadding="10" border="0"	align="center" style="border:5px #eeeeee solid; background:#f9f9f9; padding:20px; width:500px; margin:0 auto; font-family:cambria; font-size:14px; color:#444444;">
						  <tr>
						 <td>Dear '.$name.',</td></tr>
						 <tr>
						  <td>
						 <p> '.$othername.' travel request has been '.$stat.'. <p>
						
						<p>For details, Login at TIP website. <a href="tip.teachersity.org">tip.teachersity.org</a></p>

						  </td></tr>
						  <tr>
							 <td><strong>Warm Wishes,<br/><br/>
							  Tip Team</strong></br>
							   </td>
						   </tr>
						  </table>	 
						  </html>';

	$headers  = "From: TIP Intranet < ".$from." >\n";
    $headers .= "X-Sender: ".$from." < ".$from." >\n";
    $headers .= 'X-Mailer: PHP/' . phpversion();
    $headers .= "X-Priority: 1\n"; // Urgent message!
    $headers .= "Return-Path: ".$from."\n"; // Return path for errors
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=iso-8859-1\n";
		
	//$sentmail = mail($to, $subject, $email_message, $headers);
	//echo $to.",". $subject.",".$email_message.$headers;die;
	if($sentmail!=''){
	$status = "Send";
		return $status;
	}else{
		$status = "Not Send";
		return $status;
	}
}
function employee_details($emp_id){
	$qry = mysql_query("select concat(t1.first_name,' ',t1.last_name) as name, t2.off_email_address as email_address from personal_detail as t1 inner join official_detail as t2 on t1.emp_id=t2.emp_id where t1.emp_id='".$emp_id."' limit 1");
	$res= mysql_fetch_array($qry); 
		return $res; 
	
}


}
$test_obj = new Email();
$test_obj->test();
?>