<?php
date_default_timezone_set('Asia/Calcutta'); 
include ('emailmailer/class.phpmailer.php');
include ('emailmailer/class.smtp.php');
$mail = new PHPMailer();
$mail->IsSMTP();
$mail->Mailer = 'smtp';
$mail->SMTPAuth = true;
$mail->Host = 'smtp.office365.com'; // "ssl://smtp.gmail.com" didn't worked
$mail->Port = 587;
$mail->SMTPSecure = 'tls';
$mail->Username = "noreply@selaqui.org";
$mail->Password = "Sisschool@12345";
$mail->IsHTML(true); // if you are going to send HTML formatted emails
$mail->SingleTo = false; // if you want to send a same email to multiple users. multiple emails will be sent one-by-one.
$mail->From = "noreply@selaqui.org";
$mail->FromName = "SelaQui International School";
$mail->SMTPDebug  = 1;//
mysql_connect("localhost", "sisschoo_selaquicrm", "sisschoo_selaquicrm") or die(mysql_error());
mysql_select_db("sisschoo_selaquicrm") or die(mysql_error());
if($_REQUEST['action']=='submit_form'){
   if(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
		$ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
    } elseif(!empty($_SERVER['REMOTE_ADDR'])) { 
		$ip = $_SERVER['REMOTE_ADDR']; 
	} else { 
		$ip="Not Set"; 
	}
	$date = date('Y-m-d H:i:s');
	$first_name=$_REQUEST['name'];
	$state=$_REQUEST['stateid'];
	$city=$_REQUEST['cityid'];
	$email=$_REQUEST['email_id'];
	$phone_no=$_REQUEST['mobile'];
	$message=$_REQUEST['comment'];
	$class_name=$_REQUEST['stu_class'];
	$utm_source=$_REQUEST['utm_source'];
	$utm_medium=$_REQUEST['utm_medium'];
	$utm_campaign=$_REQUEST['utm_campaign'];
	/*if($utm_source==''){
	  $v_type='Organic';  
	}else{
	  $v_type='Paid';    
	}*/
	$v_type='Landing Page';
	$msg=0;
	if($first_name!='' && $state!='' && $city!='' && $email!='' && $phone_no!='' && $message!='' && $class_name!='')
	{
        	$query = "INSERT INTO student (`stud_name`,`joined`,`emp_id`,`state`,`city`,`email`,`mobno`,`comment`,`grade`,`v_type`,`ip_address`,`utm_medium`,`utm_campaign`,`utm_location`,`utm_adgroup`)
                  VALUES('$first_name','$date','100100','$state','$city','$email','$phone_no','".mysql_real_escape_string($message)."','$class_name','$v_type','$ip','$utm_medium','$utm_campaign','$utm_source','$utm_source')";
                $result = mysql_query($query);
                if ($result == 1)
                {
                       
                       $mail->ClearAllRecipients() ;
                       $mail->addAddress($email,$first_name);
                       $mail->Subject = "Request a Call Back";
                       $mail->Body = '<html>
			<table cellspacing="0"   cellpadding="10" border="0"	align="center" style="border:5px #eeeeee solid; background:#f9f9f9; padding:20px; width:500px; margin:0 auto; font-family:cambria; font-size:14px; color:#444444;">
				<tr>
					<td>Dear Sir,</td>

				</tr>

				<tr>
					<td>
						<p>We have received your inquiry. Our Admissions Counsellor will get back to you soon.</a></strong>
						</p>
						
					</td>
				</tr>
				<tr>
					<td><strong>Warm Wishes,<br/><br/>
						SelaQui International School </strong></br>
					</td>
				</tr>
			</table>
		</html>';
		
		$to = $email;
         $subject = "Request a Call Back";
         
         $message = '<html>
			<table cellspacing="0"   cellpadding="10" border="0"	align="center" style="border:5px #eeeeee solid; background:#f9f9f9; padding:20px; width:500px; margin:0 auto; font-family:cambria; font-size:14px; color:#444444;">
				<tr>
					<td>Dear Sir,</td>

				</tr>

				<tr>
					<td>
						<p>We have received your inquiry. Our Admissions Counsellor will get back to you soon.</a></strong>
						</p>
						
					</td>
				</tr>
				<tr>
					<td><strong>Warm Wishes,<br/><br/>
						SelaQui International School </strong></br>
					</td>
				</tr>
			</table>
		</html>';
        
         
         $header = "From:noreply@selaqui.org \r\n";
         $header .= "MIME-Version: 1.0\r\n";
         $header .= "Content-type: text/html\r\n";
         $retval = mail ($to,$subject,$message,$header);

/*if(!$mail->Send()){
  $stm =  "Message was not sent <br />PHPMailer Error: " . $mail->ErrorInfo;
}else{
   $stm = "Message sent";
}*/
                        $msg=1;
                } 
                else 
                {
                    $msg=2;
                }
	    
	}
        else
        {
             $msg=3;
        }
        echo $msg;
    
    
}


?>