const eparichaya_authkey=document.getElementById("ePlugin_authkey").getAttribute("data-value");
const eparichayaurl = "https://www.eparichaya.com/api-module/";
const eppathurl1 = (window.location.origin+window.location.pathname);
const epremoveTag = 'title,base,link[rel="canonical"],meta[name="author"],meta[name="document-type"],meta[name="document-rating"],meta[name="robots"],meta[name="googlebot"],meta[name="Expires"],meta[name="coverage"],meta[name="distribution"],meta[name="rating"],meta[name="target"],meta[name="HandheldFriendly"],meta[http-equiv="content-language"],meta[name="Copyright"],meta[name="YahooSeeker"],meta[name="classification"],meta[name="allow-search"],meta[name="Content-Language"],meta[name="geo.region"],meta[name="address"],meta[name="twitter:card"],meta[name="twitter:card"],meta[name="twitter:description"],meta[name="twitter:title"],meta[property="twitter:image"],meta[name="twitter:site"],meta[name="twitter:domain"],meta[property="og:locale"],meta[property="og:type"],meta[property="og:title"],meta[property="og:image"],meta[property="og:description"],meta[property="og:url"],meta[name="keywords"],meta[name="description"],link[type="application/rss+xml"],link[rel="shortcut icon"]';
var epmainpopup = '';
var epmainpopup1=`<div class="ep-popup">
	<div class="ep-popup-content">
		<div>
			<h6>MAKE AN INQUIRY!</h6>
		</div>
		<a href="javascript:void(0)" class="ep-fade-out ep-main-btn-circle">╳</a>
		<form id="epenqform" autocomplete="off" method="post" action="#">
			<div class="ep-form-group">
				<input type="text" placeholder="Name..." id="ep-enq-name" name="name" required="">
			</div>
			<div class="ep-form-group">
				<input type="text" placeholder="Type mobile no..." id="ep-enq-phone" name="phone" required="">
			</div>
			<div class="ep-form-group">
				<span id="ep-form-err-msg"></span>
			</div>
			<button type="button" class="ep-main-btn-rect">Send</button>
		</form>
	</div>
</div>`;
var epmainpopup2=`<div class="epupdatesoverlay">
	<div class="epupdatespopup">
		<h2><a href="${window.location.origin}/updates.html" target="_blank">Latest Updates</a></h2>
		<a class="epupdatesclose" href="javascript:void(0)">&times;</a>
		<div class="epupdatescontent"></div>
	</div>
</div>`;
var epmainpopup3=`<ul class="eppopupicons">`;
	var epmainpopup4=`<li class="epshowpopup eptooltip"><a href="" id="epwhatsapp" target="_blank"><img src="${eparichayaurl}io-plugin/images/WhatsApp.png"> <span class="eptooltiptext eptexttips">WhatsApp</span></a></li>`;
	var epmainpopup5=`<li class="epshowpopup eptooltip"><a href="" id="epcall"><img src="${eparichayaurl}io-plugin/images/call.png"> <span class="eptooltiptext eptexttips">Call Now</span></a></li>`;
	var epmainpopup6=`<li class="epshowpopup eptooltip" id="epenquireform"><img src="${eparichayaurl}io-plugin/images/inqury.png"> <span class="eptooltiptext eptexttips">Enquire Now</span></li>`;
	var epmainpopup7=`<li class="epshowpopup eptooltip" id="eplocupdates"><img src="${eparichayaurl}io-plugin/images/updates.png"> <span class="eptooltiptext eptexttips">Updates</span></li>`;
	var epmainpopup8=`<li class="epdefaultpopup eptooltip"><img id="epdefaultimg" src="${eparichayaurl}io-plugin/images/chaticon.png"> <span class="eptooltiptext eptexttips">Contact Now</span></li>`;
var epmainpopup9=`</ul>`;

var epbtntype = "mouseover";
var isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
if (isMobile) {
    var epbtntype = "click";
}
var element = document.createElement('link');
element.type = 'text/css';
element.rel = 'stylesheet';
element.href = eparichayaurl+'io-plugin/css/addons.css';
document.getElementsByTagName("head")[0].appendChild(element);

function getUserData(){
    var epxhttp1 = new XMLHttpRequest();
    epxhttp1.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var epresponse1 = JSON.parse(this.response);
            if(epresponse1.status===0){
                if(epresponse1.postion=='1'){
                    document.getElementById('epmainpopup').classList.add("epmainpopupright");
                }
                if(epresponse1.services.updates==1){
                    epmainpopup+=epmainpopup2;
                }
                if(epresponse1.services.enqform==1){
                    epmainpopup+=epmainpopup1;
                }
                epmainpopup+=epmainpopup3;
                if(epresponse1.services.whatsappbtn==1){
                    epmainpopup+=epmainpopup4;
                }
                if(epresponse1.services.callbtn==1){
                    epmainpopup+=epmainpopup5;
                }
                if(epresponse1.services.enqform==1){
                    epmainpopup+=epmainpopup6;
                }
                if(epresponse1.services.updates==1){
                    epmainpopup+=epmainpopup7;
                }
                epmainpopup+=epmainpopup8;
                epmainpopup+=epmainpopup9;
                document.getElementById('epmainpopup').innerHTML = epmainpopup;
                var epdefaultimg = document.querySelector("#epdefaultimg");
                var eplocupdates = document.querySelector("#eplocupdates");
                var epupdatesoverlay = document.querySelector(".epupdatesoverlay");
                var epupdatesclose = document.querySelector(".epupdatesclose");
                
                var epdefaultpopup = document.querySelector(".epdefaultpopup");
                var epshowpopup = document.querySelectorAll(".epshowpopup");
                var eptexttips = document.querySelectorAll(".eptexttips");
                
                
                if(epresponse1.postion=='1'){
    				eptexttips.forEach(function(eptexttips1){
    				    eptexttips1.classList.remove('eptooltiptext');
    				    eptexttips1.classList.add('eptooltiptextright');
    				});
                }
                
                epdefaultpopup.addEventListener(epbtntype, function(){
                    document.querySelector('.epdefaultpopup.eptooltip .eptexttips').style.visibility = 'hidden';
                	epshowpopup.forEach((epshowpopup1)=>{
                		epshowpopup1.classList.add("active");
                	});
                	epdefaultimg.src = eparichayaurl+"io-plugin/images/close-button.png";
                });
                epdefaultimg.addEventListener("click", function(){
                	epshowpopup.forEach((epshowpopup1)=>{
                		epshowpopup1.classList.remove("active");
                	});
                	epdefaultimg.src = eparichayaurl+"io-plugin/images/chaticon.png";
                });
                
                if(epresponse1.services.callbtn==1){
                    generateCallLinkEp(epresponse1.data.mobile);
                }
                if(epresponse1.services.whatsappbtn==1){
                    generateWhatsAppLinkEp(epresponse1.data.mobile);
                }
                
                if(epresponse1.services.enqform==1){
                    generateEnqFormEp();
                }
                if(epresponse1.services.updates==1){
                    generateUpdatesPopupEp();
                    eplocupdates.addEventListener("click", function(){
                        epupdatesoverlay.classList.add('epupdateactive');
                    });
                    epupdatesclose.addEventListener("click", function(){
                        epupdatesoverlay.classList.remove('epupdateactive');
                    });
                }
            }else if(epresponse1.status===2){
                epmainpopup+=epmainpopup2;
                document.getElementById('epmainpopup').innerHTML = epmainpopup;
                generateUpdatesPopupEp();
            }
        }
    };
    epxhttp1.open("POST", eparichayaurl+"addons/getInfo", true);
    epxhttp1.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    epxhttp1.send("username="+eparichaya_authkey + "&sitepath=" + eppathurl1);
}
function generateWhatsAppLinkEp(mobilenumber){
    var epwhatsapp = document.querySelector("#epwhatsapp");
    var epwhatsappmsg = `https://api.whatsapp.com/send?phone=91${mobilenumber}&text=Hi,need more information about ${window.location.origin} Please contact me.`;
    epwhatsapp.setAttribute('href',epwhatsappmsg);
}
function generateCallLinkEp(mobilenumber){
    var epcall = document.querySelector("#epcall");
    epcall.setAttribute('href',`tel:${mobilenumber}`);
}
function generateEnqFormEp(){
    var eppopup = document.querySelector(".ep-popup");
    var epfadeout = document.querySelector(".ep-fade-out");
    var epenquireform = document.querySelector("#epenquireform");
    var epenquireformbtn = document.querySelector(".ep-main-btn-rect");
    var epenqname = document.querySelector("#ep-enq-name");
    var epenqphone = document.querySelector("#ep-enq-phone");
    var epformerrmsg = document.querySelector("#ep-form-err-msg");
    var epenqform = document.querySelector("#epenqform");
    epfadeout.addEventListener("click", function(){
    	eppopup.classList.remove("active");
    });
    epenquireform.addEventListener("click", function(){
    	eppopup.classList.add("active");
    });
    epenquireformbtn.addEventListener("click", function(){
    	epformerrmsg.innerHTML = "";
    	if(epenqname.value===""){
    		epformerrmsg.innerHTML = "Enter Name";
    	}else if(epenqphone.value===""){
    		epformerrmsg.innerHTML = "Enter Mobile";
    	}else if(epenqphone.value.length!="10"){
    		epformerrmsg.innerHTML = "Enter Valid 10 digit Mobile";
    	}else{
            var epxhttp2 = new XMLHttpRequest();
            epxhttp2.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    var epresponse2 = JSON.parse(this.response);
            		epformerrmsg.innerHTML = epresponse2.message;
            		if(epresponse2.status===0){
                		epenqform.reset();
                		setTimeout(function(){
                			epformerrmsg.innerHTML = "";
                			eppopup.classList.remove("active");
                		},3000);
            		}
                }
            };
            epxhttp2.open("POST", eparichayaurl+"addons/enquiryForm", true);
            epxhttp2.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            epxhttp2.send("username="+eparichaya_authkey+"&queryname="+epenqname.value+"&querymobile="+epenqphone.value);
    	}
    });
}

function generateUpdatesPopupEp(){
    var epupdatescontent = document.querySelector(".epupdatescontent");
    var epxhttp3 = new XMLHttpRequest();
    epxhttp3.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var epresponse3 = this.response;
            if(epresponse3!='0'){
                epupdatescontent.innerHTML = epresponse3;
            }else{
                eplocupdates.style.display = 'none';
            }
        }
    };
    epxhttp3.open("POST", eparichayaurl+"addons/getShortUpdates", true);
    epxhttp3.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    epxhttp3.send("username="+eparichaya_authkey + "&sitepath=" + eppathurl1);
}
function updtateSegment(){
    var epxhttp6 = new XMLHttpRequest();
    epxhttp6.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
        }
    };
    epxhttp6.open("POST", eparichayaurl+"siteplugin/updtateSegment", true);
    epxhttp6.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    epxhttp6.send("username="+eparichaya_authkey+"&sitepath=" + eppathurl1);
}

getUserData();