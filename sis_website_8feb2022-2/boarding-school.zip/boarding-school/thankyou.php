<!DOCTYPE html>
<html lang="en">
<head>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-4634742-2"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-4634742-2');
  gtag('config', 'AW-1040837567');
</script>
<!-- Event snippet for FI - Landing Page Lead Form conversion page -->
<script>
  gtag('event', 'conversion', {
      'send_to': 'AW-1040837567/-r8BCLWF9QEQv9en8AM',
      'value': 1.0,
      'currency': 'INR'
  });
</script>

<!-- Facebook Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '458914331510269');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=458914331510269&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->
<script>
  fbq('track', 'CompleteRegistration', {
    value: 1,
    currency: 'INR',
  });
</script>


<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SelaQui</title>
<link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico">
<!-- custom CSS -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/reset.css" rel="stylesheet">
<link href="css/thank_style.css" rel="stylesheet">
<link rel="stylesheet" href="js/3dSlider/3dGallery.css">
<link href="css/responsive.css" rel="stylesheet">
<link rel="stylesheet" href="css/carousel/owl.carousel.min.css">
<link rel="stylesheet" href="css/carousel/owl.theme.default.min.css">
<!-- TABS CSS START -->
<link rel="stylesheet" type="text/css" href="fonts/styles.css" />
<!-- Animate CSS START -->
<link rel="stylesheet" href="css/popup/magnific-popup.css">
<link href="css/animate.css" rel="stylesheet">
<link rel="stylesheet" href="js/form/validationEngine.jquery.css" />
<!-- FONTS AWSMA FONTS -->
<link rel="stylesheet" href="fonts/fonticon/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet"> 
<link href="https://fonts.googleapis.com/css?family=Poppins:700&display=swap" rel="stylesheet"> 


<script src="js/jquery.min.js"></script>

<script>
var code = Math.floor(100000 + Math.random() * 900000);
jQuery(document).ready(function()
{
	jQuery("#phone").change(function()
	{
		var phone = jQuery("#phone").val();
		
		//alert(code);
	    $.ajax({
            type : 'POST',
            url : 'smsCode.php',
			crossDomain: true,
			dataType: 'json',
			
            data: {
                phone : phone,
				code : code
            },
            success : function(data){
				
            }
        });
		
		jQuery("#otp").show('fast');
   });
});

function verify_mobile(form)
{
	var otpField = jQuery('#otp').val();
	
	if(otpField == code)
	{
		return true;
	}
	if(otpField != code)
	{
		alert('OTP did not match');
		return false;
	}
}
</script>
<script>
window.addEventListener('load', function() {
	url = new URL(window.location.href);
	var campaign_name = url.searchParams.get("utm_campaign");
	var keyword = url.searchParams.get("utm_keyword");
	var source = url.searchParams.get("utm_source");
	var network = url.searchParams.get("utm_network");
	document.getElementById("campaign_url").value = window.location.href;
	document.getElementById("campaign_name").value = campaign_name;
	document.getElementById("keyword").value = keyword;
	document.getElementById("sourceId").value = source;
	document.getElementById("network").value = network;
	
	if (document.referrer)
	{
		var myReferer = document.referrer;
		document.getElementById("referrerid").value = myReferer;
	}
	else
	{
		document.getElementById("referrerid").value = 'None';
	}
})

//alert(window.location.href);
/*function gcaptchaValidation()
{
	var response = grecaptcha.getResponse();
	if(response.length == 0)
	{
	   alert('Captcha must be validated.');
	   return false;
	}
	else
	{
		return true;
	}
}*/
</script>
</head>
<body>
<header id="header" class="header">
    <div class="headertop">
		<div class="container" style="text-align:center; padding:20px;">
			<div class="col-sm-12 col-xs-12 logo">
				<a href="index.html"><img src="images/logo.png" alt="" /></a>
			</div>
		</div>
	</div>
</header>

<!-- Hero section start (Slider) -->
<section class="container-fluid hero-section" style="position: relative;">
    <div class="row">
        <div id="heroo" class="owl-carousel owl-theme" style="opacity:0.5;">
            <!-- Slide item #1-->
            <div class="item hero-section-slide bc-img01"></div>
        </div>
    </div>
	<div class="container">
    <div class="dsu-intro" style="left:0;">
        <div id="inner">
            <div class="col-sm-12 nopd leftsec_content">
                <div class="dsu-addmission" style="width:100%;">
                    <div class="banner-heading text-center" style="font-family:arial;text-align:center; line-height:50px;">
                        <h1 class="wow fadeInUp thank" data-wow-delay="0.1s">Thank you for your enquiry.<br> Someone from our team<br>
 will be in touch with you shortly.</h1>
 <br>
 
 
						<a href="index.html" class="btn btn-success" style=" background:#b11016; color:#ffffff; padding:10px 20px;">Back to Home</a>
                         </div>

 
                </div>
            </div>
            
        </div>
    </div>
	</div>
</section>


<a href="#" id="back-top" title="Back To Top"></a>

<!--<script src="js/jquery.min.js"></script>-->
<script src="js/bootstrap.min.js"></script>
<script src="js/wow.min.js"></script>  
<script src="css/popup/jquery.magnific-popup.min.js"></script>
<script src="js/form/jquery.validationEngine.js"></script>
<script src="js/form/jquery.validationEngine-en.js"></script>
<script src="js/form/script.js"></script>
<script src="js/form/state.js"></script>
<!-- Silder Owl Carousel JS -->
<script type="text/javascript" src="css/carousel/owl.carousel.min.js"></script>
<!-- counting js satrt -->
<script src="css/counting/jquery.inview.min.js"></script>
<script src="css/counting/main.js"></script>
<script src="js/custom.js"></script>
<script src="js/3dSlider/3dGallery.js"></script>
<script type="text/javascript">
$('a[href^="#applyBox"]').on('click', function(event) {
    var target = $(this.getAttribute('href'));
    if( target.length ) {
        event.preventDefault();
        $('html, body').stop().animate({
            scrollTop: target.offset().top
        }, 1000);
    }
});
</script>
</body>
</html>