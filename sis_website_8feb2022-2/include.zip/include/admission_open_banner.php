<h2 class="subscribe-title">Admissions Open</h2>
<p class="wow fadeInDown" data-wow-delay="0.2s">For Class V To IX & XI Session 2022-23
</p>

<form class="text-center">      
<a href="https://www.selaqui.org/registration-form.php" class="btn btn-common">
Apply Now
</a>
</form>