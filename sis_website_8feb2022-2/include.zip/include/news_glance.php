<? //session_start();
include('include/db.php'); ?>
<div class="team-item wow fadeInUp" data-wow-delay="0.2s">
    
<div class="team-img">
    <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FSelaQuiIntlSchool&tabs=timeline&width=240&height=330&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="240" height="330" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe>
<!--<div class="panel panel-default wow fadeInLeft" data-wow-delay="0.3s">
    
<div class="panel-heading"> <span class="glyphicon glyphicon-list-alt"></span><b>News at a Glance</b></div>
<div class="panel-body">
<div id="nt-example1-container">						
<ul id="nt-example1">
<?php 
	$res=mysql_query("select * from sela_tblnews order by id desc limit 0,5 ");
	$i=1;
	while($re=mysql_fetch_array($res)){
?>
<li><p><img src="webadmin/upload/<?php echo $re['eFile']; ?>" alt="<?php echo ucwords(strtolower(strip_tags($re['heading']))); ?>" data-toggle="tooltip" title="<?php echo ucwords(strtolower($re['heading'])); ?>" width="60" class="img-fluid"><a href="news-at-a-glance.php"><?php echo $re['heading']; ?></a></p></li>
<? } ?>
</ul>
<i class="fa fa-arrow-down" id="nt-example1-next"></i><i class="fa fa-arrow-up" id="nt-example1-prev"></i>
</div>
</div>
<div class="panel-footer"> </div>
</div>-->

</div>              
</div>