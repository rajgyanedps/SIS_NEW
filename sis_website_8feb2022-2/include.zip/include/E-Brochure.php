<div class="team-item wow fadeInUp" data-wow-delay="0.2s">
<div class="team-img">
<div class="blog-item">
<div class="blog-image">
<a href="https://www.selaqui.org/Download/sis-brochure.pdf" target="_blank">
<img class="img-fluid" src="assets/images/e-brochure.jpg" alt="Download E-Brochure">
</a>
</div>
<div class="descr">
<div class="tag"><a href="https://www.selaqui.org/Download/sis-brochure.pdf" target="_blank">Download</a></div>
<h3 class="title">
<a href="https://www.selaqui.org/Download/sis-brochure.pdf" target="_blank">
E-Brochure
</a>
</h3>                
</div>
</div>
</div>
</div>