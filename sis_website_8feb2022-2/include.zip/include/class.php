<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-4634742-2" defer></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-4634742-2');
  gtag('config', 'AW-1040837567');
</script>


<?php
    $host  = $_SERVER['HTTP_HOST'];
	if($host == 'localhost'){
		$tp_name = 'http'; 
	}else{
		$tp_name = 'https';
	}
	$host_upper = strtoupper($host);
	$path   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
	$baseurl = "$tp_name://" . $host . $path . "/";
    if(!function_exists('getCurrentPageURL')){
    function getCurrentPageURL($type){
    $uri      = $_SERVER['REQUEST_URI'];
    $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
	$base_url      = $protocol . $_SERVER['HTTP_HOST'].'/';
	$url      = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
	$query    = $_SERVER['QUERY_STRING'];
	if ($type == 'query') {
					return $query; // Outputs: Query String
	} else if ($type == 'uri') {
					return $uri; // Outputs: URI    
	} else if ($type == 'url') {
					return $url; // Outputs: Full URL    
	} else if ($type == 'base_url') {
					return $base_url; // Outputs: Full URL    
	} else if ($type == 'title') {
		$ext = pathinfo($uri);
		$filename =  ucwords(str_replace("-"," ",$ext['filename']));
		return $filename; // Outputs: Full URL    
	}
}
}
?>
<link rel="stylesheet" type="text/css" media="wait" onload="if(media!='all')media='all'" href="<?=$baseurl;?>assets/css/bootstrap-reboot.min.css" >
<noscript><link rel="stylesheet" href="<?=$baseurl;?>assets/css/bootstrap-reboot.min.css"></noscript>
<link rel="stylesheet" type="text/css" media="all" href="<?=$baseurl;?>assets/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" media="wait" onload="if(media!='all')media='all'" href="<?=$baseurl;?>assets/css/bootstrap-theme.min.css">
<noscript><link rel="stylesheet" href="<?=$baseurl;?>assets/css/bootstrap-theme.min.css"></noscript>
<link rel="stylesheet" type="text/css" media="wait" onload="if(media!='all')media='all'" href="<?=$baseurl;?>assets/fonts/line-icons.css">
<noscript><link rel="stylesheet" href="<?=$baseurl;?>assets/fonts/line-icons.css"></noscript>
<link rel="stylesheet" type="text/css" media="wait" onload="if(media!='all')media='all'" href="<?=$baseurl;?>assets/font-awesome-4.7.0/css/font-awesome.min.css">
<noscript><link rel="stylesheet" href="<?=$baseurl;?>assets/font-awesome-4.7.0/css/font-awesome.min.css"></noscript>
<link rel="stylesheet" type="text/css" media="wait" onload="if(media!='all')media='all'" href="<?=$baseurl;?>assets/css/slicknav.css">
<noscript><link rel="stylesheet" href="<?=$baseurl;?>assets/css/slicknav.css"></noscript>
<link rel="stylesheet" type="text/css" media="wait" onload="if(media!='all')media='all'" href="<?=$baseurl;?>assets/css/nivo-lightbox.css" >
<noscript><link rel="stylesheet" href="<?=$baseurl;?>assets/css/nivo-lightbox.css"></noscript>
<link rel="stylesheet" type="text/css" media="wait" onload="if(media!='all')media='all'" href="<?=$baseurl;?>assets/css/animate.css">
<noscript><link rel="stylesheet" href="<?=$baseurl;?>assets/css/animate.css"></noscript>
<link rel="stylesheet" type="text/css" media="all" href="<?=$baseurl;?>assets/css/main.css" >
<link rel="stylesheet" type="text/css" media="all" href="<?=$baseurl;?>assets/css/menu.css">
<link rel="stylesheet" type="text/css" media="wait" onload="if(media!='all')media='all'" href="<?=$baseurl;?>assets/css/slider-form.css">
<noscript><link rel="stylesheet" href="<?=$baseurl;?>assets/css/slider-form.css"></noscript>
<link rel="stylesheet" type="text/css" media="wait" onload="if(media!='all')media='all'" href="<?=$baseurl;?>assets/css/news-scroller.css">
<noscript><link rel="stylesheet" href="<?=$baseurl;?>assets/css/news-scroller.css"></noscript>
<link rel="stylesheet" type="text/css" media="wait" onload="if(media!='all')media='all'" href="<?=$baseurl;?>assets/js/upload/upload.css">
<noscript><link rel="stylesheet" href="<?=$baseurl;?>assets/js/upload/upload.css"></noscript>
<link rel="stylesheet" type="text/css" media="wait" onload="if(media!='all')media='all'" href="<?=$baseurl;?>assets/js/owlcarousel/assets/owl.carousel.min.css">
<noscript><link rel="stylesheet" href="<?=$baseurl;?>assets/js/owlcarousel/assets/owl.carousel.min.css"></noscript>
<link rel="stylesheet" type="text/css" media="wait" onload="if(media!='all')media='all'" href="<?=$baseurl;?>assets/js/owlcarousel/assets/owl.theme.default.min.css">
<noscript><link rel="stylesheet" href="<?=$baseurl;?>assets/js/owlcarousel/assets/owl.theme.default.min.css"></noscript>
<link rel="stylesheet" type="text/css" media="wait" onload="if(media!='all')media='all'" href="<?=$baseurl;?>assets/css/ie.css">
<noscript><link rel="stylesheet" href="<?=$baseurl;?>assets/css/ie.css"></noscript>

<link rel="stylesheet" media="all" href="<?=$baseurl;?>assets/css/popup.css">

<link rel="stylesheet" type="text/css" media="wait" onload="if(media!='all')media='all'" href="<?=$baseurl;?>assets/css/responsive.css">
<noscript><link rel="stylesheet" href="<?=$baseurl;?>assets/css/responsive.css"></noscript>
<script type="text/javascript">
function OpenPopUP() {
      document.getElementById('light').style.display = 'block';
      return false;
    }
function ClosePopUP() {
      document.getElementById('light').style.display = 'none';
      return false;
    }
</script>




<script type="text/javascript">
(function(a,e,c,f,g,h,b,d){var k={ak:"1040837567",cl:"6oGYCPvzkG0Qv9en8AM",autoreplace:"7669040404"};a[c]=a[c]||function(){(a[c].q=a[c].q||[]).push(arguments)};a[g]||(a[g]=k.ak);b=e.createElement(h);b.async=1;b.src="//www.gstatic.com/wcm/loader.js";d=e.getElementsByTagName(h)[0];d.parentNode.insertBefore(b,d);a[f]=function(b,d,e){a[c](2,b,k,d,null,new Date,e)};a[f]()})(window,document,"_googWcmImpl","_googWcmGet","_googWcmAk","script");
</script>

<!--Start of Zopim Live Chat Script--> 
<!--<script type="text/javascript">
window.$zopim||(function(d,s){var z=$zopim=function(c){z._.push(c)},$=z.s=
d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
_.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute('charset','utf-8');
$.src='//v2.zopim.com/?1pgIKNlSVJJtIMmVCFmBLbrodeE4XEFM';z.t=+new Date;$.
type='text/javascript';e.parentNode.insertBefore($,e)})(document,'script');
</script>-->
<!--End of Zopim Live Chat Script-->

<?php if(getCurrentPageURL('uri')<>'/'): ?>
<script type="application/ld+json">
{
  "@context": "https://schema.org/", 
  "@type": "BreadcrumbList", 
  "itemListElement": [
	  {
		"@type": "ListItem", 
		"position": 1, 
		"name": "Home",
		"item": "<?php echo getCurrentPageURL('base_url'); ?>"  
	  },
	  {
		"@type": "ListItem", 
		"position": 2, 
		"name": "<?php echo getCurrentPageURL('title'); ?>",
		"item": "<?php echo getCurrentPageURL('url'); ?>"  
	  }
  ]
}
</script>
<?php endif; ?>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "School",
  "name": "SelaQui International School",
  "url": "<?php echo getCurrentPageURL('base_url'); ?>",
  "sameAs": [
    "https://www.facebook.com/SelaQuiIntlSchool",
    "https://in.pinterest.com/selaquidehradun/",
    "https://www.linkedin.com/school/selaqui-international-school/about/",
    "https://twitter.com/SelaqIntlSchool",
    "https://en.wikipedia.org/wiki/SelaQui_International_School",
    "https://www.youtube.com/channel/UClITON3SEr-qyG9MlZOkiQw"
  ]
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "School",
  "url": "<?php echo getCurrentPageURL('base_url'); ?>",
  "logo": "<?php echo getCurrentPageURL('base_url'); ?>assets/images/sis_logo_test.png"
}
</script>

<script type="application/ld+json">
{
   "@context":{
      "@vocab":"http://schema.org/"
   },
   "@graph":[
      {
         "@id":"<?php echo getCurrentPageURL('base_url'); ?>",
         "@type":"School",
         "name":"SelaQui International School",
         "url":"<?php echo getCurrentPageURL('base_url'); ?>",
         "logo":"<?php echo getCurrentPageURL('base_url'); ?>assets/images/sis_logo_test.png",
         "sameAs":[
            "https://www.facebook.com/SelaQuiIntlSchool",
            "https://in.pinterest.com/selaquidehradun/",
            "https://www.linkedin.com/school/selaqui-international-school/about/",
            "https://twitter.com/SelaqIntlSchool",
            "https://en.wikipedia.org/wiki/SelaQui_International_School",
            "https://www.youtube.com/channel/UClITON3SEr-qyG9MlZOkiQw"
         ]
      },
      {
         "@type":"School",
         "parentOrganization":{
            "name":"School Campus"
         },
         "name":"SelaQui International School",
         "image":"<?php echo getCurrentPageURL('base_url'); ?>assets/images/sis_logo_test.png",
         "address":{
            "@type":"PostalAddress",
            "addressLocality":"Dehradun",
            "addressRegion":"Uttarakhand",
            "postalCode":"248011",
            "addressCountry":"India",
            "streetAddress":"Chakarata Rd, Selaqui Industrial Area"
         },
         "contactPoint":[
            {
               "@type":"ContactPoint",
               "telephone":"+91 7253051000",
               "email":"selaqui@selaqui.org",
               "faxNumber":"+91 135 3051399",
               "contactType":"customer service",
               "areaServed":"India",
			   "hoursAvailable":["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday", "09:00-17:00"]
            }
         ]
      },
      {
         "@type":"School",
         "parentOrganization":{
            "name":"Delhi Office"
         },
         "name":"SelaQui International School",
         "image":"<?php echo getCurrentPageURL('base_url'); ?>assets/images/sis_logo_test.png",
         "address":{
            "@type":"PostalAddress",
            "addressLocality":"New Delhi",
            "addressRegion":"Delhi",
            "postalCode":"110017",
            "addressCountry":"India",
            "streetAddress":"A-Block, 3rd Floor, MGF Metropolitan Mall, District Centre Saket"
         },
         "contactPoint":[
            {
               "@type":"ContactPoint",
               "telephone":"+91 11 47342000",
               "email":"selaqui@selaqui.org",
               "faxNumber":"+91 11 47342099",
               "contactType":"customer service",
               "areaServed":"India",
			   "hoursAvailable":["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday", "09:00-17:00"]
            }
         ]
      }
  ]
}
</script>