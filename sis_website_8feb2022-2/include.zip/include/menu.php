<nav class="navbar fixed-top scrolling-navbar">
   <div id="Header_top_links">
      <div class="container-fluid">
         <div class="Header_top_links_box pull-right text-right">
            <ul>
               <li><a href="https://www.selaqui.org/blog/" target="_blank">BLOG</a></li>
               <li class="mhide"><a href="<?=$baseurl;?>Gallery/gallery.asp" target="_blank">GALLERY</a></li>
               <!--<li class="mhide"><a href="https://110.172.155.195/" target="_blank">LOGIN</a></li>-->
               <li><a class="mhide" href="<?=$baseurl;?>school-career-opportunities.php">CAREER</a></li>
               <li><a class="mhide" href="<?=$baseurl;?>sitemap.php">SITEMAP</a></li>
               <li><a class="mhide" href="<?=$baseurl;?>faq.php">FAQ's</a></li>
               <li>
                  <a href="<?=$baseurl;?>alumni.php">
                     ALUMNI <!--<img src="<?=$baseurl;?>assets/images/new2.gif" alt="New Info"/>-->
                  </a>
               </li>
               <li>
                  <a href="https://alumni.mindler.com/selaqui" target="_blank">
                     MINDLER ALUMNI LOGIN<!--<img src="<?=$baseurl;?>assets/images/new2.gif" alt="New Info"/>-->
                  </a>
               </li>
               <!--<li>
                  <a href="<?=$baseurl;?>Download/Calender.pdf" target="_blank">AUTUMN CALENDAR</a> <img src="<?=$baseurl;?>assets/images/new2.gif" alt="New Info"/>
               </li>-->
               <li><a href="<?=$baseurl;?>online-fee-payment.php" style="font-size:14px; color:#FF0;"><strong>ONLINE FEE PAYMENT</strong></a></li>
               <li><a href="<?=$baseurl;?>cbse-result-2021.php"><strong>CBSE XII RESULT 2021</strong> <img src="<?=$baseurl;?>assets/images/new2.gif" alt="New Info"  /></a></li>
               <li><a href="<?=$baseurl;?>cbse-10th-result-2021.php" style="border:none; padding-right:0px;"><strong>CBSE X RESULT 2021</strong> <img src="<?=$baseurl;?>assets/images/new2.gif" alt="New Info"  /></a></li>
               <!--<li><a href="<?=$baseurl;?>holiday-homework-2021.php" style="border:none; padding-right:0px;"><strong>HOLIDAY HOMEWORK 2021</strong> <img src="<?=$baseurl;?>assets/images/new2.gif" alt="New Info"  /></a></li>
               <li><a class="mhide" href="<?=$baseurl;?>Download/founders_day_2016.pdf" style="border:none; color:#FF0;" target="_blank"><strong>FOUNDER'S DAY 2016</strong></a> <img src="<?=$baseurl;?>images/new2.gif" alt="New Info"  /></li>-->
            </ul>
         </div>
      </div>
      <p></p>
   </div>
   <div class="navbar-collapse" id="main-navbar">
      <div class="menu-con">
         <div class="container-fluid">
            <div id='cssmenu'>
               <ul>
                  <li><a href='<?=$baseurl;?>'>Home</a></li>
                  <li class='has-sub'>
                     <a href='#'>About the School</a>
                     <ul>
                        <li><a href="<?=$baseurl;?>cbse-residential-schools-dehradun-india.php">About <strong class='goudy'>SelaQui</strong> </a></li>
                        <li><a href="<?=$baseurl;?>school-vision-mission.php">Vision & Mission</a></li>
                        <li><a href="<?=$baseurl;?>school-headmaster-message.php">Headmaster's Welcome</a></li>
                        <!--<li><a href="<?=$baseurl;?>selaqui-boarding-school-dehradun-faculty.php ">Faculty</a></li>-->
                        <li><a href="<?=$baseurl;?>code-policy.php">Code & Policies</a></li>
                        <li><a href="<?=$baseurl;?>school-career-opportunities.php">Careers at <strong class='goudy'>SelaQui</strong></a></li>
                        <li><a href="<?=$baseurl;?>testimonials.php">Testimonials</a></li>
                     </ul>
                  </li>
                  <li>
                     <a href='#'>Academics</a>
                     <ul>
                        <li><a href='<?=$baseurl;?>cbse-boarding-school-curriculum.php'><span>Curriculum</span></a></li>
                        <li><a href='<?=$baseurl;?>learning.php'><span>Approach to Learning</span></a></li>
                        <!--  <li><a href='<?=$baseurl;?>resonance-gurukul-program.php'><span>Integrated 2 Year IIT/Medical Program</span></a></li>-->
                       
                        
                        <li class='has-sub'>
                           <a href='#'><span>Career Counselling</span></a>
                           <ul>
                              <li><a href='<?=$baseurl;?>career-counselling.php'><span>Career Information</span></a></li>
                              
                              <li class='last'><a href='https://www.mindler.com/schools/selaqui' target="_blank"><span>Mindler Career Counselling</span></a></li>
                           </ul>
                        </li>
                        
                        <li><a href='<?=$baseurl;?>e-granthalaya.php'><span>E-Granthalaya</span></a></li>
                     </ul>
                  </li>
                  <li>
                     <a href='#'>Governing Body</a>
                     <ul>
                        <li ><a href='<?=$baseurl;?>chairman-message.php'><span>Chairman's Message </span></a></li>
                        <li><a href='<?=$baseurl;?>school-governors.php'><span>Board of Governors</span></a></li>
                        <li><a href='<?=$baseurl;?>about-headmaster.php'><span>About Headmaster</span></a></li>
                     </ul>
                  </li>
                  <li>
                     <a href='#'>Sports &amp; Activities</a>
                     <ul>
                        
                        <li><a href='qmun-22.php'><span>QMUN-22</span></a></li>
                        <li><a href='<?=$baseurl;?>outreach.php'><span>Outreach Programme</span></a></li>
                        <li><a href='<?=$baseurl;?>sports-overview.php'><span>Sports Overview</span></a></li>
                        <!--<li ><a href='<?=$baseurl;?>arjuna-program.php'><span>Arjuna Program</span></a> </li>-->
                        <li class='has-sub '>
                           <a href='#'><span>Student Leadership </span></a>
                           <ul>
                              <li><a href='<?=$baseurl;?>overview.php'><span>Overview </span></a></li>
                              <li><a href='<?=$baseurl;?>school-council.php' ><span>School Council</span></a></li>
                              <li><a href='<?=$baseurl;?>prefect-council.php' ><span>Prefect's Council</span></a></li>
                              <li><a href='<?=$baseurl;?>liabrary-council.php'  ><span>Library Council </span></a></li>
                              <li><a href='<?=$baseurl;?>disciplinary-committee.php' ><span>Disciplinary Committee </span></a></li>
                              <li><a href='<?=$baseurl;?>food-council.php'  ><span>Food Council</span></a></li>
                              <li class='last'><a href='<?=$baseurl;?>house-council.php'><span>House Council</span></a></li>
                           </ul>
                        </li>
                        <li><a href='<?=$baseurl;?>residential-school-activities.php'><span>Activities</span></a> </li>
                        <li><a href='<?=$baseurl;?>trinity-college-speech-drama.php'><span> TCSD</span></a></li>
                        <li><a href='<?=$baseurl;?>international-award-for-young-people.php'><span>IAYP</span></a></li>
                        <li><a href='<?=$baseurl;?>international-school-award.php'><span>International School Award</span></a></li>
                        <!--<li><a href='<?=$baseurl;?>qmun18.php'><span>QMUN-18</span></a></li>-->
                        <li><a href='<?=$baseurl;?>qsd-21.php'><span>QSD-21</span></a></li>
                     </ul>
                  </li>
                  <li>
                     <a href='#'>Downloads</a>
                     <ul>
                        <!--<li><a href='<?=$baseurl;?>Download/founders_day_2016.pdf' target="_blank"><span>Founder's Day 2016</span></a></li>-->
                        <li><a href='<?=$baseurl;?>Download/sis-brochure.pdf' target="_blank"><span>E-Brochure</span></a></li>
                        <li><a href='<?=$baseurl;?>Download/SIS-YR-BK-2020_FOR-WEB.pdf' target="_blank"><span>Year Book 2020</span></a></li>
                        <li><a href='<?=$baseurl;?>old-yearbooks.php'><span>Old Year Books</span></a></li>
                        
                        <!--<li class='has-sub '>
                           <a href="#"><span> Calendar</span></a>
                           <ul>
                              <li><a href='<?=$baseurl;?>Download/school_calendar_2016_17.pdf' target="_blank"><span> School Calendar</span></a></li>
                                 <li><a href='<?=$baseurl;?>Download/Feb_2017.pdf' target="_blank"><span> February Calendar</span></a></li>
                                 <li><a href='<?=$baseurl;?>Download/spring_calender_2017.pdf' target="_blank"><span> Spring Calendar</span></a></li>
                              <li><a href='<?=$baseurl;?>Download/Calender.pdf' target="_blank"><span> Autumn Calendar</span></a></li>
                           </ul>
                        </li>-->
                        <li><a href='<?=$baseurl;?>newsletter.php' ><span> Newsletter</span></a></li>
                        <li><a href='<?=$baseurl;?>dispersal.php' ><span>Dispersal / Travel Arrangement</span></a></li>
                        <li class='last'><a href='#' ><span>Results</span></a>
                         <ul>
                         <li><a href="<?=$baseurl;?>cbse-result-2021.php"><strong>CBSE XII RESULT 2021</strong></a></li>
               <li><a href="<?=$baseurl;?>cbse-10th-result-2021.php" style="border:none; padding-right:0px;"><strong>CBSE X RESULT 2021</strong></a></li>
                        </ul>
                        </li>
                        <li><a href='<?=$baseurl;?>downloads.php'><span>Forms</span></a></li>
                        <!--<li class='has-sub'><a href='#'>Holiday Home Work</a>
                           <ul>
                           <li><a href="<?=$baseurl;?>download/WINTER HHW-DEC 2016-CLASS 6.pdf" target="_blank"><span>&nbsp;</span>Class VI</a></li>
                           <li><a href="<?=$baseurl;?>download/WINTER HHW-DEC 2016-CLASS 7.pdf" target="_blank"><span>&nbsp;</span>Class VII</a></li>
                           <li><a href="<?=$baseurl;?>download/WINTER HHW-DEC 2016-CLASS 8.pdf" target="_blank"><span>&nbsp;</span>Class VIII</a></li>
                           <li><a href="<?=$baseurl;?>download/WINTER HHW-DEC 2016-CLASS 9.pdf" target="_blank"><span>&nbsp;</span>Class IX</a></li>
                           <li><a href="<?=$baseurl;?>download/WINTER HHW-DEC 2016-CLASS 10.pdf" target="_blank"><span>&nbsp;</span>Class X</a></li>
                           <li><a href="<?=$baseurl;?>download/OTBA 2017-THEME 1&2-ENG-CLASS IX.pdf" target="_blank"><span>&nbsp;</span>OTBA 2017-THEME 1&2-ENG-CLASS IX</a></li>
                           <li><a href="<?=$baseurl;?>download/OTBA 2017-THEME 1&2-HINDI-CLASS IX.pdf" target="_blank"><span>&nbsp;</span>OTBA 2017-THEME 1&2-HINDI-CLASS IX</a></li>
                           <li><a href="<?=$baseurl;?>download/OTBA 2017-THEME 1&2-MATH-CLASS IX.pdf" target="_blank"><span>&nbsp;</span>OTBA 2017-THEME 1&2-MATH-CLASS IX</a></li>
                           <li><a href="<?=$baseurl;?>download/OTBA 2017-THEME 1&2-SCI-CLASS IX.pdf" target="_blank"><span>&nbsp;</span>OTBA 2017-THEME 1&2-SCI-CLASS IX</a></li>
                           <li><a href="<?=$baseurl;?>download/OTBA 2017-THEME 1&2-SST-CLASS IX.pdf" target="_blank"><span>&nbsp;</span>OTBA 2017-THEME 1&2-SST-CLASS IX</a></li>
                           <li><a href="<?=$baseurl;?>download/1-Quadratic Equations.pdf" target="_blank"><span>&nbsp;</span>1-Quadratic Equations</a></li>
                           <li><a href="<?=$baseurl;?>download/2-Probability.pdf" target="_blank"><span>&nbsp;</span>2-Probability</a></li>
                           <li><a href="<?=$baseurl;?>download/3-Arithmetic Progression.pdf" target="_blank"><span>&nbsp;</span>3-Arithmetic Progression</a></li>
                           <li><a href="<?=$baseurl;?>download/4-Heights & Distances.pdf" target="_blank"><span>&nbsp;</span>4-Heights & Distances</a></li>
                           </ul>
                           </li>-->
                        <li><a href='<?=$baseurl;?>transfer-certificate.php'><span>Transfer Certificate</span></a></li>
                     </ul>
                  </li>
                  <li>
                     <a href='#'>Pastoral System</a>
                     <ul>
                        <li ><a href='<?=$baseurl;?>pastoral.php'><span>Overview</span></a> </li>
                        <li class='has-sub'>
                           <a href='#'><span>House System</span></a>
                           <ul>
                              <li><a href='<?=$baseurl;?>agnihousementor.php'><span>Agni </span></a></li>
                              <li><a href='<?=$baseurl;?>akash.php'><span>Akash</span></a></li>
                              <li><a href='<?=$baseurl;?>prithvihouse-mentor.php'><span>Prithvi </span></a></li>
                              <li class='last'><a href='<?=$baseurl;?>Jalhousementro.php'><span>Jal</span></a></li>
                           </ul>
                        </li>
                     </ul>
                  </li>
                  <li>
                     <a href='#'>Public Disclosure</a>
                     <ul>
                        <li><a href='Download/Annual-Calendar-2021-22.pdf' target="_blank"><span>Annual Calendar 2021-22</span></a></li>
                        <li><a href='Download/Board-Result-Faculty-Details-&-School-Infrastrucutre.pdf' target="_blank"><span>Board Result Faculty Details & School Infrastrucutre</span></a></li>
                        <li><a href='Download/Building-Safety-Certificate.pdf' target="_blank"><span>Building-Safety-Certificate</span></a></li>
                        <li><a href='Download/Certificate-from-DEO.pdf' target="_blank"><span>Certificate from DEO</span></a></li>
                        <li><a href='Download/Drinking-Water-&-Hygienic-Condition-certificate-July-2021.pdf' target="_blank"><span>Drinking Water & Hygienic Condition certificate July 2021</span></a></li>
                        <li><a href='Download/Extension-of-Affiliation-Approval-Sr.-SEC.-School-up-to-31st-March-2026.pdf' target="_blank"><span>Extension of Affiliation Approval Sr. SEC. School up to 31st March 2026</span></a></li>
                        <li><a href='Download/Fee-Structure-2021-22.pdf' target="_blank"><span>Fee-Structure-2021-22</span></a></li>
                        <li><a href='Download/fire-NOC.pdf' target="_blank"><span>Fire NOC</span></a></li>
                        <li><a href='Download/Fire-Certificate-24Dec2022.pdf' target="_blank"><span>Fire Safety Certificate</span></a></li>
                        <li><a href='Download/List-of-SMC.pdf' target="_blank"><span>List of SMC</span></a></li>
                        <li><a href='Download/NOC-from-State-Government.pdf' target="_blank"><span>NOC from State Government</span></a></li>
                        <li><a href='Download/Sanitary-Certificate-July-2021.pdf' target="_blank"><span>Sanitary Certificate July 2021</span></a></li>
                     </ul>
                  </li>
                  <li>
                     <a href='#'>Admissions</a>
                     <ul>
                        <li ><a href='<?=$baseurl;?>school-admission-process.php'><span>Procedure</span></a></li>
                        <li ><a href='<?=$baseurl;?>registration-form.php'><span>Online Registration</span></a></li>
                        <li >
                           <a href='<?=$baseurl;?>boarding-school-fee-details.php'><span>Fee Structure</span></a>
                           <!-- <ul>
                              <li><a href='<?=$baseurl;?>regular-fee-details.php' ><span>Regular Fee </span></a></li>
                              <li><a href='<?=$baseurl;?>gurukul-fee-details.php' ><span>Gurukul Fee</span></a></li>
                              <li><a href='#'><span>Arjuna Fee </span></a></li>
                              
                              </ul>-->
                        </li>
                        <li ><a href='<?=$baseurl;?>scholarships-bursaries.php'><span>Scholarships and Bursaries</span></a></li>
                        <!--<li class='has-sub last'>
                           <a href="#"><span> Calendar</span></a>
                           <ul>
                              <li><a href='<?=$baseurl;?>Download/school_calendar_2016_17.pdf' target="_blank"><span> School Calendar</span></a></li>
                                 <li><a href='<?=$baseurl;?>Download/spring_calender.pdf' target="_blank"><span> Spring Calendar</span></a></li>
                              <li><a href='<?=$baseurl;?>Download/Calender.pdf' target="_blank"><span> Autumn Calendar</span></a></li>
                           </ul>
                        </li>-->
                     </ul>
                  </li>
                  
                  <!--<li class='has-sub'>
                     <a href='#'>Holiday Homework <img src="<?=$baseurl;?>assets/images/new2.gif" alt="New Info"  /></a>
                     <ul>
                        <li><a href="<?=$baseurl;?>homework-summer.php">Summer Holiday Homework <img src="<?=$baseurl;?>assets/images/new2.gif" alt="New Info"  /></a></li>
                        <!--<li><a href="<?=$baseurl;?>homework_winter.php">Winter Holiday Homework <img src="<?=$baseurl;?>assets/images/new2.gif" alt="New Info"  /></a></li>
                     </ul>
                  </li>-->
                   <li><a href='<?=$baseurl;?>covid-update.php'>Covid-19 Update <img src="<?=$baseurl;?>assets/images/new2.gif" alt="New Info"  /></a></li>
                  <li><a href='<?=$baseurl;?>contact-dehradun-boarding-school.php'>Contact Us</a></li>
               </ul>
            </div>
         </div>
      </div>
      <div class="navbar-header">
         <div class="container-fluid">
            <div class="row">
               <div class="col-xl-6 col-lg-6 col-sm-6 col-3">
                  <a href="<?=$baseurl;?>" class="navbar-brand">
                  <img class="w-logo lazyload" data-src="<?=$baseurl;?>assets/images/sis_logo_test_w.png" alt="Sela Qui International School">
                  <img class="b-logo" src="<?=$baseurl;?>assets/images/sis_logo_test.png" alt="Sela Qui International School">
                  <img class="m_w_logo" src="<?=$baseurl;?>assets/images/m_w_logo.png" alt="Sela Qui International School">
                  <img class="m_b_logo" src="<?=$baseurl;?>assets/images/m_b_logo.png" alt="Sela Qui International School">
                  </a>
               </div>
               <div class="col-xl-6 col-lg-6 col-sm-6 col-9">
                  <div class="callnow">
                     <ul>
                        <li>
                           <p><span><strong></strong><strong><i class="fa fa-phone" aria-hidden="true"></i></strong></span><a href="tel:7669040404">7669-040404</a></p>
                        </li>
                        <li class="reopen">
                           <p><span><strong></strong><strong><i class="fa fa-empire" aria-hidden="true"></i></strong></span><a href="https://www.selaqui.org/covid-update.php">Reopening School</a></p>
                        </li>
                     </ul>
                  </div>
                  
               </div>
            </div>
         </div>
      </div>
   </div>
</nav>
<div class="right_floating"><a href="https://www.selaqui.org/registration-form.php"> <i class="fa fa-pencil-square-o" aria-hidden="true"></i> &nbsp;<b>Enquire Now </b></a></div>

<!--<a href="https://www.future50schools.com/blog/schools/selaqui-international-school/" style="position:absolute; right:0; bottom:30%; z-index: 99999999" target="_blank" id="Future50SchoolsLink" rel="nofollow"><img src="<?=$baseurl;?>assets/images/future-50-floater.png" alt="Future 50 Floater"></a>-->