<style>
.blog-section{
    padding: 65px 0;
}

.blog-slider .blog-item .descr h3 a{
	font-size: 15px;
    line-height: 20px;
    font-weight: 300;
    display: block;
}

.blog-box {
    display: block;
    height: 335px;
}

.blogCarousel .owl-prev{
	position: absolute;
	z-index: 10;
	display: inline-block;  
	left: -104px; 
	cursor: pointer; 
	font-size: 0.1px; 
	top: 37%; 
	width: 45px; 
	height: 45px;  	
    padding: 12px 5px !important;
	background: #00743d;
}
.blogCarousel .owl-next{
	position: absolute; 
	z-index: 10; 
	display: inline-block; 
	right: -51px;  
	cursor: pointer;
	font-size: 0.1px;  
	top: 37%; 
	width: 45px;  
	height: 45px;  
    padding: 12px 5px !important;
	background: #00743d;
}

/*blog carousel Library*/

.blogCarousel,
.blogCarousel .owl-item {
	-webkit-tap-highlight-color: transparent;
	position: relative
}

.blogCarousel .animated {
	-webkit-animation-duration: 1s;
	animation-duration: 1s;
	-webkit-animation-fill-mode: both;
	animation-fill-mode: both
}

.blogCarousel .owl-animated-in {
	z-index: 0
}

.blogCarousel .owl-animated-out {
	z-index: 1
}

.blogCarousel .fadeOut {
	-webkit-animation-name: fadeOut;
	animation-name: fadeOut
}

@-webkit-keyframes fadeOut {
	0% {
		opacity: 1
	}
	100% {
		opacity: 0
	}
}

@keyframes fadeOut {
	0% {
		opacity: 1
	}
	100% {
		opacity: 0
	}
}

.owl-height {
	-webkit-transition: height .5s ease-in-out;
	-moz-transition: height .5s ease-in-out;
	-ms-transition: height .5s ease-in-out;
	-o-transition: height .5s ease-in-out;
	transition: height .5s ease-in-out
}

.blogCarousel {
	display: none;
	width: 100%;
	z-index: 1
}

.blogCarousel .owl-stage {
	position: relative;
	-ms-touch-action: pan-Y
}

.blogCarousel .owl-stage:after {
	content: ".";
	display: block;
	clear: both;
	visibility: hidden;
	line-height: 0;
	height: 0
}

.blogCarousel .owl-stage-outer {
	position: relative;
	overflow: hidden;
	-webkit-transform: translate3d(0, 0, 0)
}

.blogCarousel .owl-controls .owl-dot,
.blogCarousel .owl-controls .owl-nav .owl-next,
.blogCarousel .owl-controls .owl-nav .owl-prev {
	cursor: pointer;
	cursor: hand;
	-webkit-user-select: none;
	-khtml-user-select: none;
	-moz-user-select: none;
	-ms-user-select: none;
	user-select: none
}

.blogCarousel.owl-loaded {
	display: block
}

.blogCarousel.owl-loading {
	opacity: 0;
	display: block
}

.blogCarousel.owl-hidden {
	opacity: 0
}

.blogCarousel .owl-refresh .owl-item {
	display: none
}

.blogCarousel .owl-item {
	min-height: 1px;
	float: left;
	-webkit-backface-visibility: hidden;
	-webkit-touch-callout: none;
	-webkit-user-select: none;
	-moz-user-select: none;
	-ms-user-select: none;
	user-select: none
}

.blogCarousel .owl-item img {
	display: block;
	width: 100%;
	height: 200px;
	-webkit-transform-style: preserve-3d;
	transform-style: preserve-3d;
	background-position: center;
	background-size: cover;
	background-repeat: no-repeat;
}

.blogCarousel.owl-text-select-on .owl-item {
	-webkit-user-select: auto;
	-moz-user-select: auto;
	-ms-user-select: auto;
	user-select: auto
}

.blogCarousel .owl-grab {
	cursor: move;
	cursor: -webkit-grab;
	cursor: -o-grab;
	cursor: -ms-grab;
	cursor: grab
}

.blogCarousel.owl-rtl {
	direction: rtl
}

.blogCarousel.owl-rtl .owl-item {
	float: right
}

.no-js .blogCarousel {
	display: block
}

.blogCarousel .owl-item .owl-lazy {
	opacity: 0;
	-webkit-transition: opacity .4s ease;
	-moz-transition: opacity .4s ease;
	-ms-transition: opacity .4s ease;
	-o-transition: opacity .4s ease;
	transition: opacity .4s ease
}
</style>

<?php 
// Include the wp-load'er
include('blog/wp-load.php');

// Get the last 10 posts
// Returns posts as arrays instead of get_posts' objects
$recent_posts = wp_get_recent_posts(array(
	'numberposts' => 10
));
?>
<section class="blog-section">
    <div class="container">
		<div class="row">
			<div class="col-12">
				<div class="section-title-header text-center">
					<h2 class="section-title wow fadeInUp" data-wow-delay="0.2s">Latest Blogs</h2>
				</div>
			</div>
		</div>	
        <div class="row blog-slider">		
			<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 wow fadeInUp animated " data-wow-delay="0.2s" style="visibility: visible;-webkit-animation-delay: 0.2s; -moz-animation-delay: 0.2s; animation-delay: 0.2s;">			
                <div id="blogCarousel" class="blogCarousel owl-theme">
			<?php			
			// Do something with them
				foreach($recent_posts as $post) {
					/* grab the url for the full size featured image */
					//$featured_img_url = get_the_post_thumbnail_url('thumbnail'); 
					$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post['ID'] ), 'single-post-thumbnail' ); 
					echo '<div class="item team-item wow fadeInUp blog-box" data-wow-delay="0.2s">';
					echo '<div class="team-img">';
					echo '<div class="blog-item">';
					echo '<div class="blog-image">';
					echo '<a href="'.get_permalink($post['ID']).'" target="_blank" title="'.$post['post_title'].'">';
					echo '<img class="img-fluid" style="background-image:url('.$image[0].');">';
					echo '</a>';
					echo '</div>';
					echo '<div class="descr">';
					//echo '<div class="tag"><a href="https://www.selaqui.org/Download/sis-brochure.pdf" target="_blank">Download</a></div>';
					echo '<h3 class="title">';
					echo '<a href="'.get_permalink($post['ID']).'" target="_blank">';
					echo $post['post_title'];
					echo '</a>';
					echo '</h3>';
					echo '</div>';
					echo '</div>';
					echo '</div>';
					echo '</div>';
				}
			?>

				</div>
			</div>
		</div>
	</div>	
</section>
<style type="text/css">
ul.useful_link {
    display: block;
}
</style>
<footer class="footer-area">
    <div class="container">
        <div class="row">
            <div class="col-md-5 col-lg-5 col-sm-5 col-xs-12 wow fadeInUp animated" data-wow-delay="0.2s" style="visibility: visible;-webkit-animation-delay: 0.2s; -moz-animation-delay: 0.2s; animation-delay: 0.2s;">
                <img src="https://www.selaqui.org/assets/images/sis_logo_test.png" alt="Selaqui International School" style="background: #fff;">
                <p style="line-height: 18px;margin: 20px 0;">Chakarata Rd, Selaqui Industrial Area, <br>Dehradun-248011, Uttarakhand</p>
                <p style="line-height: 18px;margin: 20px 0;">General Queries: 7253051000 <br>Toll Free: 7669 040404 <br> Fax: +91 135 3051399 <br>Email: selaqui@selaqui.org, admissions@selaqui.org</p>
            </div>
            <div class="col-md-2 col-lg-2 col-sm-2 col-xs-12 wow fadeInUp animated" data-wow-delay="0.2s" style="visibility: visible;-webkit-animation-delay: 0.2s; -moz-animation-delay: 0.2s; animation-delay: 0.2s;">
                <h3>Useful Links</h3>
                <ul class="useful_link">
                    <li><a href="https://www.selaqui.org/about-cbse-boarding-schools-india.php"><span>About Us</span> </a></li>
                    <li><a href="https://www.selaqui.org/cbse-boarding-school-curriculum.php"><span>Curriculum</span></a></li>
                    <li><a href="https://www.selaqui.org/school-admission-process.php"><span>Admission Process</span></a></li>
                    <li><a href="https://www.selaqui.org/registration-form.php"><span>Registration Form</span></a></li>
                    <li><a href="https://www.selaqui.org/boarding-school-fee-details.php"><span>School Fee Details</span></a></li>
                    <li><a href="https://www.selaqui.org/online-fee-payment.php"><span>Online Fee Payment</span></a></li>
                    <li><a href="https://www.selaqui.org/residential-school-activities.php"><span>School Activities</span></a></li>
                    <li><a href="https://www.selaqui.org/sports-overview.php"><span>Sports Overview</span></a></li>
                </ul>
            </div>
            <div class="col-md-2 col-lg-2 col-sm-2 wow fadeInUp animated" data-wow-delay="0.8s" style="visibility: visible;-webkit-animation-delay: 0.8s; -moz-animation-delay: 0.8s; animation-delay: 0.8s;">
                <h3>&nbsp;</h3>
                <ul class="useful_link">
                    <li><a href="https://www.selaqui.org/blog/"><span>Blog</span></a></li>
                    <li><a href="https://www.selaqui.org/contact-dehradun-boarding-school.php"><span>Contact Us</span></a></li>
                    <li><a href="https://www.selaqui.org/Gallery/gallery.asp" target="_blank"><span>Gallery</span></a></li>
                    <li><a href="https://www.selaqui.org/school-career-opportunities.php"><span>Career</span></a></li>
                    <li><a href="https://www.selaqui.org/sitemap.php"><span>Sitemap</span></a></li>
                    <li><a href="https://www.selaqui.org/alumni.php"><span>Alumni</span></a></li>
                </ul>
            </div>
            <div class="col-md-3 col-lg-3 col-sm-3 col-xs-12 wow fadeInUp animated" data-wow-delay="0.8s" style="visibility: visible;-webkit-animation-delay: 0.8s; -moz-animation-delay: 0.8s; animation-delay: 0.8s;">
                <!-- /.widget -->
                <div class="widget pull-right">
                    <ul class="footer-social">
                        <li><a class="facebook" href="https://www.facebook.com/SelaQuiIntlSchool" target="_blank"><i class="lni-facebook-filled"></i></a></li>
                        <!--<li><a class="google-plus" href="https://plus.google.com/u/0/110951674589018557780" target="_blank"><i class="lni-google-plus"></i></a></li>-->
                        <li><a class="pinterest" href="https://www.pinterest.com/selaquidehradun/" target="_blank"><i class="fa fa-pinterest-p"></i></a></li>
                        <li><a class="linkedin" href="https://www.linkedin.com/company/selaqui-international-school/" target="_blank"><i class="lni-linkedin-filled"></i></a></li>
                        <li><a class="twitter" href="https://twitter.com/SelaqIntlSchool" target="_blank"><i class="lni-twitter-filled"></i></a></li>
                        <li><a class="wiki" href="https://en.wikipedia.org/wiki/SelaQui_International_School" target="_blank"><i class="fa fa-wikipedia-w"></i></a></li>
                        <li><a class="youtube" href="https://www.youtube.com/channel/UClITON3SEr-qyG9MlZOkiQw" target="_blank"><i class="fa fa-youtube-play"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Footer Section End -->
<div id="copyright">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <div class="site-info">
               <p>© Copyright 2020, All Rights Reserved</p>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- Go to Top Link -->
<a href="#" class="back-to-top">
<i class="lni-chevron-up"></i>
</a>
