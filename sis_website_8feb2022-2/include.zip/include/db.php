
<?php
//mysql_connect("localhost", "root", "")or die(mysql_error()); 
//mysql_connect("selaquicrm.db.5227155.hostedresource.com", "selaquicrm", "Siscrm1#") or die(mysql_error());

//mysql_select_db("selaquicrm") or die(mysql_error());
mysql_connect("localhost", "sisschoo_selaquicrm", "sisschoo_selaquicrm") or die(mysql_error());
mysql_select_db("sisschoo_selaquicrm") or die(mysql_error());


?>