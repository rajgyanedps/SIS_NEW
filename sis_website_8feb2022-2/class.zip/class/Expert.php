<?php
class Expert{
public function __construct()
		  { 
		     include("db.php");
		  }
public function asked_question($userid,$catid='',$status='1',$limit=''){

			if($catid !=""){
			$wh = " and ques_cat_id='".$catid."'";
			}
			if($limit!=""){
				 $lim = $limit;
			}
//echo "select * from expert_question left join expert_answer on expert_answer.question_id=expert_question.id where 1 and added_by='".$userid."'  and expert_question.status='".$status."' ".$wh." ORDER BY expert_question.added_date DESC ".$lim ;
			 $qry = mysql_query("select * from expert_question left join expert_answer on expert_answer.question_id=expert_question.id where 1 and added_by='".$userid."'  and expert_question.status='".$status."' ".$wh." ORDER BY expert_question.added_date DESC ".$lim );
			
			 while($res1 = mysql_fetch_array($qry))
			 {
				$arr_res[] = $res1;
			 }
			return $arr_res;
		  }
public function insert_question($post){
	@extract($post);
	$qry = "insert into expert_question set question='". htmlspecialchars($ask, ENT_QUOTES, 'UTF-8')."',ques_cat_id='".$ask_cat."',added_by='".$_SESSION['studentid']."',added_date=now(),status='1'";
	$res= mysql_query($qry);
	$lastid = mysql_insert_id();
	return $lastid;
	}		  
	  
}
?>