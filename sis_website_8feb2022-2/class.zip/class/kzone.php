<?php
class kzone{
public function __construct()
		  { 
		    // include("db.php");
			;
		  }
public function select_qry($qry,$wh=""){

			 $qry = mysql_query($qry ." ".$wh);
			
			 while($res1 = mysql_fetch_array($qry))
			 {
				$arr_res[] = $res1;
			 }
			return $arr_res;
		  }
public function insert_question($post){
	@extract($post);
	$qry = "insert into expert_question set question='". htmlspecialchars($ask, ENT_QUOTES, 'UTF-8')."',ques_cat_id='".$ask_cat."',added_by='".$_SESSION['studentid']."',added_date=now(),status='1'";
	$res= mysql_query($qry);
	$lastid = mysql_insert_id();
	return $lastid;
	}		  
	  
}
?>