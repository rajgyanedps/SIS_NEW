<?php
error_reporting(0);
session_start();
date_default_timezone_set('Asia/Kolkata');
$DATE =  date('Y-m-d H:i:s');
include('../include/db.php');



	
function getUserIP()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    return $ip;
}
$user_ip = getUserIP();



/************************************************/
if($_REQUEST['utm_source']|| $_REQUEST['utm_medium'])
   {
	$_SESSION['fb_campaing_key']=
	array('utm_source'=>$_REQUEST['utm_source'],
	'utm_medium' => $_REQUEST  ['utm_medium']);
 	}
 
 if($_REQUEST['PSE'] || $_REQUEST['PAC'] || $_REQUEST['PCA'] && $_REQUEST['PAG'] && $_REQUEST['PKW'] && $_REQUEST['PMT'] || $_REQUEST['PDS'] || $_REQUEST['PPC'] || $_REQUEST['PAD'] )
{		
$_SESSION['campaign_key']=array(
							'PSE' => $_REQUEST['PSE'],
							'PAC' => $_REQUEST['PAC'],
							'PCA' => $_REQUEST['PCA'],
							'PAG' => $_REQUEST['PAG'],
							'PKW' => $_REQUEST['PKW'],
							'PMT' => $_REQUEST['PMT'],
							'PDS' => $_REQUEST['PDS'],
							'PPC' => $_REQUEST['PPC'],
							'PAD' => $_REQUEST['PAD']);	
}
$information_sourse = $_POST['information_sourse'];
if($_POST['continue_reg'])
{
extract($_POST);
extract($_GET);
//$_POST['letters_code'];
//$_SESSION['6_letters_code'];

if(empty($_SESSION['6_letters_code']) || strcasecmp($_SESSION['6_letters_code'], $_POST['letters_code']) != 0)
 {
	
     $errors_captcha = "\n The captcha code does not match!"; 
	 $errors_new='1';
}
$email=$_POST['email'];
$mobile=$_POST['mobile'];
$sel_user = "SELECT * FROM golf_lead WHERE email='$email' and mobno='$mobile' and mobno!='' ";
$res_user =  mysql_query($sel_user);
$num_res=mysql_fetch_array($res_user);
$num_row = mysql_num_rows($res_user);
$VarificationCode = md5(time().rand(9,20));
if($num_row <=0)
	 {
          $filed = $_SESSION['campaign_key'];
		  $informationsourse = 'Lead';
		   if($_SESSION['fb_campaing_key'])
		   {
		       $informationsourse .= " _ ". $_SESSION['fb_campaing_key']['utm_medium'];
	       }
	  if($errors_new!='1')
	   {
	  
	  $user_sql="insert into golf_lead(name,mobno,email,address,age,occupation,study_at,s_c_name,class,interested_course,date,ip_address,PSE,PAC,PCA,PAG,PKW,PMT,PDS,PPC,PAD,information_source) values('$name','$mobile','$email','$address','$age','$occupation','$study_at','$s_c_name','$class','$interested_in','".$DATE."','$user_ip','".$filed['PSE']."','".$filed['PAC']."','".$filed['PCA']."','".$filed['PAG']."','".$filed['PKW']."','".$filed['PMT']."','".$filed['PDS']."','".$filed['PPC']."','".$filed['PAD']."','".$informationsourse."')";
mysql_query($user_sql) or die(mysql_error());
$_SESSION['formfill']=true;
$subject = 'Thank you for Golf Enquiry.';
         $txt = '<table cellspacing="0" width="600" cellpadding="0" border="0" align="center" style="border:1px solid #3e3e3e">                           

<tr><td><table cellspacing="0" width="550" cellpadding="0" border="0" align="center" style="font-family:Tahoma, Geneva, sans-serif; font-size:13px; color:#333; line-height:20px;">
<tr>
<td align="left">&nbsp;</td>
</tr>
<tr>
<td align="left"><strong>Hi '.ucwords($name).',</strong></td>
</tr>
<tr>
<td align="left">&nbsp;</td>
</tr>
<tr>
<td align="left">Thank you for showing interest in SelaQui Golf Academy.We will get in touch with you shortly. </td>
</tr>
<tr>
                                             <td align="left">&nbsp;</td>
                                           </tr>
                                           <tr>
<td align="left"><strong>Following are the details we have received from your end:</strong></td>                                
</tr>
                            <tr>
                                             <td align="left">&nbsp;</td>
                            </tr>
                            <tr>
<td align="left">Name:'.ucwords($name).'</td>                                
</tr>
                         <tr>
<td align="left">Email Id: '.$email.'</td>                                
</tr>
                         <tr>
<td align="left">Mobile:  '.$mobile.'</td>                                
</tr>
                         <tr>
<td align="left">Address:  '.$address.'</td>                                
</tr>
                                
					    
                       <tr>
                         <td align="left">&nbsp;</td>
                       </tr>
                       
                       <tr>
                         <td align="left">&nbsp;</td>
                       </tr>
                       <tr>
<td align="left"> <strong>Thanks,<br/>
SelaQui Golf Academy </strong></td>                                
</tr>
                                          </table></td>
				        </tr>
				       <tr><td>&nbsp;</td></tr>
				      <tr>
				          <td>&nbsp;</td>
				     </tr>
			     </table>

			 ';

		$headers  = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
		$headers .= "From: SelaQui Golf Academy<admissions@selaqui.org>". "\r\n";
		$headers .= "Return-Path: <noreply@selaqui.org>". "";

       $mail= mail($email,$subject,$txt,$headers);
        
        if($mail)
         {
       
				$message_mail ="Mail Sent Successfullly";	   
	   
                //include('../mailcontent/message.php'); 
            //  $to='internationalselaqui@gmail.com,bishtmca83@gmail.com';
             //mail($to,$subject1,$txt1,$headers); 
			   }
	 		$_SESSION['leaddone']=1;
          	unset($_SESSION['campaign_key']);
			// header('location:index.php?done=1');
			echo '<script>window.location ="index.php?done=1";</script>';
          
		 exit;
	
                            	 }    } else { 
                                    
                                    $errors='This Enquiry Already Sent.';
                                    }
        
}



?>
<!DOCTYPE HTML>

<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>SelaQui Golf Academy | Golf Academy Dehradun</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="SelaQui International School Dehradun brings SelaQui Golf Academy in collaboration with Amandeep Johl Golf Academy, an International Award Winning Golf player Mr. Amandeep Johl." />
	<meta name="keywords" content="selaqui golf academy, golf academy dehradun, dehradun golf academy, best school with golf facilities, schooling with golf course" />
	<meta name="author" content="" />

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Kaushan+Script" rel="stylesheet">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Themify Icons-->
	<link rel="stylesheet" href="css/themify-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">

	<!-- Bootstrap DateTimePicker -->
	<link rel="stylesheet" href="css/bootstrap-datetimepicker.min.css">

	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">

  


	<!-- Modernizr JS -->

	<script type="text/javascript">
	var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-4634742-2']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>
	
	
	<script src="js/modernizr-2.6.2.min.js"></script>
		<script type="text/javascript">
function validate_udetail(){
	
	if(document.getElementById("name").value.trim()=="" )
	{
		alert("Enter Your Name");
		document.getElementById("name").focus();
		return false;
	}
	
	
	
	if (document.getElementById("email").value=="" )
	{
		alert("The e-mail ld is blank or \n an invalid value has been entered.");
        document.getElementById("email").focus();		
        return false;
    }
	if (echeck(document.getElementById("email").value)==false)
	{
		document.getElementById("email").value=""
		document.getElementById("email").focus();
		return false
	}
	
	
	if(document.getElementById("mobile").value=="")

	{
		alert("Enter Mobile No");
		document.getElementById("mobile").focus();
		return false;
	}
	
	if(document.getElementById("mobile").value!="")
		{
			var stripped1 = document.getElementById("mobile").value.replace(/[\(\)\.\-\ ]/g, '');
			if(isNaN(parseInt(stripped1)))
			{
				alert("The mobile number contains illegal characters");
				document.getElementById("mobile").focus();
				return false;			
			}
			else if ((stripped1.length < 10) || (stripped1.length > 12))
			{
        	
				alert("The mobile number is the wrong length.");
				document.getElementById("mobile").focus();
				return false;
			
    		} 
		
	} 
	
	
	if(document.getElementById("address").value.trim()=="" )
	{
		alert("Enter Your Address");
		document.getElementById("address").focus();
		return false;
	}
	
	if(document.getElementById("age").value.trim()=="")
	{
		alert("Enter Your Age");
		document.getElementById("age").focus();
		return false;
	}
	if(document.getElementById("occupation").value=="")
	{
		alert("Select Occupation");
		document.getElementById("occupation").focus();
		return false;
	}
     if(document.getElementById("occupation").value=="Student" && document.getElementById("study_at").value=='')
	{
		alert("Select School ");
		document.getElementById("study_at").focus();
		return false;
	}
	if(document.getElementById("occupation").value=="Student" && document.getElementById("s_c_name").value=='')
	{
		alert("Enter Your School Name ");
		document.getElementById("s_c_name").focus();
		return false;
	}
	if(document.getElementById("occupation").value=="Student" && document.getElementById("class").value=='')
	{
		alert("Choose Your Class ");
		document.getElementById("class").focus();
		return false;
	}
	if(document.getElementById("interested_in").value=="" )
	{
		alert("Choose Your Golf Course ");
		document.getElementById("interested_in").focus();
		return false;
	}
	
	if(document.getElementById("letters_code").value=="" )
	{
		alert("Enter Capcha Code");
		document.getElementById("letters_code").focus();
		return false;
	}	
	return true;
}


function echeck(str) {

		var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
		   alert("Invalid E-mail ID")
		   return false
		}

		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   alert("Invalid E-mail ID")
		   return false
		}

		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    alert("Invalid E-mail ID")
		    return false
		}

		 if (str.indexOf(at,(lat+1))!=-1){
		    alert("Invalid E-mail ID")
		    return false
		 }

		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    alert("Invalid E-mail ID")
		    return false
		 }

		 if (str.indexOf(dot,(lat+2))==-1){
		    alert("Invalid E-mail ID")
		    return false
		 }
		
		 if (str.indexOf(" ")!=-1){
		    alert("Invalid E-mail ID")
		    return false
		 }

 		 return true					
	}

/**************************************/


</script>
<style type="text/css">
select option {
    background: #000000;
    color:#fff;
    text-shadow:0 1px 0 rgba(0,0,0,0.4);
}
</style>
<script type="text/javascript">
(function(a,e,c,f,g,h,b,d){var k={ak:"1040837567",cl:"6oGYCPvzkG0Qv9en8AM",autoreplace:"7669040404"};a[c]=a[c]||function(){(a[c].q=a[c].q||[]).push(arguments)};a[g]||(a[g]=k.ak);b=e.createElement(h);b.async=1;b.src="//www.gstatic.com/wcm/loader.js";d=e.getElementsByTagName(h)[0];d.parentNode.insertBefore(b,d);a[f]=function(b,d,e){a[c](2,b,k,d,null,new Date,e)};a[f]()})(window,document,"_googWcmImpl","_googWcmGet","_googWcmAk","script");
</script>

	<!-- Global site tag (gtag.js) - AdWords: 1040837567 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-1040837567"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-1040837567');
</script>
</head>

	<body>

		
	<div class="gtco-loader"></div>
	
	<div id="page">

	
	<!-- <div class="page-inner"> -->
	<nav class="gtco-nav" role="navigation">
		<div class="gtco-container">
			
			<div class="row">
				<div class="col-sm-8 col-xs-12">
					<div id="gtco-logo"><a href="index.html"><img src="images/golf_logo.png" height="143"> SelaQui Golf Academy</a> <img src="images/amandeep_johl_logo.png" height="150"></div>
                    
				</div>
				<div class="col-xs-4 text-right menu-1">
					<ul>
						<!--<li><a href="menu.html">Menu</a></li>
						<li class="has-dropdown">
							<a href="services.html">Services</a>
							<ul class="dropdown">
								<li><a href="#">Food Catering</a></li>
								<li><a href="#">Wedding Celebration</a></li>
								<li><a href="#">Birthday's Celebration</a></li>
							</ul>
						</li>
						<li><a href="contact.html">Contact</a></li>-->
						<li class="btn-cta"><a href="mailto:golf@selaqui.org"><span><img src="images/email_icon.png" style="margin-top:-4px;" width="40"> golf@selaqui.org</span></a></li>
					</ul>	
				</div>
			</div>
			
		</div>
	</nav>
	
	<header id="gtco-header" class="gtco-cover gtco-cover-md" role="banner" style="background-image: url(images/img_5.jpg)" data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-12 col-md-offset-0 text-left">
					

					<div class="row row-mt-15em">
						<div class="col-md-7 mt-text animate-box" data-animate-effect="fadeInUp">
                        <h1 class="cursive-font" style="font-size:35px; font-family:'Palatino Linotype', 'Book Antiqua', Palatino, serif; color:#FBB448; font-weight:bold; margin:260px 0 0 300px;"><img src="images/collaboration.png" width="387" height="280"></h1>
							<!--<h1 class="cursive-font" style="margin:20px 0 0 50px; font-family:'Palatino Linotype', 'Book Antiqua', Palatino, serif;">
                            <div><img src="images/tick_icon.png" width="25" style="margin-top:-10px;"> CBSE Curriculum</div>
<div><img src="images/tick_icon.png" width="25" style="margin-top:-10px;"> Healthy Nutritious Food</div>

<div><img src="images/tick_icon.png" width="25" style="margin-top:-10px;"> Safe & Secure Campus</div>

<div><img src="images/tick_icon.png" width="25" style="margin-top:-10px;"> Extra Curricular Activities</div>

<div><img src="images/tick_icon.png" width="25" style="margin-top:-10px;"> Separate Hostels</div>

<div><img src="images/tick_icon.png" width="25" style="margin-top:-10px;"> 24X7 Teacher Guidance</div>

<div><img src="images/tick_icon.png" width="25" style="margin-top:-10px;"> IIT-JEE/NEET Curriculum</div><br>
</h1>-->
<!--<h1 class="cursive-font col-sm-6" style="font-size:25px; padding:20px; font-family:'Palatino Linotype', 'Book Antiqua', Palatino, serif; background:#FBB448; color:#000000; text-align:center; border-radius:15px;">Admissions Open<br>
V, VI, VII, VIII, IX & XI<br>
<a href="http://selaqui.org/registration-form.php" class="btn btn-danger">Apply Now</a></h1>-->
					</div>
                      
						<div class="col-md-4 col-md-push-1 animate-box" data-animate-effect="fadeInRight">
							<div class="form-wrap">
								<div class="tab">
									
									<div class="tab-content">
										<div class="tab-content-inner active" data-content="signup">
										<?php
										if($message_mail) { ?>
										  <h3 style="color:green;"><?php echo $message_mail; ?></h3>
										<?php } ?>
										<?php if($errors){ ?>
                  <h3 style="color:red;"><?php echo $errors; unset($errors);  ?></h3> <?php } ?>
				  <?php if($errors_captcha) {  ?>   <h3 style="color:red;"> <?php  echo $errors_captcha ; ?> </h3> <?php }  ?>
				  
                 								
												<? if($_GET['done']==1){  ?>

<script type="text/javascript">
	var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-4634742-2']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//www.googleadservices.com/pagead/conversion/1040837567/?value=1.00&amp;currency_code=INR&amp;label=xZqHCK2G9QEQv9en8AM&amp;guid=ON&amp;script=0"/>
</div>
</noscript>

</script>
<div align="center" style="padding:30px;" class="ari13"> 
<p><strong>Thank you for showing interest.
</strong><br />
<br />
We have received your submission. <br />
We will get back to you shortly.</p>
<p>To know more about the information, please visit <br />
<a href="http://www.selaqui.org/golf"><strong>www.Selaqui.org/golf </strong></a><br />
</p>
 </div> 

<?php  echo '<meta http-equiv="refresh" content="4;url=index.php">';} else { ?>
												
												
											<h3 class="cursive-font" align="center">ENQUIRY</h3>
											<form action="#" method="post" name="userdetails" id="form" onSubmit="return validate_udetail();">
												
                                                <div class="row form-group">
													<div class="col-md-12">
														<!--<label for="date-start">Student Name</label>-->
														<input type="text" class="form-control" name="name" id="name" placeholder="Name">
													</div>
												</div>
                                                <div class="row form-group">
													<div class="col-md-12">
														<!--<label for="date-start">Email</label>-->
														<input type="text" class="form-control" name="email" id="email" placeholder="Email">
													</div>
												</div>
                                                <div class="row form-group">
													<div class="col-md-12">
														<!--<label for="date-start">Mobile</label>-->
														<input type="text" class="form-control" name="mobile" id="mobile" placeholder="Mobile">
													</div>
												</div>
                                                <!--<div class="row form-group">
													<div class="col-md-12">
														
														<input type="text" class="form-control" name="state" id="state" placeholder="State">
													</div>
												</div>-->
                                                <!--<div class="row form-group">
													<div class="col-md-12">
														
														<input type="text" name="city" id="city" class="form-control" placeholder="City">
													</div>
												</div>-->
												<div class="row form-group">
													<div class="col-md-12">
														
	<input type="text" name="address" id="address" class="form-control" placeholder="Address">
													</div>
												</div>
                                                <div class="row form-group">
													<div class="col-md-12">
														
														<input type="text" name="age" id="age" class="form-control" placeholder="Age">
													</div>
												</div>
                                                <div class="row form-group">
													<div class="col-md-12">
														<!--<label for="activities">Select Class</label>-->
														<select name="occupation" id="occupation" class="form-control" onChange="select_type(this.value)">
															<option value="">Select Occupation</option>
															
      <option value="Student">Student</option>
      <option value="Service">Service</option>
      <option value="Business">Business</option>
     
														</select>
													</div>
												</div>
                                                 <div class="row form-group" style="display:none;" id="study_at_div">
													<div class="col-md-12">
														<!--<label for="activities">Information Source</label>-->
														<select name="study_at" id="study_at" class="form-control"  onChange="select_study_at(this.value)">
                                                        <option value="">Select</option>
															<option value="School">School</option>
															<option value="College">College</option>
															</select>
													</div>
												</div>
                                                <div class="row form-group" style="display:none;" id="s_c_div">
													<div class="col-md-12">
														
														<input type="text" name="s_c_name" id="s_c_name" class="form-control" placeholder="School / College Name">
													</div>
												</div>
												 
                                                <div class="row form-group" style="display:none;" id="class_div">
													<div class="col-md-12">
														<!--<label for="activities">Information Source</label>-->
														<select name="class" id="class" class="form-control">
                                                        <option value="">Select Class</option>
															<option value="Class V">Class V</option>  
															<option value="Class V">Class VI</option>  
															<option value="Class V">Class VII</option>  
															<option value="Class V">Class VIII</option>  
															<option value="Class V">Class IX</option>  
															<option value="Class V">Class X</option>  
															<option value="Class V">Class XI</option>  
															<option value="Class V">Class XII</option>  
      														
														</select>
													</div>
												</div>
                                                <div class="row form-group">
													<div class="col-md-12">
														<!--<label for="activities">Information Source</label>-->
<select name="interested_in" id="interested_in" class="form-control">
                                                        <option value="" selected>Select Golf Course</option>  														
															<option value="Beginner">Beginner</option>
      														<option value="Professional">Professional</option><option value="Amateur">Amateur</option>
      														
														</select>
													</div>
												</div>
												<div class="row form-group">
												
                                                <div class="col-md-3">
												<img src="Capcha/captcha_code_file.php?rand=<?php echo rand(); ?>" id='captchaimg' class="float_l capcha-img" />
												 </div>
													<div class="col-md-6">
														
													<input id="letters_code" name="letters_code" type="text" placeholder="Enter Code" onClick="this.value='';"  style="width:132px; margin-left:10px; float:left;" class="txtfield " />
													</div>
													
													
													
                                                    <label for="date-start" style="font-size:13px; text-align:center;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Type the text displayed in image </label>
												</div>
												

												<div class="row form-group">
													<div class="col-md-12">
														<input type="submit" class="btn btn-primary btn-block" name="continue_reg"  id="conver" value="Submit" style="color:#000000; font-weight:bold; font-size:18px;">
													</div>
												</div>
											</form>	
											<?php } ?>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
							
					
				</div>
			</div>
		</div>
	</header>

	
	
	<div class="gtco-section">
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center gtco-heading">
					<h2 class="cursive-font primary-color">About SelaQui Golf Academy</h2>
					<p>The ‘SelaQui Golf Course’ is spread over an area of approx 2.38 hectares, conforms to PGA guidelines, specifications and quality, comprises of 5 Greens including one large Island Green approx 5950 sft surrounded by 3600 Water Hazard with fountains which are illuminated by night with colorful lights, 6 challenging Bunkers and integral Driving Range.  The setting is picturesque, pollution free with whispering Pine Trees and Bamboo grove in the backdrop. All greens are elevated, well manicured and play true to the line. The course is professionally designed and aesthetically landscaped with lush fairways is a treat for the eye. The Course architecture includes an underground rain and storm water drainage system and an elaborate sprinkler system for watering the golf course. The ‘SelaQui Golf Course’ is integral to the School and provides a rare opportunity for the students to take up and excel in the game. 
 
</p>
				</div>
			</div>
			
		</div>
	</div>
	
	<div id="gtco-features">
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-12 text-center gtco-heading animate-box">
                <div class="col-md-3"><span>
						<img src="images/amandeep_johl.jpg" height="300" style="float:right; border:5px #ffffff solid;"> </span>
                        </div>
					<div class="col-md-7">
                    <h2 class="cursive-font">About Amandeep Johl</h2>
                    
<p>Amandeep Johl is a former national golf champion.<br>
  Mr. Johl has played for India in the Junior Team from 1986 to 1987. He has played for India in the Amateur Team from 1987 to 1990.<br>
  He was the national amateur champion in 1989 and turned professional in 1990.</p>
                  </div>
				</div>
			</div>
			
		</div>
	</div>


	<!--<div class="gtco-cover gtco-cover-sm" style="background-image: url(images/img_bg_1.jpg)"  data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
		<div class="gtco-container text-center">
			<div class="display-t">
				<div class="display-tc">
					<h1>Integrated 2 Year Residential Program For Class - XI Science (Non-Medical/Medical) Students</h1>
					<p><a href="http://selaqui.org/registration-form.php" class="btn btn-primary" style="color:#000000;">Register Now</a></p>
				</div>	
			</div>
		</div>
	</div>-->

	<!--<div id="gtco-counter" class="gtco-section">
		<div class="gtco-container">

			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center gtco-heading animate-box">
					<h2 class="cursive-font primary-color">Testimonials</h2>
					<p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius.</p>
				</div>
			</div>

			<div class="row">
				
				<div class="col-md-3 col-sm-6 animate-box" data-animate-effect="fadeInUp">
					<div class="feature-center">
						<span class="counter js-counter" data-from="0" data-to="5" data-speed="5000" data-refresh-interval="50">1</span>
						<span class="counter-label">Avg. Rating</span>

					</div>
				</div>
				<div class="col-md-3 col-sm-6 animate-box" data-animate-effect="fadeInUp">
					<div class="feature-center">
						<span class="counter js-counter" data-from="0" data-to="43" data-speed="5000" data-refresh-interval="50">1</span>
						<span class="counter-label">Food Types</span>
					</div>
				</div>
				<div class="col-md-3 col-sm-6 animate-box" data-animate-effect="fadeInUp">
					<div class="feature-center">
						<span class="counter js-counter" data-from="0" data-to="32" data-speed="5000" data-refresh-interval="50">1</span>
						<span class="counter-label">Chef Cook</span>
					</div>
				</div>
				<div class="col-md-3 col-sm-6 animate-box" data-animate-effect="fadeInUp">
					<div class="feature-center">
						<span class="counter js-counter" data-from="0" data-to="1985" data-speed="5000" data-refresh-interval="50">1</span>
						<span class="counter-label">Year Started</span>

					</div>
				</div>
					
			</div>
		</div>
	</div>-->

	

	<div id="gtco-subscribe">
	  <div class="gtco-container">
        
		<div class="row animate-box">
		  <div class="col-md-12  text-center gtco-heading">
					<h2 class="cursive-font">Gallery</h2>
                    <div class="row">

				<div class="col-lg-4 col-md-4 col-sm-6">
					<a href="images/gallery/1.jpg" class="fh5co-card-item image-popup">
						<figure style="height:200px; margin:0; border:2px #ffffff solid;">
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="images/gallery/1.jpg" alt="Image" class="img-responsive">
						</figure>
						
					</a>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-6">
					<a href="images/gallery/2.jpg" class="fh5co-card-item image-popup">
						<figure style="height:200px; margin:0; border:2px #ffffff solid;">
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="images/gallery/2.jpg" alt="Image" class="img-responsive">
						</figure>
						
					</a>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-6">
					<a href="images/gallery/3.jpg" class="fh5co-card-item image-popup">
						<figure style="height:200px; margin:0; border:2px #ffffff solid;">
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="images/gallery/3.jpg" alt="Image" class="img-responsive">
						</figure>
						
					</a>
				</div>


				<div class="col-lg-4 col-md-4 col-sm-6">
					<a href="images/gallery/4.jpg" class="fh5co-card-item image-popup">
						<figure style="height:200px; margin:0; border:2px #ffffff solid;">
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="images/gallery/4.jpg" alt="Image" class="img-responsive">
						</figure>
						
					</a>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6">
					<a href="images/gallery/5.jpg" class="fh5co-card-item image-popup">
						<figure style="height:200px; margin:0; border:2px #ffffff solid;">
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="images/gallery/5.jpg" alt="Image" class="img-responsive">
						</figure>
						
					</a>
				</div>

				
                
                <div class="col-lg-4 col-md-4 col-sm-6">
					<a href="images/gallery/7.jpg" class="fh5co-card-item image-popup">
						<figure style="height:200px; margin:0; border:2px #ffffff solid;">
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="images/gallery/7.jpg" alt="Image" class="img-responsive">
						</figure>
						
					</a>
				</div>


                <div class="col-lg-4 col-md-4 col-sm-6">
					<a href="images/gallery/9.jpg" class="fh5co-card-item image-popup">
						<figure style="height:200px; margin:0; border:2px #ffffff solid;">
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="images/gallery/9.jpg" alt="Image" class="img-responsive">
						</figure>
						
					</a>
				</div>
                
                
                <div class="col-lg-4 col-md-4 col-sm-6">
					<a href="images/gallery/12.jpg" class="fh5co-card-item image-popup">
						<figure style="height:200px; margin:0; border:2px #ffffff solid;">
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="images/gallery/12.jpg" alt="Image" class="img-responsive">
						</figure>
						
					</a>
				</div>
                
                <div class="col-lg-4 col-md-4 col-sm-6">
					<a href="images/gallery/14.jpg" class="fh5co-card-item image-popup">
						<figure style="height:200px; margin:0; border:2px #ffffff solid;">
							<div class="overlay"><i class="ti-plus"></i></div>
							<img src="images/gallery/14.jpg" alt="Image" class="img-responsive">
						</figure>
						
					</a>
				</div>
                
			</div>
					<!--<p>Be the first to know about the new templates.</p>-->
				</div>
		  </div>
		</div>
	</div>

	<footer id="gtco-footer" role="contentinfo" style="background-image: url(images/img_5.jpg)" data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
		<div class="gtco-container">
			<div class="row row-pb-md">

				

				
				<div class="col-md-12 text-center">
					<div class="gtco-widget">
						<h3>Get In Touch</h3>
						<ul class="gtco-quick-contact">
							<li><a href="#"><i class="icon-phone"></i> 9873743433</a></li>
							<li><a href="mailto:golf@selaqui.org"><i class="icon-mail2"></i> golf@selaqui.org </a></li>
                            <!--<li><a href="#"><i class="icon-chat"></i> Live Chat</a></li>-->
						</ul>
					</div>
					<!--<div class="gtco-widget">
						<h3>Get Social</h3>
						<ul class="gtco-social-icons">
							<li><a href="#"><i class="icon-twitter"></i></a></li>
							<li><a href="#"><i class="icon-facebook"></i></a></li>
							<li><a href="#"><i class="icon-linkedin"></i></a></li>
							<li><a href="#"><i class="icon-dribbble"></i></a></li>
						</ul>
					</div>-->
				</div>

				<div class="col-md-12 text-center copyright">
					<p><small class="block">&copy; 2018. All Rights Reserved.</small> 
						<!--<small class="block">Designed by <a href="http://gettemplates.co/" target="_blank">GetTemplates.co</a> Demo Images: <a href="http://unsplash.com/" target="_blank">Unsplash</a></small>--></p>
				</div>

			</div>

			

		</div>
	</footer>
	<!-- </div> -->

	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
	
	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Carousel -->
	<script src="js/owl.carousel.min.js"></script>
	<!-- countTo -->
	<script src="js/jquery.countTo.js"></script>

	<!-- Stellar Parallax -->
	<script src="js/jquery.stellar.min.js"></script>

	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	
	<script src="js/moment.min.js"></script>
	<script src="js/bootstrap-datetimepicker.min.js"></script>


	<!-- Main -->
	<script src="js/main.js"></script>
<script>
function select_type(v)
{
	
	if(v!='')
	{
		if(v=='Student')
		{
			
			document.getElementById("study_at_div").style.display='block';
		}
		else
		{
			document.getElementById("study_at_div").style.display='none';
			document.getElementById("s_c_div").style.display='none';
			document.getElementById("class_div").style.display='none';
		}
	}
}
function select_study_at(v)
{
	//alert(v);
	if(v!='')
	{
		document.getElementById("s_c_div").style.display='block';
		document.getElementById("class_div").style.display='block';
		if(v=='School')
		{
			document.getElementById("class").innerHTML='<option value="">Select Class</option>															<option value="Class V">Class V</option><option value="Class V">Class VI</option>										<option value="Class V">Class VII</option><option value="Class V">Class VIII</option>									<option value="Class V">Class IX</option><option value="Class V">Class X</option>														<option value="Class V">Class XI</option><option value="Class V">Class XII</option>';
		}
		if(v=='College')
		{
			document.getElementById("class").innerHTML='<option value="">Select Course</option>															<option value="Under Graduate">Under Graduate</option><option value="Graduate">Graduate</option><option value="Post Graduate">Post Graduate</option>';
		}
	}
	else
	{
		document.getElementById("s_c_div").style.display='none';
		document.getElementById("class_div").style.display='none';
	}
}
</script>
	</body>
</html>

