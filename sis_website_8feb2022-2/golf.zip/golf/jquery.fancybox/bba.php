<? session_start();
$cookieval = $_SESSION["visitor"];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<base href="http://www.selaquieducation.org/" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>BBA Institutes in Dehradun, Dehradun BBA Institutes, BBA Colleges in Dehradun, Best BBA Colleges in Dehradun</title><link rel="shortcut icon" href="http://www.selaqui.org/images/favicon.ico" type="image/x-icon">
<meta name="description" content="Sela Qui University is one of the best BBA Institute in Dehradun, India offering Bachelor degree. Looking for top BBA institutes and colleges just visit at www.selaquieducation.org">

<meta name="keywords" content="bba institutes in dehradun, dehradun bba institutes, bba colleges in dehradun, top bba institutes in dehradun, beat bba colleges in dehradun, dehradun  top bba institutes , top bba colleges in dehradun, bba institutes in india, indian bba institutes">

<meta name="robots"content="index,follow">
<meta name="googlebot"content="INDEX,FOLLOW"/>
<meta name="YahooSeeker"content="INDEX,FOLLOW"/>
<meta name="msnbot" content="INDEX,FOLLOW"/>
<link href="CSS/sahe-style.css" type="text/css" rel="stylesheet" />
<link href="CSS/text.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" type="text/css" href="jquery.fancybox/jquery.fancybox.css" media="screen" />
	<script type="text/javascript" src="jquery.fancybox/jquery-1.3.2.min.js"></script>
	<script type="text/javascript" src="jquery.fancybox/jquery.easing.1.3.js"></script>
	<script type="text/javascript" src="jquery.fancybox/jquery.fancybox-1.2.1.pack.js"></script>
	<script type="text/javascript">
	$(document).ready(function() {
 
	$("a#udetail").fancybox({ 'hideOnContentClick': false ,
					  'overlayShow':true  ,
					  'frameWidth':500 ,
					  'frameHeight':400,
					  'overlayOpacity':0.7					  
					   })<? //if(!isset($_SESSION['visitor'])){ ?> //.trigger('click')<? //} ?>; 
	});
	</script>
    <script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-17463085-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
<!-- Global site tag (gtag.js) - AdWords: 1040837567 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-1040837567"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-1040837567');
</script>
</head>

<body>

<div id="mainContainer">
  <? include('include/header.php');
	     include('include/topmenu.php');
	   ?> 
  
  <div class="Banner">
    <div class="Banner-L"><img src="images/pic13.jpg" alt="BBA Institutes in Dehradun" /></div>
    <a href="user_details.php" id="udetail" class="iframe"></a> 
    <? include('include/rightbox.php'); ?>
  </div>
  <div id="body-container" style="padding-top:5px;">
  <div class="ari-12org" style="margin-bottom:10px; padding:4px 10px; margin:3px 10px 10px; width:96%; background:#ffead9; border:#fbad68 dashed 1px;"><a class="ari-12org" href="index.php">Home</a> &gt;&nbsp;<a href="/graduate-undergraduate-program"> SelaQui Graduate Schools</a> &gt; BBA</div>
    <div class="body-L">
      <? include("include/programleft.php"); ?>
    </div>
    <div class="body-R">
      <div class="body-R-L">
       
        <div class="body-R-L-content ari-11blk">
         
          <div class="highlight-box">
            <div class="highlight-box-top">
              <div class="highlight-title ari-17blk ">SelaQui Institute of Management [SIM]</div>
              <div class="cl"><img src="images/spacer.gif" height="3" /></div>
              <p class="highlight-content ari-11blk"><a href=""><strong>Bachelor of Business Administration(Honors)</strong></a>
               <br><br>
                <div align="right" style="margin-right:10px"><a style="color:#ff5400;font-size:12px;" href="admission.php?course=BBA (Hns.)">Apply Now</a></div>

<div  class="highlight-content ari-11blk">
Affiliated
with the UTU, it conducts three-year full
time undergraduate program in Business
Administration and Management, leading to
a <strong>honors degree, BBA [Honors] from UTU</strong>.
It admits class XII graduates as per prescribed
admission process and offers specialization in
any of the four focus areas:</div></p>
          </div>
            <div class="highlight-box-botm"></div>
            <div class="cl"></div>
          </div>
          <p>&nbsp;</p>
         
          <div class="highlight-box">
            <div class="highlight-box-top">
              <div class="highlight-title ari-17blk ">BBA (H) Programs</div>
              <div class="cl"><img src="images/spacer.gif" height="3" /></div>
              <p class="highlight-content ari-11blk"><strong>1. Human Resource Development</strong><br /><br />
              <strong>2. Marketing</strong><br /><br />
              <strong>3. Finance</strong><br />
              <br />
              <strong>4. Operations</strong></p>
              

              <p class="highlight-content ari-11blk"><strong><a href="">Eligibility and Processes</a></strong></p>
              <p class="highlight-content ari-11blk">XIIth pass with 70% marks for General
candidates.</p>
              <p class="highlight-content ari-11blk">Relaxation of up to 5% marks for Physically Handicapped (PH).</p>
              <p class="highlight-content ari-11blk">65% marks for widows/wards of Defense
personnel (War Casualty) category; and degree
with pass marks for SC/ST candidates.</p>
              <p class="highlight-content ari-11blk">University Counseling is not available for this
program.</p>
              <p class="highlight-content ari-11blk"><em><strong>Quotas do not apply.</strong><br />

 <strong>100% seats offered through Open Process.</strong>
                </em><br />
              </p>
            </div>
            <div class="cl"><img src="images/spacer.gif" height="15" /></div>
            <div class="highlight-box-botm"></div>
            <div class="cl"></div>
          </div>
           
          <p>&nbsp;</p>
        </div>
        <div class="cl"></div>
        
      </div>
      <div class="body-R-R">
        <? 
		$graduate=true;
		include("include/rightpanel.php") ?>
        
         
      </div>
    </div>
    <div class="cl"><img src="images/spacer.gif" height="30" /></div>
  </div>
   <? include('include/footer.php'); ?>
  <div class="cl"></div>
</div>
</body>
</html>
