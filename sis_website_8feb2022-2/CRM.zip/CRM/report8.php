<?php 
ob_start();
require_once('connection.php'); 
//$today = date("Y-m-d");
//$thisMonth=date("Y-m%");
//$time = time("H:i:s");
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Data_Report.xls");
header("Pragma: no-cache");
header("Expires: 0");
$now=date("j-n-Y");
echo "\t \t Report ON ".$now."\t";
$sql_model=mysql_query("SELECT addschool.school_id, addschool.school_name, addschool.add1, addschool.add2, addschool.city, last_contact.school_id, last_contact.joined, last_contact.status, last_contact.name, last_contact.followup, last_contact.remarkdate, members.emp_id, (SELECT count(*) FROM addcontact WHERE school_id>'".$_GET['emp_id']."' and school_id<'".($_GET['emp_id']+100000)."' and last_contact.school_id=addcontact.school_id) as contact, (SELECT other FROM addcontact WHERE school_id>'".$_GET['emp_id']."' and school_id<'".($_GET['emp_id']+100000)."' and last_contact.school_id=addcontact.school_id limit 1) as otherstep, (SELECT remarktime FROM addcontact WHERE school_id>'".$_GET['emp_id']."' and school_id<'".($_GET['emp_id']+100000)."' and last_contact.school_id=addcontact.school_id limit 1) as remtime FROM addschool, last_contact, members WHERE emp_id ='".$_GET['emp_id']."' and last_contact.school_id >'".$_GET['emp_id']."' and last_contact.school_id <'".($_GET['emp_id'] + 100000)."' and addschool.school_id=last_contact.school_id order by joined asc");
print("\n");
print("\n");
	    echo "S.No."."\t";
		echo "School Id"."\t";
		echo "School Name"."\t";
		echo "Date & Time"."\t";
		echo "Person name"."\t";
		echo "Status"."\t";
		echo "Follow Up"."\t";
		echo "Next Step"."\t";
		echo "No. of Contacts"."\t";
						
		print("\n"); 
		$i=1;
 while($row = mysql_fetch_array($sql_model))
    {
        echo $i."\t";
		echo $row['school_id']."\t";
		echo $row['school_name']."\t";
		echo $row['joined']."\t";
		echo $row['name']."\t";
		echo $row['status']."\t";
		echo $row['followup']."\t";
		echo $row['otherstep']."\t";
		echo $row['contact']."\t";
				
		print "\n";
		$i+=1;		
    }

?>