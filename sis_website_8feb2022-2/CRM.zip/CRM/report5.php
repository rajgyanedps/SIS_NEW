<?php 
ob_start();
require_once('connection.php'); 
$schoolid = $_GET['school_id'];
?>
<?php
//$today = date("Y-m-d");
//$thisMonth=date("Y-m%");
//$time = time("H:i:s");
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Amount_Report.xls");
header("Pragma: no-cache");
header("Expires: 0");
$now=date("j-n-Y");
echo "\t \t Report ON ".$now."\t";
$sql_model=mysql_query("SELECT *, addschool.school_id, addschool.school_name FROM addammount, addschool WHERE addammount.school_id ='".$_GET['school_id']."' and addschool.school_id=addammount.school_id order by addammount.joined asc");
print("\n");
print("\n");
	    echo "S.No."."\t";
		echo "School Id"."\t";
		echo "School Name"."\t";
		echo "Total Amount"."\t";
		echo "Amount Paid"."\t";
		echo "Balance Amount"."\t";
		echo "Due Date"."\t";
		echo "Cheque No."."\t";
		
		print("\n"); 
		$i=1;
 while($row = mysql_fetch_array($sql_model))
    {
        echo $i."\t";
		echo $row['school_id']."\t";
		echo $row['school_name']."\t";
		echo $row['totalamm']."\t";
		echo $row['advanceamm']."\t";
		echo $row['balanceamm']."\t";
		echo $row['duedate']."\t";
		echo $row['chequeno']."\t";
		
		print "\n";
		$i+=1;		
    }

?>