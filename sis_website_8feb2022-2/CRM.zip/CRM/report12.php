<?php 
ob_start();
session_start();
require_once('connection.php'); 
?>
<?php
//$today = date("Y-m-d");
//$thisMonth=date("Y-m%");
//$time = time("H:i:s");
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Status_Report.xls");
header("Pragma: no-cache");
header("Expires: 0");
$now=date("j-n-Y");
echo "\t \t Report ON ".$now."\t";



$sql_cust = $_SESSION['report12'];
	

		$result	= mysql_query($sql_cust) or die(mysql_error());
		
print("\n");
print("\n");
	    echo "S.No."."\t";
		echo "Student Name"."\t";
		echo "Phone No"."\t";
		echo "City"."\t";
		echo "Class"."\t";
		echo "Date(Last Update)"."\t";
		echo "Remark"."\t";
		echo "Status"."\t";
	
		
		
		print("\n"); 
		$i=1;
   while($res=mysql_fetch_array($result))
    {
        echo $i."\t";
		echo $res['stud_name']."\t";
		echo $res['phone_code'].' '.$res['phone_no']."\t";
		
		echo $res['city']."\t";
		echo $res['course']."\t";

              $Queryforremark = mysql_query("SELECT * FROM contact WHERE stud_id = '".$res['stud_id']."' ORDER BY `contact_id` DESC");
	          $ResultofRemark = mysql_fetch_array($Queryforremark,MYSQL_ASSOC);
              if($ResultofRemark['joined']!='0000-00-00'){ $joindate =  date("d-M-y",strtotime($ResultofRemark['joined']));}
		 echo $joindate."\t";
	
	if($ResultofRemark['followup']=='Other'){ $remarks =  $ResultofRemark['other']; } else { $remarks = $ResultofRemark['followup']; }
							if($ResultofRemark['remarkdate']!='0000-00-00')
							{			 
		                      $remarks.= ' '.'On'.' ';
		                      $remarks.=   date("d-M-y", strtotime($ResultofRemark['remarkdate'])).'at'. $ResultofRemark['remarktime'];
							}
		  echo $remarks."\t";
		  echo $_GET['stat'].' '. "Student"."\t";
			print "\n";
		$i+=1;		
    }

?>
					
	