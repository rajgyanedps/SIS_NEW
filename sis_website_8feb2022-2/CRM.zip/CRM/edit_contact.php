<?
session_start();
include("connection.php");
$_GET['id'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style>
.mheading{
font-size:12px;
font-family:Tahoma;
font-weight:bold;
padding:2px;
margin:0;
height:25px;
background-color:#CCCCCC;
}
</style>
<script type="text/javascript">
function showhide(val)
{
if(val.value=='OTHER')
document.getElementById('divnb').style.display='block';
else
document.getElementById('divnb').style.display='none';
}

function validate_edit()
{
// checking surname field
	  
	  if (document.edit_contact.surname.value=="")
		 {
			alert("The Surname is blank. \nPlease select the surname field in the combo box.");
			document.edit_contact.surname.focus();		
			return false;
		  }		
// checking name field
      if (document.edit_contact.name.value=="")
		 {
			alert("The Name field is blank. \nPlease enter name in the text box.");
			document.edit_contact.name.focus();
			return false;
		  }	  	    
	  
//checking alphabetic values in name

    var iChars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ';
    for (i = 0; i < document.edit_contact.name.value.length; i++)
	 {
		  if (iChars.indexOf(document.edit_contact.name.value.charAt(i)) == -1)
		   {
			 alert('Please enter letters only in Name field');
			 document.edit_contact.name.focus();
			 return false;
		   }
     }	
// checking designation field	  
	if (document.edit_contact.desig.value=="")
		 {
			alert("The designation is blank. \nPlease select the designation field in the combo box.");
			document.edit_contact.desig.focus();		
			return false;
		  }	
  
// checking otherdesig in designation (OTHER)
    if(document.edit_contact.desig.value=="OTHER")
	   {
		 if (document.edit_contact.otherdesig.value=="")
		 {
			alert("The other designation field is blank. \nPlease enter the other designation field in the text box.");
			document.edit_contact.otherdesig.focus();		
			return false;
		 }		
	  }	  
// checking phonecode field
	  
	  if (document.edit_contact.phonecode.value=="")
	 {
		alert("The Phone Code is blank. \nPlease enter the Phone Code field in the text box.");
        document.edit_contact.phonecode.focus();		
        return false;
      }
	  
//checking numeric value in phonecode
     var n = document.edit_contact.phonecode.value;
    if(isNaN(n) == true) 
	{
        alert('Your entry is not a numberic value in code no. field, Please try again');
        document.edit_contact.phonecode.focus();
        return false;
    }	  
// checking phoneno field
	  
	  if (document.edit_contact.phoneno.value=="")
	 {
		alert("The Phone No. is blank. \nPlease enter the Phone No. field in the text box.");
        document.edit_contact.phoneno.focus();		
        return false;
      }
	  
//checking numeric value in phoneno
     var n = document.edit_contact.phoneno.value;
    if(isNaN(n) == true)
	 {
        alert('Your entry is not a numberic value in phone no. field, Please try again');
        document.edit_contact.phoneno.focus();
        return false;
    }	  	
// checking mobno field
	  
	  if (document.edit_contact.mobno.value=="")
	 {
		alert("The Mob. No. is blank. \nPlease enter the Mob. No. field in the text box.");
        document.edit_contact.mobno.focus();		
        return false;
      }
	  
//checking numeric value in mobno
     var n = document.edit_contact.mobno.value;
    if(isNaN(n) == true)
	 {
        alert('Your entry is not a numberic value in mob. no. field, Please try again');
        document.edit_contact.mobno.focus();
        return false;
    }	  		  
//checking numeric value in faxcode
     var n = document.edit_contact.faxcode.value;
    if(isNaN(n) == true) 
	{
        alert('Your entry is not a numberic value in code no. field, Please try again');
        document.edit_contact.faxcode.focus();
        return false;
    }	  
//checking numeric value in faxno
     var n = document.edit_contact.faxno.value;
    if(isNaN(n) == true)
	 {
        alert('Your entry is not a numberic value in fax no. field, Please try again');
        document.edit_contact.faxno.focus();
        return false;
    }
	return true;	  	  		
	  }

</script>
</head>
<?
if(isset($_POST['edit']))
{

$sql="UPDATE addperson SET surname='".$_POST['surname']."',name='".$_POST['name']."',desig='".$_POST['desig']."',otherdesig='".$_POST['otherdesig']."',phonecode='".$_POST['phonecode']."',phoneno='".$_POST['phoneno']."',mobno='".$_POST['mobno']."',faxcode='".$_POST['faxcode']."',faxno='".$_POST['faxno']."',email='".$_POST['email']."' WHERE school_id='".$_POST['school_id']."' and id='".$_GET['id']."'";

$result=mysql_query($sql) or die(mysql_error());

?>
<script language="javascript">
 parent.location.reload();
 </script>
        <?

}
?>
<body>
<form name="edit_contact" action="" method="post"  onsubmit="return validate_edit();">
<table border="0" align="center"  bgcolor="#f3f7fd" cellpadding="8" cellspacing="0" style="border:solid 1px #71befb;"> 
<tr>
  <td background="butbg.gif" height="10px" style="border-bottom:solid 1px #71befb; font-family:Verdana, Arial; font-size:13px; color:#064582;">&nbsp;&nbsp;<b>Edit Contact Person</b></td>
</tr>
<?
$sql_cust = "SELECT * FROM addperson WHERE school_id='".$_GET['school_id']."' and id='".$_GET['id']."'";
$result = mysql_query($sql_cust);
$row = mysql_fetch_array($result);

?>

<tr><td>
<table width="464" align="center" style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:13px">

<tr><td colspan="3"></td></tr>
<tr>
<input type="hidden" name="school_id" value="<?= $_GET['school_id']?>">
<td>Surname</td>
<td>:</td>
<td><select name="surname" style="height:20px; border:solid 1px #61b5f8; background-color:#FFFFFF;"> >
<option value="">--Select--</option>
<option value="Mr." <? if($row['surname']=='Mr.') echo "selected";?>>Mr.</option>
<option value="Mrs." <? if($row['surname']=='Mrs.') echo "selected";?>>Mrs.</option>
<option value="Miss" <? if($row['surname']=='Miss') echo "selected";?>>Miss</option>
<option value="Dr." <? if($row['surname']=='Dr.') echo "selected";?>>Dr.</option>
<option value="Col." <? if($row['surname']=='Col.') echo "selected";?>>Col.</option>
<option value="Sis." <? if($row['surname']=='Sis.') echo "selected";?>>Sis.</option>
<option value="Fr." <? if($row['surname']=='Fr.') echo "selected";?>>Fr.</option>
</select>&nbsp;<font color="#FF0000"><b>*</b></font></td>
</tr>
<tr><td>Name</td>
<td>:</td>
<td><input type="text" name="name" size="40" value="<?=$row['name']?>" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" />&nbsp;<font color="#FF0000"><b>*</b></font></td>
</tr>
<tr><td>Designation</td>
<td>:</td>
<td><select name="desig" onchange="showhide(this)" style="height:20px; border:solid 1px #61b5f8; background-color:#FFFFFF;">
<option value="">--Select--</option>
<option value="Chairman" <? if($row['desig']=='Chairman') echo "selected";?>>Chairman</option>
<option value="Principal" <? if($row['desig']=='Principal') echo "selected";?>>Principal</option>
<option value="Owner" <? if($row['desig']=='Owner') echo "selected";?>>Owner</option>
<option value="Vice Principal" <? if($row['desig']=='Vice Principal') echo "selected";?>>Vice Principal</option>
<option value="Management Member" <? if($row['desig']=='Management Member') echo "selected";?>>Management Member</option>
<option value="School Coordinator" <? if($row['desig']=='School Coordinator') echo "selected";?>>School Coordinator</option>
<option value="Senior Teacher" <? if($row['desig']=='Senior Teacher') echo "selected";?>>Senior Teacher</option>
<option value="Teacher" <? if($row['desig']=='Teacher') echo "selected";?>>Teacher</option>
<option value="OTHER" <? if($row['desig']=='OTHER') echo "selected";?>>OTHER</option>
</select>&nbsp;<font color="#FF0000"><b>*</b></font></td></tr>
<tr><td>Other Designation</td>
<td>:</td>
<td><div id="divnb" style="display:none"><input type="text" name="otherdesig" size="40" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" />&nbsp;<font color="#FF0000"><b>*</b></font></div></td></tr>
<tr><td>Code No.</td>
<td>:</td>
<td><input type="text" name="phonecode" value="<?=$row['phonecode']?>" size="40" maxlength="5" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" />&nbsp;<font color="#FF0000"><b>*</b></font></td></tr>
<tr><td>Phone No.</td>
<td>:</td>
<td><input type="text" name="phoneno" value="<?=$row['phoneno']?>" size="40" maxlength="8" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" />&nbsp;<font color="#FF0000"><b>*</b></font></td>
</tr>
<tr><td>Mobile No.</td>
<td>:</td>
<td><input type="text" name="mobno" value="<?=$row['mobno']?>" size="40" maxlength="11" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" />&nbsp;<font color="#FF0000"><b>*</b></font></td></tr>
<tr><td>Code No.</td>
<td>:</td>
<td><input type="text" name="faxcode" value="<?=$row['faxcode']?>"  size="40" maxlength="5" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" /></td></tr>
<tr><td>Fax No.</td>
<td>:</td>
<td><input type="text" name="faxno" value="<?=$row['faxno']?>" size="40" maxlength="8" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" /></td></tr>
<tr><td>Email Id</td>
<td>:</td>
<td><input type="text" name="email" value="<?=$row['email']?>" size="40" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" /></td></tr>
<tr><td colspan="3"></td></tr>
<tr><td colspan="3"></td></tr><tr><td colspan="3"></td></tr><tr><td colspan="3"></td></tr>
<tr><td align="center" colspan="3"><input type="submit" name="edit" value="Submit" />
</td></tr>
<tr><td colspan="4"></td></tr>
</table>
</td></tr></table>
    </form>

</body>
</html>
