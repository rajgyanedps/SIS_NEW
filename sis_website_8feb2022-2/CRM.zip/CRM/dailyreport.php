<?php
session_start();
include("connection.php");
if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='Project Manager' && $_SESSION['user_type']!='Tele Caller')
//if (!isset($_SESSION[myusername]))
{
 header("Location: index.php");
}
$_SESSION['this_page']='dailyreport.php';
?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Employee Total Call Report</title>
<link rel="stylesheet" type="text/css" href="calendar-blue.css">
<script type="text/javascript" src="calendar.js"></script>
<script type="text/javascript" src="calendar-en.js"></script>
<script type="text/javascript" src="calendar-setup.js"></script>
<script language="javascript1.2" src="tabber.js"></script>

<script type="text/javascript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php
include("header.php");
?>
<br />

<form action="dailyreport.php" method="get" name="dailyreport">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Search Datewise report</b>
  <img src="CalendarIcon.gif" name="get_stud_date1" width="22" height="23" border="0" align="absmiddle" id="get_stud_date1" style="cursor: pointer;" title="Date selector" onMouseOver="this.style.background='red';" onMouseOut="this.style.background=''" />
  &nbsp;<input type="text" name="date1" size="10" id="date1" onChange="setdt();" />
    <script type="text/javascript">
	  	Calendar.setup({
        inputField     :    "date1",     // id of the input field
	    //ifFormat       :    "%Y/%m/%d %l:%M %P",      // format of the input field
	  	//ifFormat       :    "%m-%d-%Y",      // format of the input field
	  	ifFormat       :    "%Y-%m-%d",      // format of the input field
        button         :    "get_stud_date1",  // trigger for the calendar (button ID)
        align          :    "Tl",           // alignment (defaults to "Bl")
        singleClick    :    true,
		showsTime		:	true
    });

        </script>

&nbsp;&nbsp;<input type="submit" name="Submit" value="Search" />
   
</form>
   <? 				
if (isset($_GET['date1']))
{
$dt=$_GET['date1'];
}
else
{
$dt=date('Y-m-d');
}
 ?>
 <br />
<font size="3px" color="#000000" style="padding-left:20px"><b>Call Report: <?php echo date("d-M-y",strtotime($dt));?></b></font>

<table width="100%" border="1" align="center" cellpadding="5" cellspacing="2" style="font-size:13px">

<tr bgcolor="#999999" align="center">

      <td width="5%" align="left" background="footerbg.jpg" class="whitetxt11">S.No.</td>
      <td width="25%" align="left" background="footerbg.jpg" class="whitetxt11">Employee name</td>
      <td width="30%" align="left" background="footerbg.jpg" class="whitetxt11">No. of School Contact</td>
      <td width="13%" align="left" background="footerbg.jpg" class="whitetxt11">Positive</td>
      <td width="12%" align="left" background="footerbg.jpg" class="whitetxt11">Negative</td>
      <td width="15%" align="left" background="footerbg.jpg" class="whitetxt11">Moderate</td>
      
    </tr>
<? 


	$sql_cust = "SELECT emp_id,emp_name, (select count(*) from last_contact where DATE(joined)='$dt' and school_id>emp_id and school_id<emp_id+100000) as scontact, (select count(*) from last_contact where DATE(joined)='$dt' and status='Positive' and school_id>emp_id and school_id<emp_id+100000) as pcontact, (select count(*) from last_contact where DATE(joined)='$dt' and status='Negative' and school_id>emp_id and school_id<emp_id+100000) as ncontact, (select count(*) from last_contact where  DATE(joined)='$dt' and status='Moderate' and school_id>emp_id and school_id<emp_id+100000) as mcontact FROM members";

		$result	= mysql_query($sql_cust) or die(mysql_error());
		$count = 0;
		while($res=mysql_fetch_array($result))
{         
     
$dd = date("d-M-y",strtotime($res['remarkdate']));

if($acol) {
	           $x = "bgcolor='#F0F0F0'";
	          } else {
	            $x = "bgcolor='#D8D8D8'";
 	          }
			  $acol=!$acol;
			  $count++;
?>

<tr <?=$x;?> align="left">

      <td width="5%"><? echo $count;?>.</td>
        
                <td width="25%"><?php echo $res['emp_name'];?></td>
                  <td width="30%"><a href="#" onclick="MM_openBrWindow('dailycallreport.php?emp_id=<?php echo $res['emp_id'];?>&amp;fromdate=<?=$dt?>','CallReport','toolbar=yes,location=yes,status=yes,menubar=yes,scrollbars=yes,resizable=yes')"><?php echo $res['scontact'];?></a></td>
    <td width="13%"><a href="#" onclick="MM_openBrWindow('dailycallreport.php?emp_id=<?php echo $res['emp_id'];?>&amp;stat=Positive&amp;fromdate=<?=$dt?>','CallReport','toolbar=yes,location=yes,status=yes,menubar=yes,scrollbars=yes,resizable=yes')"><?php echo $res['pcontact'];?></a></td>
    <td width="12%"><a href="#" onclick="MM_openBrWindow('dailycallreport.php?emp_id=<?php echo $res['emp_id'];?>&amp;stat=Negative&amp;fromdate=<?=$dt?>','CallReport','toolbar=yes,location=yes,status=yes,menubar=yes,scrollbars=yes,resizable=yes')"><?php echo $res['ncontact'];?></a></td>
    <td width="15%"><a href="#" onclick="MM_openBrWindow('dailycallreport.php?emp_id=<?php echo $res['emp_id'];?>&amp;stat=Moderate&amp;fromdate=<?=$dt?>','CallReport','toolbar=yes,location=yes,status=yes,menubar=yes,scrollbars=yes,resizable=yes')"><?php echo $res['mcontact'];?></a></td>
                         
                        
  </tr>
                         
 
  <?
}
?>
                  
                </table>				  
			   
<table width="100%" align="center">
<tr>
<td class="footer" width="942" >&copy; 2009 TeacherSITY. All rights reserved</td>
</tr>

</table>
 


</body>
</html>