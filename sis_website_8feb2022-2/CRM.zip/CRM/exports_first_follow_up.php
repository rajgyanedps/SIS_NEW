<?php 
session_start();
include("connection.php");
error_reporting(0);
@extract($_GET);
@extract($_POST); 
$empid=$_REQUEST['empid'];
$infosearch=$_REQUEST['info_search'];
if(isset($_GET['empid']) && $_GET['empid']!=''){
				$strqry=" and student.emp_id='".$_GET['empid']."'";
			}
if($_GET['info_search']!= '') {
				$key2="and student.status = '".$_GET['info_search']."'";
				//$_GET['info_search']="";
			} else {
				$key2=" ";
			}
if(strlen($_GET['keyword'])>0){
				$key="%".$_GET['keyword'];
			} else {
				$key="";
			}
if($_REQUEST['from']!="" && $_REQUEST['to']!="") {
				$from1=$_REQUEST['from'];
				$to1=$_REQUEST['to'];
				$from=date('Y-m-d',strtotime("$from1"));
				$to=date('Y-m-d',strtotime("$to1"));
				$t=" and date(student.joined)>='$from' AND date(student.joined)<='$to'"; 
				
			} else {
				$t="";
			}
			if($order_by!="") {
    	$KEYWORD_SEARCH_5="ORDER BY $order_by $img_name";
    } else {
    	$KEYWORD_SEARCH_5="ORDER BY joined DESC, student.stud_id DESC";
    }
	if( $empid > 0){
	$enqqry= "SELECT student. * ,members.emp_id, members.emp_name FROM members inner join student on members.emp_id =student.emp_id WHERE project_id!='5' and stud_name LIKE '".$_GET['schoolname1']."%' ".$key2."  and (add1 like '".$key."%' or add2 like '".$key."%' or state like '".$key."%' or city like '".$key."%') ".$strqry.$t."  $KEYWORD_SEARCH_5  ";

	}else{
	$enqqry= "SELECT student. * ,members.emp_id, members.emp_name FROM members inner join student on members.emp_id =student.emp_id WHERE project_id!='5' and  stud_name LIKE '".$_GET['schoolname1']."%' ".$key2."  and (add1 like '".$key."%' or add2 like '".$key."%' or state like '".$key."%' or city like '".$key."%') ".$strqry.$t."  $KEYWORD_SEARCH_5  ";
	}

   
  header("Pragma: public");
    header("Expires: 0");
    header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
    header("Content-Type: application/force-download");
    header("Content-Type: application/octet-stream");
    header("Content-Type: application/download");;
    header("Content-Disposition: attachment;filename=export_first_follow_up.xls "); 
    header("Content-Transfer-Encoding: binary ");



$enqqry;
$enqqry1;
$enqres=mysql_query($enqqry) or die(mysql_error());
	?>
    <table border="1" cellpadding="1" cellspacing="1" >
		<tr bgcolor="#E8E8E8" style="font:Verdana, Arial, Helvetica, sans-serif">
			<?php
				echo "<th>Sr. No.</th>"."\t";
				echo "<th>Stud_id</th>"."\t";
				echo "<th>Student Name</th>"."\t";
				echo "<th>Enquiry Date</th>"."\t";
				echo "<th>Course</th>"."\t";
				echo "<th>Status</th>"."\t";
				echo "<th>Followup</th>"."\t";
				echo "<th>First_followup</th>"."\t";
				echo "<th>Gaps in days</th>"."\t";
				//echo "Date"."\t";
				print("\n"); 
			?>
		</tr>
        <?php	
          $i=1;
            while($row_application = mysql_fetch_array($enqres)) {  
			    $sel="select * from contact  where stud_id = '".$row_application['stud_id']."' order by contact_id ASC limit 1";
                $qry = mysql_query($sel);
                $res = mysql_fetch_assoc($qry);
			    if($res['joined']!=''){
					$date1 = new DateTime($row_application['joined']);
					$date2 = new DateTime($res['joined']);
					$interval = $date1->diff($date2);
					$date_a = new DateTime($row_application['joined']);
					$date_b = new DateTime($res['joined']);
					$interval = date_diff($date_a,$date_b);
					$interval='+'.$interval->days.' Days ,Time Diff: '.$time=$interval->format('%h:%i:%s').'(hh:mm:ss)';
				}else{
				    $interval='Follow up date not avaliable';
				}
                // shows the total amount of days (not divided into years, months and days like above)
                    echo "<tr>"; 
					echo "<td>".$i."</td>"."\t";
					echo "<td>".$row_application['stud_id']."</td>"."\t";
					echo "<td>".$row_application['stud_name']."</td>"."\t";
					echo "<td>".$row_application['joined']."</td>"."\t";
					echo "<td>".$row_application['course']."</td>"."\t";
					echo "<td>".$row_application['status']."</td>"."\t";
				//  echo    $sel="select t1.other, t1.joined, t2.emp_id from contact as t1 inner join student as t2 on //t1.stud_id= t2.stud_id where t2.emp_id = '".$_REQUEST['empid']."' order by joined desc limit 1";
                //$qry = mysql_query($sel);
                //   $res = mysql_fetch_assoc($qry);
                if($res['followup'] == 'Other'){
				//echo trim($res11['other'])."\t";
				    echo "<td>".str_replace(array("\r\n", "\r", "\n", "\t"), ' ',$res['other'])."</td>"."\t";
			    }else{
				    echo "<td>".str_replace(array("\r\n", "\r", "\n", "\t"), ' ', $res['remarktime'])."</td>"."\t";
				//echo trim($res11['followup'])."\t";
		        }
				//	echo "<td>".$res['other']."</td>"."\t";
                    echo "<td>".$res['joined']."</td>"."\t";
					echo "<td>".$interval."</td>"."\t";
					print "\n";	
					echo "</tr>";
			     $i++;
			}
           //echo date("d-M-Y",strtotime($row_application['entered_date']))."\t";
         ?>

      </table>
    