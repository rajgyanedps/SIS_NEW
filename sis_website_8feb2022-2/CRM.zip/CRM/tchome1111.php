<?php
session_start();
include("automatic.php");
include("connection.php");
if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='Project Manager' && $_SESSION['user_type']!='Tele Caller')
//if (!isset($_SESSION[myusername]))
{
 header("Location: index.php");
}
?>
<?
$_SESSION['this_page']='tchome.php';

@extract($_GET);

if($order_by!="")
{	
	$KEYWORD_SEARCH_5="ORDER BY $order_by $img_name"; 
}
else
{
	$KEYWORD_SEARCH_5="ORDER BY school_id ASC";
}	




?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Tele Caller Home Page</title>
<script type="text/javascript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php
include("header.php");
?>
<div align="center" class="msg">
  <?=$_GET['msg1']; ?>
</div>
<?php
$sql = "select count(*) as totalmsg from message WHERE `to`='".$_SESSION['emp_id']."'";
$result1 = mysql_query($sql);
$res1 = mysql_fetch_array($result1);
?>
<? if($res1['totalmsg']=='0')
{
}
else
{?>
<div align="center"><font size="3px">You have received&nbsp;<strong><? echo $res1['totalmsg'];?></strong>&nbsp;Leads&nbsp;&nbsp;<a href="seemsg.php">View All</a></font></div>
<? }?>
<!--<div align="right"><font size="3px" style="padding-right:10px"><a href="#" onClick="MM_openBrWindow('Brochure TeacherSITY-ACER.pdf','CallReport','toolbar=yes,location=yes,status=yes,menubar=yes,scrollbars=yes,resizable=yes')"><b>Download TeacherSITY-ACER Brochure</b></a></font><br />
  <font size="3px" style="padding-right:10px"><a href="#" onClick="MM_openBrWindow('Doc ACER.pdf','CallReport','toolbar=yes,location=yes,status=yes,menubar=yes,scrollbars=yes,resizable=yes')"><b>Download Frequently Asked Question(FAQ)</b></a></font></div>-->
<div style="clear:both"></div>
<? 
$sql_cust10 = "SELECT * FROM task inner join members on members.emp_id=task.recipient_id WHERE recipient_id='".$_SESSION['emp_id']."' and status='Pending'";
	
$result10	= mysql_query($sql_cust10) or die(mysql_error());
		$num_rows10 = mysql_num_rows($result10);
		$res10=mysql_fetch_array($result10);
?>
<table width="100%">
  <tr>
    <td style="padding-left:20px; padding-bottom:5px; background-color:#f3f7fd;"><font size="3px" color="#FF0000">
      <?=$num_rows10 ?>
      &nbsp;Pending Task <a href="taskuser.php">Click here to view</a></font></td>
  </tr>
</table>
<table align="center" width="100%">
  <tr>
    <td width="100%"><form action="tchome.php" method="get" name="tchome">
        <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#f3f7fd;border:solid 1px #88c9fd;">
          <tr>
            <td height="20" colspan="7" align="center" valign="middle" background="butbg.gif"><marquee behavior="slide" direction="left">
              <font size="4.5" face="Verdana, Arial, Helvetica, sans-serif"><b>Search Student</b></font>
            </marquee></td>
          </tr>
          
          <tr>
            <td width="7%" height="35" valign="middle" style="padding-left:15px"><b>Search By </b></td>
            <td width="2%" valign="middle"><b>:</b></td>
            <td width="7%" valign="middle"><b>Student Name</b></td>
            <td width="16%" valign="middle"><input type="text" name="schoolname1" size="30" style="border:solid 1px #61b5f8;font-size:12px;width:145px; color:#0a5095;background-color:#ffffff;" /></td>
            <td width="3%" valign="middle"><b>City</b></td>
            <td valign="middle"><input type="text" name="city1" size="25" style="border:solid 1px #61b5f8;font-size:12px;width:145px; color:#0a5095;background-color:#ffffff;"/>
              &nbsp;
              <input type="submit" name="submit" value="Search" /></td>
            <td align="right" valign="middle"><font size="3px" color="#FF0000"><b>PENDING TASKS &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></td>
          </tr>
          <tr>
            <td colspan="5"></td>
          </tr>
          <tr>
            <td colspan="5"></td>
          </tr>
        </table>
        <br />
        <table align="center" width="100%">
          <tr>
            <td width="40%" valign="top"><table width="100%" border="0" align="center" cellpadding="5" cellspacing="1" bgcolor="#81cafd" style="font-size:13px">
                <tr bgcolor="#999999" align="center">
                  <td width="11%" height="25" align="left" background="footerbg.jpg" class="whitetxt11">S.No.</td>
                  <td align="left" background="footerbg.jpg" class="whitetxt11" width="24%">
                  
                
                  
                  <? if($_GET['img_name']=='desc' && $_GET['order_by']=='school_name')
   				  { 
 				  ?>
                 
						 <a href="tchome.php?order_by=school_name&img_name=asc"><strong>Student Name&nbsp;</strong><img src="image/asc.gif" alt="Descending Order" border="0"></a>
 				<? 
    			} 
				else 
				{ 
				?>
    					<a href="tchome.php?order_by=school_name&img_name=desc"><strong>Student Name&nbsp;</strong><img src="image/dsc.gif" alt="Ascending Order" border="0"></a>
				<?
				}
				?>	
                  
                  
                  </td>
                  <td align="left" background="footerbg.jpg" class="whitetxt11" width="16%">
                  
                 
                  
                  <? if($_GET['img_name']=='desc' && $_GET['order_by']=='city')
   				  { 
 				  ?>
						 <a href="tchome.php?order_by=city&img_name=asc"><strong>City&nbsp;</strong><img src="image/asc.gif" alt="Descending Order" border="0"></a>
 				<? 
    			} 
				else 
				{ 
				?>
    					<a href="tchome.php?order_by=city&img_name=desc"><strong>City&nbsp;</strong><img src="image/dsc.gif" alt="Ascending Order" border="0"></a>
				<?
				}
				?>	
                  
                  
                  
                  
                  </td>
                  <td align="left" background="footerbg.jpg" class="whitetxt11" width="32%">Last Status</td>
                  <td align="left" background="footerbg.jpg" class="whitetxt11" width="17%">Date</td>
                </tr>
                <?php
$sql_cust = "SELECT addschool.school_id, addschool.school_name, addschool.city, last_contact.status, (SELECT msgdate from message WHERE message.school_id=addschool.school_id ORDER BY msgdate DESC LIMIT 1) as leaddate FROM addschool
LEFT JOIN last_contact ON addschool.school_id = last_contact.school_id where addschool.school_id >'".$_SESSION['emp_id']."' and addschool.school_id <'".($_SESSION['emp_id'] + 100000)."' and school_name like '".trim($_GET['schoolname1'])."%' and city like '".trim($_GET['city1'])."%' $KEYWORD_SEARCH_5";
$result	= mysql_query($sql_cust) or die(mysql_error());
$num_rows 	= mysql_num_rows($result);	
if($num_rows==0)
		{
		echo "<div align=center><font color=red size=+1>No Record Found</font></div>";
		}
		$incr = 1;
		
		if(!$_REQUEST['spageno']){
			$spageno = 1;
		} else {
			$spageno= $_REQUEST['spageno'];
		}
		$spagesize=50;
		$incr = (($spageno-1)*$spagesize)+1;
		$first=$spageno*$spagesize-($spagesize-1);
		$last=$first+$spagesize-1; 
		$temp=($num_rows%$spagesize);
		if ($temp==0)
		$spages=($num_rows/$spagesize);
		else
		$spages=($num_rows/$spagesize)+1;
		settype($spages, "integer"); 

		for($i=1;$i<$first;$i++)
			$row2000=mysql_fetch_row($result);
     
	 
//<?php
//$query="SELECT * FROM addschool";
//$result=mysql_query($query) or die(mysql_error());
while($res=mysql_fetch_array($result) and ($first<=$last))
{
if($res['leaddate']=="")$dd ='-'; else $dd = date("d-M-y",strtotime($res['leaddate']));
if($i%2==0) {
	           $x = "bgcolor='#e9f5ff'";
	          } else {
	            $x = "bgcolor='#d8effe'";
 	          }
?>
                <tr <? if (date("Y-M-d",strtotime($res['leaddate']))==date("Y-M-d",strtotime("-1 days")) || date("Y-M-d",strtotime($res['leaddate']))==date("Y-M-d"))
 { echo 'bgcolor="#FFCCCC"'; } else { echo $x; } ?> align="left">
                  <td width="11%"><? echo $i;?>.</td>
                  <td width="24%"><a href="11.php?school_id=<? echo $res['school_id'];?>"><?php echo $res['school_name'];?></a></td>
                  <td width="16%"><?php echo $res['city'];?></td>
                  <td width="32%" align="center"><?php if($res['status']=='Positive'){?>
                    <img src="image/green.gif" border="0" name="plus_sign" alt="Click here to view positive report" align="center"/>
                    <? } else if($res['status']=='Negative'){ ?>
                    <img src="image/red.gif" border="0" name="minus_sign" alt="Click here to view negative report" align="center"/>
                    <? } else if($res['status']=='Moderate'){ ?>
                    <img src="image/mod.gif" border="0" name="minus_sign" align="center"/>
                    <? } else if($res['status']=='Paid'){ ?>
                    <img src="image/paddy-smiley26.gif" border="0" name="paid" alt="Paid School" align="center" />
                  <? }else echo "-";?></td>
                  <td width="17%"><?php echo $dd;?></td>
                </tr>
                <? 
	 	  $incr++;
	$first++;	
  $i=$i+1;
  } 
	?>
              </table>
              <? if($num_rows > 0){	?>
              <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                <tr>
                  <td colspan="3"><img src="image/spacer.gif" height="3" /></td>
                </tr>
                <tr>
                  <td   height="26"  valign="middle" background="newbar.jpg" class="table_td_heading" style="padding-left:5px;" width="60%"><span class="table_td_heading">Pages:
                    <? if ($spageno==1) { ?>
                    &nbsp;
                    <? } else {?>
                    <a href="tchome.php?spageno=<?=$spageno-1?>&tpageno=<?=$_REQUEST['tpageno']?>&schoolname1=<?= $_GET['schoolname1'] ?>&keyword=<?=$_GET['keyword']?>&img_name=<?=$_GET['img_name']?>&order_by=<?=$_GET['order_by']?>" class="table_td_heading">Previous</a>
                    <? } 
					for ($i=1; $i<=$spages;$i++)
					{
					if($spageno==$i)	{?>
                    <strong class="table_td_heading"><? echo $i;?></strong>
                    <? }
						else
					{
					if($i%5==0)
{


					
					?>
                    <strong><a class="table_td_heading" href="tchome.php?spageno=<?=$i?>&tpageno=<?=$_REQUEST['tpageno']?>&schoolname1=<?= $_GET['schoolname1'] ?>&keyword=<?=$_GET['keyword']?>&img_name=<?=$_GET['img_name']?>&order_by=<?=$_GET['order_by']?>">
                    <?=$i?>
                    </a></font></strong>
                    <? 
					}
					}
					}
					?>
                    <? if ($spageno<$spages) { ?>
                    <a href="tchome.php?spageno=<?=$spageno+1?>&tpageno=<?=$_REQUEST['tpageno']?>&schoolname1=<?= $_GET['schoolname1'] ?>&keyword=<?=$_GET['keyword']?>&img_name=<?=$_GET['img_name']?>&order_by=<?=$_GET['order_by']?>" class="table_td_heading">Next</a>
                    <? } else {?>
                    <? } ?>
                    </span></td>
                  <td width="10%" align="right" valign="middle" background="newbar.jpg" class="data"><!--DWLayoutEmptyCell-->&nbsp;</td>
                  <td width="30%" align="center" valign="middle" background="newbar.jpg" class="data"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td align="right" valign="middle" class="table_td_heading" style="padding-right:5px;" width="100%"><strong>Page</strong>&nbsp;
                          <?=$spageno?>
                          &nbsp;of&nbsp;
                          <?=$spages?>
                        </td>
                      </tr>
                    </table></td>
                </tr>
                <tr>
                  <td colspan="3">&nbsp;</td>
                </tr>
                <tr>
                  <td align="center" valign="middle" colspan="3"><input type="button" name="Back" value="  Back  " onclick="javascript:history.go(-1)" /></td>
                </tr>
              </table></td>
            <td width="60%" valign="top"><table width="100%" border="0" align="center" cellpadding="5" cellspacing="1" bgcolor="#81cafd" style="font-size:13px">
                <tr bgcolor="#999999" align="center">
                  <td width="5%" height="25" align="left" background="footerbg.jpg" class="whitetxt11">S.No.</td>
                  <td align="left" background="footerbg.jpg" class="whitetxt11" width="22%">Student Name</td>
                  <td align="left" background="footerbg.jpg" class="whitetxt11" width="17%">Person</td>
                  <td align="left" background="footerbg.jpg" class="whitetxt11" width="13%">Date</td>
                  <td align="left" background="footerbg.jpg" class="whitetxt11" width="13%">Time</td>
                  <td align="left" background="footerbg.jpg" class="whitetxt11" width="13%">Follow Up</td>
                  <td align="left" background="footerbg.jpg" class="whitetxt11" width="17%">Next Step</td>
                </tr>
                <?php

	$sql_cust = "SELECT *, (select other from addcontact where  addcontact.school_id=addschool.school_id order by joined desc limit 1) as othernextstep, (select remarktime from addcontact where  addcontact.school_id=addschool.school_id order by joined desc limit 1) as remtime FROM addschool,last_contact where last_contact.school_id >'".$_SESSION['emp_id']."' and last_contact.school_id <'".($_SESSION['emp_id'] + 100000)."' and last_contact.school_id=addschool.school_id AND remarkdate > '2009-10-01' and last_contact.status!='Negative' order by remarkdate desc";
	
$result	= mysql_query($sql_cust) or die(mysql_error());
		$num_rows 	= mysql_num_rows($result);	
		
		$incr = 1;
		
		if(!$_REQUEST['tpageno']){
			$tpageno = 1;
		} else {
			$tpageno= $_REQUEST['tpageno'];
		}
		$tpagesize=50;
		$incr = (($tpageno-1)*$tpagesize)+1;
		$first=$tpageno*$tpagesize-($tpagesize-1);
		$last=$first+$tpagesize-1; 
		$temp=($num_rows%$tpagesize);
		if ($temp==0)
		$tpages=($num_rows/$tpagesize);
		else
		$tpages=($num_rows/$tpagesize)+1;
		settype($tpages, "integer"); 

		for($i=1;$i<$first;$i++)
			$row2000=mysql_fetch_row($result);
     
     
     
//<?php
//$query="SELECT * FROM addschool";
//$result=mysql_query($query) or die(mysql_error());
while($res=mysql_fetch_array($result) and ($first<=$last))
{
if($i%2==0) {
	           $x = "bgcolor='#e9f5ff'";
	          } else {
	            $x = "bgcolor='#d8effe'";
 	          }
?>
                <tr <?=$x;?> align="left">
                  <td width="5%"><? echo $i;?>.</td>
                  <td width="22%"><?
 if(date("Y-M-d",strtotime($res['remarkdate']))<=date("Y-M-d") && $res['status']!='Paid')
 {
 ?>
                    <font color="#FF0000"><blink><strong><a href="11.php?school_id=<? echo $res['school_id'];?>"><?php echo $res['school_name'];?></a></strong></blink></font>
                    <? 
 }
 else 
 {
 ?>
                    <a href="11.php?school_id=<? echo $res['school_id'];?>"><?php echo $res['school_name'];?></a>
                    <? 
 } 
 ?>
                  </td>
                  <td width="17%"><? if(date("Y-M-d",strtotime($res['remarkdate']))<=date("Y-M-d") && $res['status']!='Paid')
 {
 ?>
                    <font color="#009900"><blink><strong><?php echo $res['name'];?></strong></blink></font>
                    <? 
 }
 else 
 {
 ?>
                    <?php echo $res['name'];?>
                    <? 
 } 
 ?>
                  </td>
                  <td width="13%"><? if(date("Y-M-d",strtotime($res['remarkdate']))<=date("Y-M-d") && $res['status']!='Paid')
 {?>
                    <font color="#FF0000"><blink><strong><?php echo date("d-M-y",strtotime($res['remarkdate']));?></strong></blink></font>
                    <? }
 else 
 {?>
                    <?php echo date("d-M-y",strtotime($res['remarkdate']));?>
                    <? 
 } ?>
                  </td>
                  <td width="13%"><?php echo $res['remtime'];?></td>
                  <td width="13%"><?php echo $res['followup'];?></td>
                  <td width="17%"><?php echo $res['othernextstep'];?></td>
                </tr>
                <? 
	 	  $incr++;
	$first++;	
  $i=$i+1;
  } 
	?>
              </table>
              <? if($num_rows > 0){	?>
              <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                <tr>
                  <td colspan="3"><img src="image/spacer.gif" height="3" /></td>
                </tr>
                <tr>
                  <td height="26" valign="middle" background="newbar.jpg" width="60%" class="table_td_heading" style="padding-left:5px;"><span class="table_td_heading">Pages:
                    <? if ($tpageno==1) { ?>
                    &nbsp;
                    <? } else {?>
                    <a href="tchome.php?tpageno=<?=$tpageno-1?>&spageno=<?=$spageno?>" class="table_td_heading">Previous</a>
                    <? } 
					for ($i=1; $i<=$tpages;$i++)
					{
					if($tpageno==$i)	{?>
                    <strong class="table_td_heading"><? echo $i;?></strong>
                    <? }
						else
					{
					if($i%5==0)
{
					?>
                    <strong><a class="table_td_heading" href="tchome.php?tpageno=<?=$i?>&spageno=<?=$spageno?>">
                    <?=$i?>
                    </a></font></strong>
                    <? 
					}
					}
					}
					?>
                    <? if ($tpageno<$tpages) { ?>
                    <a href="tchome.php?tpageno=<?=$tpageno+1?>&spageno=<?=$spageno?>" class="table_td_heading">Next</a>
                    <? } else {?>
                    <? } ?>
                    </span></td>
                  <td width="10%" align="right" valign="middle" background="newbar.jpg" class="data"><!--DWLayoutEmptyCell-->&nbsp;</td>
                  <td width="30%" align="center" valign="middle" background="newbar.jpg" class="data"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td align="right" width="100%" valign="middle" class="table_td_heading" style="padding-right:5px;"><strong>Page</strong>&nbsp;
                          <?=$tpageno?>
                          &nbsp;of&nbsp;
                          <?=$tpages?>
                        </td>
                      </tr>
                    </table>
                    <strong></strong></td>
                </tr>
              </table></td>
          </tr>
        </table>
        <table align="center" width="100%">
          <tr>
            <td class="footer" width="100%" >&copy; 2009 TeacherSITY. All rights reserved</td>
          </tr>
        </table>
        <? }?>
        <? }?>
      </form></td>
  </tr>
</table>
</body>
</html>
