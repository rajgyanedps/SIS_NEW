<?php
session_start();
include('functions.inc.php');
include("connection.php");
if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='Project Manager' && $_SESSION['user_type']!='Tele Caller' && $_SESSION['temp_type']!='y')
//if (!isset($_SESSION[myusername]))
{
 header("Location: index.php");
}
$_SESSION['this_page']='download_fb_lead.php';

require_once 'PHPExcel/Classes/PHPExcel.php';



// create new PHPExcel object
$objPHPExcel = new PHPExcel();
// writer already created the first sheet for us, let's get it
$objSheet = $objPHPExcel->getActiveSheet();
// rename the sheet
$objSheet->setTitle('Download FB Lead');

// let's bold and size the header font and write the header
// as you can see, we can specify a range of cells, like here: cells from A1 to A4
$objSheet->getStyle('A1:L1')->getFont()->setBold(true)->setSize(12);

$char = 66;
// write header]
$query=mysql_query("SHOW COLUMNS FROM fb_lead_data");
$ct=mysql_num_rows($query);
 $objSheet->getCell(A.'1')->setValue('SR.NO.');
while($col_name = mysql_fetch_array($query))
    {
		if($col_name['Field']!='id')
		{
			if($col_name['Field']=='compain_type')
			{
				$col_name['Field']='campaign type';
			}
      $objSheet->getCell(chr($char).'1')->setValue(strtoupper($col_name['Field']));
      $char++;
		}
    }
$objSheet->getCell(K.'1')->setValue('FOLLOWUP');
$objSheet->getCell(L.'1')->setValue('STATUS');
// Now we need to get the data from the DB. While we have a row in the result:
$rowIterator=2; //our row number. We begin from 2 because the first one is the title.
$data=mysql_query("select * from fb_lead_data ORDER BY enquiry_date DESC");
$char = 65;
$j=1;
while ($RowInfo = mysql_fetch_array($data))
{
	$status=mysql_fetch_array(mysql_query("select * from fb_std_followups
	 where std_id='".$RowInfo['id']."'
	 order by id desc limit 1"));

    $objSheet->getCell('A'.$rowIterator)->setValue($j);
	
	$objSheet->getCell('B'.$rowIterator)->setValue(date("d-m-Y",strtotime($RowInfo['enquiry_date'])));

	$objSheet->getCell('C'.$rowIterator)->setValue($RowInfo['ad_name']);
	
	$objSheet->getCell('D'.$rowIterator)->setValue($RowInfo['ac_year']);
	
	$objSheet->getCell('E'.$rowIterator)->setValue($RowInfo['compain_type']);
	
	$objSheet->getCell('F'.$rowIterator)->setValue($RowInfo['is_organic']);
	
	$objSheet->getCell('G'.$rowIterator)->setValue($RowInfo['student_name']);

	$objSheet->getCell('H'.$rowIterator)->setValue($RowInfo['student_email']);
	$objSheet->getCell('I'.$rowIterator)->setValue($RowInfo['city']);
	$objSheet->getCell('J'.$rowIterator)->setValue($RowInfo['mobile_no']);
	
	 $objSheet->getCell('K'.$rowIterator)->setValue($status['follow_ups']);
	 $objSheet->getCell('L'.$rowIterator)->setValue($status['status']);
   
$j++;
$rowIterator++;
}



// autosize the columns
$char = 65;
for ($i=1;$i<=12;$i++){
    $objSheet->getColumnDimension(chr($char))->setAutoSize(true);
    $char++;
}
header("Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
header("Content-Disposition: attachment; filename=\"download_fb_lead.xlsx\"");
header("Cache-Control: max-age=0");
// create the writer
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, "Excel2007");
ob_clean();
$objWriter->save("php://output");


?>
