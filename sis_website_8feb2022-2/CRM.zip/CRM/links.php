<script type="text/javascript">
function MM_openBrWindow(theURL,winName,features) 
{ 
  window.open(theURL,winName,features);
}
</script>
<div id="topNav">
<ul>
<li><a href="pmhome.php" <?php if($_SESSION['this_page']=='pmhome.php')echo 'class="hover"'?>><b>Home</b></a></li>
<li><a href="addschool.php" <?php if($_SESSION['this_page']=='addschool.php')echo 'class="hover"'?>><b>Add School</b></a></li>
<li><a href="monthlyreport.php?mod=Daily&date1=<?= date("Y-m-d")?>"<?php if($_SESSION['this_page']=='monthlyreport.php' && $_GET['mod']=='Daily')echo 'class="hover"'?>><b>Daily Report</b></a></li>
<li><a href="monthlyreport.php?mod=Monthly&month1=<?=date("m")?>"<?php if($_SESSION['this_page']=='monthlyreport.php' && $_GET['mod']=='Monthly')echo 'class="hover"'?>><b>Monthly Report</b></a></li> 
<li><a href="usercallrecord.php"><b>Total Call Record</b></a></li>
<li><a href="#" onclick="MM_openBrWindow('userschoolreport.php?stat=Paid','Paid','toolbar=yes,location=yes,scrollbars=yes,resizable=yes,width=870,height=620')"><b>Paid</b></a></li>
<li><a href="#" onclick="MM_openBrWindow('userschoolreport.php?stat=Positive','Positive','toolbar=yes,location=yes,scrollbars=yes,resizable=yes,width=870,height=620')"><b>+Ve</b></a></li>
<li><a href="#" onclick="MM_openBrWindow('userschoolreport.php?stat=Moderate','Moderate','toolbar=yes,location=yes,scrollbars=yes,resizable=yes,width=870,height=620')"><b>Mod.</b></a></li>
<li><a href="#" onclick="MM_openBrWindow('userschoolreport.php?stat=Negative','Negative','toolbar=yes,location=yes,scrollbars=yes,resizable=yes,width=870,height=620')"><b>-Ve</b></a></li>
<li><a href="taskuser.php" <?php if($_SESSION['this_page']=='taskuser.php')echo 'class="hover"'?>><b>My Tasks</b></a></li>
<li><a href="Logout.php"><b>Logout</b></a></li>
</ul>
</div>