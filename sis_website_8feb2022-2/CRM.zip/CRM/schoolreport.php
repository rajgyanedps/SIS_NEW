<?php
session_start();
include("connection.php");
if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='Project Manager' && $_SESSION['user_type']!='Tele Caller')
//if (!isset($_SESSION[myusername]))
{
 header("Location: index.php");
}
?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Employee Total School</title>
<script type="text/javascript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php
include("header.php");
?>
<?php
$sql = "select * from members WHERE emp_id='".$_GET['emp_id']."'";
$result1 = mysql_query($sql);
$res1 = mysql_fetch_array($result1);
$res1['emp_id'];
?>
<form action="schoolreport.php" method="get" name="schoolreport">
<table align="center" width="100%"><tr><td width="1000px" align="left"><font size="4.5" face="Verdana, Arial, Helvetica, sans-serif"><b>Student Report(<? echo $res1['emp_name'];?>)</b></font></td></tr></table>
<?php
if ($_GET['type']=="2")
				{
				$sql_cust="SELECT * FROM  student WHERE emp_id ='".$_GET['emp_id']."' and status is NULL order by student.stud_id asc"; 
					
					}
					elseif ($_GET['type']=="1")
					{
					$sql_cust="SELECT * FROM  student WHERE emp_id ='".$_GET['emp_id']."' and (status='Positive' or status='Negative' or status='Moderate') order by student.stud_id asc"; 
					
					}
					elseif ($_GET['type']=="3")
					{
					$sql_cust="SELECT * FROM  student WHERE emp_id ='".$_GET['emp_id']."' and status='Paid' order by student.stud_id asc"; 
					
					}
					else
					{
					$sql_cust="SELECT * FROM  student WHERE emp_id ='".$_GET['emp_id']."' order by student.stud_id asc"; 
					
					}
		$result	= mysql_query($sql_cust) or die(mysql_error());
		$num_rows 	= mysql_num_rows($result);	
?>
<br />
<table width="100%">
  <tr><td>
<font color="#000000" size="3px" style="padding-left:15px"><b>Convert to Excel</b>&nbsp;&nbsp;<a href="#" onClick="javascript:window.open('report7.php?emp_id=<?=$res1['emp_id']?>&type=<?=$_GET['type']?>','myReport','');"><img src="logo_excel.gif" alt="Export" border="0"></a></font>
</td>
<td>
<b>Search Student By :</b>&nbsp;
<select name="check" id="check" onChange="location.href='schoolreport.php?emp_id=<?= $_GET['emp_id'];?>&type=' + this.value;">
<option value="">All</option>
<option value="1" <? if($_GET['type']==1) echo 'selected' ?>>Contacted School</option>
<option value="2" <? if($_GET['type']==2) echo 'selected' ?>>UnContacted School</option>
<option value="3" <? if($_GET['type']==3) echo 'selected' ?>>Paid School</option>
</select>
</td>
<?
if($num_rows>0)
{
?>

<td align="center" style="padding-right:10px">
<b>Records Found :</b>&nbsp;<strong><? echo $num_rows?></strong></td></tr>
<?
}
else
{
?>
<tr>
<td colspan="2" align="center" style="padding-right:10px">
<b>No Records Found</b></td>
<?
}
?>

</tr></table>
<table width="100%" border="0" align="center" cellpadding="5" cellspacing="1" bgcolor="#CCCCCC" style="font-size:12px">
<?
if($num_rows>0)
{
?>
<tr bgcolor="#999999" align="center">

      <td align="left" background="footerbg.jpg" class="whitetxt11">S.No.</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11"><a href="schoolreport.php?pageno=<?=$_REQUEST['pageno']?>">Student Name</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11">Address 1</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11">Address 2</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11"><a href="schoolreport.php?pageno=<?=$_REQUEST['pageno']?>">City</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11">Phone</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11">Status</td>
    </tr>
	<?
	
}
				
				
		$incr = 1;
		
		if(!$_REQUEST['pageno']){
			$pageno = 1;
		} else {
			$pageno= $_REQUEST['pageno'];
		}
		$pagesize=100;
		$incr = (($pageno-1)*$pagesize)+1;
		$first=$pageno*$pagesize-($pagesize-1);
		$last=$first+$pagesize-1; 
		$temp=($num_rows%$pagesize);
		if ($temp==0)
		$pages=($num_rows/$pagesize);
		else
		$pages=($num_rows/$pagesize)+1;
		settype($pages, "integer"); 

		for($i=1;$i<$first;$i++)
			$row2000=mysql_fetch_row($result);
     
     
     
//<?php
//$query="SELECT * FROM addschool";
//$result=mysql_query($query) or die(mysql_error());
while($res=mysql_fetch_array($result) and ($first<=$last))
{
if($i%2==0) {
	           $x = "bgcolor='#F0F0F0'";
	          } else {
	            $x = "bgcolor='#D8D8D8'";
 	          }
?>

<tr <?=$x;?> align="left">
        <td><? echo $i;?>.</td>
      
      <td><strong> <a href="11.php?stud_id=<? echo $res['stud_id'];?>"> <?php echo $res['stud_name'];?></a></strong></td>
      <td><?php echo $res['add1'];?></td>
      <td><?php echo $res['add2'];?></td>
      <td><?php echo $res['city'];?></td>
      <td><?php echo $res['phone_code']." ".$res['phone_no']; ?></td>
      <td align="center"><?php if($res['status']=='Positive'){?> <img src="image/green.gif" border="0" name="plus_sign" alt="Positive School" align="center"/><? } else if($res['status']=='Negative'){ ?><img src="image/red.gif" border="0" name="minus_sign" alt="Negative School" align="center"/><? } else if($res['status']=='Moderate'){ ?><img src="image/mod.gif" border="0" name="minus_sign" alt="Moderate School" align="center"/><? }  else if($res['status']=='Admission'){ ?><img src="image/admission.png" border="0" name="Admission" alt="Admission" align="center"/>
	  <? } else if($res['status']=='Paid'){ ?>
      <img src="image/paddy-smiley26.gif" border="0" name="paid" alt="Paid School" align="center" />
	   <? }else if($res['status']=='NoContact'){ ?>
                   <img src="image/nocontact.png" border="0" name="Admission" alt="Admission" align="center" />
                   <? }else if($res['status']=='Session2013-14'){ ?>
                   <img src="image/2013-14.jpg.png" border="0" name="Admission" alt="Admission" align="center" />
	  
	  
	  <? }else echo "-";?></td> 
    </tr>
                         
 <? 
	 	  $incr++;
	$first++;	
  $i=$i+1;
  } 
	?>
  </table>
        
  <? if($num_rows > 0){	?>
  <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
			  
<tr><td colspan="3"></td></tr>
			  <tr>
				<td   height="26"  valign="middle" background="newbar.jpg" class="table_td_heading" style="padding-left:5px;">
					<span class="table_td_heading">Pages:
					<? if ($pageno==1) { ?>
					&nbsp; 
					<? } else {?> 
					<a href="schoolreport.php?emp_id=<?= $_GET['emp_id'] ?>&type=<?= $_GET['type']?>&pageno=<?=$pageno-1?>" class="table_td_heading">Previous</a>
				    <? } 
					for ($i=1; $i<=$pages;$i++)
					{
					if($pageno==$i)	{?>
				    <strong class="table_td_heading"><? echo $i;?></strong>
				    <? }
						else
					{

if($i%5==0)
{
					?>
				    <strong><a class="table_td_heading" href="schoolreport.php?emp_id=<?= $_GET['emp_id'] ?>&type=<?= $_GET['type']?>&pageno=<?=$i?>">
					<?=$i?>
					</a></font></strong>
				    <? }
					}
					}
					?>
				    <? if ($pageno<$pages) { ?>
				    <a href="schoolreport.php?emp_id=<?= $_GET['emp_id'] ?>&type=<?= $_GET['type']?>&pageno=<?=$pageno+1?>" class="table_td_heading">Next</a>
				    <? } else {?>
				    <? } ?>				
		        </span></td>
				<td width="40" align="right" valign="middle" background="newbar.jpg" class="data">&nbsp;</td>
				<td width="125" align="center" valign="middle" background="newbar.jpg" class="data"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td align="right" valign="middle" class="table_td_heading" style="padding-right:5px;"><strong>Page</strong>&nbsp;
                    <?=$pageno?>
&nbsp;of&nbsp;
<?=$pages?>                    </td>
                  </tr>
                  
                </table>				  
			    <strong></strong></td>
			  </tr>
</table>
<table width="100%" align="center">
<tr>
<td class="footer" width="942" >&copy; 2009 TeacherSITY. All rights reserved</td>
</tr>

</table>
  <? }?>

</form>

</body>
</html>