<?php 
ob_start();
require_once('connection.php'); 
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Total_Report.xls");
header("Pragma: no-cache");
header("Expires: 0");

$now=date("j-n-Y");
echo "\t \t Report ON ".$now."\t";


if ($_GET['type']=="2")
				{
				$sql_cust="SELECT *,last_contact.status, members.emp_id FROM  members,addschool left join last_contact on addschool.school_id=last_contact.school_id  WHERE emp_id ='".$_GET['emp_id']."' and addschool.school_id >'".$_GET['emp_id']."' and addschool.school_id <'".($_GET['emp_id'] + 100000)."' and status is NULL order by addschool.school_id asc"; 
					
					}
					elseif ($_GET['type']=="1")
					{
					$sql_cust="SELECT *,last_contact.status, members.emp_id FROM  members,addschool left join last_contact on addschool.school_id=last_contact.school_id  WHERE emp_id ='".$_GET['emp_id']."' and addschool.school_id >'".$_GET['emp_id']."' and addschool.school_id <'".($_GET['emp_id'] + 100000)."' and (status='Positive' or status='Negative' or status='Moderate') order by addschool.school_id asc"; 
					
					}
					elseif ($_GET['type']=="3")
					{
					$sql_cust="SELECT *,last_contact.status, members.emp_id FROM  members,addschool left join last_contact on addschool.school_id=last_contact.school_id  WHERE emp_id ='".$_GET['emp_id']."' and addschool.school_id >'".$_GET['emp_id']."' and addschool.school_id <'".($_GET['emp_id'] + 100000)."' and status='Paid' order by addschool.school_id asc"; 
					
					}
					else
					{
					$sql_cust="SELECT *,last_contact.status, members.emp_id FROM  members,addschool left join last_contact on addschool.school_id=last_contact.school_id  WHERE emp_id ='".$_GET['emp_id']."' and addschool.school_id >'".$_GET['emp_id']."' and addschool.school_id <'".($_GET['emp_id'] + 100000)."' order by addschool.school_id asc"; 
					
					}

 $sql_model=mysql_query($sql_cust);
print("\n");
print("\n");
	    echo "S.No."."\t";
		echo "School Id"."\t";
		echo "School Name"."\t";
		echo "Address 1"."\t";
		echo "Address 2"."\t";
		echo "City"."\t";
		echo "Phone No."."\t";
				
		print("\n"); 
		$i=1;
 while($row = mysql_fetch_array($sql_model))
    {
        echo $i."\t";
		echo $row['school_id']."\t";
		echo $row['school_name']."\t";
		echo $row['add1']."\t";
		echo $row['add2']."\t";
		echo $row['city']."\t";
		echo $row['phone_code'].", ".$row['phone_no']."\t";
				
		print "\n";
		$i+=1;		
    }

?>