<?
session_start();
if(isset($_SESSION['getuser_type'])!='Parent')
{
?>
<script language="javascript1.2">document.location.href="../index.php";</script>
<?
}
error_reporting(0);
?>
<table width="100%" border="0" align="center" cellpadding="4" cellspacing="0" >
      <tr>
        <td width="18%" height="70" align="left" class="dothr"><img src="../images/small.gif" width="28" height="25" /></td>
        <td width="82%" height="70" class="dothr"><a href="home.php" class="leftmenulink">Home</a></td>
      </tr>
      <tr>
        <td height="50" align="left" class="dothr"><a href="editprofile.php"><img src="../images/small%20(1).gif" width="29" height="25" border="0" /></a></td>
        <td height="50" class="dothr"><a href="editprofile.php" class="leftmenulink">Edit Profile</a></td>
      </tr>
      <tr>
        <td height="50" align="left" class="dothr"><a href="academics.php"><img src="../images/small%20(2).gif" width="22" height="25" border="0" /></a></td>
        <td height="50" class="dothr"><a href="academics.php" class="leftmenulink">Academics</a></td>
      </tr>
      <tr>
        <td height="50" align="left" class="dothr"><a href="academics.php"><img src="../images/small%20(3).gif" width="28" height="25" border="0" /></a></td>
        <td height="50" class="dothr"><a href="attendance.php" class="leftmenulink">Absence Record</a></td>
      </tr>
      <tr>
        <td height="50" align="left" class="dothr"><a href="health.php"><img src="../images/small%20(4).gif" width="25" height="25" border="0" /></a></td>
        <td height="50" class="dothr"><a href="health.php" class="leftmenulink">Health</a></td>
      </tr>
      <tr>
        <td height="50" align="left" class="dothr"><a href="sport.php"><img src="../images/small%20(5).gif" width="19" height="25" border="0" /></a></td>
        <td height="50" class="dothr"><a href="sport.php" class="leftmenulink">Sports</a></td>
      </tr>
      <tr>
        <td height="50" align="left" class="dothr"><a href="achievement.php"><img src="../images/small%20(6).gif" width="24" height="23" border="0" /></a></td>
        <td height="50" class="dothr"><a href="achievement.php" class="leftmenulink">Achievements</a></td>
      </tr>
      <tr>
        <td height="50" align="left" class="dothr"><a href="fees.php"><img src="../images/small%20(7).gif" width="25" height="25" border="0" /></a></td>
        <td height="50" class="dothr"><a href="fees.php" class="leftmenulink">Fees</a></td>
      </tr>
      <tr>
        <td height="50" align="left" class="dothr"><a href="accounts.php"><img src="../images/small%20(8).gif" width="25" height="25" border="0" /></a></td>
        <td height="50" class="dothr"><a href="accounts.php" class="leftmenulink">Imprest Accounts</a></td>
      </tr>
      <tr>
        <td height="50" align="left" class="dothr"><a href="calendar.php"><img src="../images/calsmall.jpg" alt="" width="22" height="23" border="0" /></a></td>
        <td height="50" class="dothr"><a href="calendar.php" class="leftmenulink">Calendar of Events</a></td>
      </tr>
      <tr>
        <td height="50" align="left" class="dothr"><a href="../logout.php"><img src="../images/small%20(9).gif" width="25" height="25" border="0" /></a></td>
        <td height="50" class="dothr"><a href="../logout.php" class="leftmenulink">Logout</a></td>
  </tr>
    </table>