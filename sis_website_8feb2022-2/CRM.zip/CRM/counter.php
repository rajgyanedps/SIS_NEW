<?php
session_start();
include("connection.php");
$sql="SELECT * FROM 11";
$result=mysql_query($sql);
$rows=mysql_fetch_array($result);
$Counter=$rows['counter'];

// if have no counter value set counter = 1
if(empty($Counter)){
$Counter=1;
$sql1="INSERT INTO 11(counter) VALUES('$Counter')";
$result1=mysql_query($sql1);
}

echo "You 're visitors No. ";
echo $Counter;

// count more value
$addcounter=$Counter+1;
$sql2="update 11 set counter='$addcounter'";
$result2=mysql_query($sql2);


?>
