<div style="margin-left:20px"><tr><td class="footer" width="1000" >&copy; 2009 TeacherSITY. All rights reserved</td></tr>
</div>
</table>

