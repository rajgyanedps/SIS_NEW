<? 
session_start();

$db = "selaquicrm";
$db1 ="iitjeecrm";
$db2 =" neetcrm ";
$connection = mysql_connect('selaquicrm.db.5227155.hostedresource.com','selaquicrm','Siscrm1#',true);
$connection1 = mysql_connect('iitjeecrm.db.5227155.hostedresource.com','iitjeecrm','Iitjee@1');
$connection2 = mysql_connect('68.178.139.6','neetcrm','Neetcrm1@');
mysql_select_db($db,$connection);




mysql_select_db($db1,$connection1);
mysql_select_db($db2,$connection2);



$today=date("Y-m-d") ;

$sql1=mysql_query("select * from $db.student where joined like '%".$today."%'",$connection);
$cnt1=mysql_num_rows($sql1);

$sql11=  mysql_fetch_array(mysql_query("select count(*) as paid_lead from $db.student where joined like '%".$today."%' AND v_type='PPC' ",$connection));

 $total1=$sql11['paid_lead'];



//$sql2=mysql_query("select v_type,count(v_type)  as total from $db1.registration where date like '%".$today."%' group by v_type",$connection1);


$sql1=mysql_query("select * from $db1.registration where date like '%".$today."%'",$connection1);
 $cnt2=mysql_num_rows($sql1);

$sql12=  mysql_fetch_array(mysql_query("select count(*) as paid_lead from $db1.registration where date like '%".$today."%' AND v_type='PPC' ",$connection1));

$paid_total=$sql11['paid_lead'];


$sql1=mysql_query("select * from $db2.student where joined like '%".$today."%'",$connection2);
 $cnt3=mysql_num_rows($sql1);

$sql13=  mysql_fetch_array(mysql_query("select count(*) as paid_lead from $db2.student where joined like '%".$today."%' AND v_type='PPC' ",$connection2));

$paid_total3=$sql13['paid_lead'];




?>


<table border="1" width="50%" align="center">
    <tr>
       <td colspan="4">Lead Report</td> </tr>
      <tr>  <td></td> <td>Paid</td> <td>Organic</td> <td>Total</td></tr>
         <tr>  <td>SIS </td> <td><?=$total1;?></td> <td><?=$cnt1-$total1;?></td><td><?=$cnt1;?></td> </tr>
         <tr>  <td>NEET</td> <td><?=$paid_total; ?></td> <td><?=$cnt2-$paid_total;?></td><td><?=$cnt2;?></td> </tr>
             <tr>  <td>IIT</td> <td><?=$paid_total3;?></td> <td><?=$cnt3-$paid_total3;?></td><td><?=$cnt3;?></td> </tr>
          
      
   
</table>