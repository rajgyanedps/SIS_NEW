<?php 
require_once('connection.php'); 
?>
<?php
//$today = date("Y-m-d");
//$thisMonth=date("Y-m%");
//$time = time("H:i:s");
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Emp_Report.xls");
header("Pragma: no-cache");
header("Expires: 0");
$now=date("j-n-Y");
echo "\t \t Report ON ".$now."\t";
$sql_model=mysql_query("SELECT * FROM members order by emp_id");
print("\n");
print("\n");
	    echo "S.No."."\t";
		echo "Emp Id"."\t";
		echo "Username"."\t";
		echo "Password"."\t";
		echo "Emp Name"."\t";
		echo "Email Id"."\t";
		echo "User type"."\t";
		echo "Gender"."\t";
		echo "Address"."\t";
		echo "Mob No."."\t";
		
		print("\n"); 
		$i=1;
 while($row = mysql_fetch_array($sql_model))
    {
        echo $i."\t";
		echo $row['emp_id']."\t";
		echo $row['username']."\t";
		echo $row['password']."\t";
		echo $row['emp_name']."\t";
		echo $row['email']."\t";
		echo $row['user_type']."\t";
		echo $row['gender']."\t";
		echo $row['address']."\t";
		echo $row['mobno']."\t";
		
		print "\n";
		$i+=1;		
    }

?>