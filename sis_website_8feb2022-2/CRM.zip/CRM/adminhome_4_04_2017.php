<?php
session_start();
error_reporting(0);
date_default_timezone_set('Asia/Calcutta');
include('functions.inc.php');
include("automatic.php");
include("connection.php");

$DATE=date('Y-m-d');

if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='Project Manager' && $_SESSION['user_type']!='Tele Caller')
{
 header("Location: index.php");
}
$_SESSION['this_page']='adminhome.php';
@extract($_GET);

if($order_by!="")
{	
	$KEYWORD_SEARCH_5="ORDER BY $order_by $img_name"; 
}
else
{
	$KEYWORD_SEARCH_5="ORDER BY joined DESC, student.stud_id DESC";
}	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Administrator Home Page</title><link rel="shortcut icon" href="http://www.selaqui.org/images/favicon.ico" type="image/x-icon">
<link rel="stylesheet" type="text/css" href="calendar-blue.css">
<script type="text/javascript" src="calendar.js"></script>
<script type="text/javascript" src="calendar-en.js"></script>
<script type="text/javascript" src="calendar-setup.js"></script>
<script language="javascript1.2" src="tabber.js"></script>
<script type="text/javascript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}

function chkselect(chk,chkall)
  {
  var chkl=chk.length;
  if (chk.length != undefined)
  {
  for(i=0;i<chkl;i++)
  {
  chk[i].checked=chkall.checked;
  }
  }
  else
  {
  chk.checked=chkall.checked;
  }
 
  }
//-->
</script>
<script type="text/javascript">
function delete_chk()
	{
	var agree=confirm("Are you sure! Want to Delete");
if (agree)
	return true ;
else
	return false ;
	}
</script>
<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	background-repeat: no-repeat;
}
.online {
	background-image: url(image/1.gif);
	background-repeat: no-repeat;
	background-position: left center;
	height: 20px;
	padding-left: 20px;
}
.offline {
	background-image: url(image/2.gif);
	background-repeat: no-repeat;
	background-position: left center;
	height: 20px;
	padding-left: 20px;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />

<link rel="stylesheet" type="text/css" href="jquery.fancybox/jquery.fancybox.css" media="screen" />
<script type="text/javascript" src="jquery.fancybox/jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="jquery.fancybox/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="jquery.fancybox/jquery.fancybox-1.2.1.pack.js"></script>
<script type="text/javascript">

function MM_openBrWindow(theURL,winName,features) {
  window.open(theURL,winName,features);
}

	$(document).ready(function()

	 {
     $("a.pmodee").fancybox({ 'hideOnContentClick': false ,

					  'overlayShow':true  ,

					  'frameWidth':950 ,

					  'frameHeight':250,

					  'overlayOpacity':0.7 }); 
	});
</script>


</head>
<body>
<?php
include("header.php");
?>
<br />
<div style="margin-left:10px;width:520px;height:110px;background-color:#f3f7fd;border:solid 1px #88c9fd;float:left">
  <div style="border-bottom:solid 1px #88c9fd;padding-left:10px;height:20px;background:url(image/headbg.png) repeat-x;font-size:12px; color:#064582;line-height:20px;font-weight:bold;">Search options </div>
  <div style="width:520px; margin-top:10px; float:left;">
    <form name="adminhome" action="adminhome.php" method="get" style="margin:0;padding:0;padding-top:5px">
      <label style="padding-left:6px;width:70px;float:left;font-size:11px;line-height:20px">Student Name:</label>
      <input type="text" name="schoolname1" size="15" value="<?= $_GET['schoolname1'] ?>" style="float:left;height:17px;line-height:18px;border:solid 1px #61b5f8;font-size:12px;width:120px; color:#0a5095;background-color:#ffffff" />
      <label style="padding-left:30px;width:80px;float:left;font-size:11px;line-height:20px">Add./City/State:</label>
      <input type="text" name="keyword" size="15"  value="<?= $_GET['keyword'] ?>" style="float:left;height:17px;line-height:18px;border:solid 1px #61b5f8;font-size:12px;width:120px; color:#0a5095;background-color:#ffffff" /><br /><br />


      
      <label style="padding-left:5px;width:95px;float:left;font-size:11px;line-height:20px; margin-top:10px;">Information Source:</label>
            
      <select name="info_search"  style="float:left;height:20px;line-height:18px;border:solid 1px #61b5f8;font-size:12px;width:135px; color:#0a5095;background-color:#ffffff; margin-top:10px;" >
  <option value="">---Select---</option>
  <option value="Arjuna">Arjuna</option>
  <option value="Application">Application</option>
  <option value="Registration">Registration</option>
  <option value="Enquiry">Enquiry</option>
   <option value="Lead">Lead</option>
  <option value="Telephone">Telephone</option>
  <option value="SMS">SMS</option>
  <option value="Google">Google</option>
  <option value="Internet">Internet</option>
  <option value="Hoarding">Hoarding</option>
  <option value="Newspaper">Newspaper</option>
  <option value="Fair/Exhibition">Fair/Exhibition</option>
  <option value="Seminar">Seminar</option>
  <option value="Word of Mouth">Word of Mouth</option>
  <option value="Data">Data</option>
  <option value="Counseling Associate">Counseling Associate</option>
  <option value="UTU Counseling">UTU Counseling</option>
  <option value="Magzine">Magzine</option>
  
  
</select>
      <label style="padding-left:6px; width:70px; float:left;font-size:11px; margin-top:10px;line-height:20px">Filter By:</label>
      <select name="empid" id="empid" style="float:left;height:18px;line-height:20px;border:solid 1px #61b5f8;font-size:12px; color:#0a5095; width:120px;background-color:#ffffff;height:20px; margin-top:10px;">
        <option value="" >All</option>
        <?
$sql = "select emp_id, emp_name from members where username!='Open Data'  order by emp_id";
$result = mysql_query($sql);
while($row = mysql_fetch_row($result))
		{
		?>
        <option value="<?=$row[0];?>" <? if($_GET['empid']==$row[0
		]) echo 'selected' ?> >
        <?=$row[1];?>
        </option>
        <?
}
?>
      </select>
      <div style="margin-right:8px; text-align:right; margin-top:10px; float:right;">
        <input type="submit" value="Search" />
      </div>
   
  </div>
</div>
<?php
$sql = "select count(*) as totalmsg from message WHERE `to`='".$_SESSION['emp_id']."'";
$result1 = mysql_query($sql) ;
$res1 = mysql_fetch_array($result1);
if($res1['totalmsg']>0 || strlen($_GET['msg'])>0 )
{?>
<div style="margin-left:14px;width:215px;height:110px;background-color:#f3f7fd;border:solid 1px #88c9fd;float:left">
  <div style="border-bottom:solid 1px #88c9fd;padding-left:10px;height:20px;background:url(image/headbg.png) repeat-x;font-size:12px;color:#064582;line-height:20px;font-weight:bold;">Notifications </div>
  <br />
  <div align="center"> <font color="#FF0000">
    <?=$_GET['msg']; ?>
    </font> </div>
  <div align="center">You have received&nbsp;<strong><?php echo $res1['totalmsg'];?></strong>&nbsp;Leads&nbsp;&nbsp;<a href="seemsg.php">View All</a> </div>
</div>
<? }?>
<? 
if(isset($_GET['empid']) && $_GET['empid']!=''){
$strqry=" and student.emp_id='".$_GET['empid']."'";
}
if(strlen($_GET['keyword'])>0){
$key="%".$_GET['keyword'];
}
else
{
$key="";
}
if($_GET['info_search']=="Arjuna")
{
$key2="and project_id=5";
$_GET['info_search']="";
}
else
{
$key2=" ";
}
if($_REQUEST['from']!="" && $_REQUEST['to']!="")
{
$from1=$_REQUEST['from'];
$to1=$_REQUEST['to'];
$from=date('Y-m-d',strtotime("$from1"));
$to=date('Y-m-d',strtotime("$to1,+1 day"));
 $t=" and student.joined>='$from' AND student.joined<='$to'";
}
else
{
$t="";
}
$sql_cust1 = "SELECT *, (select other from contact where  contact.stud_id=student.stud_id order by joined desc limit 1) as othernextstep, (select remarktime from contact where  contact.stud_id=student.stud_id order by joined desc limit 1) as remtime FROM student where student.emp_id='".$_SESSION['emp_id']."' and remarkdate!='0000-00-00' order by remarkdate desc";
  
$result1	= mysql_query($sql_cust1) or die(mysql_error());
		$num_rows1 	= mysql_num_rows($result1);	
		

    $start=0;
$pagesize=50;

if(isset($_GET['start'])) 
	$start=$_GET['start'];

if(isset($_GET['pagesize'])) 
	$pagesize=$_GET['pagesize'];
                
  $sql_cust = "SELECT student. * ,members.emp_name FROM members inner join student on members.emp_id =student.emp_id WHERE stud_name LIKE '".$_GET['schoolname1']."%' and information_source like '%".$_GET['info_search']."%'  ".$key2."  and (add1 like '".$key."%' or add2 like '".$key."%' or state like '".$key."%' or city like '".$key."%') and page_group  NOT LIKE '%IIT%'and page_group NOT LIKE '%NEET%' ". $strqry.$t." $KEYWORD_SEARCH_5 limit $start,$pagesize ";
  
 /* $selectcount = "SELECT student. * ,members.emp_name FROM members inner join student on members.emp_id =student.emp_id WHERE stud_name LIKE '".$_GET['schoolname1']."%' and information_source like '%".$_GET['info_search']."%'  ".$key2."  and (add1 like '".$key."%' or add2 like '".$key."%' or state like '".$key."%' or city like '".$key."%') and page_group  NOT LIKE '%IIT%'and page_group NOT LIKE '%NEET%' ". $strqry.$t." $KEYWORD_SEARCH_5  ";  // coomented by ajay on 7-jan-2017*/
  
  $selectcount = "SELECT student. * ,members.emp_name FROM members inner join student on members.emp_id =student.emp_id WHERE stud_name LIKE '".$_GET['schoolname1']."%' and information_source like '%".$_GET['info_search']."%'  ".$key2."  and (add1 like '".$key."%' or add2 like '".$key."%' or state like '".$key."%' or city like '".$key."%') ". $strqry.$t." $KEYWORD_SEARCH_5  ";
  
//print($sql_cust); //die;		
/*		
$sql_cust = "SELECT addschool. * , members.emp_name,last_contact.status FROM members, addschool LEFT JOIN last_contact ON addschool.school_id = last_contact.school_id WHERE ".$delqry."members.emp_id = ( floor( addschool.school_id /100000 ) ) *100000 AND school_name LIKE '".$_GET['schoolname1']."%' and information_source like '".$_GET['info_search']."%' and (add1 like '".$key."%' or add2 like '".$key."%' or state like '".$key."%' or city like '".$key."%') ". $strqry." and (last_contact.status!='Negative' or last_contact.status is NULL) $KEYWORD_SEARCH_5";		
	*/	
	$abc=  mysql_query($selectcount);
        $no_of_results=  mysql_num_rows($abc);
          
	 $reccnt=$no_of_results; 
$result	= mysql_query($sql_cust) or die(mysql_error());
$num_rows= $reccnt;



?>
<?php
$sql15="SELECT *, addtime(last_active, '12:30:00') as last_active FROM members WHERE username!='Open Data' and username!='del_school' order by online desc, emp_name";
$result15=mysql_query($sql15);
?>
<div style="margin-left:14px;width:350px;height:110px;background-color:#f3f7fd;border:solid 1px #88c9fd;float:left">
  <div style="border-bottom:solid 1px #88c9fd;padding-left:10px;height:20px;background:url(image/headbg.png) repeat-x;font-size:12px;color:#064582;line-height:20px;font-weight:bold">Online&nbsp;&nbsp;&nbsp; - &nbsp;&nbsp;&nbsp;&nbsp;Last Active</div>
  <div style="height:65px; margin-top:5px; color:#0a5095; padding:5px; overflow:auto">
    <? 
$count=0;
while($res15=mysql_fetch_array($result15))
{
$count++;
if($res15['online']==1  && strtotime($res15['last_active'])>=strtotime("-30 minutes")) 
$cls= 'class="online"';
 else
 $cls='class="offline"';
?>
    <div <?  echo $cls ?>><? echo $res15['emp_name'];?>&nbsp;&nbsp;
      <? if($res15['last_active']=='0000-00-00 00:00:00')
{?>
      <? }
else
{?>
      (<? echo date("d-M-y", strtotime($res15['last_active']));?>&nbsp;&nbsp;<? echo date("H:i A", strtotime($res15['last_active']));?>)
      <? }?>
    </div>
    <? } ?>
  </div>
</div>

<div>

    From: <input name="from" type="text" id="from" size="8" class="file-field" value="<?=$_GET['from']?>" />
              <img src="CalendarIcon.gif" name="get_stud_date4" width="16" height="16" border="0" align="absmiddle" id="get_stud_date4" style="cursor: pointer;" title="Date selector" onmouseover="this.style.background='red';" onmouseout="this.style.background=''" />
	 <script type="text/javascript">
	  	Calendar.setup({
        inputField     :    "from",     // id of the input field
	    //ifFormat       :    "%Y/%m/%d %l:%M %P",      // format of the input field
	  	//ifFormat       :    "%m-%d-%Y",      // format of the input field
	  	ifFormat       :    "%d-%m-%Y",      // format of the input field
        button         :    "get_stud_date4",  // trigger for the calendar (button ID)
        align          :    "Tl",           // alignment (defaults to "Bl")
        singleClick    :    true,
		showsTime		:	true
    });

</script> 

   To:<input name="to" type="text" id="to" size="8" class="file-field" value="<?=$_GET['to']?>"/> 
   <img src="CalendarIcon.gif" name="get_stud_date3" width="16" height="16" border="0" align="absmiddle" id="get_stud_date3" style="cursor: pointer;" title="Date selector" onmouseover="this.style.background='red';" onmouseout="this.style.background=''" />
	  <script type="text/javascript">
	  	Calendar.setup({
        inputField     :    "to",     // id of the input field
	    //ifFormat       :    "%Y/%m/%d %l:%M %P",      // format of the input field
	  	//ifFormat       :    "%m-%d-%Y",      // format of the input field
	  	ifFormat       :    "%d-%m-%Y",      // format of the input field
        button         :    "get_stud_date3",  // trigger for the calendar (button ID)
        align          :    "Tl",           // alignment (defaults to "Bl")
        singleClick    :    true,
		showsTime		:	true
    });
</script>

<input type="submit" name="date_search" value="Search"/>




<div style="width:500px; float:right;">
<div style="float:left; padding:0 10px; 0 10px;">
<a href="student_sis_xls.php?schoolname1=<?=$_REQUEST['schoolname1']?>&from=<?=$_REQUEST['from']?>&to=<?=$_REQUEST['to']?>&empid=<?=$_REQUEST['empid']?>&keyword=<?=$_REQUEST['keyword']?>&info_search=<?=$_REQUEST['info_search']?>">
<strong style="text-align:center; float:left;"><img src="images/logo_excel.gif" width="25"  height="20z" /><br/>
Export with comment</strong></a></div>
<div style="float:left;  padding:0 10px; 0 10px;">
<a href="student_withoutcomment.php?schoolname1=<?=$_REQUEST['schoolname1']?>&from=<?=$_REQUEST['from']?>&to=<?=$_REQUEST['to']?>&empid=<?=$_REQUEST['empid']?>&keyword=<?=$_REQUEST['keyword']?>&info_search=<?=$_REQUEST['info_search']?>">
<strong style="text-align:center; float:left;"><img src="images/logo_excel.gif" width="25"  height="20z" /><br/>
Export without comment</strong></a></div>
<div style="float:left;  padding:0 10px; 0 10px;">
<a href="reg_excel.php?schoolname1=<?=$_REQUEST['schoolname1']?>&from=<?=$_REQUEST['from']?>&to=<?=$_REQUEST['to']?>&empid=<?=$_REQUEST['empid']?>&keyword=<?=$_REQUEST['keyword']?>&info_search=<?=$_REQUEST['info_search']?>">
<strong style="text-align:center; float:left;"><img src="images/logo_excel.gif" width="25"  height="20z" /><br/>
Export Registration</strong></a></div>



</div>
</div>






</div>
</form>
<div style="clear:both;height:5px"></div>
<form name="lead_transfer" action="lead_transfer.php" method="post" >
  <table width="100%" border="0" align="center" style="border:medium"><tr><td colspan="2" align="center"><table width="100%" border="0" align="center" style="border:medium">
    <tr>
      <td colspan="2" align="center"><? if(isset($_GET['msg1'])) ?>
          <font color="#FF0000" size="3px">
          <?=$_GET['msg1'];?>
        </font></td>
    </tr>
    <tr>
      <td colspan="2" align="center"><? if(isset($_GET['stmsg'])) {?>
          <font color="#FF0000" size="2px">Record deleted successfully</font> <? } ?></td>
    </tr>
    <tr>
    <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td >&nbsp;&nbsp;&nbsp;<b>Transfer Selected To:</b>&nbsp;&nbsp;&nbsp;
          <select name="employee_id" id="employee_id" style="height:20px; font-size:12px; color:#0a5095; border:solid 1px #61b5f8;">
            <?
$sql8 = "select emp_id, emp_name from members where username!='Open Data' order by emp_id";
$result8 = mysql_query($sql8);
while($row8 = mysql_fetch_row($result8))
		{
		?>
            <option value="<?=$row8[0];?>">
              <?=$row8[1];?>
              </option>
            <?
}
?>
          </select>
        &nbsp;
        <input type="submit" name="submit5" value="Transfer" style="height:22px" />     
      &nbsp;  &nbsp;  <input  type="submit" name="delete" value="Delete Selected"  onClick="return getId();"/> 
      <br/>
         <br/>
      <div style="float:left;"><img src="images/very_positive.jpg" border="0" name="minus_sign" alt="Click here to view Very Positive report" align="center">&nbsp;&nbsp;Very Positive&nbsp;&nbsp; 
          <img src="image/green.gif" border="0" name="minus_sign" alt="Click here to view negative report" align="center">&nbsp;&nbsp;Positive&nbsp;&nbsp;
          <img src="image/mod.gif" border="0" name="minus_sign" align="center">&nbsp;&nbsp;Moderate&nbsp;&nbsp;
          <img src="images/not_interested.jpg" border="0" name="minus_sign" alt="" align="center">
        &nbsp;&nbsp;  Not Interested&nbsp;&nbsp;
      <img src="images/not_eligible.jpg" border="0" name="minus_sign" alt="Click here to view Not Eligible report" align="center">&nbsp;&nbsp;Not Eligible&nbsp;&nbsp;
      <img src="image/nocontact.png" border="0" name="Admission" alt="Admission" align="center">&nbsp;&nbsp; No Contact&nbsp;&nbsp; 
      <img src="image/paddy-smiley26.gif" border="0" name="paid" alt="Paid School" align="center">&nbsp;&nbsp;Paid&nbsp;&nbsp;    
       <img src="image/admission.png" border="0" name="Admission" alt="Admission" align="center">&nbsp;&nbsp;Admission&nbsp;&nbsp;
              <img src="images/duplicate.jpg" border="0" name="Duplicate" alt="Duplicate" align="center">&nbsp;&nbsp;Duplicate&nbsp;&nbsp;
      <img src="image/red.gif" border="0" name="minus_sign" alt="Click here to view negative report" align="center">&nbsp;&nbsp;Negative&nbsp;&nbsp; 
      
             <img src="image/2013-14.jpg.png" border="0" name="Admission" alt="Admission" align="center"> &nbsp;&nbsp;Session 2016-17 &nbsp;&nbsp;
			  <img src="image/2013-14_green.png" border="0" name="Admission" alt="Admission" align="center"> &nbsp;&nbsp;Session 2017-18
      
      </div>
      </td>
     
    

      <td align="right" style="padding-right:10px"><? if($num_rows!=0){?>
          <strong>Records Found: <? echo $num_rows ?></strong>
          <? } ?></td>
    </tr>
  </table>    <font color="#FF0000" size="3px">&nbsp;</font></td>
    </tr>
</table>
  <table align="center" width="100%">
    <tr>
      <? 
	  
	 
 
if($num_rows>0)
{
?>
      <td width="60%" valign="top"><table width="100%" border="0" align="center" cellpadding="5" cellspacing="1" bgcolor="#81cafd" style="font-size:11px" >
          <tr bgcolor="#999999" align="center">
            <td height="20" align="left" background="footerbg.jpg" class="whitetxt11"><input type="checkbox" name="chk1" id="chk1" onClick="return chkselect(document.lead_transfer['school_id[]'],this)" /></td>
            <td align="left" background="footerbg.jpg" class="whitetxt11">S.No.</td>
            <td align="left" background="footerbg.jpg" class="whitetxt11"><? if($_GET['img_name']=='desc' && $_GET['order_by']=='stud_name')
   { 
 ?>
              <a href="adminhome.php?order_by=stud_name&img_name=asc&empid=<?=$_GET['empid'] ?>&schoolname1=<?= $_GET['schoolname1'] ?>&info_search=<?= $_GET['info_search'] ?>&keyword=<?=$_GET['keyword']?>"><strong>Student Name&nbsp;</strong><img src="image/asc.gif" alt="Descending Order" border="0"></a>
              <? 
    } 
	else 
	{ 
	?>
              <a href="adminhome.php?order_by=stud_name&img_name=desc&empid=<?=$_GET['empid'] ?>&schoolname1=<?= $_GET['schoolname1'] ?>&info_search=<?= $_GET['info_search'] ?>&keyword=<?=$_GET['keyword']?>"><strong>Student Name&nbsp;</strong><img src="image/dsc.gif" alt="Ascending Order" border="0"></a>
              <?
	}
	?>
            </td>
          
            <td align="left" background="footerbg.jpg" class="whitetxt11"><? if($_GET['img_name']=='desc' && $_GET['order_by']=='city')
   { 
 ?>
              <a href="adminhome.php?order_by=city&img_name=asc&empid=<?=$_GET['empid'] ?>&schoolname1=<?= $_GET['schoolname1'] ?>&info_search=<?= $_GET['info_search'] ?>&keyword=<?=$_GET['keyword']?>"><strong>City&nbsp;</strong><img src="image/asc.gif" alt="Descending Order" border="0"></a>
              <? 
    } 
	else 
	{ 
	?>
              <a href="adminhome.php?order_by=city&img_name=desc&empid=<?=$_GET['empid'] ?>&schoolname1=<?= $_GET['schoolname1'] ?>&info_search=<?= $_GET['info_search'] ?>&keyword=<?=$_GET['keyword']?>"><strong>City&nbsp;</strong><img src="image/dsc.gif" alt="Ascending Order" border="0"></a>
              <?
	}
	?></td>
            
             <td align="left" background="footerbg.jpg" class="whitetxt11"><? if($_GET['img_name']=='desc' && $_GET['order_by']=='state')
   { 
 ?>
              <a href="adminhome.php?order_by=state&img_name=asc&empid=<?=$_GET['empid'] ?>&schoolname1=<?= $_GET['schoolname1'] ?>&info_search=<?= $_GET['info_search'] ?>&keyword=<?=$_GET['keyword']?>"><strong>State&nbsp;</strong><img src="image/asc.gif" alt="Descending Order" border="0"></a>
              <? 
    } 
	else 
	{ 
	?>
              <a href="adminhome.php?order_by=state&img_name=desc&empid=<?=$_GET['empid'] ?>&schoolname1=<?= $_GET['schoolname1'] ?>&info_search=<?= $_GET['info_search'] ?>&keyword=<?=$_GET['keyword']?>"><strong>State&nbsp;</strong><img src="image/dsc.gif" alt="Ascending Order" border="0"></a>
              <?
	}
	?></td>
            
            <td align="left" background="footerbg.jpg" class="whitetxt11">Phone No./Mob No.</td>
            <td align="left" background="footerbg.jpg" class="whitetxt11">Reports</td>
            <td align="left" background="footerbg.jpg" class="whitetxt11">
            
            <? if($_GET['img_name']=='desc' && $_GET['order_by']=='status')
   				{ 
 			?>
             <a href="adminhome.php?order_by=status&img_name=asc&empid=<?=$_GET['empid'] ?>&schoolname1=<?= $_GET['schoolname1'] ?>&info_search=<?= $_GET['info_search'] ?>&keyword=<?=$_GET['keyword']?>"><strong>Status&nbsp;</strong><img src="image/asc.gif" alt="Descending Order" border="0"></a>
              <? 
    			} 
				else 
				{ 
			?>
            <a href="adminhome.php?order_by=status&img_name=desc&empid=<?=$_GET['empid'] ?>&schoolname1=<?= $_GET['schoolname1'] ?>&info_search=<?= $_GET['info_search'] ?>&keyword=<?=$_GET['keyword']?>"><strong>Status&nbsp;</strong><img src="image/dsc.gif" alt="Ascending Order" border="0"></a>
              <?
				}
			?>
            
            
            
            </td>
            <td align="left" background="footerbg.jpg" class="whitetxt11">
            <? if($_GET['img_name']=='desc' && $_GET['order_by']=='information_source')
   { 
 ?>
              <a href="adminhome.php?order_by=information_source&img_name=asc&empid=<?=$_GET['empid'] ?>&schoolname1=<?= $_GET['schoolname1'] ?>&info_search=<?= $_GET['info_search'] ?>&keyword=<?=$_GET['keyword']?>"><strong>Information Source&nbsp;</strong><img src="image/asc.gif" alt="Descending Order" border="0"></a>
              <? 
    } 
	else 
	{ 
	?>
              <a href="adminhome.php?order_by=information_source&img_name=desc&empid=<?=$_GET['empid'] ?>"><strong>Information Source&nbsp;</strong><img src="image/dsc.gif" alt="Ascending Order" border="0"></a>
              <?
	}
	?>
            
            </td>
            
            <td align="left" background="footerbg.jpg" class="whitetxt11" >Coordinator</td>
            <td align="left" background="footerbg.jpg" class="whitetxt11" >Payment Status</td>
             <td align="left" background="footerbg.jpg" class="whitetxt11" >Ip Address</td>
              <td align="left" background="footerbg.jpg" class="whitetxt11" >Visitor Type</td>
               <td align="left" background="footerbg.jpg" class="whitetxt11" >Keyword(PKW)</td>
                <td align="left" background="footerbg.jpg" class="whitetxt11" >Placement(PPC)</td>
                              <td align="left" background="footerbg.jpg" class="whitetxt11" >Placement(PCA)</td>
            <td align="left" background="footerbg.jpg" class="whitetxt11" >Delete</td>
          </tr>
          <? 

if($num_rows==0)
{
echo "<div align=center><font color=red size=+1>No Record Found</font></div>";
}
if($start==''){
    $j=1;}else{$j=$start+1;}
    $i=1;
while($res=mysql_fetch_array($result))
{ 
if($res['joined']=="")$dd ='-'; else $dd = date("d-M-y",strtotime($res['joined']));
$select_status = "SELECT  joined as stjoined, status FROM student where stud_id='".$res['stud_id']."'";
$result_status	= mysql_query($select_status) or die(mysql_error());
$status = mysql_fetch_array($result_status);
if($i%2==0) {
$x = "bgcolor='#e9f5ff'";
} else {
$x = "bgcolor='#d8effe'";
}
?>
          <tr <? if (date("Y-M-d",strtotime($res['leaddate']))==date("Y-M-d",strtotime("-1 days")) || date("Y-M-d",strtotime($res['leaddate']))==date("Y-M-d"))
 { echo 'bgcolor="#FFCCCC"'; } else { echo $x; } ?> align="left">
              <td><input type="checkbox" name="school_id[]" value="<?=$res['stud_id']?>" />
           <input type="hidden" name="emp_id[]" value="<?=$res['emp_id']?>" />
            
            </td>
            <td><? echo $j++;?>.</td>
            <td><? if($res['emp_id']==$_SESSION['emp_id'])
{?>
              <a href="11.php?stud_id=<? echo $res['stud_id'];?>"><?php echo ucwords(strtolower($res['stud_name']));?></a>
              <? }
else
{?>
              <a href="#" onClick="MM_openBrWindow('schoolinfo.php?school_id=<? echo $res['stud_id'];?>','schoolinfo','scrollbars=yes,resizable=yes,width=650,height=350')" style="font-size:12px"><?php echo ucwords(strtolower($res['stud_name']));?></a>
              <? }?>
            </td>
           
            <td><?php echo ucwords(strtolower($res['city']));?><br />
             
              <td>
              <?php echo ucwords(strtolower($res['state']));?></td>
            <td> <?php echo $res['phone_code']." ".$res['phone_no']; ?><br />
              <?php 
			  
			  $check_status=mysql_query("select * from  ordermanagement where memberid='".$res['stud_id']."'");
			  $check_sta=mysql_fetch_array($check_status);
			  if($res['mobno']!='0') echo $res['mobno']; else echo '-'; ?> </td>
            <td align="left"><a href="contactreport.php?stud_id=<? echo $res['stud_id'];?>">Contact</a><br />
              <!--<a href="test.php?school_id=<? echo $res['stud_id'];?>">Total Test</a>--></td>
            <td height="22" align="center"><?php if($res['status']=='Positive'){?>
                            <img src="image/green.gif" border="0" name="plus_sign" alt="Click here to view positive report" align="center"/>
                            <? } else if($res['status']=='Not Intrested'){ ?>
                            <img src="image/red.gif" border="0" name="minus_sign" alt="Click here to view Not Intrested report" align="center"/>
                            <? } 
                            
                            else if($res['status']=='Very Positive'){ ?>
                            <img src="images/very_positive.jpg" border="0" name="minus_sign" alt="Click here to view Very Positive report" align="center"/>
                            <? }
                            else if($res['status']=='Not Eligible'){ ?>
                            <img src="images/not_eligible.jpg" border="0" name="minus_sign" alt="Click here to view Not Eligible report" align="center"/>
                            
              <? }else if($res['status']=='Admission'){ ?>
              <img src="image/admission.png" border="0" name="admission" alt="Admission" align="center"/>
              <? } else if($res['status']=='Moderate'){ ?>
              <img src="image/mod.gif" border="0" name="minus_sign" alt="Moderate School" align="center" />
              <? } 
			  else if($res['status']=='Paid' and $check_sta['paymentstatus']=='Paid' ){ ?>
              <img src="image/paddy-smiley26.gif" border="0" name="paid" alt="Paid School" align="center" />
              <? }
			  
			  else if($res['status']=='NoContact'){ ?>
              <img src="image/nocontact.png" border="0" name="Admission" alt="Admission" align="center" />
              <? }else if($res['status']=='Session2014-15'){ ?>
              <img src="image/2013-14.jpg.png" border="0" name="Admission" alt="Admission" align="center" />
              <? }else echo "-";?></td>
              <td> <?php echo $res['information_source'];if($res['project_id']==5){echo " -Arjuna";} if($res['referral']=='fb') echo " - FB"; ?>
              <br />
              
              
              <?php      if($status['stjoined'] >='2014-05-01 02:00:00')
              {
             
                 echo  $stdate=date('d-M-Y h:i:s A',strtotime($status['stjoined']));
              }			  
		 else if( $status['stjoined'] <='2014-05-01 02:00:00' && $status['stjoined']!='0000-00-00')
			  {                               
echo  $stdate=date('d-M-Y H:i:s A',strtotime($status['stjoined']."+12 hours +32 minutes"));
		
			  }
			  ?></td>
              <td><?php echo $res['emp_name'];?><br /></td>
              
              <td width="16%">
			  <?php
			$ress  =   @mysql_fetch_array(mysql_query("select * from ordermanagement where memberid = '".$res['stud_id']."'"),MYSQL_ASSOC);
			
			   if(($res['information_source']=='Registration')){?>
                <!--    <a href="#" style="text-decoration:none"  onclick="window.open('editapp_detail.php?app_id=<?=$res['stud_id']?>','popup','width=800,height=800,scrollbars=yes,resizable=no,toolbar=no,directories=no,location=no,menubar=no,status=no,left=350,top=180'); return false"> <img src="images/edit.png" border="0" /> </a> 
                     ||-->
                       <?php    
			
			//print_r($ress['payment']);die;
			 if($ress['paymentstatus']=='pending' ){ ?><span style="font-weight:bold; color:#777"><a href="pmode_detail.php?reg_id=<?=$res['stud_id']?>" style="text-decoration:none;font-weight:bold; color:#999999" class="pmodee iframe">Pending</a></span><?  }
			 
			 if($ress['paymentstatus']=='Paid'){  ?><a href="pmode_detail.php?reg_id=<?=$res['stud_id']?>" style="text-decoration:none;font-weight:bold; color:#009900" class="pmodee iframe">Paid</a> <? } 
			
			 if($ress['paymentstatus']=='Underprocess'){ ?> <span style="font-weight:bold; color:#cc9900;"><a href="pmode_detail.php?reg_id=<?=$res['stud_id']?>" style="text-decoration:none;font-weight:bold; color:#330066" class="pmodee iframe">Underprocess</a></span><? }
 			
			 if($ress['paymentstatus']=='Unsuccessful') {  ?> <span style="font-weight:bold; color:#ff0000"><a href="pmode_detail.php?reg_id=<?=$res['stud_id']?>" style="text-decoration:none;font-weight:bold; color:#ff0000" class="pmodee iframe">Unsuccessful</a></span><? }
			
			 ?>
			
			
                  <!--  || 
                      
                      <a href="reg_detail.php?app_id=<?=$res['stud_id']?>" style="text-decoration:none" onclick="window.open('reg_detail.php?reg_id=<?=$res['stud_id']?>','popup','width=800,height=800,scrollbars=yes,resizable=no,toolbar=no,directories=no,location=no,menubar=no,status=no,left=350,top=180'); return false"><img src="images/print.jpg" width="19" height="20" border="0" /></a>--><? }?></td>
               <td><?php echo $res['ip_address'];?></td>
                <td><?php if($res['PPC']!="" || $res['PKW']!="" || $res['PCA']!=""){echo "paid";}
                else{ echo "Organic";}?></td>
                  <td><?php  if($res['PKW']!=""){echo $res['PKW'];} else { echo "-";}?></td>
                    <td><?php if($res['PPC']!=""){ echo $res['PPC'];} else { echo "-";}?></td>
                     <td><?php if($res['PCA']!=""){ echo $res['PCA'];} else {echo "-";} ?></td>
              <td align="center"><a href="stud_delete.php?stud_id=<?=$res['stud_id'];?>"><img src="images/del.gif" border="0" onClick="return delete_chk()"/></a></td>
          </tr>
          <? 
$incr++;
$first++;	
$i=$i+1;
} 
?>
        </table>
        <? if($reccnt > 0){	
?>
        <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
          <em>
          <tr>
            <td colspan="3"><img src="image/spacer.gif" height="3" /></td>
          </tr>
          </em>
          <tr>
            <td valign="middle" background="newbar.jpg" class="table_td_heading" style="padding-left:30px;" width="18%">&nbsp;</td>
            <td width="70%" height="26" valign="middle" background="newbar.jpg" class="table_td_heading" style="padding-top:2px;">
                <span class="table_td_heading">
<? include("paging.inc.php")
            ; ?>
              </span></td>
            <td width="12%" align="center" valign="middle" background="newbar.jpg" class="data">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
<!--                <tr>
                  <td align="right" valign="middle" class="table_td_heading" style="padding-right:5px;" width="100%"><strong>Page</strong>&nbsp;
                    <?=$spageno?>
                    &nbsp;of&nbsp;
                    <?=$spages?>
                  </td>
                </tr>-->
              </table></td>
            <?
}
?>
          </tr>
          <tr>
            <td colspan="3"><img src="image/spacer.gif" height="12" /></td>
          </tr>
          
          <tr>
            <td colspan="3"><img src="image/spacer.gif" height="10" /></td>
          </tr>
        </table></td>
      <? 
if($num_rows1>0)
{
?>
      <td width="40%" valign="top"><table width="100%" border="0" align="center"  cellpadding="5" cellspacing="1" bgcolor="#81cafd" style="font-size:11px">
          <tr bgcolor="#81cafd" align="center">
            <td width="9%" height="20" align="left" background="footerbg.jpg" class="whitetxt11">S.No.</td>
            <td align="left" background="footerbg.jpg" class="whitetxt11" width="21%">Student Name</td>
            
            <td align="left" background="footerbg.jpg" class="whitetxt11" width="12%">Date</td>
            <td align="left" background="footerbg.jpg" class="whitetxt11" width="12%">Time</td>
            <td align="left" background="footerbg.jpg" class="whitetxt11" width="12%">Foll. Up</td>
            <td align="left" background="footerbg.jpg" class="whitetxt11" width="19%">Next</td>
          </tr>
          <?
$incr = 1;
		
		if(!$_REQUEST['tpageno']){
			$tpageno = 1;
		} else {
			$tpageno= $_REQUEST['tpageno'];
		}
		$tpagesize=50;
		$incr = (($tpageno-1)*$tpagesize)+1;
		$first=$tpageno*$tpagesize-($tpagesize-1);
		$last=$first+$tpagesize-1; 
		$temp=($num_rows1%$tpagesize);
		if ($temp==0)
		$tpages=($num_rows1/$tpagesize);
		else
		$tpages=($num_rows1/$tpagesize)+1;
		settype($tpages, "integer"); 

		for($i=1;$i<$first;$i++)
			$row2000=mysql_fetch_row($result1);
     
     
     
//<?php
//$query="SELECT * FROM addschool";
//$result=mysql_query($query) or die(mysql_error());
while($res1=mysql_fetch_array($result1) and ($first<=$last))
{
if($i%2==0) {
	           $x = "bgcolor='#e9f5ff'";
	          } else {
	            $x = "bgcolor='#d8effe'";
 	          }
?>
          <tr <?=$x;?> align="left">
            <td width="9%"><? echo $i;?>.</td>
            <td width="21%"><?
 if (date("Y-M-d",strtotime($res1['remarkdate']))<=date("Y-M-d") && $res1['status']!='Paid')
 {
 ?>
              <font color="#FF0000"><blink><strong><a href="11.php?stud_id=<? echo $res1['stud_id'];?>"><?php echo $res1['stud_name'];?></a></strong></blink></font>
              <? 
 }
 else 
 {
 ?>
              <a href="11.php?stud_id=<? echo $res1['stud_id'];?>"><?php echo $res1['stud_name'];?></a>
              <? 
 } 
 ?>
            </td>
            
            <td width="12%">
                <? 
                if($res1['remarkdate'] <='2014-05-01 02:00:00')
                {
                
                if(date("Y-M-d",strtotime($res1['remarkdate']))<=date("Y-M-d") && $res1['status']!='Paid')
                           {   ?>
              <font color="#FF0000"><blink><strong><?php echo date("d-M-y",strtotime($res1['remarkdate']."+12 hours +32 minutes"));?></strong></blink></font>
              <? }
 else 
 {?>
              <?php echo date("d-M-y",strtotime($res1['remarkdate']."+12 hours +32 minutes"));?>
              <? 
 }
 
 
                }
                
              else{  
                  if(date("Y-M-d",strtotime($res1['remarkdate']))<=date("Y-M-d") && $res1['status']!='Paid')
                           {   ?>
              <font color="#FF0000"><blink><strong><?php echo date("d-M-y",strtotime($res1['remarkdate']));?></strong></blink></font>
              <? }
 else 
 {?>
              <?php echo date("d-M-y",strtotime($res1['remarkdate']));?>
              <? 
 } }
 ?>
            </td>
            <td width="12%"><?php echo $res1['remtime'];?></td>
            <td width="12%"><?php echo $res1['followup'];?></td>
            <td width="19%"><?php echo $res1['othernextstep'];?></td>
          </tr>
          <? 
	 	  $incr++;
	$first++;	
  $i=$i+1;
  } 
	?>
        </table>
        <? if($num_rows > 0){	?>
        <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td colspan="3"><img src="image/spacer.gif" height="3" /></td>
          </tr>
          <tr>
            <td   height="26"  valign="middle" background="newbar.jpg" class="table_td_heading" style="padding-left:5px;" width="60%"><span class="table_td_heading">Pages:
              <? if ($tpageno==1) { ?>
              &nbsp;
              <? } else {?>
              <a href="adminhome.php?empid=<?=$_GET['empid'] ?>&schoolname1=<?=$_GET['schoolname1'] ?>&keyword=<?=$_GET['keyword']?>&tpageno=<?=$tpageno-1?>&spageno=<?=$spageno?>" class="table_td_heading">Previous</a>
              <? } 
					for ($i=1; $i<=$tpages;$i++)
					{
					if($tpageno==$i)	{?>
              <strong class="table_td_heading"><? echo $i;?></strong>
              <? }
						else
					{
					if($i%5==0)
{
					?>
              <strong><a class="table_td_heading" href="adminhome.php?empid=<?=$_GET['empid'] ?>&schoolname1=<?=$_GET['schoolname1'] ?>&keyword=<?=$_GET['keyword']?>&tpageno=<?=$i?>&spageno=<?=$spageno?>">
              <?=$i?>
              </a></font></strong>
              <? 
					}
					}
					}
					?>
              <? if ($tpageno<$tpages) { ?>
              <a href="adminhome.php?empid=<?=$_GET['empid'] ?>&schoolname1=<?=$_GET['schoolname1'] ?>&keyword=<?=$_GET['keyword']?>&tpageno=<?=$tpageno+1?>&spageno=<?=$spageno?>" class="table_td_heading">Next</a>
              <? } else {?>
              <? } ?>
              </span></td>
            <td width="10%" align="right" valign="middle" background="newbar.jpg" class="data"><!--DWLayoutEmptyCell-->&nbsp;</td>
            <td width="30%" align="center" valign="middle" background="newbar.jpg" class="data"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td align="right" valign="middle" class="table_td_heading" style="padding-right:5px;" width="100%"><strong>Page</strong>&nbsp;
                    <?=$tpageno?>
                    &nbsp;of&nbsp;
                    <?=$tpages?>
                  </td>
                </tr>
              </table>
              <strong></strong></td>
          </tr>
        </table></td>
      <?
}
?>
    </tr>
  </table>
  <table align="center" width="100%">
    <tr>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td class="footer" width="100%" >&copy; 2009 TeacherSITY. All rights reserved</td>
    </tr>
  </table>
  <? }?>
  <? }?>
</form>
</body>
</html>
