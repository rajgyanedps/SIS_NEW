<?php
ob_start();
error_reporting(0);
session_start();
include("connection.php");
if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='School Login' && $_SESSION['user_type']!='Tele Caller')
{
 header("Location: index.php");
}

if (isset($_POST['submit']))
{

if($_POST['course']=='B.Tech')
{
$stream = $_POST['btech_stream'];

}
else if($_POST['course']=='MBA')
{
$stream = $_POST['mba_stream'];
}
else
{
$stream = "";
}

$sql="INSERT INTO student( joined, stud_name, add1, add2, city, phone_code,phone_no,email, state, pin, course, stream, percentage,information_source,req_type,emp_id) VALUES (now(),'".$_POST['stud_name']."','".$_POST['add1']."','".$_POST['add2']."','".$_POST['city']."','".$_POST['phone_code']."','".$_POST['phone_no']."','".$_POST['email']."','".$_POST['state']."','".$_POST['pin']."','".$_POST['course']."','$stream','".$_POST['percentage']."','".$_POST['information_source']."','Offline' ,'100100')";

$result=mysql_query($sql) or die(mysql_error());


if ($_SESSION['user_type']=="Project Manager")
{
header("Location: pmhome.php?msg1=Student Added Successfully......");
}
else if ($_SESSION['user_type']=="Tele Caller")
{
header("Location: tchome.php?msg1=Student Added Successfully......");
}
else
{
header("Location: adminhome.php?empid=".$_SESSION['emp_id']."&msg=Student Added Successfully......");
}
}
?>
<?
$_SESSION['this_page']='student.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Add New Student</title><link rel="shortcut icon" href="http://www.selaqui.org/images/favicon.ico" type="image/x-icon">

<script type="text/javascript">
function show_tr(tr_id) {

//document.getElementById("support8").style.display = 'none';
//document.getElementById("support9").style.display = 'none'; 
document.getElementById(tr_id).style.display = 'block'; 
} 

function showhide(val)
{
if(val.value=='B.Tech')
document.getElementById('course_pref').style.display='block';
else
document.getElementById('course_pref').style.display='none';
if(val.value=='MBA')
document.getElementById('course_pref1').style.display='block';
else
document.getElementById('course_pref1').style.display='none';

}
</script>


<script type="text/javascript">
function validate_addform()
{
//checking school name field
   if (document.add_school.stud_name.value=="")
	{
		alert("The Student name field is blank. \nPlease enter Student name in the text box.");
		document.add_school.stud_name.focus();
		return false;
      }
//checking add1 field
     if (document.add_school.course.value=="")
	 {
		alert("Course is blank. \nPlease select the Course field in the combo box.");
		document.add_school.course.focus();
		return false;
      }	
	  
	  if (document.add_school.course.value=="MBA")
	  {
	  	if(document.add_school.mba_stream.value=="")
		{
		alert("Stream is blank. \nPlease select the Stream field in the combo box.");
		document.add_school.mba_stream.focus();
		return false;
		}
      }	
	  if (document.add_school.course.value=="B.Tech")
	  {
	  	if(document.add_school.btech_stream.value=="")
		{
		alert("Stream is blank. \nPlease select the Stream field in the combo box.");
		document.add_school.btech_stream.focus();
		return false;
		}
      }	   
	  
	  
//checking add1 field
      	 //if (document.add_school.add2.value=="")
		//{
		//alert("The Address 2 field is blank. \nPlease enter Address 2 in the text box.");
		//document.add_school.add2.focus();
		//return false;
      //}	  
//checking city field
    // if (document.add_school.city.value=="")
	//{
		//alert("The City field is blank. \nPlease enter city in the text box.");
		//document.add_school.city.focus();
		//return false;
      //}	  	    
	  
//checking alphabetic values in City

    var iChars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ';
    for (i = 0; i < document.add_school.city.value.length; i++) {
      if (iChars.indexOf(document.add_school.city.value.charAt(i)) == -1) {
         alert('Please enter letters only in City field');
         document.add_school.city.focus();
         return false;
      }
      }	
// checking phone_code field
	  
	  //if (document.add_school.phone_code.value=="")
	 //{
		//alert("The Phone Code is blank. \nPlease enter the Phone Code field in the text box.");
        //document.add_school.phone_code.focus();		
        //return false;
      //}
	  
//checking numeric value in phone_code
     var n = document.add_school.phone_code.value;
    if(isNaN(n) == true) {
        alert('Your entry is not a numberic value in code no. field, Please try again');
        document.add_school.phone_code.focus();
        return false;
    }	    
// checking phone_no field
	  
	  //if (document.add_school.phone_no.value=="")
	 //{
		//alert("The Phone No. is blank. \nPlease enter the Phone No. field in the text box.");
        //document.add_school.phone_no.focus();		
        //return false;
     // }
	  

//checking numeric value in fax_code
     

// checking state field
	  
	 // if (document.add_school.state.value=="")
	 //{
		//alert("The State is blank. \nPlease select the state field in the combo box.");
        //document.add_school.state.focus();		
        //return false;
      //}		

// checking pin field
	  
	 // if (document.add_school.pin.value=="")
	 //{
		//alert("The pin no. is blank. \nPlease enter the pin no. field in the text box.");
        //document.add_school.pin.focus();		
        //return false;
      //}
	  
//checking numeric value in pin
     var n = document.add_school.pin.value;
    if(isNaN(n) == true) {
        alert('Your entry is not a numberic value in pin no. field, Please try again');
        document.add_school.pin.focus();
        return false;
    }	
// checking boardaff field
	  
	  if (document.add_school.boardaff.value=="")
	 {
		alert("The Board Affiliation is blank. \nPlease select the board affiliation field in the combo box.");
        document.add_school.boardaff.focus();		
        return false;
      }		

}	  				  			  		

</script>
<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php
include("header.php");
?>
<br /><br /><br />
<form name="add_school" method="post" action="" onsubmit="return validate_addform();">
<table width="800" border="0" align="center" bgcolor="#f3f7fd" cellpadding="8" cellspacing="0" style="border:solid 1px #71befb;"> 
<tr><td background="butbg.gif" height="10px" style="border-bottom:solid 1px #71befb; font-size:13px; color:#064582;">&nbsp;&nbsp;<b>Add New Student</b></td>
</tr>

<tr><td><table width="100%" align="center" cellpadding="0" cellspacing="6" style="font-size:13px">
  <tr>
    <td width="126">Student Name</td>
    <td width="4">:</td>
    <td width="236"><input type="text" name="stud_name" size="30"   style="border:solid 1px #61b5f8; background-color:#FFFFFF;" />
      &nbsp;<font color="#FF0000"><b>*</b></font></td>
    <td width="116">&nbsp;&nbsp;Class</td>
    <td width="4">:</td>
    <td width="252"><select name="course" id="course" style="border:solid 1px #61b5f8; background-color:#FFFFFF;">
      <option value="">--Select--</option>
      <option value="V">V</option>
      <option value="VI">VI</option>
      <option value="VII">VII</option>
      <option value="VIII">VIII</option>
      <option value="IX">IX</option>
      <option value="X">X</option>
      <option value="XI &shy; Science / Medical">XI &shy; Science / Medical</option>
      <option value="X">XI &shy; Science / Non-Medical</option>
      <option value="X">XI &shy; Commerce</option>
      <option value="XI">XI &shy; Humanities</option>
     </select>
      &nbsp;<font color="#FF0000"><b>*</b></font>
      <div id="course_pref" style="width:80%; float:left; z-index:1; margin-top:5px; <? if($_POST['course']!='B.Tech'){ ?> display:none; <? } ?>">
        <select name="btech_stream" id="btech_stream" style="width:160px; border:solid 1px #61b5f8; background-color:#FFFFFF;">
          <option value="">--Select Stream--</option>
          <option value="Mechanical" <? if($_POST['btech_stream']=='Mechanical'){ echo "selected"; } ?>>Mechanical</option>
          <option value="Civil" <? if($_POST['btech_stream']=='Civil'){ echo "selected"; } ?>>Civil</option>
          <option value="Electrical" <? if($_POST['btech_stream']=='Electrical'){ echo "selected"; } ?>>Electrical</option>
          <option value="Electronics & Comm. Business" <? if($_POST['btech_stream']=='Electronics & Comm. Business'){ echo "selected"; } ?>>Electronics & Comm. Business</option>
          <option value="Computer" <? if($_POST['btech_stream']=='Computer'){ echo "selected"; } ?>>Computer</option>
        </select>
        &nbsp;<font color="#FF0000"><b>*</b></font></div>
      <div id="course_pref1" style="width:80%; float:left; z-index:1000; margin-top:5px; <? if($_POST['course']!='B.Tech'){ ?> display:none; <? } ?>">
        <select name="mba_stream" id="mba_stream" style="width:160px; border:solid 1px #61b5f8; background-color:#FFFFFF;">
          <option value="">--Select Stream--</option>
          <option value="Financial" <? if($_POST['mba_stream']=='Financial'){ echo "selected"; } ?>>Financial</option>
          <option value="HR" <? if($_POST['mba_stream']=='HR'){ echo "selected"; } ?>>HR</option>
          <option value="IT" <? if($_POST['mba_stream']=='IT'){ echo "selected"; } ?>>IT</option>
          <option value="Marketing" <? if($_POST['mba_stream']=='Marketing'){ echo "selected"; } ?>>Marketing</option>
          <option value="International Business" <? if($_POST['mba_stream']=='International Business'){ echo "selected"; } ?>>International Business</option>
        </select>
        &nbsp;<font color="#FF0000"><b>*</b></font></div></td>
  </tr>
  <tr>
    <td>Email Id</td>
    <td>:</td>
    <td><input type="text" name="email" id="email" size="30" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" />    </td>
    <td>&nbsp;&nbsp;Phone No.</td>
    <td>:</td>
    <td><input type="text" name="phone_code" id="phone_code" size="8" maxlength="8"  style="border:solid 1px #61b5f8; background-color:#FFFFFF;" />
        <input type="text" name="phone_no" size="17" maxlength="100"  style="border:solid 1px #61b5f8; background-color:#FFFFFF;" /></td>
  </tr>
  <tr>
    <td>Address1</td>
    <td>:</td>
    <td><input type="text" name="add1" id="add1" size="30" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" /></td>
    <td>&nbsp;&nbsp;Address2</td>
    <td>:</td>
    <td><input type="text" name="add2" id="add2" size="30" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" /></td>
  </tr>
  <tr>
    <td>City</td>
    <td>:</td>
    <td><input type="text" name="city" id="city" size="30" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" /></td>
    <td>&nbsp;&nbsp;State</td>
    <td>:</td>
    <td><input type="text" name="state" id="state" size="30" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" /></td>
  </tr>
  <tr>
    <td>Pin</td>
    <td>:</td>
    <td><input type="text" name="pin" id="pin" size="30" maxlength="6" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" /></td>
    <td nowrap="nowrap">&nbsp;&nbsp;Information Source</td>
    <td>:</td>
    <td><select name="information_source"  style="border:solid 1px #61b5f8; background-color:#FFFFFF; width:170px">
      <option value="">---Select---</option>
      <option value="Application">Application</option>
      <option value="Registration">Registration</option>
      <option value="Enquiry">Enquiry</option>
      <option value="Telephone">Telephone</option>
      <option value="SMS">SMS</option>
      <option value="Google">Google</option>
      <option value="Internet">Internet</option>
      <option value="Hoarding">Hoarding</option>
      <option value="Newspaper">Newspaper</option>
      <option value="Fair/Exhibition">Fair/Exhibition</option>
      <option value="Seminar">Seminar</option>
      <option value="Word of Mouth">Word of Mouth</option>
      <option value="Data">Data</option>
      <option value="Counselling Associate">Counselling Associate</option>
      <option value="Magzine">Magzine</option>
      <option value="Walk In">Walk In</option>
      <option value="Referral">Referral</option>
    </select></td>


 



  </tr>
  <!--<tr>
    <td>Percentage</td>
    <td>:</td>
    <td><input type="text" name="percentage" id="percentage" size="30" maxlength="6"  style="border:solid 1px #61b5f8; background-color:#FFFFFF;" /></td>
    <td>&nbsp;&nbsp;</td>
    <td></td>
    <td>&nbsp;</td>
  </tr>-->
  <tr>
    <td colspan="6"></td>
  </tr>
  <tr>
    <td colspan="6"></td>
  </tr>
  <tr>
    <td colspan="6"></td>
  </tr>
  <tr>
    <td colspan="6"></td>
  </tr>
  <tr>
    <td align="center" colspan="6"><input type="submit" name="submit" value="Submit"  />    </td>
  </tr>
  <tr>
    <td colspan="6"></td>
  </tr>
</table></td>
</tr></table>
</form>
</body>
</html>

