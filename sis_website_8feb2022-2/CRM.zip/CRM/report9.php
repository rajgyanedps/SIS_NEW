<?php 
require_once('connection.php'); 
?>
<?php
//$today = date("Y-m-d");
//$thisMonth=date("Y-m%");
//$time = time("H:i:s");
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Data_Report.xls");
header("Pragma: no-cache");
header("Expires: 0");
$now=date("j-n-Y");
echo "\t \t Report ON ".$now."\t";
$sql_model=mysql_query("SELECT * FROM addassessment WHERE school_id='".$_GET['school_id']."' order by joined asc");
print("\n");
print("\n");
	    echo "S.No."."\t";
		echo "Date & Time"."\t";
		echo "School is working with Org."."\t";
		echo "Name of Org."."\t";
		
		print("\n"); 
		$i=1;
 while($row = mysql_fetch_array($sql_model))
    {
        echo $i."\t";
		echo $row['joined']."\t";
		echo $row['working']."\t";
		echo $row['other_working']."\t";
		
		
		
				
		print "\n";
		$i+=1;		
    }

?>