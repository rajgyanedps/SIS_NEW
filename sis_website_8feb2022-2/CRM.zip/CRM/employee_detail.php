<? session_start();
include("connection.php");
?>
<div style="height:350px;overflow:auto;">
 <?
 $emp_name = "select * from members order by emp_id asc";
 $result_name = mysql_query($emp_name) or die(mysql_error());
 while($row_name=mysql_fetch_array($result_name))
 {
 echo"<br>";
 ?>
 <a href="userlist.php?emp_id=<? echo $row_name['emp_id'];?>"><? echo $row_name['emp_name'];?></a>
<?
 echo"<br>";
 }
 
 ?>
 </div>
