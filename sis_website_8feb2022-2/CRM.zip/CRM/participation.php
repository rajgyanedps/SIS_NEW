<?php
include("connection.php");
session_start();
if (isset($_POST['submit']))

{
$q="DELETE FROM addparticipation WHERE school_id='".$_POST['school_id']."'";
$d=mysql_query($q) or die(mysql_error());

$sql="INSERT INTO addparticipation(school_id,joined,statuspart,datetest,expstudent,exptest,actstudent,acttest) VALUES ('".$_POST['school_id']."',now(),'".$_POST['statuspart']."','".$_POST['datetest']."','".$_POST['expstudent']."','".$_POST['exptest']."','".$_POST['actstudent']."','".$_POST['acttest']."')";

$result=mysql_query($sql) or die(mysql_error());

if ($_SESSION['user_type']=="Project Manager")
{
header("Location: pmhome.php?msg=School Participation Added Successfully......");
}
else if ($_SESSION['user_type']=="Tele Caller")
{
header("Location: tchome.php?msg=School Participation Added Successfully......");
}
else
{
header("Location: adminhome.php?msg=School Participation Added Successfully......");
}
}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Add School Participation</title>
<link rel="stylesheet" type="text/css" href="calendar-blue.css">
<script type="text/javascript" src="calendar.js"></script>
<script type="text/javascript" src="calendar-en.js"></script>
<script type="text/javascript" src="calendar-setup.js"></script>
<script language="javascript1.2" src="tabber.js"></script>

<script type="text/javascript">
function ValidateForm()
{
// checking datetest field
      if (document.participation.datetest.value=="")
	{
		alert("The date of test field is blank. \nPlease enter date of test in the text box.");
		document.participation.datetest.focus();
		return false;
      }	 
// checking expstudent field
	  
	  if (document.participation.expstudent.value=="")
	 {
		alert("The Expected Student is blank. \nPlease enter the Expected Student field in the text box.");
        document.participation.expstudent.focus();		
        return false;
      }
	  
//checking numeric value in expstudent
     var n = document.participation.expstudent.value;
    if(isNaN(n) == true) {
        alert('Your entry is not a numberic value in expected student field, Please try again');
        document.participation.expstudent.focus();
        return false;
    }	  	
// checking exptest field
	  
	  if (document.participation.exptest.value=="")
	 {
		alert("The Expected Test is blank. \nPlease enter the Expected Test field in the text box.");
        document.participation.exptest.focus();		
        return false;
      }
	  
//checking numeric value in exptest
     var n = document.participation.exptest.value;
    if(isNaN(n) == true) {
        alert('Your entry is not a numberic value in expected test field, Please try again');
        document.participation.exptest.focus();
        return false;
    }	  
//checking numeric value in actstudent
     var n = document.participation.actstudent.value;
    if(isNaN(n) == true) {
        alert('Your entry is not a numberic value in actual student field, Please try again');
        document.participation.actstudent.focus();
        return false;
    }	  	  	
//checking numeric value in acttest
     var n = document.participation.acttest.value;
    if(isNaN(n) == true) {
        alert('Your entry is not a numberic value in actual test field, Please try again');
        document.participation.acttest.focus();
        return false;
    }	  	  						   	
	  }
</script>
<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />
</head>

<body>
<?php
include("header.php");
?>
<br /><br /><br /><br />
<form name="participation" method="post" action="participation.php" onsubmit="return ValidateForm();">
<table border="0" align="center" bgcolor="#f3f7fd" cellpadding="8" cellspacing="0" style="border:solid 1px #71befb;"> 
<tr><td background="butbg.gif" height="10px" style="border-bottom:solid 1px #71befb; font-size:13px; color:#064582;">&nbsp;&nbsp;<b>Add School Participation</b></td></tr>


<tr><td>
<table width="491" border="0" align="center" cellpadding="4" cellspacing="0" style="font-size:13px">

<tr><td colspan="3"></td></tr>
<tr>
<input type="hidden" name ="school_id" value="<?= $_GET['school_id']?>">
<td>Status of Participation</td>
<td>:</td>
<td><select name="statuspart" style="height:20px; border:solid 1px #92cdfd;font-size:13px;  color:#0a5095;background-color:#ffffff">
<option value="Positive">Positive</option>

</select>&nbsp;<font color="#FF0000"><b>*</b></font>
</td>
</tr>
<tr><td>Date of Test</td>
<td>:</td>
<td><label>
<input type="text" name="datetest" size="40" id="datetest1" onchange="setdt();" readonly="readonly"  style="height:18px; border:solid 1px #92cdfd;font-size:13px;  color:#0a5095;background-color:#ffffff"/>
<img src="CalendarIcon.gif" name="get_stud_date" width="22" height="23" border="0" align="absmiddle" id="get_stud_date" style="cursor: pointer;" title="Date selector" onmouseover="this.style.background='red';" onmouseout="this.style.background=''" />
        <script type="text/javascript">
	  	Calendar.setup({
        inputField     :    "datetest1",     // id of the input field
	    //ifFormat       :    "%Y/%m/%d %l:%M %P",      // format of the input field
	  	//ifFormat       :    "%m-%d-%Y",      // format of the input field
	  	ifFormat       :    "%Y-%m-%d",      // format of the input field
        button         :    "get_stud_date",  // trigger for the calendar (button ID)
        align          :    "Tl",           // alignment (defaults to "Bl")
        singleClick    :    true,
		showsTime		:	true
    });

        </script>
        </label>&nbsp;<font color="#FF0000"><b>*</b></font>      
</td>
</tr>
<tr><td>No. of Expected Students</td>
<td>:</td>
<td><input type="text" name="expstudent" size="40"  style="height:18px; border:solid 1px #92cdfd;font-size:13px;  color:#0a5095;background-color:#ffffff"/>&nbsp;<font color="#FF0000"><b>*</b></font>
</td></tr>

<tr><td>No. of Expected Tests</td>
<td>:</td>
<td><input type="text" name="exptest" size="40"  style="height:18px; border:solid 1px #92cdfd;font-size:13px;  color:#0a5095;background-color:#ffffff"/>&nbsp;<font color="#FF0000"><b>*</b></font></td></tr>
<tr><td>No. of Actual Students</td>
<td>:</td>
<td><input type="text" name="actstudent" size="40"  style="height:18px; border:solid 1px #92cdfd;font-size:13px;  color:#0a5095;background-color:#ffffff"/></td></tr>
<tr><td>No. of Actual Tests</td>
<td>:</td>
<td><input type="text" name="acttest" size="40"  style="height:18px; border:solid 1px #92cdfd;font-size:13px;  color:#0a5095;background-color:#ffffff"/>
</td></tr>

<tr><td colspan="3"></td></tr>
<tr><td colspan="3"></td></tr><tr><td colspan="3"></td></tr><tr><td colspan="3"></td></tr>
<tr><td colspan="3" align="center"><input type="submit" name="submit" value="Submit" /></td></tr>
</table></td></tr></table>


<br /><br />
<table width="95%" border="0" align="center" cellpadding="5" cellspacing="0" style="font-size:13px;">
<tr bgcolor="#999999" align="center">

      <td align="left" background="footerbg.jpg" class="whitetxt11" width="2%">S.No.</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="13%">Date & Time</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="5%">Status</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="10%">Date of Test</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="17%">Expected No. of Student</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="15%">Expected No. of Test</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="15%">Actual No. of Student</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="13%">Actual No. of test</a></td>
    </tr>
<?php
$sql_cust = "SELECT * FROM addparticipation WHERE school_id='".$_GET['school_id']."' order by joined asc";
$result = mysql_query($sql_cust);
$count = 0;
while($row = mysql_fetch_array($result))
{
	$count++;
?>
<tr>
        <td valign="top" width="2%"><? echo $count;?>.</td>
             <td width="13%"><?php echo $row['joined'];?></td>
                 <td width="5%"><?php echo $row['statuspart'];?></td>
                     <td width="10%"><?php echo $row['datetest'];?></td>
                         <td width="17%"><?php echo $row['expstudent'];?></td>
                             <td width="15%"><?php echo $row['exptest'];?></td>
                                 <td width="15%"><?php echo $row['actstudent'];?></td>
                                     <td width="13%"><?php echo $row['acttest'];?></td>
    </tr>
    <?
}
?>
</table>
</form>
</body>
</html>