<?php
include("connection.php");
session_start();
if (isset($_POST['submit']))

{
$sql="INSERT INTO addammount(school_id,joined,totalamm,advanceamm,balanceamm,senddate,duedate,chequeno,bankname,city) VALUES ('".$_POST['school_id']."', now(),'".$_POST['totalamm']."','".$_POST['advanceamm']."','".$_POST['balanceamm']."','".$_POST['senddate']."','".$_POST['duedate']."','".$_POST['chequeno']."','".$_POST['bankname']."','".$_POST['city']."')";

$result=mysql_query($sql) or die(mysql_error());

$q="DELETE FROM last_totalamm WHERE school_id='".$_POST['school_id']."'";
$d=mysql_query($q) or die(mysql_error());

$a="INSERT INTO last_totalamm(school_id,totalamm) VALUES ('".$_POST['school_id']."','".$_POST['totalamm']."')";
$x=mysql_query($a) or die(mysql_error());

if ($_SESSION['user_type']=="Project Manager")
{
header("Location: pmhome.php?msg=Ammount Details Added Successfully......");
}
else if ($_SESSION['user_type']=="Tele Caller")
{
header("Location: tchome.php?msg=Ammount Details Added Successfully......");
}
else
{
header("Location: adminhome.php?msg=Ammount Details Added Successfully......");
}
}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Add Amount Details</title>
<link rel="stylesheet" type="text/css" href="calendar-blue.css">
<script type="text/javascript" src="calendar.js"></script>
<script type="text/javascript" src="calendar-en.js"></script>
<script type="text/javascript" src="calendar-setup.js"></script>
<script language="javascript1.2" src="tabber.js"></script>

<script language="javascript">
function calc()
{
var a = document.addammount.advanceamm.value;
var t = document.addammount.totalamm.value;
var p = document.addammount.alreadypaid.value;
document.addammount.balanceamm.value = (t-p)-a;

}

function ValidateForm()
{
// checking advanceammount field
	  
	  if (document.addammount.advanceamm.value=="")
	 {
		alert("The Advance Ammount is blank. \nPlease enter the Advance Ammount field in the text box.");
        document.addammount.advanceamm.focus();		
        return false;
      }
	  
//checking numeric value in advanceammount
     var n = document.addammount.advanceamm.value;
    if(isNaN(n) == true) {
        alert('Your entry is not a numberic value in advance ammount field, Please try again');
        document.addammount.advanceamm.focus();
        return false;
    }	
// checking balanceammount field
	  
	  if (document.addammount.balanceamm.value=="")
	 {
		alert("The Balance Ammount is blank. \nPlease click the Balance button.");
        document.addammount.balanceamm.focus();		
        return false;
      }	 
// checking senddate field
	  
	  if (document.addammount.senddate.value=="")
	 {
		alert("The Send Date is blank. \nPlease click the calander button.");
        document.addammount.senddate.focus();		
        return false;
      }	
// checking duedate field
	  
	  if (document.addammount.duedate.value=="")
	 {
		alert("The Due Date is blank. \nPlease click the calander button.");
        document.addammount.duedate.focus();		
        return false;
      }	
// checking chequeno. field
	  
	  if (document.addammount.chequeno.value=="")
	 {
		alert("The Cheque No. is blank. \nPlease enter the cheque no. in the text box.");
        document.addammount.chequeno.focus();		
        return false;
      }		
// checking bankname field
	  
	  if (document.addammount.bankname.value=="")
	 {
		alert("The Bank Name is blank. \nPlease enter the bank name in the text box.");
        document.addammount.bankname.focus();		
        return false;
      }		  	  
// checking city field
	  
	  if (document.addammount.city.value=="")
	 {
		alert("The City is blank. \nPlease enter the city in the text box.");
        document.addammount.city.focus();		
        return false;
      }			  		  	   		  
}
</script>
<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php
include("header.php");
?>
<?php
$w="SELECT * FROM addparticipation WHERE school_id='".$_GET['school_id']."'";
$result=mysql_query($w) or die(mysql_error());
$row=mysql_fetch_array($result);
?>
<?php
$q="SELECT SUM(advanceamm) as sumamm FROM addammount WHERE school_id='".$_GET['school_id']."'";
$result1=mysql_query($q) or die(mysql_error());
$row1=mysql_fetch_array($result1);
?>
<?php
$x="SELECT balanceamm as lastamm FROM addammount WHERE school_id='".$_GET['school_id']."' order by joined desc limit 1";
$result2=mysql_query($x) or die(mysql_error());
$row2=mysql_fetch_array($result2);
?>
<?php
function mul($a,$b)
{
$total=$a*$b;
return $total;
}
?>
<br /><br /><br />
<form name="addammount" method="post" action="ammount.php" onsubmit="return ValidateForm();">
<table width="493" border="0" align="center" bgcolor="#f3f7fd" cellpadding="8" cellspacing="0" style="border:solid 1px #71befb;"> 
<tr><td background="butbg.gif" height="10px" style="border-bottom:solid 1px #71befb; font-size:13px; color:#064582;">&nbsp;&nbsp;<b>Add Amount Details</b></td>
</tr>


<tr><td>
<table width="476" border="0" align="center" cellpadding="4" cellspacing="0" style="font-size:13px">

<tr><td colspan="3"></td></tr>

<tr><td>Total No. of Tests</td>
<td>:</td>
<input type="hidden" name ="school_id" value="<?= $_GET['school_id']?>">
<td><input type="text" name="totaltest" size="40" readonly="readonly" value="<? echo $row['exptest'] ?>" style="height:18px; border:solid 1px #92cdfd;font-size:13px; color:#0a5095;background-color:#ffffff;" />
</td>
</tr>
<tr><td>Rs. Per Test</td>
<td>:</td>
<td><input type="text" name="rspertest" size="40" value="135" readonly="readonly" style="height:18px; border:solid 1px #92cdfd;font-size:13px; color:#0a5095;background-color:#ffffff;" />
</td>
</tr>
<tr><td>Total Amount</td>
<td>:</td>
<td><input type="text" name="totalamm" id="totalamm" size="40" readonly="readonly" value="<? echo mul($row['exptest'],135)?>" style="height:18px; border:solid 1px #92cdfd;font-size:13px; color:#0a5095;background-color:#ffffff;" />
     
</td></tr>
<tr><td><b>Already Paid</b></td>
<td>:</td>
<td><input type="text" name="alreadypaid" id="alreadypaid" size="40" readonly="readonly" value="<? echo $row1['sumamm'] ?>" style="height:18px; border:solid 1px #92cdfd;font-size:13px; color:#0a5095;background-color:#ffffff;" /> </td></tr>

<tr>
<td>Advance Amount</td>
<td>:</td>
<td><input type="text" name="advanceamm" id="advanceamm" size="40" onchange="calc()" style="height:18px; border:solid 1px #92cdfd;font-size:13px; color:#0a5095;background-color:#ffffff;"/>&nbsp;<font color="#FF0000"><b>*</b></font></td></tr>
<tr>
<td>Balance Amount</td>
<td>:</td>
<td><input type="text" name="balanceamm" id="balanceamm" size="40" readonly="readonly" value="<? echo $row2['lastamm'] ?>" style="height:18px; border:solid 1px #92cdfd;font-size:13px; color:#0a5095;background-color:#ffffff;"/></td>&nbsp;
</tr>
<tr><td>Received Cheque/DD Date</td>
<td>:</td>
<td><label><input type="text" name="senddate" size="40" readonly="readonly" id="senddate1" onchange="setdt();" style="height:18px; border:solid 1px #92cdfd;font-size:13px; color:#0a5095;background-color:#ffffff;"/>
<img src="CalendarIcon.gif" name="get_stud_date" width="22" height="23" border="0" align="absmiddle" id="get_stud_date" style="cursor: pointer;" title="Date selector" onmouseover="this.style.background='red';" onmouseout="this.style.background=''" />
        <script type="text/javascript">
	  	Calendar.setup({
        inputField     :    "senddate1",     // id of the input field
	    //ifFormat       :    "%Y/%m/%d %l:%M %P",      // format of the input field
	  	//ifFormat       :    "%m-%d-%Y",      // format of the input field
	  	ifFormat       :    "%Y-%m-%d",      // format of the input field
        button         :    "get_stud_date",  // trigger for the calendar (button ID)
        align          :    "Tl",           // alignment (defaults to "Bl")
        singleClick    :    true,
		showsTime		:	true
    });

        </script>
        </label>&nbsp;<font color="#FF0000"><b>*</b></font>       
</td></tr>
<tr><td>Due Date</td>
<td>:</td>
<td><label><input type="text" name="duedate" size="40" readonly="readonly" id="duedate1" onchange="setdt();" style="height:18px; border:solid 1px #92cdfd;font-size:13px; color:#0a5095;background-color:#ffffff;" />
<img src="CalendarIcon.gif" name="get_stud_date1" width="22" height="23" border="0" align="absmiddle" id="get_stud_date1" style="cursor: pointer;" title="Date selector" onmouseover="this.style.background='red';" onmouseout="this.style.background=''" />
        <script type="text/javascript">
	  	Calendar.setup({
        inputField     :    "duedate1",     // id of the input field
	    //ifFormat       :    "%Y/%m/%d %l:%M %P",      // format of the input field
	  	//ifFormat       :    "%m-%d-%Y",      // format of the input field
	  	ifFormat       :    "%Y-%m-%d",      // format of the input field
        button         :    "get_stud_date1",  // trigger for the calendar (button ID)
        align          :    "Tl",           // alignment (defaults to "Bl")
        singleClick    :    true,
		showsTime		:	true
    });

        </script>
        </label> &nbsp;<font color="#FF0000"><b>*</b></font>     
</td></tr>
<tr><td>Cheque/DD No.</td>
<td>:</td>
<td><input type="text" name="chequeno" size="40" style="height:18px; border:solid 1px #92cdfd;font-size:13px; color:#0a5095;background-color:#ffffff;" />&nbsp;<font color="#FF0000"><b>*</b></font>
</td></tr>
<tr><td>Bank Name</td>
<td>:</td>
<td><input type="text" name="bankname" size="40" style="height:18px; border:solid 1px #92cdfd;font-size:13px; color:#0a5095;background-color:#ffffff;" />&nbsp;<font color="#FF0000"><b>*</b></font>
</td></tr>
<tr><td>City</td>
<td>:</td>
<td><input type="text" name="city" size="40" style="height:18px; border:solid 1px #92cdfd;font-size:13px; color:#0a5095;background-color:#ffffff;" />&nbsp;<font color="#FF0000"><b>*</b></font>
</td></tr>
<tr><td colspan="3"></td></tr>
<tr><td colspan="3"></td></tr><tr><td colspan="3"></td></tr><tr><td colspan="3"></td></tr>
<tr><td colspan="3" align="center"><input type="submit" name="submit" value="Submit" /></td></tr>

</table></td></tr></table>


<br /><br />
<table width="95%" border="0" align="center" cellpadding="5" cellspacing="0" style="font-size:13px">
<tr bgcolor="#999999" align="center">

      <td align="left" background="footerbg.jpg" class="whitetxt11" width="4%">S.No.</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="21%">Date & Time</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="15%">Total Amm.</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="15%">Amount Paid</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="15%">Balance Amount</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="15%">Due Date</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="15%">Cheque No.</a></td>
      
    </tr>
<?php
$sql_cust = "SELECT *, addammount.joined, addschool.school_id, addschool.school_name FROM addammount, addschool WHERE addammount.school_id ='".$_GET['school_id']."' and addschool.school_id=addammount.school_id order by addammount.joined asc";
$result = mysql_query($sql_cust);
$count = 0;
while($row = mysql_fetch_array($result))
{
	$count++;
?>
<tr>
        <td valign="top" width="4%"><? echo $count;?>.</td>
             <td width="21%"><?php echo $row['joined'];?></td>
                 <td width="15%"><?php echo $row['totalamm'];?></td>
                     <td width="15%"><?php echo $row['advanceamm'];?></td>
                         <td width="15%"><?php echo $row['balanceamm'];?></td>
                             <td width="15%"><?php echo $row['duedate'];?></td>
                                 <td width="15%"><?php echo $row['chequeno'];?></td>
                                     
    </tr>
    <?
}
?>
</table>
</form>
</body>
</html>