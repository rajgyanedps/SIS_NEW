<script type="text/javascript" src="Script/prototype.js"></script>
	<script type="text/javascript" src="Script/effects.js"></script>
	<script type="text/javascript" src="Script/accordion.js"></script>
    	<script type="text/javascript">
			
		//
		//  In my case I want to load them onload, this is how you do it!
		// 
		Event.observe(window, 'load', loadAccordions, false);
	
		//
		//	Set up all accordions
		//
					
				function loadAccordions() {
			
			var bottomAccordion = new accordion('vertical_container');
			
				
			// Open first one
			bottomAccordion.activate($$('#vertical_container .accordion_toggle')[0]);
			

		}
			
		
		
	</script>
<style type="text/css" >
		
		/*
			Vertical Accordions
		*/
		
		.accordion_toggle {
	display: block;
	height: 25px;
	width: 158px;
	line-height: 25px;
	color: #ffffff;
	font-weight: bold;
	text-decoration: none;
	outline: none;
	font-size: 12px;
	color: #000000;
	cursor: pointer;
	margin: 0;
	background-color: #7AD0E3;
	background-image: url(images/accordion_toggle.jpg);
	background-repeat: no-repeat;
	background-position: right top;
	border-bottom-width: 1px;
	border-bottom-style: solid;
	border-bottom-color: #2392A9;
	padding-top: 0;
	padding-right: 10px;
	padding-bottom: 0;
	padding-left: 10px;
		}
		
		.accordion_toggle_active {
			background: url(images/accordion_toggle_active.jpg) no-repeat top right #e0542f;
			color: #ffffff;
			border-bottom: 1px solid #f68263;
		}
		
		.accordion_content {
	color: #444444;
	overflow: hidden;
	padding-top: 5px;
	padding-right: 5px;
	padding-bottom: 30px;
	padding-left: 5px;
	background-image: url(images/panelbody.gif);
	background-repeat: repeat-y;
	background-position: center;
		}
			
			.accordion_content h2 {
				margin: 15px 0 5px 10px;
				color: #0099FF;
			}
			
			.accordion_content p {
	line-height: 150%;

			}
			
		
.style1 {font-weight: bold}

</style>

<!-- Edit the dimensions of the below, plus background color-->

<div id="vertical_container" style="float:left:200px">
<h1 class="accordion_toggle">CPD Features</h1>
<div class="accordion_content">
<a class="leftmenu" href="about_cpd.php">About CPD</a>
<br />
<a class="leftmenu" href="cpd_objective.php">CPD Objective</a>
<br/>
<a class="leftmenu" href="empower_training.php">Empower and Training</a>
<br/>
<a class="leftmenu" href="destinguish_feature.php">Distinguishing Feature</a>
<br/>
<a class="leftmenu" href="program_offered.php">CPD Programs</a>
<br/>
<a class="leftmenu" href="program_process.php">CPD Program Process</a>
<br/>
<a class="leftmenu" href="empowerment_cycle.php">Empowerment Cycle</a>
<br/>
<a class="leftmenu" href="cpd_organization.php">The CPD Organisation</a>
<br />
<a class="leftmenu" href="program_list.php">CPD Programs on Offer</a>

</div>

<h1 class="accordion_toggle">SLMP Features</h1>
<div class="accordion_content">
<a class="leftmenu" href="program_desc.php">Program Description</a>
<br />
<a class="leftmenu" href="program_obj.php">Program Objectives</a>
<br/>
<a class="leftmenu" href="program_content.php">Program Content</a>
<br/>
<a class="leftmenu" href="slmp_proglist.php">SLMP Programs on Offer</a>

</div>
</div>



