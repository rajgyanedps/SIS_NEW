<?php
session_start();
include('functions.inc.php');
include("connection.php");
if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='Project Manager' && $_SESSION['user_type']!='Tele Caller' && $_SESSION['temp_type']!='y')
//if (!isset($_SESSION[myusername]))
{
 header("Location: index.php");
}
$_SESSION['this_page']='golf_lead_edit.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Fb Student Data</title>

<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />
</head>
<body>

<?php
if(isset($_REQUEST['update']))
{
	extract($_POST);
	$q1=mysql_query("update golf_lead set date='".$enquiry_date."',name='".$name."',mobno='".$mobile."',email='".$email."',address='".$address."',age='".$age."',occupation='".$occupation."',study_at='".$study_at."',
	s_c_name='".$s_c_name."',class='".$class."',interested_course='".$interested_course."' where id='".$_REQUEST['edit_id']."' ");
	if($q1)
	{
		$msg="Update Data Succussfully";
	}
}
include("header.php");
$ed=mysql_fetch_array(mysql_query("select * from golf_lead where id='".$_REQUEST['edit_id']."'"));



?>
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.2/themes/smoothness/jquery-ui.css"/>
<script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script> 
<script>
$(function()
 {
                $("#date").datepicker({
                   
                    dateFormat: 'yy-mm-dd'
                         });
				               
            });

</script>
<br />
<?php
 $statusMsgClass = 'alert-success';
if(isset($msg))
{
	 echo '<div class="alert '.$statusMsgClass.'">'.$msg.'</div>';
	 echo'<script>window.location.href="golf_lead.php";</script>';
}
?>
<form name="edit_data" method="post" action="">
<table align="center" width="40%" style="border:#EFEFEF solid 1px; background-color:#EFEFEF">
<tr><td colspan="2" align="center" style="background-color:#43a2da; color:#FFF; height:30px;">FB Lead Edit Data</td></tr>
<tr><td colspan="2" align="center" style="height:15px;"></td></tr>
<tr><td style="padding-left:5px;">Enquiry Date:</td><td><input type="text" name="enquiry_date"  required="required" value="<?php echo $ed['date']?>" style="height:28px; width:300px;" readonly="readonly" id="date"/></td></tr>
<tr><td colspan="2" style="height:10px;"></td></tr>
<tr><td style="padding-left:5px;">Name:</td><td><input type="text" name="name" value="<?php echo $ed['name']?>" required="required" style="height:28px; width:300px;"/></td></tr>
<tr><td colspan="2" style="height:10px;"></td></tr>
<tr><td style="padding-left:5px;">Mobile:</td><td><input type="text" name="mobile" value="<?php echo $ed['mobno']?>"  required="required" style="height:28px; width:300px;" maxlength="10"/></td></tr>
<tr><td colspan="2" style="height:10px;"></td></tr>
<tr><td style="padding-left:5px;">E-mail:</td><td><input type="text"  name="email"  value="<?php echo $ed['email']?>" required="required" style="height:28px; width:300px;"/></td></tr>
<tr><td colspan="2" style="height:10px;"></td></tr>
<tr><td style="padding-left:5px;">Address:</td><td><input type="text" name="address"  value="<?php echo $ed['address']?>" required="required" style="height:28px; width:300px;"/></td></tr>
<tr><td colspan="2" style="height:10px;"></td></tr>
<tr><td style="padding-left:5px;">Age:</td><td><input type="text" name="age" value="<?php echo $ed['age']?>" required="required"  style="height:28px; width:300px;"/></td></tr>
<tr><td colspan="2" style="height:10px;"></td></tr>
<tr><td style="padding-left:5px;">Occupation:</td><td><input type="text" name="occupation" value="<?php echo $ed['occupation']?>" required="required" style="height:28px; width:300px;"/></td></tr>
<tr><td colspan="2" style="height:10px;"></td></tr>
<tr><td style="padding-left:5px;">Study_at:</td><td><input type="text" name="study_at" value="<?php echo $ed['study_at']?>" required="required" style="height:28px; width:300px;"/></td></tr>
<tr><td colspan="2" style="height:10px;"></td></tr>
<tr><td style="padding-left:5px;">School / College Name:</td><td><input type="text" name="s_c_name" value="<?php echo $ed['s_c_name']?>" required="required" style="height:28px; width:300px;"/></td></tr>
<tr><td colspan="2" align="center" style="height:15px;"></td></tr>
<tr><td style="padding-left:5px;">Class	:</td><td><input type="text" name="class" value="<?php echo $ed['class']?>" required="required" style="height:28px; width:300px;"/></td></tr>
<tr><td colspan="2" align="center" style="height:15px;"></td></tr>
<tr><td style="padding-left:5px;">interested_course	:</td><td><input type="text" name="interested_course" value="<?php echo $ed['interested_course']?>" required="required" style="height:28px; width:300px;"/></td></tr>
<tr><td colspan="2" align="center" style="height:15px;"></td></tr>
<tr><td colspan="2" align="center" style="height:15px;"><input type="submit" name="update" class="btn btn-primary" value="update"/></td></tr>
<tr><td colspan="2" align="center" style="height:15px;"></td></tr>

</table>
</form>

</body>

</html>