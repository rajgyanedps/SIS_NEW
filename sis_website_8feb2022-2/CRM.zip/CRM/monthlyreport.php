<?php
session_start();
include("connection.php");
if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='School Login' && $_SESSION['user_type']!='Tele Caller')
//if (!isset($_SESSION[myusername]))
{
 header("Location: index.php");
}
$_SESSION['this_page']='monthlyreport.php';
?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Employee Total Call Report</title>
<link rel="stylesheet" type="text/css" href="calendar-blue.css">
<script type="text/javascript" src="calendar.js"></script>
<script type="text/javascript" src="calendar-en.js"></script>
<script type="text/javascript" src="calendar-setup.js"></script>
<script language="javascript1.2" src="tabber.js"></script>

<script type="text/javascript">
function showhide(val)
{
if(val.value=='Daily')
document.getElementById('divnb').style.display='block';
else
document.getElementById('divnb').style.display='none';
if(val.value=='Monthly')
document.getElementById('divmb').style.display='block';
else
document.getElementById('divmb').style.display='none';
}
</script>


<script type="text/javascript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php
include("header.php");
?>
<br />
<form action="" method="get" name="dailyreport">
<div style="float:left">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Select Type:</b>&nbsp;&nbsp;&nbsp;

<select name="mod" onchange="showhide(this)" >
<option value="">-Select-</option>
<option value="Daily">Daily</option>
<option value="Monthly">Monthly</option>
<option value="All">All</option>
</select>
</div>

<div id="divnb" style="display:none;float:left">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Select Date</b>
  <img src="CalendarIcon.gif" name="get_stud_date1" width="22" height="23" border="0" align="absmiddle" id="get_stud_date1" style="cursor: pointer;" title="Date selector" onMouseOver="this.style.background='red';" onMouseOut="this.style.background=''" />
  &nbsp;<input type="text" name="date1" size="10" id="date1" />
    <script type="text/javascript">
	  	Calendar.setup({
        inputField     :    "date1",     // id of the input field
	    //ifFormat       :    "%Y/%m/%d %l:%M %P",      // format of the input field
	  	//ifFormat       :    "%m-%d-%Y",      // format of the input field
	  	ifFormat       :    "%Y-%m-%d",      // format of the input field
        button         :    "get_stud_date1",  // trigger for the calendar (button ID)
        align          :    "Tl",           // alignment (defaults to "Bl")
        singleClick    :    true,
		showsTime		:	true
    });

        </script></div>
        <div id="divmb" style="display:none;float:left">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Select Month:</b>
<select name="month1" id="month1">
<option value="">-Select Month-</option>
<option value="1">January</option>
<option value="2">February</option>
<option value="3">March</option>
<option value="4">April</option>
<option value="5">May</option>
<option value="6">June</option>
<option value="7">July</option>
<option value="8">August</option>
<option value="9">September</option>
<option value="10">October</option>
<option value="11">November</option>
<option value="12">December</option>
</select></div>
<input type="submit" value="Search" style="margin-left:20px;float:left" />
</form>
   <br />
 <br />
 <br />

<font color="#000000" size="3px" style="padding-left:15px"><b>Convert to Excel</b>&nbsp;&nbsp;

<a href="report11.php?date1=<?=$_GET['date1']?>&month1=<?=$_GET['month1']?>"><img src="logo_excel.gif" alt="Export" border="0"></a></font>
<table width="100%" border="0" align="center" cellpadding="5" cellspacing="1" bgcolor="#81cafd" style="font-size:13px">

<tr bgcolor="#999999" align="center">

      <td width="8%" align="left" background="footerbg.jpg" class="whitetxt11">S.No.</td>
    <td width="20%" align="left" background="footerbg.jpg" class="whitetxt11">Employee name</td>
    <td width="24%" align="left" background="footerbg.jpg" class="whitetxt11">No of Leads</td>
    <td width="24%" align="left" background="footerbg.jpg" class="whitetxt11">No. of Calls</td>
    <td width="6%" align="left" background="footerbg.jpg" class="whitetxt11">Admission</td>
    <td width="7%" align="left" background="footerbg.jpg" class="whitetxt11">Paid</td>
    <td width="11%" align="left" background="footerbg.jpg" class="whitetxt11">Positive</td>
    <td width="12%" align="left" background="footerbg.jpg" class="whitetxt11">Moderate</td>
    <td width="12%" align="left" background="footerbg.jpg" class="whitetxt11">Negative</td>
    <td width="12%" align="left" background="footerbg.jpg" class="whitetxt11">No Contacted</td>
    <td width="12%" align="left" background="footerbg.jpg" class="whitetxt11">Session(2013-14)</td>
  </tr>
<? 
if (strlen($_GET['date1'])>0)
{
$strqry=" and DATE(contact_date)='".$_GET['date1']."'";
$strqry1=" and DATE(contact.joined)='".$_GET['date1']."'";
$strqry2=" and DATE(joined)='".$_GET['date1']."'";
}
				
elseif (strlen($_GET['month1'])>0)
{
$strqry=" and MONTH(contact_date)='".$_GET['month1']."'";
$strqry1=" and MONTH(contact.joined)='".$_GET['month1']."'";
$strqry2=" and MONTH(joined)='".$_GET['month1']."'";

}
				
$sql_cust = "SELECT emp_id,emp_name,(select count(*) from student where student.emp_id='".$_SESSION['emp_id']."' ". $strqry2." ) as lcontact, (select count(*) from contact inner join student on contact.stud_id=student.stud_id where student.emp_id='".$_SESSION['emp_id']."' ". $strqry1.") as scontact, (select count(*) from student where status='Positive' ". $strqry." and student.emp_id='".$_SESSION['emp_id']."') as pcontact, (select count(*) from student where status='Negative' ". $strqry." and student.emp_id='".$_SESSION['emp_id']."') as ncontact, (select count(*) from student where status='Moderate' ". $strqry." and student.emp_id='".$_SESSION['emp_id']."') as mcontact, (select count(*) from student where status='Paid' ". $strqry." and student.emp_id='".$_SESSION['emp_id']."') as paidcontact, (select count(*) from student where status='Admission' ". $strqry." and student.emp_id='".$_SESSION['emp_id']."') as admitcontact 
, (select count(*) from student where status='NoContact' ". $strqry." and student.emp_id='".$_SESSION['emp_id']."') as nocontacts
, (select count(*) from student where status='Session2013-14' ". $strqry." and student.emp_id='".$_SESSION['emp_id']."') as newsessioncontacts

 FROM members WHERE members.emp_id='".$_SESSION['emp_id']."'";


//$sql_cust = "SELECT emp_id,emp_name, (select count(*) from contact where stud_id>'".$_SESSION['emp_id']."' and stud_id<('".$_SESSION['emp_id']."'+100000) ". $strqry.") as scontact, (select count(*) from contact where status='Positive' ". $strqry." and stud_id>'".$_SESSION['emp_id']."' and stud_id<('".$_SESSION['emp_id']."'+100000)) as pcontact, (select count(*) from contact where status='Negative' ". $strqry." and stud_id>'".$_SESSION['emp_id']."' and stud_id<('".$_SESSION['emp_id']."'+100000)) as ncontact, (select count(*) from contact where status='Moderate' ". $strqry." and stud_id>'".$_SESSION['emp_id']."' and stud_id<('".$_SESSION['emp_id']."'+100000)) as mcontact, (select count(*) from contact where status='Paid' ". $strqry." and stud_id>'".$_SESSION['emp_id']."' and stud_id<('".$_SESSION['emp_id']."'+100000)) as paidcontact, (select count(*) from contact where status='Admission' ". $strqry." and stud_id>'".$_SESSION['emp_id']."' and stud_id<('".$_SESSION['emp_id']."'+100000)) as admitcontact FROM members WHERE emp_id='".$_SESSION['emp_id']."'";





		$result	= mysql_query($sql_cust) or die(mysql_error());
		$count = 0;
		while($res=mysql_fetch_array($result))
{         
     
$dd = date("d-M-y",strtotime($res['remarkdate']));

if($acol) {
	           $x = "bgcolor='#e9f5ff'";
	          } else {
	            $x = "bgcolor='#d8effe'";
 	          }
			  $acol=!$acol;
			  $count++;
?>

<tr <?=$x;?> align="left">

      <td><? echo $count;?>.</td>
        
    <td><?php echo $res['emp_name'];?></td>
    <td><?php echo $res['lcontact'];?></td>
    <td><!--<a href="#" onclick="MM_openBrWindow('dailycallreport.php?emp_id=<?php echo $res['emp_id'];?>&amp;fromdate=<?= $_GET['date1']?>&amp;frommonth=<?= $_GET['month1']?>','CallReport','toolbar=yes,location=yes,status=yes,menubar=yes,scrollbars=yes,resizable=yes')"></a>--><?php echo $res['scontact']-1;?></td>
    <td><!--<a href="#" onclick="MM_openBrWindow('dailycallreport.php?emp_id=<?php echo $res['emp_id'];?>&amp;stat=Admission&amp;fromdate=<?= $_GET['date1']?>&amp;frommonth=<?= $_GET['month1']?>','CallReport','toolbar=yes,location=yes,status=yes,menubar=yes,scrollbars=yes,resizable=yes')"></a>--><?php echo $res['admitcontact'];?></td>
    <td><!--<a href="#" onclick="MM_openBrWindow('dailycallreport.php?emp_id=<?php echo $res['emp_id'];?>&amp;stat=Paid&amp;fromdate=<?= $_GET['date1']?>&amp;frommonth=<?= $_GET['month1']?>','CallReport','toolbar=yes,location=yes,status=yes,menubar=yes,scrollbars=yes,resizable=yes')"></a>--><?php echo $res['paidcontact'];?></td>             
    <td><!--<a href="#" onclick="MM_openBrWindow('dailycallreport.php?emp_id=<?php echo $res['emp_id'];?>&amp;stat=Positive&amp;fromdate=<?= $_GET['date1']?>&amp;frommonth=<?= $_GET['month1']?>','CallReport','toolbar=yes,location=yes,status=yes,menubar=yes,scrollbars=yes,resizable=yes')"></a>--><?php echo $res['pcontact'];?></td>
    <td><!--<a href="#" onclick="MM_openBrWindow('dailycallreport.php?emp_id=<?php echo $res['emp_id'];?>&amp;stat=Moderate&amp;fromdate=<?= $_GET['date1']?>&amp;frommonth=<?= $_GET['month1']?>','CallReport','toolbar=yes,location=yes,status=yes,menubar=yes,scrollbars=yes,resizable=yes')"></a>--><?php echo $res['mcontact'];?></td>
    <td><!--<a href="#" onclick="MM_openBrWindow('dailycallreport.php?emp_id=<?php echo $res['emp_id'];?>&amp;stat=Negative&amp;fromdate=<?= $_GET['date1']?>&amp;frommonth=<?= $_GET['month1']?>','CallReport','toolbar=yes,location=yes,status=yes,menubar=yes,scrollbars=yes,resizable=yes')"></a>--><?php echo $res['ncontact'];?></td>
    <td><!--<a href="#" onclick="MM_openBrWindow('dailycallreport.php?emp_id=<?php echo $res['emp_id'];?>&amp;stat=Negative&amp;fromdate=<?= $_GET['date1']?>&amp;frommonth=<?= $_GET['month1']?>','CallReport','toolbar=yes,location=yes,status=yes,menubar=yes,scrollbars=yes,resizable=yes')"></a>--><?php echo $res['nocontacts'];?></td>
    <td><!--<a href="#" onclick="MM_openBrWindow('dailycallreport.php?emp_id=<?php echo $res['emp_id'];?>&amp;stat=Negative&amp;fromdate=<?= $_GET['date1']?>&amp;frommonth=<?= $_GET['month1']?>','CallReport','toolbar=yes,location=yes,status=yes,menubar=yes,scrollbars=yes,resizable=yes')"></a>--><?php echo $res['newsessioncontacts'];?></td>
  </tr>
  <?
}
?>
                </table>				  
			   
<table width="100%" align="center">
<tr>
<td>&nbsp;</td>
</tr>
<tr>
<td class="footer" width="942" >&copy; 2009 TeacherSITY. All rights reserved</td>
</tr>

</table>
 


</body>
</html>