<?php
session_start();
include("connection.php");
if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='Project Manager' && $_SESSION['user_type']!='Tele Caller')
{
 header("Location: index.php");
}
$_SESSION['this_page']='tasks.php';
@extract($_GET);

if($order_by!="")
{	
	$KEYWORD_SEARCH_5="ORDER BY $order_by $img_name"; 
}
else
{
	$KEYWORD_SEARCH_5="ORDER BY msg_date desc";
}	

$chk=$_POST['empid'];
$chk_no=count($chk);
if (isset($_POST['submit']))
{
for($i=0;$i<$chk_no;$i++)
{
$sql="INSERT INTO task(sender_id,recipient_id,msg,msg_date,status) VALUES 
('".$_SESSION['emp_id']."','".$chk[$i]."','".$_POST['mssg']."',now(),'Pending')";
$result=mysql_query($sql) or die(mysql_error());
$task="insert into sync_sql (query,entered,updated) values('".addslashes($sql)."',now(),0)";
$taskadmin=mysql_query($task);
}
header("Location:tasks.php?msg=Message%20Sent%20Successfully......");
}

if (isset($_POST['submit10']))
{
$sql20="UPDATE task SET status='".$_POST['stat']."' WHERE msg_id='".$_POST['msg_id']."'";
$result20=mysql_query($sql20) or die(mysql_error());
$updatetask="insert into sync_sql (query,entered,updated) values('".addslashes($sql20)."',now(),0)";
$taskupdat=mysql_query($updatetask);
header("Location:tasks.php?msg=Message%20Update%20Successfully......");
}

if (isset($_POST['submit11']))
{
$sql21="INSERT INTO archive (SELECT * FROM task WHERE msg_id='".$_POST['msg_id']."')";
$result21=mysql_query($sql21) or die(mysql_error());
$archiveinsert="insert into sync_sql (query,entered,updated) values('".addslashes($sql21)."',now(),0)";
$insertarch=mysql_query($archiveinsert);
$sql22="DELETE FROM task WHERE msg_id='".$_POST['msg_id']."'";
$result22=mysql_query($sql22) or die(mysql_error());
$delarchive="insert into sync_sql (query,entered,updated) values('".addslashes($sql22)."',now(),0)";
$delarch=mysql_query($delarchive);
header("Location:tasks.php?msg=Message%20Sent%20to%20Archive%20Successfully......");
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>My Tasks</title>
<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
<!--
function MM_goToURL() { //v3.0
  var i, args=MM_goToURL.arguments; document.MM_returnValue = false;
  for (i=0; i<(args.length-1); i+=2) eval(args[i]+".location='"+args[i+1]+"'");
}
//-->
</script>
</head>
<body>
<?php
include("header.php");
?>
<br />
<div align="center" class="msg" style="margin:0;">
  <?=$_GET['msg']; ?>
</div>
<div style="margin-left:20px; margin-bottom:5px; margin-top:0px; width:165px; height:35px">
  <input name="archive message" style="height:35px" type="button" onclick="MM_goToURL('parent','archive.php');return document.MM_returnValue" value="Show All Archive Message" />
</div>
<table align="center" width="100%">
  <tr>
    <td width="65%" valign="top"><table width="100%" border="0" align="center" cellpadding="5" cellspacing="0" style="font-size:13px" background="#81cafd">
        <tr bgcolor="#999999" align="center">
          <td width="2%" height="22" align="left" background="footerbg.jpg" bgcolor="#999999" class="whitetxt11">S.No.</td>
          <td width="20%" height="20" align="left" background="footerbg.jpg" class="whitetxt11">Tasks</td>
          <td width="13%" height="20" align="left" background="footerbg.jpg" class="whitetxt11"><? if($_GET['img_name']=='desc' && $_GET['order_by']=='msg_date')
   { 
 ?>
            <a href="tasks.php?order_by=msg_date&img_name=asc"><strong>Date&nbsp;</strong><img src="image/asc.gif" alt="Descending Order" border="0"></a>
            <? 
    } 
	else 
	{ 
	?>
            <a href="tasks.php?order_by=msg_date&img_name=desc"><strong>Date&nbsp;</strong><img src="image/dsc.gif" alt="Ascending Order" border="0"></a>
            <?
	}
	?>
          </td>
          <td width="10%" height="20" align="left" background="footerbg.jpg" class="whitetxt11"><? if($_GET['img_name']=='desc' && $_GET['order_by']=='sender_name')
   { 
 ?>
            <a href="tasks.php?order_by=sender_name&img_name=asc"><strong>From&nbsp;</strong><img src="image/asc.gif" alt="Descending Order" border="0"></a>
            <? 
    } 
	else 
	{ 
	?>
            <a href="tasks.php?order_by=sender_name&img_name=desc"><strong>From&nbsp;</strong><img src="image/dsc.gif" alt="Ascending Order" border="0"></a>
            <?
	}
	?>
          </td>
          <td width="10%" height="20" align="left" background="footerbg.jpg" class="whitetxt11"><? if($_GET['img_name']=='desc' && $_GET['order_by']=='rec_name')
   { 
 ?>
            <a href="tasks.php?order_by=rec_name&img_name=asc"><strong>To&nbsp;</strong><img src="image/asc.gif" alt="Descending Order" border="0"></a>
            <? 
    } 
	else 
	{ 
	?>
            <a href="tasks.php?order_by=rec_name&img_name=desc"><strong>To&nbsp;</strong><img src="image/dsc.gif" alt="Ascending Order" border="0"></a>
            <?
	}
	?>
          </td>
          <td width="10%" height="20" align="left" background="footerbg.jpg" class="whitetxt11"><? if($_GET['img_name']=='desc' && $_GET['order_by']=='status')
   { 
 ?>
            <a href="tasks.php?order_by=status&img_name=asc"><strong>Status&nbsp;</strong><img src="image/asc.gif" alt="Descending Order" border="0"></a>
            <? 
    } 
	else 
	{ 
	?>
            <a href="tasks.php?order_by=status&img_name=desc"><strong>Status&nbsp;</strong><img src="image/dsc.gif" alt="Ascending Order" border="0"></a>
            <?
	}
	?>
          </td>
          <td width="15%" height="20" align="left" background="footerbg.jpg" class="whitetxt11">Notes</td>
          <td width="10%" height="20" align="left" background="footerbg.jpg" class="whitetxt11">Move To</td>
          <td width="10%" height="20" align="left" background="footerbg.jpg" class="whitetxt11">Reply</td>
        </tr>
        <?php

 $sql_cust = "SELECT task.*, a.emp_name as rec_name,b.emp_name as sender_name FROM task inner join members a on a.emp_id=task.recipient_id inner join members b on b.emp_id=task.sender_id  WHERE (recipient_id='".$_SESSION['emp_id']."' or sender_id='".$_SESSION['emp_id']."') $KEYWORD_SEARCH_5";
	
$result	= mysql_query($sql_cust) or die(mysql_error());
		$num_rows 	= mysql_num_rows($result);	
		$incr = 1;
		
		if(!$_REQUEST['pageno']){
			$pageno = 1;
		} else {
			$pageno= $_REQUEST['pageno'];
		}
		$pagesize=25;
		$incr = (($pageno-1)*$pagesize)+1;
		$first=$pageno*$pagesize-($pagesize-1);
		$last=$first+$pagesize-1; 
		$temp=($num_rows%$pagesize);
		if ($temp==0)
		$pages=($num_rows/$pagesize);
		else
		$pages=($num_rows/$pagesize)+1;
		settype($pages, "integer"); 

		for($i=1;$i<$first;$i++)
			$row2000=mysql_fetch_row($result);
     
while($res=mysql_fetch_array($result) and ($first<=$last))
{

if($i%2==0) {
	           $x = "bgcolor='#e9f5ff'";
	          } else {
	            $x = "bgcolor='#d8effe'";
 	          }
?>
        <? if($res['status']=='Pending')
	{?>
        <tr align="left" bgcolor="#FFB3B3" >
          <? }
	else
	{?>
        <tr align="left" bgcolor="#9BFF9B" >
          <? }?>
          <td width="2%" style="font-size:11px; font-family:Arial, Helvetica, sans-serif;border-top:1px solid #000000"><? echo $i;?>.&nbsp;</td>
          <td width="20%" style="font-size:11px; font-family:Arial, Helvetica, sans-serif;border-top:1px solid #000000"><?php echo $res['msg'];?>&nbsp;</td>
          <td width="13%" style="font-size:11px; font-family:Arial, Helvetica, sans-serif;border-top:1px solid #000000"><?php echo date("d-M-y", strtotime($res['msg_date']));?><br />
            <?php echo date("H:i A", strtotime($res['msg_date']));?>&nbsp;</td>
          <td width="10%" style="font-size:11px; font-family:Arial, Helvetica, sans-serif;border-top:1px solid #000000"><?php echo $res['sender_name'];?>&nbsp;</td>
          <td width="10%" style="font-size:11px; font-family:Arial, Helvetica, sans-serif;border-top:1px solid #000000"><?php echo $res['rec_name'];?>&nbsp;</td>
          <td width="25%" style="font-size:11px; font-family:Arial, Helvetica, sans-serif;border-top:1px solid #000000"><form action="tasks.php" method="post">
              <input type="hidden" name ="msg_id" value="<?= $res['msg_id']?>">
              <div style="float:left; width:83px;"> <select name="stat">
            <option value="Done" <? if ($res['status']== 'Done') echo "selected";?> >Done</option>
            <option value="Pending" <? if ($res['status']== 'Pending') echo "selected"; ?>>Pending</option>
          </select></div>
           <div style="float:left; margin-left:5px; width:55px;"><input type="submit" name="submit10" value="Update" /> </div>
          </form></td>
          <td width="15%" style="font-size:11px; font-family:Arial, Helvetica, sans-serif;border-top:1px solid #000000"><?php echo $res['notes'];?>&nbsp;</td>
          <td width="10%" style="font-size:11px; font-family:Arial, Helvetica, sans-serif;border-top:1px solid #000000"><form action="tasks.php" method="post">
              <input type="hidden" name ="msg_id" value="<?= $res['msg_id']?>">
              <input type="submit" name="submit11" value="Archive" />
            </form></td>
          <td width="10%" style="font-size:12px; font-family:Arial, Helvetica, sans-serif;border-top:1px solid #000000" align="center"><? if($res['recipient_id']==$_SESSION['emp_id'])
		{?>
            <a href="replymsg.php?msg_id=<? echo $res['msg_id'];?>">Reply</a>
            <? }?>
          </td>
        </tr>
        <? 
	 	  $incr++;
	$first++;	
  $i=$i+1;
  } 
	?>
      </table>
      <? if($num_rows > 0){	?>
      <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td colspan="3"><img src="image/spacer.gif" height="2" /></td>
        </tr>
        <tr>
          <td height="26"  valign="middle" background="newbar.jpg" class="table_td_heading" style="padding-left:5px;" width="60%"><span class="table_td_heading">Pages:
            <? if ($pageno==1) { ?>
            &nbsp;
            <? } else {?>
            <a href="tasks.php?pageno=<?=$pageno-1?>&orderby=<?=$orderby?>&sortby=<?=$sortby?>" class="table_td_heading">Previous</a>
            <? } 
					for ($i=1; $i<=$pages;$i++)
					{
					if($pageno==$i)	{?>
            <strong class="table_td_heading"><? echo $i;?></strong>
            <? }
						else
					{
					if($i%5==0)
{
					?>
            <strong><a class="table_td_heading" href="tasks.php?pageno=<?=$i?>&orderby=<?=$orderby?>&sortby=<?=$sortby?>">
            <?=$i?>
            </a></strong>
            <? 
					}
					}
					}
					?>
            <? if ($pageno<$pages) { ?>
            <a href="tasks.php?pageno=<?=$pageno+1?>&orderby=<?=$orderby?>&sortby=<?=$sortby?>" class="table_td_heading">Next</a>
            <? } else {?>
            <? } ?>
            </span></td>
          <td width="10%" align="right" valign="middle" background="newbar.jpg" class="data"><!--DWLayoutEmptyCell-->&nbsp;</td>
          <td width="30%" align="center" valign="middle" background="newbar.jpg" class="data"><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td align="right" valign="middle" class="table_td_heading" style="padding-right:5px;" width="100%"><strong>Page</strong>&nbsp;
                  <?=$pageno?>
                  &nbsp;of&nbsp;
                  <?=$pages?>
                </td>
              </tr>
            </table>
            <strong></strong></td>
        </tr>
      </table>
      <? }?>
    <br /></td>
    <td width="35%" valign="top"><form name="tasks" action="tasks.php" method="post">
        <table width="100%" border="0" align="center" cellpadding="5" cellspacing="0" style="font-size:13px" bgcolor="#d8effe">
          <tr bgcolor="#999999">
            <td width="100%" height="22" colspan="2" background="footerbg.jpg" bgcolor="#999999" class="whitetxt11"><font size="3px">
            <div style="margin:0px 0px 0px 8px;"><b>Send New Message</b></div></font></td>
          </tr>
          <tr>
            <td align="center" valign="top"><div style="margin:15px 0px 0px 8px; color:#06417c; background:#e9f5ff; padding:5px; text-align:left;"> <b>Send To:</b></div></td>
            <td><select name="empid[]" size="5" multiple id="empid" style="float:left;line-height:20px; margin-top:15px; font-size:12px;width:230px; color:#0a5095; background:#f7fafe; border:solid 1px #61b5f8;">
                <?
$sql = "select emp_id, emp_name from members where username!='Open Data' order by emp_id";
$result = mysql_query($sql);
while($row = mysql_fetch_row($result))
		{
		?>
                <option value="<?=$row[0];?>" <? if($_GET['empid']==$row[0]) echo 'selected' ?> >
                <?=$row[1];?>
                </option>
                <?
}
?>
              </select>
            </td>
          </tr>
          <tr>
            <td align="left" valign="top"><div style="margin:12px 0px 0px 8px; background:#e9f5ff; color:#06417c; padding:5px; text-align:left;"> <b>Enter Your Message</b></div></td>
            <td><textarea name="mssg" rows="6" cols="26" style="background:#f7fafe; margin-top:10px; border:solid 1px #61b5f8; color:#0a5095;">
</textarea></td>
          </tr>
          <tr>
            <td height="30" colspan="2" align="center" bgcolor="#e9f5ff"><input type="submit" name="submit" value=" Send " />
            </td>
          </tr>
          <tr>
            <td height="5" colspan="2"><img src="image/spacer.gif" height="5" /> </td>
          </tr>
        </table>
      </form></td>
  </tr>
</table>
<table align="center" width="100%">
<tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td class="footer" width="100%" >&copy; 2009 TeacherSITY. All rights reserved</td>
  </tr>
</table>
</body>
</html>
