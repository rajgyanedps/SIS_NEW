<?php
session_start();
include("connection.php");
if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='Project Manager' && $_SESSION['user_type']!='Tele Caller')
//if (!isset($_SESSION[myusername]))
{
 header("Location: index.php");
}
?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Employee Total Call Report</title>
<link rel="stylesheet" type="text/css" href="calendar-blue.css">
<script type="text/javascript" src="calendar.js"></script>
<script type="text/javascript" src="calendar-en.js"></script>
<script type="text/javascript" src="calendar-setup.js"></script>
<script language="javascript1.2" src="tabber.js"></script>

<script type="text/javascript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php
include("header.php");
?>
<?php
$sql = "select * from members WHERE emp_id='".$_GET['emp_id']."'";
$result1 = mysql_query($sql);
$res1 = mysql_fetch_array($result1);
$res1['emp_id'];
?>

<form action="totalcallreport.php" method="get" name="totalcallreport">
<input type="hidden" name="emp_id" value="<? echo $_GET['emp_id']; ?>" />
<table width="100%" align="center">
  <tr><td width="1000px" height="25" align="left" bgcolor="#f3f7fd"><font size="4.5" face="Verdana, Arial, Helvetica, sans-serif"><div style="margin-left:20px;"><b>Total Call Report (<? echo $res1['emp_name'];?>)</b></div></font></td>
  </tr>
<tr><td>&nbsp;</td></tr></table>
<div style="float:left;line-height:20px;width:80%; margin-bottom:10px;">
<font color="#000000" size="3px" style="padding-left:15px"><b>Convert to Excel</b>&nbsp;&nbsp;<a href="#" onClick="javascript:window.open('report10.php?emp_id=<?=$res1['emp_id'];?>&fromdate=<?=$_GET['fromdate']?>&todate=<?=$_GET['todate']?>','myReport','');"><img src="logo_excel.gif" alt="Export" border="0"></a></font>


&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Search Call detail&nbsp;&nbsp;&nbsp;From</b>
  <img src="CalendarIcon.gif" name="get_stud_date1" width="22" height="23" border="0" align="absmiddle" id="get_stud_date1" style="cursor: pointer;" title="Date selector" onMouseOver="this.style.background='red';" onMouseOut="this.style.background=''" />
  &nbsp;<input type="text" name="fromdate" size="10" id="fromdate" />
    <script type="text/javascript">
	  	Calendar.setup({
        inputField     :    "fromdate",     // id of the input field
	    //ifFormat       :    "%Y/%m/%d %l:%M %P",      // format of the input field
	  	//ifFormat       :    "%m-%d-%Y",      // format of the input field
	  	ifFormat       :    "%Y-%m-%d",      // format of the input field
        button         :    "get_stud_date1",  // trigger for the calendar (button ID)
        align          :    "Tl",           // alignment (defaults to "Bl")
        singleClick    :    true,
		showsTime		:	true
    });

        </script>
&nbsp;&nbsp;&nbsp;&nbsp;<b>To</b>        
   <img src="CalendarIcon.gif" name="get_stud_date2" width="22" height="23" border="0" align="absmiddle" id="get_stud_date2" style="cursor: pointer;" title="Date selector" onMouseOver="this.style.background='red';" onMouseOut="this.style.background=''" />
  &nbsp;<input type="text" name="todate" size="10" id="todate" />
    <script type="text/javascript">
	  	Calendar.setup({
        inputField     :    "todate",     // id of the input field
	    //ifFormat       :    "%Y/%m/%d %l:%M %P",      // format of the input field
	  	//ifFormat       :    "%m-%d-%Y",      // format of the input field
	  	ifFormat       :    "%Y-%m-%d",      // format of the input field
        button         :    "get_stud_date2",  // trigger for the calendar (button ID)
        align          :    "Tl",           // alignment (defaults to "Bl")
        singleClick    :    true,
		showsTime		:	true
    });

        </script>     
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" value="Search" /></div> 
 <div style="float:left;width:18%;line-height:20px" align="right">
 <?php
 if (strlen($_GET['fromdate'])>0)
{

if (strlen($_GET['todate'])>0)
{
$strqry=" and date(contact.joined) between '".$_GET['fromdate']."' AND '".$_GET['todate']."' ";
}
else
{
$strqry=" and date(contact.joined)='".$_GET['fromdate']."'";
}
}
	 $sql_cust = "SELECT contact.*,contact.joined as jdate, student.emp_id,student.stud_name, student.stud_id, student.add1, student.add2, student.city FROM contact INNER JOIN student ON contact.stud_id=student.stud_id WHERE student.emp_id ='".$_GET['emp_id']."' ". $strqry." order by contact.joined desc";

/*
	 $sql_cust = "SELECT *,contact.joined as jdate, members.emp_id,student.stud_name, student.stud_id FROM contact, members, student WHERE emp_id ='".$_GET['emp_id']."' and addcontact.school_id >'".$_GET['emp_id']."' and addcontact.school_id <'".($_GET['emp_id'] + 100000)."' and addcontact.school_id=addschool.school_id ". $strqry." order by addcontact.joined desc";
*/
		$result	= mysql_query($sql_cust) or die(mysql_error());
		$num_rows= mysql_num_rows($result);
 ?>   
 
 <b>Records Found :</b>&nbsp;<strong><? echo $num_rows?></strong></div>   
 <br /><br />
<table width="100%" border="0" align="center" cellpadding="5" cellspacing="1" bgcolor="#81cafd" style="font-size:12px">

<tr bgcolor="#999999" align="center">

      <td height="22" align="left" background="footerbg.jpg" class="whitetxt11">&nbsp;</td>
      
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="200">Student Name</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" style="width:100px">Call Date/Time</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11">Person Name</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11">Status</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11">Date</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11">Time</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11">Follow Up</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11">Next Step</td>
    </tr>
                <? 

		$count = 0;
		while($res=mysql_fetch_array($result))
		{         
			if($res['remarkdate']!='0000-00-00')
			$dd = date("d-M-y",strtotime($res['remarkdate']));
			else
			$dd = "-";

if($acol) {
	           $x = "bgcolor='#e9f5ff'";
	          } else {
	            $x = "bgcolor='#d8effe'";
 	          }
			  $acol=!$acol;
			  $count++;
?>

<tr <?=$x;?> align="left">
      <td>&nbsp;</td>
         
                <td><strong> <a href="11.php?stud_id=<? echo $res['stud_id'];?>"><?php echo $res['stud_name'];?><br />
                <?php echo $res['add1'];?>,<?php echo $res['add2'];?><br />
                <?php echo $res['city'];?></a></strong></td>
      <td><?php 
	  if($res['jdate']!='0000-00-00 00:00:00')
	   {
	   		echo date("d-M-y",strtotime($res['jdate']));?><br />
			<?php echo date("H:i A",strtotime($res['jdate']));
		}
			?></td>
      <td>
	  <? if($res['stud_name']=='0')
	{
	echo " &nbsp;";
	}
	else
	{?>
	  <?php echo $res['stud_name'];?>
      <? }?>      </td>
      <td align="center"><?php if($res['status']=='Positive'){?> <img src="image/green.gif" border="0" name="plus_sign" alt="Click here to view positive report" align="center"/><? }
	  else if($res['status']=='Admission'){ ?><img src="image/admission.png" border="0" name="Admission" alt="Click here to view Admission report" align="center"/><? }
	   else if($res['status']=='Negative'){ ?><img src="image/red.gif" border="0" name="minus_sign" alt="Click here to view negative report" align="center"/><? } else if($res['status']=='Moderate'){ ?><img src="image/mod.gif" border="0" name="minus_sign" align="center"/>
	   <? } else if($res['status']=='Paid'){ ?>
       <img src="image/paddy-smiley26.gif" border="0" name="paid" alt="Paid School" align="center" />
	   <? }else if($res['status']=='NoContact'){ ?>
       <img src="image/nocontact.png" border="0" name="Admission" alt="Admission" align="center" />
       <? }else if($res['status']=='Session2013-14'){ ?>
       <img src="image/2013-14.jpg.png" border="0" name="Admission" alt="Admission" align="center" />
	   
	   <? }else echo "-";?></td>
      <td><?php echo $dd;?></td>
      <td><?php echo $res['remarktime'];?></td>
      <td><?php echo $res['followup'];?></td>
      <td><?php echo $res['other'];?></td>
    </tr>
                         
 
  <?
}
?>
                </table>				  
			   
<table width="100%" align="center">
<tr>
<td><img src="image/spacer.gif" height="10" /></td>
</tr>
<tr>
<td class="footer" width="942" >&copy; 2009 TeacherSITY. All rights reserved</td>
</tr>

</table>
 

</form>

</body>
</html>