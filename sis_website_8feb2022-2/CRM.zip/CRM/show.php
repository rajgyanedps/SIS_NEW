<?php
session_start();
include("connection.php");
if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='Project Manager' && $_SESSION['user_type']!='Tele Caller')
//if (!isset($_SESSION[myusername]))
{
 header("Location: index.php");
}

if(isset($_POST['update']))
{
$sql="UPDATE $tbl_name SET emp_name='".$_POST['emp_name']."',email='".$_POST['email']."',gender='".$_POST['gender']."',address='".$_POST['address']."',mobno='".$_POST['mobno']."' where emp_id='".$_POST['emp_id']."'";

$result2=mysql_query($sql) or die(mysql_error());
header("Location: show.php?emp_id=".$_POST['emp_id']."&msg=Record Update Successfully...");
}
?>
<?
$rsPwd ="select password from members where emp_id='".$_GET['emp_id']."'";
$rsPwdres=mysql_query($rsPwd) or die(mysql_error());
$rsrow=mysql_fetch_array($rsPwdres);

if(isset($_POST['submit']))
{
$pwdup=mysql_query("UPDATE members SET password = '".$_POST['oldpwd']."' WHERE emp_id='".$_POST['emp_id']."'") or die(mysql_error());
header("Location: show.php?emp_id=".$_POST['emp_id']."&msg=Password updated Successfully...");				
}
?>
<?
$_SESSION['this_page']='show.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Update Profile</title>
<script  type="text/javascript">
function showhide(val)
{
if(val.value=='OTHER')
document.getElementById('divnb').style.display='block';
else
document.getElementById('divnb').style.display='none';
}
</script>
<script type="text/javascript">
function ValidateForm()
{

// checking emp_name field
      if (document.form2.emp_name.value=="")
	{
		alert("The Employee Name field is blank. \nPlease enter employee name in the text box.");
		document.form2.emp_name.focus();
		return false;
      }	  	    
	  
//checking alphabetic values in name

    var iChars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ';
    for (i = 0; i < document.form2.emp_name.value.length; i++) {
      if (iChars.indexOf(document.form2.emp_name.value.charAt(i)) == -1) {
         alert('Please enter letters only in Employee Name field');
         document.form2.emp_name.focus();
         return false;
      }
      }	
//checking user email field
	  
      if (document.form2.email.value=="")
	{
		alert("The e-mail ld is blank or \nan invalid value has been entered.");
        document.form2.email.focus();		
        return false;
    }
        var txt=(document.form2.email.value)
        if (txt.indexOf("@")<0)
        {
            alert("This email address in the 'e-mail' seems wrong. Please"
            +" check the prefix and '@' sign.");
            document.form2.email.focus();           
            return false;

        } 
        
           if(txt.indexOf(".")<0)
           {
            alert("Check your e-mail ID.\n It doesn't have '.' in it");
            document.form2.email.focus();           
            return false;
          } 
// checking gender field
      if (document.form2.gender.value=="")
	{
		alert("The Gender field is blank. \nPlease select gender in the combo box.");
		document.form2.gender.focus();
		return false;
      }	  
// checking address field
      if (document.form2.address.value=="")
	{
		alert("The Address field is blank. \nPlease enter address in the text box.");
		document.form2.address.focus();
		return false;
      }
// checking mobno field
	  
	  if (document.form2.mobno.value=="")
	 {
		alert("The Mob. No. is blank. \nPlease enter the Mob. No. field in the text box.");
        document.form2.mobno.focus();		
        return false;
      }
	  
//checking numeric value in mobno
     var n = document.form2.mobno.value;
    if(isNaN(n) == true) {
        alert('Your entry is not a numberic value in mob. no. field, Please try again');
        document.form2.mobno.focus();
        return false;
    }	  

}
</script>
<script type="text/javascript">
function validateform3()
{
if (document.form3.oldpwd.value=="")
	 {
		alert("Please enter change password field in the text box.");
        document.form3.oldpwd.focus();		
        return false;
      }		
	if (document.form3.newpwd.value=="")
	 {
		alert("The New Password is blank. \nPlease enter the new password field in the text box.");
        document.form3.newpwd.focus();		
        return false;
      }		
	  }
	  </script>
<link href="msg.css" rel="stylesheet" type="text/css">
</head>
<body>
<?php
include("header.php");
?>
<br />
<div align="center" class="msg">
  <?=$_GET['msg']; ?>
</div>
<? 
//query database  where username =$_SESSION['myusername']
$query="SELECT * FROM members where emp_id='".$_GET['emp_id']."'";
$result=mysql_query($query);
$row=mysql_fetch_array($result);
?>
<br />
<table width="500" border="0" align="center"  bgcolor="#f3f7fd" cellpadding="8" cellspacing="0" style="border:solid 1px #71befb;">
  <tr>
    <td background="butbg.gif" height="10px" colspan="2" style="font-size:13px; color:#064582;"><b>Update Profile</b></td>
  </tr>
  <tr>
    <td><form name="form2" method="post" action="show.php" onsubmit="return ValidateForm();">
        <input type="hidden" name="emp_id" value="<?=$_GET['emp_id'] ?>" />
        <table width="500" border="0" align="center" cellpadding="3" cellspacing="1">
          <tr>
            <td width="130" height="25" bgcolor="#e9f5ff" style="font-size:12px; padding-left:10px;">Employee Name :</td>
            <td width="285" bgcolor="#e9f5ff"><input type="text" name="emp_name" size="40" value="<? echo $row['emp_name'] ?>" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" />
            &nbsp;<font color="#FF0000" size="2px"><b>*</b></font></td>
          </tr>
          <tr>
            <td height="25" style="font-size:12px; padding-left:10px;">Email :</td>
            <td><input type="text" name="email" size="40" value="<? echo $row['email']?>" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" />
            &nbsp;<font color="#FF0000" size="2px"><b>*</b></font></td>
          </tr>
          <tr>
            <td height="25" bgcolor="#e9f5ff" style="font-size:12px; padding-left:10px;">Gender :</td>
            <td bgcolor="#e9f5ff"><select name="gender" style="border:solid 1px #61b5f8; background-color:#FFFFFF;">
                <option value="">--Select Here--</option>
                <option value="Male" <? if ($row['gender']== 'Male') echo "selected";?> >Male</option>
                <option value="Female" <? if ($row['gender']== 'Female') echo "selected"; ?>>Female</option>
              </select>
              &nbsp;<font color="#FF0000" size="2px"><b>*</b></font></td>
          </tr>
          <tr>
            <td height="25" style="font-size:12px; padding-left:10px;">Address :</td>
            <td><input type="text" name="address" size="40" value="<? echo $row['address']?>" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" />
            &nbsp;<font color="#FF0000" size="2px"><b>*</b></font></td>
          </tr>
          <tr>
            <td height="25" bgcolor="#e9f5ff" style="font-size:12px; padding-left:10px;">Mob No. :</td>
            <td bgcolor="#e9f5ff"><input type="text" maxlength="11" name="mobno" size="40" value="<? echo $row['mobno']?>" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" />
            &nbsp;<font color="#FF0000" size="2px"><b>*</b></font></td>
          </tr>
          <tr>
            <td height="30" colspan="2" align="center" valign="middle"><input type="submit" name="update" value="Update Record" />
            </td>
          </tr>
        </table>
      </form></td>
  </tr>
</table>
<br />
<br />
<table width="520" border="0" align="center" bgcolor="#f3f7fd" cellpadding="8" cellspacing="0" style="border:solid 1px #71befb;">
  <tr>
    <td background="butbg.gif" height="10px" colspan="2" style="padding-left:15px"><strong>Change Password</strong></td>
  </tr>
  <tr>
    <td><form name="form3" method="post" action="show.php" onsubmit="return validateform3();">
        <input type="hidden" name="emp_id" value="<?=$_GET['emp_id'] ?>" />
        <table width="500" border="0" align="center" cellpadding="1" cellspacing="1">
          <tr>
            <td colspan="2"></td>
          </tr>
          <tr>
            <td colspan="3"></td>
          </tr>
          <tr>
            <td width="130" bgcolor="#e9f5ff" style="font-size:12px; padding-left:10px; font-size:12px;">Password :</td>
            <td width="285" height="30" bgcolor="#e9f5ff"><input type="text" name="oldpwd" size="35"  value="<?=$rsrow['password'];?>" style="border:solid 1px #61b5f8; background-color:#FFFFFF;"/>
              &nbsp;<font color="#FF0000" size="2px"><b>*</b></font></td>
          </tr>
          <!--<tr><td style="font-size:12px">New Password :</td>
<td><input type="password" name="newpwd" size="30" />&nbsp;<font color="#FF0000" size="2px"><b>*</b></font></td></tr>-->
          <tr>
            <td height="30" colspan="2" align="center" valign="middle"><input type="submit" name="submit" value="Change Password" /></td>
          </tr>
        </table>
      </form></td>
  </tr>
</table>
<table align="center" width="100%">
<tr><td>&nbsp;</td></tr>
<tr><td class="footer" width="100%" >&copy; 2009 TeacherSITY. All rights reserved</td></tr>
</table>
</body>
</html>
