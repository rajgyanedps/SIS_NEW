<?php
    session_start();
    error_reporting(0);
    include("connection.php");
    //echo "<PRE>";PRINT_r($_SESSION);
    if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='Project Manager' && $_SESSION['user_type']!='Tele Caller')
    //if (!isset($_SESSION[myusername]))
    {
     header("Location: index.php");
    }
    $_SESSION['this_page']='cumulativereport.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Cumulative Report</title>
        <link rel="shortcut icon" href="http://www.selaqui.org/images/favicon.ico" type="image/x-icon">
        <script type="text/javascript">
            <!--
            function MM_openBrWindow(theURL,winName,features) { //v2.0
              window.open(theURL,winName,features);
            }
        </script>
        <style type="text/css">
            <!--
                body {
                	font-family: Arial, Helvetica, sans-serif;
                	font-size: 12px;
                	background-color: #FFFFFF;
                	background-repeat: no-repeat;
                }
                a {
                	color: #333333;
                }
                -->
        </style>
        <link href="msg.css" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" type="text/css" href="calendar-blue.css">
        <script type="text/javascript" src="calendar.js"></script>
        <script type="text/javascript" src="calendar-en.js"></script>
        <script type="text/javascript" src="calendar-setup.js"></script>
        <script language="javascript1.2" src="tabber.js"></script>
    </head>
    <body>
        <?php
            include("header.php");
        ?>
        <form action="cumulativereport.php" method="get" name="cumulativereport">
            <table align="center" width="100%">
                <tr>
                    <td colspan="2"><img src="image/spacer.gif" height="10px;" /></td>
                </tr>
                <tr>
                    <td height="25" colspan="2" align="left" bgcolor="#e9f5ff"><font size="3px" face="Verdana, Arial, Helvetica, sans-serif"><b>&nbsp; Cumulative Student Report</b></font></td>
                </tr>
                <tr>
                    <td colspan="2"><img src="image/spacer.gif" height="10px;" /></td>
                </tr>
                <tr>
                    <!--<td width="16%" height="40" align="left" valign="middle" bgcolor="#e9f5ff"><font color="#000000" size="3px" style="padding-left:10px;"><?php if($_SESSION['temp_type']!='y') {?><b>Convert to Excel</b>&nbsp;&nbsp;<a href="report2.php?information_source=<?=$_GET['information_source']?>&date1=<?=$_GET['date1']?>&date2=<?=$_GET['date2']?>"><img src="logo_excel.gif" alt="Export" border="0"></a><? }?></font>
                    </td>-->
                    <td align="left" valign="middle" bgcolor="#e9f5ff">
                        <font color="#000000" size="2px" style="padding-left:10px;">
                            <div id="divnb" style="float:left;line-height:20px">
                                &nbsp;&nbsp;&nbsp;<b>Search by From Date:</b> <img src="CalendarIcon.gif" name="get_stud_date1" width="22" height="23" border="0" align="absmiddle" id="get_stud_date1" style="cursor: pointer;" title="Date selector" onMouseOver="this.style.background='red';" onMouseOut="this.style.background=''" /> &nbsp;
                                <input type="text" name="date1" size="10" id="date1" <?php if($_GET['date1']!=''){ echo 'selected';}?> value ="<?= $_GET['date1'];?>" />
                                <script type="text/javascript">
                                    Calendar.setup({
                                    inputField     :    "date1",     // id of the input field
                                    //ifFormat       :    "%Y/%m/%d %l:%M %P",      // format of the input field
                                    //ifFormat       :    "%m-%d-%Y",      // format of the input field
                                    ifFormat       :    "%d-%m-%Y",      // format of the input field
                                    button         :    "get_stud_date1",  // trigger for the calendar (button ID)
                                    align          :    "Tl",           // alignment (defaults to "Bl")
                                    singleClick    :    true,
                                    showsTime		:	true
                                    });
                                    
                                </script>
                                &nbsp;&nbsp;&nbsp;<b>To Date:</b> <img src="CalendarIcon.gif" name="get_stud_date2" width="22" height="23" border="0" align="absmiddle" id="get_stud_date2" style="cursor: pointer;" title="Date selector" onMouseOver="this.style.background='red';" onMouseOut="this.style.background=''" /> &nbsp;
                                <input type="text" name="date2" size="10" id="date2" <?php if($_GET['date2']!=''){ echo 'selected';}?> value ="<?= $_GET['date2'];?>"  />
                                <script type="text/javascript">
                                    Calendar.setup({
                                    inputField     :    "date2",     // id of the input field
                                    //ifFormat       :    "%Y/%m/%d %l:%M %P",      // format of the input field
                                    //ifFormat       :    "%m-%d-%Y",      // format of the input field
                                    ifFormat       :    "%d-%m-%Y",      // format of the input field
                                    button         :    "get_stud_date2",  // trigger for the calendar (button ID)
                                    align          :    "Tl",           // alignment (defaults to "Bl")
                                    singleClick    :    true,
                                    showsTime		:	true
                                    });
                                    
                                </script>
                            </div>
                         <!--   <b>
                                Search by Information Source:&nbsp;
                                <select name="information_source" id="information_source"  style="border:solid 1px #61b5f8; background-color:#FFFFFF; width:170px">
                                    <option value="">---Select---</option>
                                    <?php
                                        $drop_info = "select status from student where status!= '' group by status";
                                        $result_info = mysql_query($drop_info);
                                        while($row_info = mysql_fetch_array($result_info)){?>
                                    <option value="<?= $row_info['status'];?>" <?php if($_GET['information_source'] == $row_info['status']) echo 'selected';?>><?=$row_info['status'];?></option>
                                    <?php
                                        }
                                        ?>
                                </select>
                            </b>-->
                        </font>
                        &nbsp;&nbsp;
                        <input type="submit" name="search1" value="  Search  ">
                    </td>
                </tr>
            </table>
            <table width="100%" border="0" align="center" cellpadding="5" cellspacing="1" bgcolor="#81cafd" style="font-size:11px">
                <tr height="20" bgcolor="#999999" align="center">
                    <td width="3%" align="left" background="footerbg.jpg" class="whitetxt11">S.No.</td>
                    <td width="11%" align="left" background="footerbg.jpg" class="whitetxt11">Emp Name</td>
                    <td width="6%" align="left" background="footerbg.jpg" class="whitetxt11">No. of Student</td>
                    <td width="9%" align="left" background="footerbg.jpg" class="whitetxt11">Students Contacted</td>
                    <td width="7%" align="left" background="footerbg.jpg" class="whitetxt11">No. of Calls</td>
                    <td width="6%" align="left" background="footerbg.jpg" class="whitetxt11">Admission</td>
                    <td width="6%" align="left" background="footerbg.jpg" class="whitetxt11">Campus Visit</td>
                    <td width="7%" align="left" background="footerbg.jpg" class="whitetxt11">Paid Student</td>
                    <td width="9%" align="left" background="footerbg.jpg" class="whitetxt11">Positive Student</td>
                    <td width="8%" align="left" background="footerbg.jpg" class="whitetxt11">Moderate Student</td>
                    <td width="8%" align="left" background="footerbg.jpg" class="whitetxt11">Negative Student</td>
					<td width="8%" align="left" background="footerbg.jpg" class="whitetxt11">Not Eligible</td>
                    <td width="13%" align="left" background="footerbg.jpg" class="whitetxt11">No Contacted </td>
                    <td width="13%" align="left" background="footerbg.jpg" class="whitetxt11">Session(2019-20)</td>
                </tr>
                <? 
                  /*  $infosrc="";
                    if($_GET['information_source']!='')
                    {
                    $infosrc=" and information_source='".$_GET['information_source']."'";
                    } */
                    if (strlen($_GET['date1'])>0) {
                    	$fmt_date12222 = date('Y-m-d',strtotime($_GET['date1'])); 
                    	$fmt_date1=$fmt_date12222." 00:00:00";
                    	$strdate1=" and student.joined >='$fmt_date1'";
                    	$strdate11=" and student.contact_date >='$fmt_date1'";
                    	$strdate111=" and contact.joined >='$fmt_date1'";
                       }
					if (strlen($_GET['date2'])>0){
                      	$fmt_date256666 = date('Y-m-d',strtotime($_GET['date2'])); 
                    	$fmt_date2=$fmt_date256666." 23:59:59";
                    	$strdate2=" and student.joined <='$fmt_date2'";
                    	$strdate22=" and student.contact_date <='$fmt_date2'";
                    	$strdate222=" and contact.joined <='$fmt_date2'";
                    }
                    
					$sql_cust = "SELECT emp_name,emp_id FROM members WHERE username!='Open Data' and user_type!='Admin' and username!='del_school' order by emp_name";	
                    
                    /*	
                    $sql_cust = "SELECT emp_name,emp_id, (SELECT count(*) FROM student WHERE student.emp_id=members.emp_id $infosrc $strdate1 $strdate2) as school,(SELECT count(*) from contact INNER JOIN student ON student.stud_id=contact.stud_id where student.emp_id=members.emp_id and contact_date!='0000-00-00 00:00:00' $infosrc $strdate1 $strdate2) as totcnt, (SELECT count(*) from student where student.emp_id=members.emp_id and contact_date!='0000-00-00 00:00:00' $infosrc $strdate11 $strdate22) as totcnt1 ,(SELECT count(*) from student where student.emp_id=members.emp_id $infosrc $strdate1 $strdate2  and status='Positive') as positive, (SELECT count(*) from student where student.emp_id=members.emp_id $infosrc $strdate1 $strdate2 and status='Negative') as negative, (SELECT count(*) from student where student.emp_id=members.emp_id $infosrc $strdate1 $strdate2 and status='Moderate') as moderate, (SELECT count(*) from student where student.emp_id=members.emp_id $infosrc $strdate1 $strdate2 and status='Paid') as paid, (SELECT count(*) from student where student.emp_id=members.emp_id $infosrc $strdate1 $strdate2 and status='Admission') as Admission FROM members WHERE username!='Open Data' and user_type!='Admin' and username!='del_school' order by emp_name";
                    */	
                        $result	= mysql_query($sql_cust) or die(mysql_error());
                    	$count = 0;
                    	$total1=0;
                    	$total22=0;
                    	$total2=0;
                    	$total3=0;
                    	$total4=0;
                    	$total5=0;
                    	$total51=0;
                    	$total52=0;
                    	$total6=0;
                    	$total7=0;
                    	$total8=0;
                    	$total9=0;
                    while($res=mysql_fetch_array($result)){
                    $total1=$total1+$res ['school'];
                    $total22=$total22+$res ['Admission'];
                    $total2=$total2+$res ['paid'];
                    $total3=$total3+$res ['positive'];
                    $total4=$total4+$res ['moderate'];
                    $total5=$total5+$res ['negative'];
                    $total51=$total51+$res ['NoContact'];
                    $total52=$total52+$res ['Session2013-14'];
                    $total6=$total6+$res ['test'];
                    $total7=$total7+$res ['totalamt'];
                    $total8=$total8+$res ['paidamt'];
                    $total10=$total10+$res ['totcnt'];
                    $total101=$total101+$res ['totcnt1'];
                    $total9=$total9+$res['totalamt'] - $res['paidamt'];
                    
                    if($acol) {
                               $x = "bgcolor='#e9f5ff'";
                              } else {
                                $x = "bgcolor='#d8effe'";
                    	          }
                    		  $acol=!$acol;
                    		  $count++;
                    ?>
                <tr <?=$x;?> align="left">
                    <td height="23"><? echo $count;?>.</td>
                    <td><strong><?php echo $res['emp_name'];?></strong></td>
                    <td>
                       <?php 
                         $qry_stud = "SELECT count(*) as studno FROM student WHERE student.emp_id='".$res ['emp_id']."'  $strdate1 $strdate2";
                            $res_stud = mysql_query($qry_stud) or die(mysql_error());
                            $row_stud = mysql_fetch_array($res_stud );
                            echo $row_stud['studno'];
                             $total_studno=$total_studno+$row_stud['studno'];
                        ?>
                    </td>
                    <td>
					<?php 
                   $qry_contact = "SELECT count(*) as stud_contact from student where student.emp_id='".$res ['emp_id']."' and contact_date!='0000-00-00 00:00:00' $strdate11 $strdate22";
                        $res_contact = mysql_query($qry_contact) or die(mysql_error());
                        $row_contact = mysql_fetch_array($res_contact);
                        echo $row_contact['stud_contact'];
                         $total_contact=$total_contact+$row_contact['stud_contact'];
                        ?>
					</td>
                    <td>
                        <?php
                         $qry_calls = "SELECT count(*) as calls from contact INNER JOIN student ON student.stud_id=contact.stud_id where student.emp_id='".$res ['emp_id']."' $strdate111 $strdate222";
                            $res_calls = mysql_query($qry_calls) or die(mysql_error());
                            $row_calls = mysql_fetch_array($res_calls);
                            echo $row_calls['calls'];
                            $total_calls=$total_calls+$row_calls['calls'];
                            ?>
                    </td>
                    <td>
					  <?php 
                        $qry_admit = "SELECT count(*) as admit from student where student.emp_id='".$res ['emp_id']."' $strdate1 $strdate2 and status='Admission'";
                        $res_admit = mysql_query($qry_admit) or die(mysql_error());
                        $row_admit = mysql_fetch_array($res_admit);
                        echo $row_admit['admit'];
                        $total_admit=$total_admit+$row_admit['admit'];
                        ?>
					</td>
					<td>
                          <?php 
                            $qry_camp = "SELECT count(*) as campus_visit from student where student.emp_id='".$res ['emp_id']."' $strdate1 $strdate2 and status='CampusVisit'";
                            $res_camp = mysql_query($qry_camp) or die(mysql_error());
                            $row_camp = mysql_fetch_array($res_camp);
                            echo $row_camp['campus_visit'];
                            $total_camp_visit=$total_camp_visit+$row_camp['campus_visit'];
                           ?>
                    </td>
                    <td>
                        <?php 
                      $qry_paid = "SELECT count(*) as paid_stud from student where student.emp_id='".$res ['emp_id']."' $strdate1 $strdate2 and status='Paid'";
                            $res_paid = mysql_query($qry_paid) or die(mysql_error());
                            $row_paid = mysql_fetch_array($res_paid);
                            echo $row_paid['paid_stud'];
                            $total_paid=$total_paid+$row_paid['paid_stud'];
                          ?>
                    </td>
                    <td>
					<?php 
                            $qry_positive = "SELECT count(*) as positive_stud from student where student.emp_id='".$res ['emp_id']."' $strdate1 $strdate2 and status='Positive'";
                            $res_positive = mysql_query($qry_positive) or die(mysql_error());
                            $row_positive = mysql_fetch_array($res_positive);
                            echo $row_positive['positive_stud'];
                            $total_positive=$total_positive+$row_positive['positive_stud'];
                            ?>
                    </td>
                    <td>
                        <?php 
                            $qry_mod = "SELECT count(*) as mod_stud from student where student.emp_id='".$res ['emp_id']."' $strdate1 $strdate2 and status='Moderate'";
                            $res_mod = mysql_query($qry_mod) or die(mysql_error());
                            $row_mod = mysql_fetch_array($res_mod);
                            echo $row_mod['mod_stud'];
                            $total_mod=$total_mod+$row_mod['mod_stud'];
                            ?>
                    </td>
                    <td>
                        <?php 
                            $qry_neg = "SELECT count(*) as neg_stud from student where student.emp_id='".$res ['emp_id']."' $strdate1 $strdate2 and status='Negative'";
                            $res_neg = mysql_query($qry_neg) or die(mysql_error());
                            $row_neg = mysql_fetch_array($res_neg);
                            echo $row_neg['neg_stud'];
                            $total_neg=$total_neg+$row_neg['neg_stud'];
                            ?>
                    </td>
                    <td>
                       <?php 
                            $qry_noeligible = "SELECT count(*) as noeligible_stud from student where student.emp_id='".$res ['emp_id']."' $strdate1 $strdate2 and status='Not Eligible'";
                            $res_noeligible = mysql_query($qry_noeligible) or die(mysql_error());
                            $row_noeligible= mysql_fetch_array($res_noeligible);
                            echo $row_noeligible['noeligible_stud'];
                           $total_noeligible=$total_noeligible+$row_noeligible['noeligible_stud'];
                        ?>
                    </td>
					<td>
                       <?php 
                            $qry_nocontacted = "SELECT count(*) as nocontacted_stud from student where student.emp_id='".$res ['emp_id']."' $strdate1 $strdate2 and status='NoContact'";
                            $res_nocontacted = mysql_query($qry_nocontacted) or die(mysql_error());
                            $row_nocontacted= mysql_fetch_array($res_nocontacted);
                            echo $row_nocontacted['nocontacted_stud'];
                            $total_nocontacted=$total_nocontacted+$row_nocontacted['nocontacted_stud'];
                        ?>
                    </td>
                    <td>
                          <?php 
                            $qry_newsession = "SELECT count(*) as newsession_stud from student where student.emp_id='".$res ['emp_id']."' $strdate1 $strdate2 and status='Session2019-20'";
                            $res_newsession = mysql_query($qry_newsession) or die(mysql_error());
                            $row_newsession = mysql_fetch_array($res_newsession);
                            echo $row_newsession['newsession_stud'];
                            $total_newsession=$total_newsession+$row_newsession['newsession_stud'];
                           ?>
                    </td>
				 </tr>
                <? }?>
                <tr bgcolor="#CCFFCC">
                    <td colspan="2" style="padding-left:57px"><font size="3px"><b>Sum</b></font></td>
                    <td><strong><? echo $total_studno;?></strong></td>
                    <td><strong><? echo $total_contact;?></strong></td>
                    <td><strong><? echo $total_calls;?></strong></td>
                    <td><strong><? echo $total_admit;?></strong></td>
                    <td><strong><? echo $total_camp_visit;?></strong></td>
                    <td><strong><? echo $total_paid;?></strong></td>
                    <td><strong><? echo $total_positive;?></strong></td>
                    <td><strong><? echo $total_mod;?></strong></td>
                    <td><strong><? echo $total_neg;?></strong></td>
                    <td><strong><? echo $total_noeligible;?></strong></td>
					<td><strong><? echo $total_nocontacted;?></strong></td>
                    <td><strong><? echo $total_newsession;?></strong></td>
                 </tr>
            </table>
            <table width="100%" align="center">
                <tr>
                    <td><img src="image/spacer.gif" height="5" /></td>
                </tr>
                <tr>
                    <td class="footer" width="934" >&copy; 2009 TeacherSITY. All rights reserved</td>
                </tr>
            </table>
        </form>
    </body>
</html>