<?php
session_start();
include("connection.php");
if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='Project Manager' && $_SESSION['user_type']!='Tele Caller')
//if (!isset($_SESSION[myusername]))
{
 header("Location: index.php");
}
?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>School Payment Report</title>
<script type="text/javascript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />

</head>
<body>
<?php
include("header.php");
?>
<?php
$sql = "SELECT school_id, school_name FROM addschool WHERE school_id='".$_GET['school_id']."'";
$result1 = mysql_query($sql);
$res1 = mysql_fetch_array($result1);
?>
<?
 $sql_cust = "SELECT * FROM addammount WHERE school_id ='".$_GET['school_id']."' order by addammount.joined asc";

		$result	= mysql_query($sql_cust) or die(mysql_error());
		$num_rows=mysql_num_rows($result);
?>
<form action="ammreport.php" method="post" name="ammreport" style="margin:0px;">
<table width="100%" align="center">
  <tr><td><img src="image/spacer.gif" height="20px;" /></td>
</tr>
  <tr><td height="30" align="left" bgcolor="#f3f7fd" style="padding-left:10px"><font size="3px" face="Verdana, Arial, Helvetica, sans-serif"><b>School Amount (<? echo $res1['school_name'];?>)</b></font></td>
</tr>
<tr><td><img src="image/spacer.gif" height="5" /></td></tr>
<tr><td>
<font color="#000000" size="3px" style="padding-left:15px"><b>Convert to Excel</b>&nbsp;&nbsp;<a href="report5.php?school_id=<? echo $res1['school_id'];?>"><img src="logo_excel.gif" alt="Export" border="0"></a></font>
</td></tr>
<tr><td>&nbsp;</td></tr>
</table>
<table width="100%" border="0" align="center" cellpadding="5" cellspacing="1" bgcolor="#81cafd" style="font-size:13px">
<tr bgcolor="#999999" align="center">

      <td width="5%" height="20" align="left" background="footerbg.jpg" bgcolor="#999999" class="whitetxt11">S.No.</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="20%">Total Amm</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="20%">Ammount Paid</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="15%">Balance Amm</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="20%">Due Date</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="20%">Cheque No.</td>
    </tr>
                <? 
	if($num_rows==0)
{
echo "<div align=center><font color=red size=+1>No Record Found</font></div>";
}
		$count = 0;
		
while($res=mysql_fetch_array($result))
{
if($acol) {
	           $x = "bgcolor='#e9f5ff'";
	          } else {
	            $x = "bgcolor='#d8effe'";
 	          }
			  $acol=!$acol;
			  $count++;
?>

<tr <?=$x;?> align="left">
        <td width="5%" height="30"><? echo $count;?>.</td>
      <td width="20%"><?php echo $res['totalamm'];?></td>
                        <td width="20%"><?php echo $res['advanceamm'];?></td>
                            <td width="15%"><?php echo $res['balanceamm'];?></td>
                                <td width="20%"><?php echo date("d-M-y", strtotime($res['duedate']));?></td>
                                    <td width="20%"><?php echo $res['chequeno'];?></td>
    </tr>
                         
 <? }?>
			
</table>
<table width="100%" align="center">
<tr>
<td>&nbsp;</td>
</tr>
<tr>
<td class="footer" width="944" >&copy; 2009 TeacherSITY. All rights reserved</td>
</tr>

</table>
  

</form>

</body>
</html>