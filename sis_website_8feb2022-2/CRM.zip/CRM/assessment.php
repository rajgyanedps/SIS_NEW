<?php
include("connection.php");
session_start();
if (isset($_POST['submit']))

{
$sql="INSERT INTO addassessment(school_id,joined,aware,working,nameorg,islbrochure) VALUES ('".$_POST['school_id']."',now(),'".$_POST['aware']."','".$_POST['working']."','".$_POST['nameorg']."','".$_POST['islbrochure']."')";

$result=mysql_query($sql) or die(mysql_error());

if ($_SESSION['user_type']=="Project Manager")
{
header("Location: pmhome.php?msg=Assessment Test Added Successfully......");
}
else if ($_SESSION['user_type']=="Tele Caller")
{
header("Location: tchome.php?msg=Assessment Test Added Successfully......");
}
else
{
header("Location: adminhome.php?msg=Assessment Test Added Successfully......");
}
}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Add Assessment Test</title>
<script type="text/javascript">
function showhide(val)
{
if(val.value=='Yes')
document.getElementById('divnb').style.display='block';
else
document.getElementById('divnb').style.display='none';
}
</script>

<script type="text/javascript">
function ValidateForm()
{
// checking aware field
	  
	  if (document.assessment.aware.value=="")
	 {
		alert("The Aware is blank. \nPlease select the Aware field in the combo box.");
        document.assessment.aware.focus();		
        return false;
      }		
// checking workingorg. field
	  
	  if (document.assessment.working.value=="")
	 {
		alert("The Working Org. is blank. \nPlease select the working field in the combo box.");
        document.assessment.working.focus();		
        return false;
      }		
// checking nameorg field (if Yes)
      
    if (document.assessment.working.value=="Yes")
	   {
	   	  if (document.assessment.nameorg.value=="")
	 {
		alert("The Name of the org. field is blank. \nPlease enter the name of the org. field in the text box.");
        document.assessment.nameorg.focus();		
        return false;
      }		
	  }	 
// checking islbrochure field
	  
	  if (document.assessment.islbrochure.value=="")
	 {
		alert("The isl brochure is sent is blank. \nPlease select the isl brochure field in the combo box.");
        document.assessment.islbrochure.focus();		
        return false;
      }		
      }
     </script> 
     <style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />                 
</head>

<body>
<?php
include("header.php");
?>
<br /><br /><br />
<form name="assessment" method="post" action="assessment.php" onsubmit="return ValidateForm();">
<table width="560" border="0" align="center" bgcolor="#f3f7fd" cellpadding="8" cellspacing="0" style="border:solid 1px #71befb;"> 
<tr><td background="butbg.gif" height="10px" style="font-size:13px; color:#064582;">&nbsp;&nbsp;<b>Add Assessment Test</b></td></tr>


<tr><td>
<table width="550" align="center" style="font-size:13px">

<tr><td colspan="3"></td></tr>
<tr>
<input type="hidden" name ="school_id" value="<?= $_GET['school_id']?>">
<td width="301" height="25" style="font-size:12px; padding-left:10px;">Is the school is aware about student assessment</td>
<td width="6">:</td>
<td width="226"><select name="aware">
<option value="">--Please Select--</option>
<option value="Yes">Yes</option>
<option value="No">No</option>
</select>&nbsp;<font color="#FF0000"><b>*</b></font>
</td>
</tr>
<tr><td height="25" style="font-size:12px; padding-left:10px;">Is the school working with any Org.</td>
<td>:</td>
<td><select name="working" onchange="showhide(this)">
<option value="">--Please Select--</option>
<option value="No">No</option>
<option value="Yes">Yes</option>
</select>&nbsp;<font color="#FF0000"><b>*</b></font>
</td>
</tr>
<tr><td height="25" style="font-size:12px; padding-left:10px;">Name of the Org.</td>
<td>:</td>
<td><div id="divnb" style="display:none"><input type="text" name="nameorg" size="30" />&nbsp;<font color="#FF0000"><b>*</b></font>
  </div>   
</td></tr>

<tr><td height="25" style="font-size:12px; padding-left:10px;">Has the ISL brochure been sent</td>
<td>:</td>
<td><select name="islbrochure">
<option value="">--Please Select--</option>
<option value="Yes, Couriered/Regular Mail">Yes, Couriered/Regular Mail</option>
<option value="Yes, Hand Delivered">Yes, Hand Delivered</option>
<option value="Yes, Emailed">Yes, Emailed</option>
<option value="No">No</option>
</select>&nbsp;<font color="#FF0000"><b>*</b></font></td></tr>

<tr><td colspan="3"></td></tr>
<tr><td colspan="3"></td></tr><tr><td colspan="3"></td></tr><tr><td colspan="3"></td></tr>
<tr><td height="30" colspan="3" align="center"><input type="submit" name="submit" value="Submit" /></td></tr>
</table></td></tr></table>


<br /><br /><br />
<table width="100%" border="0" align="center" cellpadding="5" cellspacing="1" bgcolor="#81cafd" style="font-size:13px">
<tr bgcolor="#999999" align="center">

      <td align="left" background="footerbg.jpg" class="whitetxt11" width="5%">S.No.</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="20%">Date & Time</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="15%">School is Aware</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="20%">School working with any Org.</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="20%">Name Org.</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="20%">ISL Brochure is sent or not</a></td>
      
    </tr>
<?php
$sql_cust = "SELECT * FROM addassessment WHERE school_id='".$_GET['school_id']."' order by joined asc";
$result = mysql_query($sql_cust);
$count = 0;
while($row = mysql_fetch_array($result))
{
	$count++;
?>
<tr>
        <td valign="top" width="5%"><? echo $count;?>.</td>
             <td width="20%"><?php echo $row['joined'];?></td>
                 <td width="15%"><?php echo $row['aware'];?></td>
                     <td width="20%"><?php echo $row['working'];?></td>
                         <td width="20%"><?php echo $row['nameorg'];?></td>
                             <td width="20%"><?php echo $row['islbrochure'];?></td>
                                 
    </tr>
    <?
}
?>
</table>
</form>
</body>
</html>