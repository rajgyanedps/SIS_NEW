<?php
session_start();
include('functions.inc.php');
include("connection.php");
if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='Project Manager' && $_SESSION['user_type']!='Tele Caller')
//if (!isset($_SESSION[myusername]))
{
 header("Location: index.php");
}
$_SESSION['this_page']='empreport2.php';

@extract($_GET);

if($order_by!="")
{	
	$KEYWORD_SEARCH_1="ORDER BY $order_by $img_name"; 
}
else
{
	$KEYWORD_SEARCH_1="ORDER BY student.contact_date DESC";
}	

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Total Student Status Report</title>
<script type="text/javascript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php

include("header.php");
$sql = "select * from members WHERE emp_id='".$_GET['emp_id']."'";
$result1 = mysql_query($sql);
$res1 = mysql_fetch_array($result1);
$res1['emp_id'];
?>
<form action="empreport2.php" method="get" name="empreport2">

  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td><br />
        <table width="100%" align="center">
          <tr>
            <td height="25" align="left" bgcolor="#e9f5ff" style="padding-left:10px"><font size="3px"><b><?php echo $_GET['stat'];?> Student :- <? echo $res1['emp_name'];?></b></font></td>
          </tr>
          <tr>
            <td height="15" align="left"  style="padding-left:10px">&nbsp;</td>
          </tr>
        </table>
        <?php
        
        $start=0;
$pagesize=50;

if(isset($_GET['start'])) 
	$start=$_GET['start'];

if(isset($_GET['pagesize'])) 
	$pagesize=$_GET['pagesize'];	
				
		
if(isset($_GET['emp_id']))
{

 $sql_cust = "SELECT student.*, members.emp_name FROM student INNER JOIN members ON student.emp_id=members.emp_id WHERE emp_id ='".$_GET['emp_id']."'  and student.status='".$_GET['stat']."' and student.course like '".$_GET['course_keyword']."%' and student.city like '".$_GET['city_keyword']."%' $KEYWORD_SEARCH_1  limit $start,$pagesize";
  $sqlnum = "SELECT student.*, members.emp_name FROM student INNER JOIN members ON student.emp_id=members.emp_id WHERE emp_id ='".$_GET['emp_id']."'  and student.status='".$_GET['stat']."' and student.course like '".$_GET['course_keyword']."%' and student.city like '".$_GET['city_keyword']."%' $KEYWORD_SEARCH_1 ";
}
 else{
	   
 $sql_cust = "SELECT student.*, members.emp_name FROM student INNER JOIN members ON student.emp_id=members.emp_id WHERE student.status='".$_GET['stat']."' and student.course like '".$_GET['course_keyword']."%' and student.city like '".$_GET['city_keyword']."%' $KEYWORD_SEARCH_1  limit $start,$pagesize";
 $sqlnum = "SELECT student.*, members.emp_name FROM student INNER JOIN members ON student.emp_id=members.emp_id WHERE student.status='".$_GET['stat']."' and student.course like '".$_GET['course_keyword']."%' and student.city like '".$_GET['city_keyword']."%' $KEYWORD_SEARCH_1";

  $abc=  mysql_query($sqlnum);
        $no_of_results=  mysql_num_rows($abc);
          
	 $reccnt=$no_of_results; 
 
 
		$result	= mysql_query($sql_cust) or die(mysql_error());
		$num_rows 	= $reccnt;
                
               
 }
   
	if($num_rows>0)
	{
	
 if ($_GET['stat']=='Paid') { ?>
        <div style="float:left; width:70%; line-height:20px; margin-bottom:7px;"><font color="#000000" size="3px" style="padding-left:15px"><?php if($_SESSION['temp_type']!='y') {?><b>Convert to Excel</b>&nbsp;&nbsp;<a href="#" onClick="javascript:window.open('report6.php?stat=Paid&amp;emp_id=<? echo $res1['emp_id'];?>','myReport','');"><img src="logo_excel.gif" alt="Export" border="0"></a></font>
 
        <div style="float:right"><font color="#000000" size="2px" style="padding-right:15px"><strong>Search by Course:</strong><? }?></font>
        <input type="text" name="course_keyword" id="course_keyword" value="<?= $_GET['course_keyword'] ?>" style="height:17px;line-height:18px;border:solid 1px #61b5f8;font-size:12px;width:120px; color:#0a5095;background-color:#ffffff"/>
        <font color="#000000" size="2px" style="padding-right:15px; padding-left:15px"><strong>City:</strong></font>
        <input type="text" name="city_keyword" id="city_keyword" value="<?= $_GET['city_keyword'] ?>" style="height:17px;line-height:18px;border:solid 1px #61b5f8;font-size:12px;width:120px; color:#0a5095;background-color:#ffffff"/>
       &nbsp;&nbsp;&nbsp; <input type="submit" value="Search" />
       <input type="hidden" value="Paid" name="stat" id="stat" />
        
        </div>
    
        </div>
        <div align="right" style="float:left;width:25%;line-height:20px"><b>Records Found :</b>&nbsp;<strong><? echo $num_rows?></strong></div>
        <? }if ($_GET['stat']=='Positive') { ?>
        <div style="float:left;width:70%;line-height:20px; margin-bottom:7px;"><font color="#000000" size="3px" style="padding-left:15px"><?php if($_SESSION['temp_type']!='y') {?><b>Convert to Excel</b>&nbsp;&nbsp;<a href="#" onClick="javascript:window.open('report6.php?stat=Positive&amp;emp_id=<? echo $res1['emp_id'];?>','myReport','');"><img src="logo_excel.gif" alt="Export" border="0"></a><? }?></font>
        <div style="float:right"><font color="#000000" size="2px" style="padding-right:15px"><strong>Search by Course:</strong></font>
        <input type="text" name="course_keyword" id="course_keyword" value="<?= $_GET['course_keyword'] ?>" style="height:17px;line-height:18px;border:solid 1px #61b5f8;font-size:12px;width:120px; color:#0a5095;background-color:#ffffff"/>
        <font color="#000000" size="2px" style="padding-right:15px; padding-left:15px"><strong>City:</strong></font>
        <input type="text" name="city_keyword" id="city_keyword" value="<?= $_GET['city_keyword'] ?>" style="height:17px;line-height:18px;border:solid 1px #61b5f8;font-size:12px;width:120px; color:#0a5095;background-color:#ffffff"/>
       &nbsp;&nbsp;&nbsp; <input type="submit" value="Search" />
       <input type="hidden" value="Positive" name="stat" id="stat" />
        
        </div>
        </div>
        <div align="right" style="float:left;width:25%;line-height:20px; margin-bottom:7px;"><b>Records Found :</b>&nbsp;<strong><? echo $num_rows?></strong></div>
        <? } if ($_GET['stat']=='Negative') { ?>
        <div style="float:left;width:70%;line-height:20px; margin-bottom:7px;"><font color="#000000" size="3px" style="padding-left:15px"><?php if($_SESSION['temp_type']!='y') {?><b>Convert to Excel</b>&nbsp;&nbsp;<a href="#" onClick="javascript:window.open('report6.php?stat=Negative&emp_id=<? echo $res1['emp_id'];?>','myReport','');"><img src="logo_excel.gif" alt="Export" border="0"></a><? }?></font>
        <div style="float:right"><font color="#000000" size="2px" style="padding-right:15px"><strong>Search by Course:</strong></font>
        <input type="text" name="course_keyword" id="course_keyword" value="<?= $_GET['course_keyword'] ?>" style="height:17px;line-height:18px;border:solid 1px #61b5f8;font-size:12px;width:120px; color:#0a5095;background-color:#ffffff"/>
        <font color="#000000" size="2px" style="padding-right:15px; padding-left:15px"><strong>City:</strong></font>
        <input type="text" name="city_keyword" id="city_keyword" value="<?= $_GET['city_keyword'] ?>" style="height:17px;line-height:18px;border:solid 1px #61b5f8;font-size:12px;width:120px; color:#0a5095;background-color:#ffffff"/>
       &nbsp;&nbsp;&nbsp; <input type="submit" value="Search" />
       <input type="hidden" value="Negative" name="stat" id="stat" />
        
        </div>
        </div>
        <div align="right" style="float:left;width:25%;line-height:20px; margin-bottom:7px;"><b>Records Found :</b>&nbsp;<strong><? echo $num_rows?></strong></div>
        <? } if ($_GET['stat']=='Moderate') { ?>
        <div style="float:left;width:70%;line-height:20px; margin-bottom:7px;"><font color="#000000" size="3px" style="padding-left:15px; margin-bottom:7px;"><?php if($_SESSION['temp_type']!='y') {?><b>Convert to Excel</b>&nbsp;&nbsp;<a href="#" onClick="javascript:window.open('report6.php?stat=Moderate&amp;emp_id=<? echo $res1['emp_id'];?>','myReport','');"><img src="logo_excel.gif" alt="Export" border="0"></a><? }?></font>
        <div style="float:right"><font color="#000000" size="2px" style="padding-right:15px"><strong>Search by Course:</strong></font>
        <input type="text" name="course_keyword" id="course_keyword" value="<?= $_GET['course_keyword'] ?>" style="height:17px;line-height:18px;border:solid 1px #61b5f8;font-size:12px;width:120px; color:#0a5095;background-color:#ffffff"/>
        <font color="#000000" size="2px" style="padding-right:15px; padding-left:15px"><strong>City:</strong></font>
        <input type="text" name="city_keyword" id="city_keyword" value="<?= $_GET['city_keyword'] ?>" style="height:17px;line-height:18px;border:solid 1px #61b5f8;font-size:12px;width:120px; color:#0a5095;background-color:#ffffff"/>
       &nbsp;&nbsp;&nbsp; <input type="submit" value="Search" />
        <input type="hidden" value="Moderate" name="stat" id="stat" />
        
        </div>
        </div>
        <div align="right" style="float:left;width:25%;line-height:20px; margin-bottom:7px;"><b>Records Found :</b>&nbsp;<strong><? echo $num_rows?></strong></div>
      <? }  
	  
	  if ($_GET['stat']=='NoContact') { ?>
        <div style="float:left;width:70%;line-height:20px; margin-bottom:7px;"><font color="#000000" size="3px" style="padding-left:15px; margin-bottom:7px;"><?php if($_SESSION['temp_type']!='y') {?><b>Convert to Excel</b>&nbsp;&nbsp;<a href="#" onClick="javascript:window.open('report6.php?stat=NoContact&amp;emp_id=<? echo $res1['emp_id'];?>','myReport','');"><img src="logo_excel.gif" alt="Export" border="0"></a><? }?></font>
        <div style="float:right"><font color="#000000" size="2px" style="padding-right:15px"><strong>Search by Course:</strong></font>
        <input type="text" name="course_keyword" id="course_keyword" value="<?= $_GET['course_keyword'] ?>" style="height:17px;line-height:18px;border:solid 1px #61b5f8;font-size:12px;width:120px; color:#0a5095;background-color:#ffffff"/>
        <font color="#000000" size="2px" style="padding-right:15px; padding-left:15px"><strong>City:</strong></font>
        <input type="text" name="city_keyword" id="city_keyword" value="<?= $_GET['city_keyword'] ?>" style="height:17px;line-height:18px;border:solid 1px #61b5f8;font-size:12px;width:120px; color:#0a5095;background-color:#ffffff"/>
       &nbsp;&nbsp;&nbsp; <input type="submit" value="Search" />
        <input type="hidden" value="NoContact" name="stat" id="stat" />
        
        </div>
        </div>
        <div align="right" style="float:left;width:25%;line-height:20px; margin-bottom:7px;"><b>Records Found :</b>&nbsp;<strong><? echo $num_rows?></strong></div>
      <? } if ($_GET['stat']=='Session2013-14') { ?>
        <div style="float:left;width:70%;line-height:20px; margin-bottom:7px;"><font color="#000000" size="3px" style="padding-left:15px; margin-bottom:7px;"><b>Convert to Excel</b>&nbsp;&nbsp;<a href="#" onClick="javascript:window.open('report6.php?stat=Session2013-14&amp;emp_id=<? echo $res1['emp_id'];?>','myReport','');"><img src="logo_excel.gif" alt="Export" border="0"></a></font>
        <div style="float:right"><font color="#000000" size="2px" style="padding-right:15px"><strong>Search by Course:</strong></font>
        <input type="text" name="course_keyword" id="course_keyword" value="<?= $_GET['course_keyword'] ?>" style="height:17px;line-height:18px;border:solid 1px #61b5f8;font-size:12px;width:120px; color:#0a5095;background-color:#ffffff"/>
        <font color="#000000" size="2px" style="padding-right:15px; padding-left:15px"><strong>City:</strong></font>
        <input type="text" name="city_keyword" id="city_keyword" value="<?= $_GET['city_keyword'] ?>" style="height:17px;line-height:18px;border:solid 1px #61b5f8;font-size:12px;width:120px; color:#0a5095;background-color:#ffffff"/>
       &nbsp;&nbsp;&nbsp; <input type="submit" value="Search" />
        <input type="hidden" value="Session2013-14" name="stat" id="stat" />
        
        </div>
        </div>
        <div align="right" style="float:left;width:25%;line-height:20px; margin-bottom:7px;"><b>Records Found :</b>&nbsp;<strong><? echo $num_rows?></strong></div>
      <? } 
	  
	  ?></td>
    </tr>
    
    
    <tr>
      <td><table width="100%" border="0" align="center" cellpadding="5" cellspacing="1" bgcolor="#81cafd" style="font-size:12px">
        <tr bgcolor="#999999" align="center">
          <td width="3%" height="20" align="left" background="footerbg.jpg" class="whitetxt11">S.No.</td>
          <td height="20" align="left" background="footerbg.jpg" class="whitetxt11" width="24%">Student Name</td>
          <td width="7%" height="20" align="left" background="footerbg.jpg" class="whitetxt11">Email Id</td>
          <!--<td width="18%" height="20" align="left" background="footerbg.jpg" class="whitetxt11">
          <? //if($_GET['img_name']=='desc' && $_GET['order_by']=='course')
   		 //{ 
		 ?>
<a href="empreport2.php?order_by=course&img_name=asc&stat=<?//=$_GET['stat']?>"><strong>Course / Stream</strong><img src="image/asc.gif" alt="Descending Order" border="0"></a>
              <? 
    //} 
	//else 
	//{ 
	?>
    <a href="empreport2.php?order_by=course&img_name=desc&stat=<?//=$_GET['stat']?>"><strong>Course / Stream</strong>
    
    <img src="image/dsc.gif" alt="Ascending Order" border="0"></a>
              <?
	//}
	?>          </td>-->
          <!--<td width="6%" height="20" align="left" background="footerbg.jpg" class="whitetxt11">Percentage</td>-->
          <td width="11%" height="20" align="left" background="footerbg.jpg" class="whitetxt11">Phone No / Mobile No</td>
          
          <td width="12%" height="20" align="left" background="footerbg.jpg" class="whitetxt11"> <? if($_GET['img_name']=='desc' && $_GET['order_by']=='city')
   		 { 
		 ?>
<a href="empreport2.php?order_by=city&img_name=asc&stat=<?=$_GET['stat']?>"><strong>City</strong><img src="image/asc.gif" alt="Descending Order" border="0"></a>
              <? 
    } 
	else 
	{ 
	?>
    <a href="empreport2.php?order_by=city&img_name=desc&stat=<?=$_GET['stat']?>"><strong>City</strong>
    
    <img src="image/dsc.gif" alt="Ascending Order" border="0"></a>
            <?
	}
	?></td>
          <td align="left" background="footerbg.jpg" class="whitetxt11" width="6%">Information Source</td>
          <td colspan="2" align="left" background="footerbg.jpg" class="whitetxt11" width="6%">Coordinator</td>
          
        </tr>
        <?
		  }
		  else
		  {
		  ?>
        <div align="right" style="float:left;width:48%;line-height:20px; margin-bottom:7px;"><b>No Record Found </b></div>
        <?
		  } 
				
	if($start==''){
    $j=1;}else{$j=$start+1;}
     
    $i=0; 
     
//<?php
//$query="SELECT * FROM addschool";
//$result=mysql_query($query) or die(mysql_error());
while($res=mysql_fetch_array($result) and ($first<=$last))
{
if($i%2==0) {
	           $x = "bgcolor='#e9f5ff'";
	          } else {
	            $x = "bgcolor='#d8effe'";
 	          }
?>
        <tr <?=$x;?> align="left">
          <td><? echo $j++;?></td>
          <td><strong> <a href="11.php?stud_id=<? echo $res['stud_id'];?>"> <?php echo $res['stud_name'];?></a></strong></td>
          <td><?php echo $res['email'];?></td>
          <!--<td><?php
		  /*
		   echo $res['course'];
		  
			if($res['stream']!="")
			{
				echo " "."-"." ".$res['stream'];
			}
			else
			{
				echo "";
			}
		   */
		   ?></td>-->
          <!--<td><?php //echo $res['percentage'];?></td>-->
          <td><?php echo $res['phone_code']." ".$res['phone_no']." ".$res['mobno']; ?></td>
          
          <td><?php echo $res['city'];?></td>
           <td><?php 
		   		   
		   echo $res['information_source'];?></td>
           <td colspan="2"><? echo $res['emp_name'];?></td>
           
        </tr><!---->
        <tr <?=$x;?> align="left">
          <td colspan="8">
          <table width="100%"> 
          
          
          <? 
	   			$sql_cust11 = "SELECT * FROM contact WHERE stud_id='".$res['stud_id']."' order by joined asc";
				$result11	= mysql_query($sql_cust11) or die(mysql_error());
				$count = 0;
		
				while($res11=mysql_fetch_array($result11))
				{
					if($acol) 
					{
	           			$x = "bgcolor='#e9f5ff'";
	          				  
					}
					else 
					{
	            		$x = "bgcolor='#d8effe'";
 	          		}
			  		$acol=!$acol;
			  		$count++;
		?>
                        <tr align="left">
                          <td width="8%"><strong><?php 
						 
                                             
                                            
           if($res11['joined'] >='2014-05-01 02:00:00' && $res11['joined']!='0000-00-00 00:00:00')
              {
           
		   	  
		   echo date('d-M-Y',strtotime($res11['joined']));}
                   
                   else if($res11['joined'] <='2014-05-01 02:00:00' && $res11['joined']!='0000-00-00 00:00:00')
                   {
                       
                    
		   echo date('d-M-Y',strtotime($res11['joined']."+12 hours +32 minutes"));
                   }
                   
		   
	
                                                  
                                                  
                                                  
						  ?></strong></td>
                          <td width="92%"><?php if($res11['followup']=='Other') echo $res11['other']; else echo $res11['followup'];?>
                          <?
				
                                                  
                                                  
                                                  
                                                    if($res11['remarkdate'] >='2014-05-01 02:00:00' && $res11['remarkdate']!='0000-00-00 00:00:00')
              {
           
		  ?> 	  
		 on <?php echo date("d-M-y", strtotime($res11['remarkdate']));?> at <?php echo $res11['remarktime'];?>
                 <?php
                 }
                   
                   else if($res11['remarkdate'] <='2014-05-01 02:00:00' && $res11['remarkdate']!='0000-00-00 00:00:00')
                   {
                       
                    
		 ?> 	  
		 on <?php echo date("d-M-y", strtotime($res11['remarkdate']."+12 hours +32 minutes"));?> at <?php echo $res11['remarktime'];?>
                 <?php
                   }
                                                  
                                                  
						  ?>
                          </td>
                        </tr>
                        <? }?>
          </table>
          </td>
          </tr>
        <? 
	 	  	
  $i=$i+1;
  } 
	?>
      </table>
      <? if($reccnt > 0){	?></td>
    </tr>
    <tr>
      <td><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td colspan="3"><img src="image/spacer.gif" height="3" /></td>
          </tr>
          <tr>
              <td width="18%" align="right" valign="middle" background="newbar.jpg" class="data">&nbsp;</td>
            <td  width="70%"   height="26"  valign="middle" background="newbar.jpg" class="table_td_heading" style="padding-left:5px;"><span class="table_td_heading">
                    <? include("paging.inc.php"); ?>
              </span></td>
            
            <td width="125" align="center" valign="middle" background="newbar.jpg" class="data"><table width="100%" border="0" cellspacing="0" cellpadding="0">
<!--                <tr>
                  <td align="right" valign="middle" class="table_td_heading" style="padding-right:5px;"><strong>Page</strong>&nbsp;
                    <?=$pageno?>
                    &nbsp;of&nbsp;
                    <?=$pages?>                  </td>
                </tr>-->
              </table>
              <strong></strong></td>
          </tr>
        </table></td>
    </tr>
    <tr>
      <td><table width="100%" align="center">
      <tr>
      <td><img src="image/spacer.gif" height="5" /></td>
    </tr>
          <tr>
            <td class="footer" width="935" >&copy; 2009 TeacherSITY. All rights reserved</td>
          </tr>
        </table></td>
    </tr>
  </table>
  <? }?>
</form>
</body>
</html>
