<script type="text/javascript">
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
</script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
<script type="text/javascript" >
$(document).ready(function()
{

$(".account").click(function()
{
var X=$(this).attr('id');
if(X==1)
{
$(".submenu").hide();
$(this).attr('id', '0'); 
}
else
{
$(".submenu").show();
$(this).attr('id', '1');
}

});

//Mouse click on sub menu
$(".submenu").mouseup(function()
{
return false
});

//Mouse click on my account link
$(".account").mouseup(function()
{
return false
});


//Document Click
$(document).mouseup(function()
{
$(".submenu").hide();
$(".account").attr('id', '');
});
});
</script>
<style type="text/css">
.drop1btn {
    border: none;
    cursor: pointer;
	color: #595959;
    display: block;
    text-decoration: none;
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    font-size: 11px;
    line-height: 20px;
    font-weight: bold;
    background-color: #FFFFFF;
    background-image: url(top_nav_btn_bg.gif);
    background-repeat: repeat-x;
    background-position: 0 bottom;
    padding: 7px 5px;
    margin: 0px;
	
width:80px !important;
}

/* The container <div> - needed to position the dropdown content */
.dropdown1 {
    position: relative;
    display: inline-block;
	
}

/* Dropdown Content (Hidden by Default) */
.dropdown-content {
    display: none;
    position: absolute;
	width:120px;
    background-color: #f9f9f9;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
}

/* Links inside the dropdown */
.dropdown-content a {
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

/* Change color of dropdown links on hover */
.dropdown-content a:hover {
    background-color: #FFFFFF !important;
    background-image: url(top_nav_btn_bg.gif) !important;
    background-repeat: repeat-x !important;
    background-position: 0 bottom; !important}

/* Show the dropdown menu on hover */
.dropdown:hover .dropdown-content {
    display: block;
}

/* Change the background color of the dropdown button when the dropdown content is shown */
.dropdown:hover .dropbtn {
    background-color: #3e8e41;
}
</style>
<link href="css/drop.css" rel="stylesheet" type="text/css" />
<link href="msg.css" rel="stylesheet" type="text/css" />
<div style=" background: url(top_bg_pra.jpg) repeat-x 0 0 !important; display:block; height:36px;">
<div id="topNav"">
<ul>
    
<li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>
<li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>
<li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>
<li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>
<li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>
<li><a href="golf_lead.php" <?php if($_SESSION['this_page']=='golf_lead.php')echo 'class="hover"'?>><b>Golf Lead</b></a></li> 

 <li><a href="Logout.php"><b>Logout</b></a></li>
 
 
 </ul>
</div>
</div>