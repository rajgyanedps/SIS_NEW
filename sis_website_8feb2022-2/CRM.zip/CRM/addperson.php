<?php
include("connection.php");
session_start();
if (isset($_POST['submit']))

{
$sql="INSERT INTO addperson(school_id,joined,surname,name,desig,otherdesig,phonecode,phoneno,mobno,faxcode,faxno,email) VALUES ('".$_POST['school_id']."',now(),'".$_POST['surname']."','".$_POST['name']."','".$_POST['desig']."','".$_POST['otherdesig']."','".$_POST['phonecode']."','".$_POST['phoneno']."','".$_POST['mobno']."','".$_POST['faxcode']."','".$_POST['faxno']."','".$_POST['email']."')";

$result=mysql_query($sql) or die(mysql_error());

if ($_SESSION['user_type']=="Project Manager")
{
header("Location: pmhome.php?msg=Contact Person Added Successfully......");
}
else if ($_SESSION['user_type']=="Tele Caller")
{
header("Location: tchome.php?msg=Contact Person Added Successfully......");
}
else
{
header("Location: adminhome.php?msg=Contact Person Added Successfully......");
}
}

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Add Contact Person</title>
<script type="text/javascript">
function showhide(val)
{
if(val.value=='OTHER')
document.getElementById('divnb').style.display='block';
else
document.getElementById('divnb').style.display='none';
}
</script>

<script type="text/javascript">
function ValidateForm()
{
// checking surname field
	  
	  if (document.contactperson.surname.value=="")
	 {
		alert("The Surname is blank. \nPlease select the surname field in the combo box.");
        document.contactperson.surname.focus();		
        return false;
      }		
// checking name field
      if (document.contactperson.name.value=="")
	{
		alert("The Name field is blank. \nPlease enter name in the text box.");
		document.contactperson.name.focus();
		return false;
      }	  	    
	  
//checking alphabetic values in name

    var iChars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ';
    for (i = 0; i < document.contactperson.name.value.length; i++) {
      if (iChars.indexOf(document.contactperson.name.value.charAt(i)) == -1) {
         alert('Please enter letters only in Name field');
         document.contactperson.name.focus();
         return false;
      }
      }	
// checking designation field	  
if (document.contactperson.desig.value=="")
	 {
		alert("The designation is blank. \nPlease select the designation field in the combo box.");
        document.contactperson.desig.focus();		
        return false;
      }	
  
// checking otherdesig in designation (OTHER)
    if (document.contactperson.desig.value=="OTHER")
	   {
	   	  if (document.contactperson.otherdesig.value=="")
	 {
		alert("The other designation field is blank. \nPlease enter the other designation field in the text box.");
        document.contactperson.otherdesig.focus();		
        return false;
      }		
	  }	  
// checking phonecode field
	  
	  if (document.contactperson.phonecode.value=="")
	 {
		alert("The Phone Code is blank. \nPlease enter the Phone Code field in the text box.");
        document.contactperson.phonecode.focus();		
        return false;
      }
	  
//checking numeric value in phonecode
     var n = document.contactperson.phonecode.value;
    if(isNaN(n) == true) {
        alert('Your entry is not a numberic value in code no. field, Please try again');
        document.contactperson.phonecode.focus();
        return false;
    }	  
// checking phoneno field
	  
	  if (document.contactperson.phoneno.value=="")
	 {
		alert("The Phone No. is blank. \nPlease enter the Phone No. field in the text box.");
        document.contactperson.phoneno.focus();		
        return false;
      }
	  
//checking numeric value in phoneno
     var n = document.contactperson.phoneno.value;
    if(isNaN(n) == true) {
        alert('Your entry is not a numberic value in phone no. field, Please try again');
        document.contactperson.phoneno.focus();
        return false;
    }	  	
// checking mobno field
	  
	  if (document.contactperson.mobno.value=="")
	 {
		alert("The Mob. No. is blank. \nPlease enter the Mob. No. field in the text box.");
        document.contactperson.mobno.focus();		
        return false;
      }
	  
//checking numeric value in mobno
     var n = document.contactperson.mobno.value;
    if(isNaN(n) == true) {
        alert('Your entry is not a numberic value in mob. no. field, Please try again');
        document.contactperson.mobno.focus();
        return false;
    }	  		  
//checking numeric value in faxcode
     var n = document.contactperson.faxcode.value;
    if(isNaN(n) == true) {
        alert('Your entry is not a numberic value in code no. field, Please try again');
        document.contactperson.faxcode.focus();
        return false;
    }	  
//checking numeric value in faxno
     var n = document.contactperson.faxno.value;
    if(isNaN(n) == true) {
        alert('Your entry is not a numberic value in fax no. field, Please try again');
        document.contactperson.faxno.focus();
        return false;
    }	  	  		
	  }
</script>
<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />
</head>

<body>
<?php
include("header.php");
?>
<br /><br />
<form name="contactperson" method="post" action="addperson.php" onsubmit="return ValidateForm();">
<table border="0" align="center" bgcolor="#f3f7fd" cellpadding="8" cellspacing="0" style="border:solid 1px #71befb;"> 
<tr>
  <td background="butbg.gif" height="10px" style="border-bottom:solid 1px #71befb; font-size:13px; color:#064582;">&nbsp;&nbsp;<b>Add Contact Person</b></td>
</tr>



<tr><td>
<table width="464" border="0" align="center" cellpadding="4" cellspacing="0" style="font-size:13px">

<tr><td colspan="3"></td></tr>
<tr>
<input type="hidden" name ="school_id" value="<?= $_GET['school_id']?>">
<td>Surname</td>
<td>:</td>
<td><select name="surname" style="height:20px; border:solid 1px #92cdfd;font-size:13px; color:#0a5095;background-color:#ffffff;">
<option value="">--Select--</option>
<option value="Mr.">Mr.</option>
<option value="Mrs.">Mrs.</option>
<option value="Miss">Miss</option>
<option value="Dr.">Dr.</option>
<option value="Col.">Col.</option>
<option value="Sis.">Sis.</option>
<option value="Fr.">Fr.</option>
</select>&nbsp;<font color="#FF0000"><b>*</b></font></td>
</tr>
<tr><td>Name</td>
<td>:</td>
<td><input type="text" name="name" size="40" style="height:18px; border:solid 1px #92cdfd;font-size:13px; color:#0a5095;background-color:#ffffff;" />&nbsp;<font color="#FF0000"><b>*</b></font></td>
</tr>
<tr><td>Designation</td>
<td>:</td>
<td><select name="desig" onchange="showhide(this)" style="height:20px; border:solid 1px #92cdfd;font-size:13px; color:#0a5095;background-color:#ffffff;">
<option value="">--Select--</option>
<option value="Chairman">Chairman</option>
<option value="Principal">Principal</option>
<option value="Owner">Owner</option>
<option value="Vice Principal">Vice Principal</option>
<option value="Management Member">Management Member</option>
<option value="School Coordinator">School Coordinator</option>
<option value="Senior Teacher">Senior Teacher</option>
<option value="Teacher">Teacher</option>
<option value="OTHER">OTHER</option>
</select>&nbsp;<font color="#FF0000"><b>*</b></font></td></tr>
<tr><td>Other Designation</td>
<td>:</td>
<td><div id="divnb" style="display:none"><input type="text" name="otherdesig" size="40" />&nbsp;<font color="#FF0000"><b>*</b></font></div></td></tr>
<tr><td>Code No.</td>
<td>:</td>
<td><input type="text" name="phonecode" size="40" maxlength="5"  style="height:18px; border:solid 1px #92cdfd;font-size:13px; color:#0a5095;background-color:#ffffff;" />&nbsp;<font color="#FF0000"><b>*</b></font></td></tr>
<tr><td>Phone No.</td>
<td>:</td>
<td><input type="text" name="phoneno" size="40" maxlength="8"  style="height:18px; border:solid 1px #92cdfd;font-size:13px; color:#0a5095;background-color:#ffffff;" />&nbsp;<font color="#FF0000"><b>*</b></font></td>
</tr>
<tr><td>Mobile No.</td>
<td>:</td>
<td><input type="text" name="mobno" size="40" maxlength="11"  style="height:18px; border:solid 1px #92cdfd;font-size:13px; color:#0a5095;background-color:#ffffff;" />&nbsp;<font color="#FF0000"><b>*</b></font></td></tr>
<tr><td>Code No.</td>
<td>:</td>
<td><input type="text" name="faxcode" size="40" maxlength="5"  style="height:18px; border:solid 1px #92cdfd;font-size:13px; color:#0a5095;background-color:#ffffff;" /></td></tr>
<tr><td>Fax No.</td>
<td>:</td>
<td><input type="text" name="faxno" size="40" maxlength="8"  style="height:18px; border:solid 1px #92cdfd;font-size:13px; color:#0a5095;background-color:#ffffff;" /></td></tr>
<tr><td>Email Id</td>
<td>:</td>
<td><input type="text" name="email" size="40"  style="height:18px; border:solid 1px #92cdfd;font-size:13px; color:#0a5095;background-color:#ffffff;" /></td></tr>
<tr><td colspan="3"></td></tr>
<tr><td colspan="3"></td></tr><tr><td colspan="3"></td></tr><tr><td colspan="3"></td></tr>
<tr><td align="center" colspan="3"><input type="submit" name="submit" value="Submit" />
</td></tr>
<tr><td colspan="4"></td></tr>
</table>
</td></tr></table>

<br /><br />
<table width="95%" border="0" align="center" cellpadding="5" cellspacing="0" style="font-size:13px">
<tr bgcolor="#999999" align="center">

      <td align="left" background="footerbg.jpg" class="whitetxt11" width="5%">S.No.</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="15%">Date & Time</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="25%">Person</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="15%">Designation</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="10%">Phone No.</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="10%">Mob. No.</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="20%">Email Id </a></td>
      </tr>
<?php
$sql_cust = "SELECT * FROM addperson WHERE school_id='".$_GET['school_id']."' order by joined asc";
$result = mysql_query($sql_cust);
$count = 0;
while($row = mysql_fetch_array($result))
{
	$count++;
?>
<tr>
        <td valign="top" width="5%"><? echo $count;?>.</td>
             <td width="15%"><?php echo $row['joined'];?></td>
                 <td width="25%"><?php echo $row['name'];?></td>
                     <td width="15%"><?php echo $row['desig'];?></td>
                         <td width="10%"><?php echo $row['phonecode']." ".$row['phoneno'];?></td>
                             <td width="10%"><?php echo $row['mobno'];?></td>
                                 <td width="20%"><?php echo $row['email'];?></td>
                                     
    </tr>
    <?
}
?>
</table>
</form>
</body>
</html>
