<?php
ob_start();
session_start();
include("connection.php");
if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='Project Manager' && $_SESSION['user_type']!='Tele Caller')
//if (!isset($_SESSION[myusername]))
{
 header("Location: index.php");
}
?>
<?
$_SESSION['this_page']='userinfo.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Member Information</title>
<link href="msg.css" rel="stylesheet" type="text/css">
<script type="text/javascript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php
include("header.php");
?>
<br />
<?php
$sql_cust = "select * from members WHERE username!='Open Data' and username!='del_school' order by emp_name";

		$result	= mysql_query($sql_cust) or die(mysql_error());
		$num_rows= mysql_num_rows($result);
		?>
<div style="float:left; width:50%;line-height:20px; margin-bottom:10px;"> <a style="margin-left:10px" href="profile.php" <?php if($_SESSION['this_page']=='userinfo.php')echo 'class="hover"'?>><font size="3px"><b>Add New User</b></font></a></div>
<div align="right" style="float:left;width:48%;line-height:20px"><b>Records Found :</b>&nbsp;<strong><? echo $num_rows?></strong></div>
<div style="float:left; width:100%">
  <table align="center" width="100%">
    <tr>
      <td width="100%"><form action="userinfo.php" method="get" name="userinfo">
          <table width="100%" border="0" align="center" cellpadding="5" cellspacing="1" bgcolor="#81cafd" style="font-size:11px">
          <tr height="20" bgcolor="#81cafd" align="center">
              <td background="footerbg.jpg" class="whitetxt11"><div align="left;">S.No.</div></td>
              <td background="footerbg.jpg" class="whitetxt11"><div align="left">User Name</div></td>
              
              <td background="footerbg.jpg" class="whitetxt11"><div align="left">Name</div></td>
              <td background="footerbg.jpg" class="whitetxt11"><div align="left">Email Id</div></td>
              <td background="footerbg.jpg" class="whitetxt11"><div align="left">User Type</div></td>
              <td background="footerbg.jpg" class="whitetxt11"><div align="center">Status-wise Report</div></td>
              <td background="footerbg.jpg" class="whitetxt11"><div align="left">Total Contact</div></td>
              <td background="footerbg.jpg" class="whitetxt11"><div align="left">Total Student</div></td>
              <td background="footerbg.jpg" class="whitetxt11"><div align="left">Last Contact</div></td>
              <td background="footerbg.jpg" class="whitetxt11"><div align="left">Update Profile</div></td>
            </tr>
            
            <? 
	     
		$count = 0;
	
while($res=mysql_fetch_array($result))
{

if($acol) {
	           $x = "bgcolor='#e9f5ff'";
	          } else {
	            $x = "bgcolor='#d8effe'";
 	          }
			  $acol=!$acol;
			  $count++;
?>
            <tr <?=$x;?> align="left">
              <td><? echo $count;?>.</td>
              <td><a href="#" onClick="MM_openBrWindow('userdetail.php?emp_id=<? echo $res['emp_id'];?>','UserInfo','width=700,height=230')"><strong><?php echo $res['username'];?></strong></a></td>
              
              <td><?php echo $res['emp_name'];?></td>
              <td><?php echo $res['email'];?></td>
              <td><?php echo $res['user_type'];?></td>
              <td align="center"><a href="empreport.php?stat=Admission&amp;emp_id=<? echo $res['emp_id'];?>"><img src="image/admission.png" border="0" name="Admission" align="center" alt="Click here to view Admission report"/></a>&nbsp;<a href="empreport.php?stat=Paid&amp;emp_id=<? echo $res['emp_id'];?>"><img src="image/paddy-smiley26.gif" border="0" name="paid_sign" align="center" alt="Click here to view Paid report"/></a>&nbsp; <a href="empreport.php?stat=Positive&amp;emp_id=<? echo $res['emp_id'];?>"> <img src="image/green.gif" border="0" name="plus_sign" alt="Click here to view positive report" align="center"/></a>&nbsp; <a href="empreport.php?stat=Moderate&amp;emp_id=<? echo $res['emp_id'];?>"><img src="image/mod.gif" border="0" name="minus_sign" align="center" alt="Click here to view moderate report"/></a>&nbsp; <a href="empreport.php?stat=Negative&amp;emp_id=<? echo $res['emp_id'];?>"><img src="image/red.gif" border="0" name="minus_sign" alt="Click here to view negative report" align="center"/></a> 
 &nbsp; <a href="empreport.php?stat=NoContact&amp;emp_id=<? echo $res['emp_id'];?>"><img src="image/nocontact.png" border="0" name="minus_sign" alt="Click here to view No Contact report" align="center"/></a> 
 
 &nbsp; <a href="empreport.php?stat=Session2013-14&amp;emp_id=<? echo $res['emp_id'];?>"><img src="image/2013-14.jpg.png" border="0" name="minus_sign" alt="Click here to view Session(2013-14) report" align="center"/></a>              
              
              
              
              </td>
              <td><a href="totalcallreport.php?emp_id=<? echo $res['emp_id'];?>">Total Contact Student</a></td>
              <td><a href="schoolreport.php?emp_id=<? echo $res['emp_id'];?>">Total Student</a></td>
              <td><a href="individualreport.php?emp_id=<? echo $res['emp_id'];?>">Last Contact Student</a></td>
              <td><a href="show.php?emp_id=<? echo $res['emp_id'];?>">Edit</a></td>
            </tr>
            <? }?>
          </table>
          <table align="center" width="100%">
             <tr>
              <td><img src="image/spacer.gif" height="5" /></td>
            </tr>
            <tr>
              <td class="footer" width="100%" >&copy; 2009 TeacherSITY. All rights reserved</td>
            </tr>
          </table>
        </form></td>
    </tr>
  </table>
</div>
</body>
</html>
