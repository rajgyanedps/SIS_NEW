<?php
    ob_start();
    session_start();
	error_reporting(0);
    include("connection.php");
    date_default_timezone_set('Asia/Calcutta');
    $DATE=date('Y-m-d H:i:s');
    if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='School Login' && $_SESSION['user_type']!='Tele Caller')
    //if (!isset($_SESSION[myusername]))
	{
     header("Location: index.php");
    }
     if(isset($_POST['walkin_submit'])){
		$walkin_date = date('Y-m-d',strtotime($_POST['walkin_date']));
		$sql_walkin = "INSERT INTO walkins (stud_id, expected_date, expected_time, walkin_status) VALUES('".$_POST['stud_id']."','$walkin_date','".$_POST['walkintime']."',0)";
		$res_walkin = mysql_query($sql_walkin) or die(mysql_error());
		header("Location: 11.php?stud_id=".$_POST['stud_id']."&walk=Expected Walkin Added Successfully.....");
    }
    if (isset($_POST['addfees'])){
		$fee_status=$_POST['fee_status'];
			if($fee_status=='0'){
			$fee_amt = '0';
			}else
				{
				$fee_amt = $_POST['fee_box'];
				}
		$sql = "UPDATE student SET fee_status='".$_POST['fee_status']."', amount='$fee_amt' WHERE stud_id ='".$_POST['stud_id']."'";
			$result=mysql_query($sql) or die(mysql_error());
			if($_POST['fee_status']==1){
			 header("Location: 11.php?stud_id=".$_POST['stud_id']."&msg=Student Fees Added Successfully......");
			}else
		     {
		      header("Location: 11.php?stud_id=".$_POST['stud_id']."&msg=");
		     }
     } 
	if (isset($_POST['submit2'])) {
		$remarkdate = $_POST['remarkdate'];
		$dd = explode('-',$remarkdate);
		$upd_remarkdate = $dd[2].'-'.$dd[1].'-'.$dd[0];
		$sql="INSERT INTO contact(stud_id,joined,status,remarkdate,remarktime,followup,other,nextstep,schoolnextstep) VALUES ('".$_POST['stud_id']."','".$DATE."','".$_POST['status']."','$upd_remarkdate','".$_POST['remarktime']."','".$_POST['followup']."','".$_POST['other']."','".$_POST['nextstep']."','".$_POST['schoolother']."')";
		$result=mysql_query($sql) or die(mysql_error()); 
		$a="UPDATE student SET contact_date='".$DATE."', status='".$_POST['status']."',followup='".$_POST['followup']."',remarkdate='$upd_remarkdate' WHERE stud_id='".$_GET['stud_id']."'";
		$x=mysql_query($a) or die(mysql_error());
		header("Location: 11.php?stud_id=".$_GET['stud_id']."&msg=Contact Details Added Successfully......");
	}
    
    if (isset($_POST['submit4'])){
		$sql="INSERT INTO addammount(stud_id,joined,totalamm,advanceamm,balanceamm,senddate,duedate,chequeno,bankname,city) VALUES ('".$_POST['stud_id']."', '".$DATE."','".$_POST['totalamm']."','".$_POST['advanceamm']."','".$_POST['balanceamm']."','".$_POST['senddate']."','".$_POST['duedate']."','".$_POST['chequeno']."','".$_POST['bankname']."','".$_POST['city']."')";
		$result=mysql_query($sql) or die(mysql_error());
		$q="DELETE FROM last_totalamm WHERE stud_id='".$_GET['stud_id']."'";
		$d=mysql_query($q) or die(mysql_error());
		$a="INSERT INTO last_totalamm(stud_id,totalamm) VALUES ('".$_GET['stud_id']."','".$_POST['totalamm']."')";
		$x=mysql_query($a) or die(mysql_error());
        //update other detail
		header("Location: 11.php?stud_id=".$_GET['stud_id']."&msg=Payment Details Added Successfully......");
    }
    
    if (isset($_POST['submit'])){
        $dob=$_POST['dd'].'/'.$_POST['mm'].'/'.$_POST['yy'];
		$sql="UPDATE student SET stud_name='".$_POST['stud_name']."',add1='".$_POST['add1']."', add2='".$_POST['add2']."', city='".$_POST['city']."', phone_code='".$_POST['phone_code']."',phone_no='".$_POST['phone_no']."',email='".$_POST['email']."', state='".$_POST['state']."', pin='".$_POST['pin']."', course='".$_POST['course']."', stream='$stream', percentage='".$_POST['percentage']."',
		information_source='".$_POST['information_source']."',Current_School='".$_POST['Current_School']."',Percentage='".$_POST['Percentage']."',dob='".$dob."',Gender1='".$_POST['Gender']."',Sports='".$_POST['Sports']."',othe_Sports='".$_POST['sports']."',Activity='".$_POST['Activity']."',Other_Activity='".$_POST['activity']."',Father_occu='".$_POST['Father_occu']."',Mother_occu='".$_POST['Mother_occu']."',Brother_sibl='".$_POST['Brother_sibl']."',Sister_sibl='".$_POST['Sister_sibl']."',why_bor_school='".$_POST['why_bor_school']."' WHERE stud_id ='".$_POST['stud_id']."'";
        $result1=mysql_query($sql) or die(mysql_error());
		header("Location: 11.php?stud_id=".$_POST['stud_id']."&msg=Record Updated Successfully......");
    }
    
    ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Student Complete Dashboard</title>
        <link rel="shortcut icon" href="http://www.selaqui.org/images/favicon.ico" type="image/x-icon">
        <link rel="stylesheet" type="text/css" href="calendar-blue.css">
        <script type="text/javascript" src="calendar.js"></script>
        <script type="text/javascript" src="calendar-en.js"></script>
        <script type="text/javascript" src="calendar-setup.js"></script>
        <script language="javascript1.2" src="tabber.js"></script>
        <link rel="stylesheet" type="text/css" href="jquery.fancybox/jquery.fancybox.css" media="screen" />
        <link href="css/admin.css" rel="stylesheet" type="text/css">
        <script type="text/javascript" src="jquery.fancybox/jquery-1.3.2.min.js"></script>
        <script type="text/javascript" src="jquery.fancybox/jquery.easing.1.3.js"></script>
        <script type="text/javascript" src="jquery.fancybox/jquery.fancybox-1.2.1.pack.js"></script>
        <script type="text/javascript">
            $(document).ready(function() {
                         var x= $("#Activity").val();
                          if(x=="Other"){
                           
                           $("#activity").css("display","block");
                         
                          }
                          
                           var xx= $("#Sports").val();
                          if(xx=="Other"){
                           
                           $("#sports").css("display","block");
                          // showactivity(this) ;    
                          }
            
            
            //                                      showsports(this);
                     
            
            				  $("a.prnc").fancybox({ 'hideOnContentClick': false ,
            				  'overlayShow':true  ,
            				  'frameWidth':510 ,
            				  'frameHeight':360,
            				  'overlayOpacity':0.7}); 
            
            
            });
            	$(document).ready(function() {
                         
            				  $("a.edit").fancybox({ 'hideOnContentClick': false ,
            				  'overlayShow':true  ,
            				  'frameWidth':500 ,
            				  'frameHeight':282,
            				  'overlayOpacity':0.7}); 
            
            
            });
            
            $(document).ready(function() {
            
            				  $("a.del").fancybox({ 'hideOnContentClick': false ,
            				  'overlayShow':true  ,
            				  'frameWidth':530 ,
            				  'frameHeight':410,
            				  'overlayOpacity':0.7}); 
                                                
            
            
            });
            
        </script>
        <script type="text/javascript">
            /*fees_validation()
            {
            
            	if (document.addfee.fee_status.value=="")
            	 {
            		alert("The Fee Status is blank. \nPlease select the status field in the combo box.");
                    document.addfee.fee_status.focus();		
                    return false;
                  }	
            	  return true;
            
            }*/
            
            
            function showhide5(val)
            {
            if(val.value=='other')
            document.getElementById('divnb3').style.display='block';
            else
            document.getElementById('divnb3').style.display='none';
            }
        </script>
        <script type="text/javascript">
            function showhide1(val)
            {
            if(val.value=='Other')
            document.getElementById('divnb2').style.display='block';
            else
            document.getElementById('divnb2').style.display='none';
            }
        </script>
        <script type="text/javascript">
            function showhide(id)
            {
            	var obje1=document.getElementById('working');
            	
            	if(obje1.value=="Other")
            	{
            	document.getElementById('otherbox').style.visibility = 'visible'; 
            	}
            	else
            	{
            	document.getElementById('otherbox').style.visibility = 'hidden'; 
            	}
            	}
            
            	
            function showhide2(val)
            {
            if(val)
            document.getElementById('assess').style.display='block';
            else
            document.getElementById('assess').style.display='none';
            }
            
            
            
            
            
            
            
            function fee_boxshow()
            {
            if(document.addfee.fee_status.value=="1")
            		{
            			document.addfee.fee_box.style.visibility = 'visible';
            		}
            	else
            		{
            			document.addfee.fee_box.style.visibility = 'hidden'; 
            		}
            }
            
            
            
            
            
            function showhide10(val)
            {
            if(val)
            document.getElementById('det').style.display='block';
            else
            document.getElementById('det').style.display='none';
            }
            
            function showhide3()
            {
            
            document.getElementById('dnewperson').style.display='block';
            }
        </script>
        <script type="text/javascript">
            function showhide4(val)
            {
            if(val.value=='OTHER')
            document.getElementById('divw').style.display='block';
            else
            document.getElementById('divw').style.display='none';
            }
            
            
            function showsports(val)
            {
                if(val.value=='Other')
            
            document.getElementById('sports').style.display='block';
            else
            document.getElementById('sports').style.display='none';
                 
            }
            
            function showactivity(val)
            {
                    
                        if(val.value=='Other')
            { 
            document.getElementById('activity').style.display='block';
            //document.getElementById('activity').value='dsfsdf';
            }
            else{
            document.getElementById('activity').style.display='none';
            }        
                      
            }
        </script>
        <script type="text/javascript">
            function ValidateForm4()
            {
            // checking status field	  
            if (document.contactdetails.status.value=="")
            	 {
            		alert("The Status is blank. \nPlease select the status field in the combo box.");
                    document.contactdetails.status.focus();		
                    return false;
                  }	
            // checking followup field	  
            if (document.contactdetails.followup.value=="")
            	 {
            		alert("The Followup is blank. \nPlease select the followup field in the combo box.");
                    document.contactdetails.followup.focus();		
                    return false;
                  }		  
            // checking other in followup (other)
                if (document.contactdetails.followup.value=="Other")
            	   {
            	   	  if (document.contactdetails.other.value=="")
            	 {
            		alert("The other field is blank. \nPlease enter the other followup field in the text box.");
                    document.contactdetails.other.focus();		
                    return false;
                  }		
            	  }	  
            // checking remark date field
             if (document.contactdetails.followup.value!="Other")
            	   {
                  if (document.contactdetails.remarkdate.value=="")
            	{
            		alert("The remark date field is blank. \nPlease enter remark date in the text box.");
            		document.contactdetails.remarkdate.focus();
            		return false;
                  }	 
            // checking remark time field
                  if (document.contactdetails.remarktime.value=="")
            	{
            		alert("The Remark time field is blank. \nPlease enter remark time in the text box.");
            		document.contactdetails.remarktime.focus();
            		return false;
                  }	  	}
            	  // checking other in schoolnextstep (other)
                if (document.contactdetails.nextstep.value=="other")
            	   {
            	   	  if (document.contactdetails.schoolother.value=="")
            	 {
            		alert("The other field is blank. \nPlease enter the other school next step field in the text box.");
                    document.contactdetails.schoolother.focus();		
                    return false;
                  }		
            	  }	   	    	      	  
            	  }
        </script>
        <script type="text/javascript">
            function Validate_walkins()
            {
            
                if (document.walkin_frm.walkin_date.value=="")
            	{
            		alert("The Walkin Date field is blank. \nPlease enter Walkin Date in the text box.");
            		document.walkin_frm.walkin_date.focus();
            		return false;
                  }	 
               if (document.walkin_frm.walkintime.value=="")
            	{
            		alert("The Walkin time field is blank. \nPlease enter Walkin time in the text box.");
            		document.walkin_frm.walkintime.focus();
            		return false;
                  }	  	
            	 	    	      	  
            }
        </script>
        <script type="text/javascript">
            function ValidateForm2()
            {
            // checking workingorg. field
            	  
            	  if (document.assessment.working.value=="")
            	 {
            		alert("The Working Org. is blank. \nPlease select the working field in the combo box.");
                    document.assessment.working.focus();		
                    return false;
                  }		
            // checking nameorg field (if Yes)
                  
                if (document.assessment.working.value=="Other")
            	   {
            	   	  if (document.assessment.other_working.value=="")
            	 {
            		alert("The Name of the org. field is blank. \nPlease enter the name of the org. field in the text box.");
                    document.assessment.other_working.focus();		
                    return false;
                  }		
            	  }	 
            
                  }
                 
        </script>
        <script type="text/javascript">
            function ValidateForm1()
            {
            // checking datetest field
                  if (document.participation.datetest.value=="")
            	{
            		alert("The date of test field is blank. \nPlease enter date of test in the text box.");
            		document.participation.datetest.focus();
            		return false;
                  }	 
            // checking expstudent field
            	  
            	  if (document.participation.expstudent.value=="")
            	 {
            		alert("The Expected Student is blank. \nPlease enter the Expected Student field in the text box.");
                    document.participation.expstudent.focus();		
                    return false;
                  }
            	  
            //checking numeric value in expstudent
                 var n = document.participation.expstudent.value;
                if(isNaN(n) == true) {
                    alert('Your entry is not a numberic value in expected student field, Please try again');
                    document.participation.expstudent.focus();
                    return false;
                }	  	
            // checking exptest field
            	  
            	  if (document.participation.exptest.value=="")
            	 {
            		alert("The Expected Test is blank. \nPlease enter the Expected Test field in the text box.");
                    document.participation.exptest.focus();		
                    return false;
                  }
            	  
            //checking numeric value in exptest
                 var n = document.participation.exptest.value;
                if(isNaN(n) == true) {
                    alert('Your entry is not a numberic value in expected test field, Please try again');
                    document.participation.exptest.focus();
                    return false;
                }	  
            	// checking expstudent field
            	  
            	  if (document.participation.actstudent.value=="")
            	 {
            		alert("The Actual Student is blank. \nPlease enter the Actual Student field in the text box.");
                    document.participation.actstudent.focus();		
                    return false;
                  }
            	  
            //checking numeric value in actstudent
                 var n = document.participation.actstudent.value;
                if(isNaN(n) == true) {
                    alert('Your entry is not a numberic value in actual student field, Please try again');
                    document.participation.actstudent.focus();
                    return false;
                }	  
            	// checking exptest field
            	  
            	  if (document.participation.acttest.value=="")
            	 {
            		alert("The Actual Test is blank. \nPlease enter the Actual Test field in the text box.");
                    document.participation.acttest.focus();		
                    return false;
                  }	  	
            //checking numeric value in acttest
                 var n = document.participation.acttest.value;
                if(isNaN(n) == true) {
                    alert('Your entry is not a numberic value in actual test field, Please try again');
                    document.participation.acttest.focus();
                    return false;
                }	  	  						   	
            	  }
        </script>
        <script type="text/javascript">
            function ValidateForm3()
            {
            // checking surname field
            	  
            	  if (document.contactperson.surname.value=="")
            	 {
            		alert("The Surname is blank. \nPlease select the surname field in the combo box.");
                    document.contactperson.surname.focus();		
                    return false;
                  }		
            // checking name field
                  if (document.contactperson.name2.value=="")
            	{
            		alert("The Name field is blank. \nPlease enter name in the text box.");
            		document.contactperson.name2.focus();
            		return false;
                  }	  	    
            	  
            //checking alphabetic values in name
            
                var iChars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ';
                for (i = 0; i < document.contactperson.name2.value.length; i++) {
                  if (iChars.indexOf(document.contactperson.name2.value.charAt(i)) == -1) {
                     alert('Please enter letters only in Name field');
                     document.contactperson.name2.focus();
                     return false;
                  }
                  }	
            // checking designation field	  
            if (document.contactperson.desig.value=="")
            	 {
            		alert("The designation is blank. \nPlease select the designation field in the combo box.");
                    document.contactperson.desig.focus();		
                    return false;
                  }	
              
            // checking otherdesig in designation (OTHER)
                if (document.contactperson.desig.value=="OTHER")
            	   {
            	   	  if (document.contactperson.otherdesig.value=="")
            	 {
            		alert("The other designation field is blank. \nPlease enter the other designation field in the text box.");
                    document.contactperson.otherdesig.focus();		
                    return false;
                  }		
            	  }	  
            
            //checking numeric value in phonecode
                 var n = document.contactperson.phonecode.value;
                if(isNaN(n) == true) {
                    alert('Your entry is not a numberic value in code no. field, Please try again');
                    document.contactperson.phonecode.focus();
                    return false;
                }	  
            
            //checking numeric value in phoneno
                 var n = document.contactperson.phoneno.value;
                if(isNaN(n) == true) {
                    alert('Your entry is not a numberic value in phone no. field, Please try again');
                    document.contactperson.phoneno.focus();
                    return false;
                }	  	
            
            //checking numeric value in mobno
                 var n = document.contactperson.mobno.value;
                if(isNaN(n) == true) {
                    alert('Your entry is not a numberic value in mob. no. field, Please try again');
                    document.contactperson.mobno.focus();
                    return false;
                }	  		  
            //checking numeric value in faxcode
                 var n = document.contactperson.faxcode.value;
                if(isNaN(n) == true) {
                    alert('Your entry is not a numberic value in code no. field, Please try again');
                    document.contactperson.faxcode.focus();
                    return false;
                }	  
            //checking numeric value in faxno
                 var n = document.contactperson.faxno.value;
                if(isNaN(n) == true) {
                    alert('Your entry is not a numberic value in fax no. field, Please try again');
                    document.contactperson.faxno.focus();
                    return false;
                }	  	  		
            	  }
        </script>
        <script language="javascript">
            function calc()
            {
            var a = document.addammount.advanceamm.value;
            var t = document.addammount.totalamm.value;
            var p = document.addammount.alreadypaid.value;
            document.addammount.balanceamm.value = (t-p)-a;
            
            }
            
            
            
            function ValidateForm()
            {
            // checking advanceammount field
            	  
            	  if (document.addammount.advanceamm.value=="")
            	 {
            		alert("The Advance Ammount is blank. \nPlease enter the Advance Ammount field in the text box.");
                    document.addammount.advanceamm.focus();		
                    return false;
                  }
            	  
            //checking numeric value in advanceammount
                 var n = document.addammount.advanceamm.value;
                if(isNaN(n) == true) {
                    alert('Your entry is not a numberic value in advance ammount field, Please try again');
                    document.addammount.advanceamm.focus();
                    return false;
                }	
            // checking balanceammount field
            	  
            	  if (document.addammount.balanceamm.value=="")
            	 {
            		alert("The Balance Ammount is blank. \nPlease click the Balance button.");
                    document.addammount.balanceamm.focus();		
                    return false;
                  }	 
            // checking senddate field
            	  
            	  if (document.addammount.senddate.value=="")
            	 {
            		alert("The Send Date is blank. \nPlease click the calander button.");
                    document.addammount.senddate.focus();		
                    return false;
                  }	
            // checking duedate field
            	  
            	  if (document.addammount.duedate.value=="")
            	 {
            		alert("The Due Date is blank. \nPlease click the calander button.");
                    document.addammount.duedate.focus();		
                    return false;
                  }	
            // checking chequeno. field
            	  
            	  if (document.addammount.chequeno.value=="")
            	 {
            		alert("The Cheque No. is blank. \nPlease enter the cheque no. in the text box.");
                    document.addammount.chequeno.focus();		
                    return false;
                  }		
            // checking bankname field
            	  
            	  if (document.addammount.bankname.value=="")
            	 {
            		alert("The Bank Name is blank. \nPlease enter the bank name in the text box.");
                    document.addammount.bankname.focus();		
                    return false;
                  }		  	  
            // checking city field
            	  
            	  if (document.addammount.city.value=="")
            	 {
            		alert("The City is blank. \nPlease enter the city in the text box.");
                    document.addammount.city.focus();		
                    return false;
                  }			  		  	   		  
            }
            function MM_openBrWindow(theURL,winName,features) { //v2.0
              window.open(theURL,winName,features);
            }
            function MM_goToURL() { //v3.0
              var i, args=MM_goToURL.arguments; document.MM_returnValue = false;
              for (i=0; i<(args.length-1); i+=2) eval(args[i]+".location='"+args[i+1]+"'");
            }
        </script>
        <style type="text/css">
            <!--
                body {
                	font-family: Arial, Helvetica, sans-serif;
                	font-size: 12px;
                	background-color: #FFFFFF;
                	background-repeat: no-repeat;
                }
                a {
                	color: #333333;
                }
                td {
                	font-size: 11px;
                }
                input, select {
                	font-size: 12px;
                }
                -->
        </style>
        <link href="msg.css" rel="stylesheet" type="text/css" />
    </head>
    <body>
        <?php
            include("header.php");
            ?><br />
        <div align="center" class="msg">
            <?=$_GET['msg']; ?>
            <?=$_GET['walk']; ?>
        </div>
        <? if($_SESSION['user_type']=='Admin') {
            }else{?>
        <form action="var.php" method="post" style="margin:0;padding:0">
            <input type="hidden" name="stud_id" value="<?=$_GET['stud_id'] ?>" />
            <table width="725" align="left">
                <tr>
                    <td width="57">
                        <div align="left" style="margin-left:15px"><a href="Javascript:history.go(-2)"><img src="images/back11.gif" width="42" height="44" border="0" /></a></div>
                    </td>
                    <td width="226">&nbsp;</td>
                    <td width="119"><b>Lead Transfer To:</b></td>
                    <td width="39">
                        <select name="emp">
                            <?
                                $sql8 = "select emp_id, emp_name from members where user_type='Admin' order by emp_id";
                                $result8 = mysql_query($sql8);
                                while($row8 = mysql_fetch_row($result8)){
                            ?>
								<option value="<?=$row8[0];?>">
									<?=$row8[1];?>
								</option>
                            <?}?>
                        </select>
                    </td>
                    <td width="12">&nbsp;</td>
                    <td width="244"><input type="submit" name="submit5" value="Transfer" /></td>
                </tr>
            </table>
        </form>
        <? }?>
		<?php
			$query = "SELECT * FROM student where stud_id='".$_GET['stud_id']."'";
			$result=mysql_query($query) or die(mysql_error());
			$row=mysql_fetch_array($result);
		?>
        <br style="clear:both" />
        <table width="99%" align="center">
            <tr>
                <td><font size="5"><? echo $row['stud_name'] ?></font></td>
            </tr>
            <tr>
                <td width="45%" valign="top">
                    <form name="addfee" method="post" action="11.php" onsubmit="return fees_validation();">
                        <table width="100%" border="0" align="center" cellpadding="5" cellspacing="0" bgcolor="#f3f7fd" style="border:solid 1px #71befb;">
                            <tr>
                                <td background="butbg.gif" height="23px" colspan="3" style="border-bottom:solid 1px #71befb; font-size:13px; color:#064582;">&nbsp;&nbsp;<b>Edit Student</b></td>
                            </tr>
                            <tr>
                                <td width="9" valign="top">&nbsp;</td>
                                <input type="hidden" name ="stud_id" value="<?= $_GET['stud_id']?>" />
                                <td width="193" valign="top">
                                    <div>Student Name</div>
                                    <input type="text" name="stud_name" size="30" value="<? echo $row['stud_name'] ?>" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" />
                                    &nbsp;<font color="#FF0000"><b>*</b></font>
                                </td>
                                <td width="180" valign="top">
                                    <div>Admission for Class:</div>
										<select name="course" id="course"  style="border:solid 1px #61b5f8; background-color:#FFFFFF; width:180px; z-index:0">
											<option value="">--Select--</option>
											<!--<option value="V">V</option>-->
											<option value="V" <? if($row['course']=='V'){ echo "selected=selected";} ?>>V</option>
											<option value="VI" <? if($row['course']=='VI'){ echo "selected=selected";} ?>>VI</option>
											<option value="VII" <? if($row['course']=='VII'){ echo "selected=selected";} ?> >VII</option>
											<option value="VIII" <? if($row['course']=='VIII'){ echo "selected=selected";} ?> >VIII</option>
											<option value="IX" <? if($row['course']=='IX'){ echo "selected=selected";} ?> >IX</option>
											<option value="X" <? if($row['course']=='X'){ echo "selected=selected";} ?> >X</option>
											<option value="XI Science / Medical" <? if($row['course']=='XI Science / Medical'){ echo "selected=selected";} ?> >XI &shy; Science / Medical</option>
											<option value="XI Science / Non-Medical" <? if($row['course']=='XI Science / Non-Medical'){ echo "selected=selected";} ?> >XI &shy; Science / Non-Medical</option>
											<option value="XI Commerce" <? if($row['course']=='XI Commerce'){ echo "selected=selected";} ?> >XI &shy; Commerce</option>
											<option value="XI Humanities" <? if($row['course']=='XI Humanities'){ echo "selected=selected";} ?> >XI &shy; Humanities</option>
										</select>
                                    <font color="#FF0000"><b>*</b></font>
                                    <div id="course_pref" style="width:90%; float:left; z-index:1; margin-top:5px; <? if($row['course']=='B.Tech'){ ?> display:block; <? } else { ?> display:none; <? } ?>">
                                        <select name="btech_stream" id="btech_stream" style="width:160px; border:solid 1px #61b5f8; background-color:#FFFFFF;">
                                            <option value="">--Select Stream--</option>
                                            <option value="Mechanical" <? if($row['stream']=='Mechanical'){ echo "selected"; } ?>>Mechanical</option>
                                            <option value="Civil" <? if($row['stream']=='Civil'){ echo "selected"; } ?>>Civil</option>
                                            <option value="Electrical" <? if($row['stream']=='Electrical'){ echo "selected"; } ?>>Electrical</option>
                                            <option value="Electronics & Comm. Business" <? if($row['stream']=='Electronics & Comm. Business'){ echo "selected"; } ?>>Electronics & Comm. Business</option>
                                            <option value="Computer" <? if($row['stream']=='Computer'){ echo "selected"; } ?>>Computer</option>
                                        </select>
                                        &nbsp;<font color="#FF0000"><b>*</b></font>
                                    </div>
                                    <div id="course_pref1" style="width:90%; float:left; z-index:1000; margin-top:5px; <? if($row['course']=='MBA'){ ?> display:block; <? } else { ?> display:none; <? } ?>">
                                        <select name="mba_stream" id="mba_stream" style="width:160px; border:solid 1px #61b5f8; background-color:#FFFFFF;">
                                            <option value="">--Select Stream--</option>
                                            <option value="Financial" <? if($row['stream']=='Financial'){ echo "selected"; } ?>>Financial</option>
                                            <option value="HR" <? if($row['stream']=='HR'){ echo "selected"; } ?>>HR</option>
                                            <option value="IT" <? if($row['stream']=='IT'){ echo "selected"; } ?>>IT</option>
                                            <option value="Marketing" <? if($row['stream']=='Marketing'){ echo "selected"; } ?>>Marketing</option>
                                            <option value="International Business" <? if($row['stream']=='International Business'){ echo "selected"; } ?>>International Business</option>
                                        </select>
                                        &nbsp;<font color="#FF0000"><b>*</b></font>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>&nbsp;</td>
                                <td>
                                    <div>Email Id</div>
                                    <input type="text" name="email" id="email" value="<? echo $row['email'] ?>" size="30" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" />
                                </td>
                                <td>
                                    <div>Phone No.</div>
                                    <input type="text" name="phone_code" value="<? echo $row['phone_code'] ?>" id="phone_code" size="8" maxlength="8"  style="border:solid 1px #61b5f8; background-color:#FFFFFF; width:50px;" /> <input type="text" name="phone_no" size="20" value="<? 
                                        if($row['mobno']=='0')
                                        
                                        echo $row['phone_no'];
                                        else if($row['phone_no']=='')  echo  $row['mobno'];
                                            else  echo $row['phone_no'].'&nbsp;/&nbsp;'. $row['mobno'];
                                            ?>" maxlength="100"  style="border:solid 1px #61b5f8; background-color:#FFFFFF;" />
                                </td>
                            </tr>
                            <tr>
                                <td>&nbsp;</td>
                                <td>
                                    <div>Address1</div>
                                    <input type="text" name="add1" id="add1" size="30" value="<? echo $row['add1'] ?>" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" />
                                </td>
                                <td>
                                    <div>Address2</div>
                                    <input type="text" name="add2" id="add2" size="30" value="<? echo $row['add2'] ?>" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" />
                                </td>
                            </tr>
                            <tr>
                                <td>&nbsp;</td>
                                <td>
                                    <div>City</div>
                                    <input type="text" name="city" id="city" size="30" value="<? echo $row['city'] ?>" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" />
                                </td>
                                <td>
                                    <div>State</div>
                                    <input type="text" name="state" id="state" size="30" value="<? echo $row['state'] ?>" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" />
                                </td>
                            </tr>
                            <tr>
                                <td>&nbsp;</td>
                                <td>
                                    <div>Pin</div>
                                    <input type="text" name="pin" id="pin" size="30" maxlength="6" value="<? echo $row['pin'] ?>" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" />
                                </td>
                                <td>
                                    <div>Information Source</div>
                                    <select name="information_source"  style="border:solid 1px #61b5f8; background-color:#FFFFFF; width:180px">
                                        <option value="">--Select--</option>
                                        <option value="Google" <? if($row['information_source']=='Google'){ echo "selected"; } ?>>Google</option>
                                        <option value="Facebook" <? if($row['information_source']=='Facebook'){ echo "selected"; } ?>>Facebook</option>
                                        <option value="Referral" <? if($row['information_source']=='Referral'){ echo "selected"; } ?>>Referral</option>
                                        <option value="Seminar" <? if($row['information_source']=='Seminar'){ echo "selected"; } ?>>Seminar</option>
                                        <option value="Newspaper Article" <? if($row['information_source']=='Newspaper Article'){ echo "selected"; } ?>>Newspaper Article</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="3"></td>
                            </tr>
                            <tr>
                                <td  colspan="3" background="butbg.gif" height="10" style="border-bottom:solid 1px #71befb; font-size:13px; color:#064582;">&nbsp;&nbsp;<b>Others</b></td>
                            </tr>
                            <tr>
                                <td>&nbsp;</td>
                                <td>
                                    <div>Current School</div>
                                    <input type="text"  value="<?php echo  $row['Current_School']?>"name="Current_School" id="Current_School" size="30" value="" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" />
                                </td>
                                <td>
                                    <div>Percentage(%):</div>
                                    <input type="text" value="<?php echo $row['Percentage']?>" name="Percentage" id="Percentage" size="30" value="" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" />
                                </td>
                            </tr>
                            <tr>
                                <td>&nbsp;</td>
                                <td>
                                    <div>D.O.B</div>
                                    <select name="dd"  style="border:solid 1px #61b5f8; background-color:#FFFFFF; width:50px">
                                        <option value="">DD</option>
                                        <?
                                            $date= explode('/',$row['dob'] );
                                            $dd=$date[0];
                                              $mm=$date[1];
                                                $yy=$date[2];
                                                      
                                                      for($i=1;$i<=31;$i++)
                                                      {
                                                      ?>
                                        <option value="<?=$i?>" <?php if($dd==$i) {?> selected="selected"<?php }?>>
                                            <?=$i?>
                                        </option>
                                        <?
                                            }
                                            ?>
                                    </select>
                                    <select name="mm"  style="border:solid 1px #61b5f8; background-color:#FFFFFF; width:50px">
                                        <option value="" <? if($row['mm']=='') echo "selected" ?>>MM</option>
                                        <option value="Jan" <? if($mm=='Jan') echo "selected" ?>>Jan</option>
                                        <option value="Feb"<? if($mm=='Feb') echo "selected" ?>>Feb</option>
                                        <option value="Mar"<? if($mm=='Mar') echo "selected" ?>>Mar</option>
                                        <option value="Apr"<? if($mm=='Apr') echo "selected" ?>>Apr</option>
                                        <option value="May"<? if($mm=='May') echo "selected" ?>>May</option>
                                        <option value="Jun" <? if($mm=='Jun') echo "selected" ?>>Jun</option>
                                        <option value="Jul"<? if($mm=='Jul') echo "selected" ?>>Jul</option>
                                        <option value="Aug"<? if($mm=='Aug') echo "selected" ?>>Aug</option>
                                        <option value="Sep"<? if($mm=='Sep') echo "selected" ?>>Sep</option>
                                        <option  value="Oct"<? if($mm=='Oct') echo "selected" ?>>Oct</option>
                                        <option value="Nov" <? if($mm=='Nov') echo "selected" ?>>Nov</option>
                                        <option value="Dec" <? if($mm=='Dec') echo "selected" ?>>Dec</option>
                                    </select>
                                    <select name="yy"  style="border:solid 1px #61b5f8; background-color:#FFFFFF; width:75px">
                                        <option value="">YYYY</option>
                                           <?
                                            $curyr=date("Y");
                                            for($i=1980;$i<=2014;$i++)
                                            {
                                            ?>
                                        <option value="<?=$i?>" <?php if($yy==$i) {?> selected="selected"<?php }?>>
                                            <?=$i?>
                                        </option>
                                            <?}?>
                                    </select>
                                </td>
                                <td>
                                    <div>Gender</div>
										<select name="Gender" id="Gender"  style="border:solid 1px #61b5f8; background-color:#FFFFFF; width:180px">
											<option value="" >---Select---</option>
											<option value="Male"<? if($row['Gender1']=='Male') echo "selected" ?>>Male</option>
											<option value="Female"<? if($row['Gender1']=='Female') echo "selected" ?>>Female</option>
										</select>
                                </td>
                            </tr>
                            <tr>
                                <td>&nbsp;</td>
                                <td>
                                    <div>Sports</div>
										<select name="Sports" id="Sports"  onchange="showsports(this)" style="border:solid 1px #61b5f8; background-color:#FFFFFF; width:180px">
											<option value="">---Select---</option>
											<option value="Cricket" <? if($row['Sports']=='Cricket') echo "selected" ?>>Cricket</option>
											<option value="Football" <? if($row['Sports']=='Football') echo "selected" ?>>Football</option>
											<option value="Basketball" <? if($row['Sports']=='Basketball') echo "selected" ?>>Basketball</option>
											<option value="Lawn Tennis" <? if($row['Sports']=='Lawn Tennis') echo "selected" ?>>Lawn Tennis</option>
											<option value="Table Tennis" <? if($row['Sports']=='Table Tennis') echo "selected" ?>>Table Tennis</option>
											<option value="Badminton" <? if($row['Sports']=='Badminton') echo "selected" ?>>Badminton</option>
											<option value="Other" <? if($row['Sports']=='Other') echo "selected" ?>>Other</option>
										</select>
                                </td>
                                <td>
                                    <div>Activity:</div>
										<select name="Activity" id="Activity"  onchange="showactivity(this)" style="border:solid 1px #61b5f8; background-color:#FFFFFF; width:180px">
											<option value="" <? if($row['information_source']=='') echo "selected" ?>>---Select---</option>
											<option value="Music"<? if($row['Activity']=='Music') echo "selected" ?>>Music</option>
											<option value="Dance"<? if($row['Activity']=='Dance') echo "selected" ?>>Dance</option>
											<option value="Arts" <? if($row['Activity']=='Arts') echo "selected" ?>>Arts</option>
											<option value="Theatre" <? if($row['Activity']=='Theatre') echo "selected" ?>>Theatre</option>
											<option value="Other" <? if($row['Activity']=='Other') echo "selected" ?>>Other</option>
										</select>
                                </td>
                            </tr>
                            <tr>
                                <td></td>
                                <td align="left"><input type="text" name="sports" id="sports" size="30" value="<? echo $row['othe_Sports'] ?>" style="border:solid 1px #61b5f8; background-color:#FFFFFF; display:none;"/>
								</td>
                                <td><input type="text" name="activity" id="activity" value="<? echo $row['Other_Activity'] ?>" size="30" value="" style="border:solid 1px #61b5f8; background-color:#FFFFFF; display:none;"/>
								</td>
                            </tr>
                            <tr>
                                <td  colspan="3" background="butbg.gif" height="10" style="border-bottom:solid 1px #71befb; font-size:13px; color:#064582;"><strong>&nbsp;&nbsp;Parents Occupations</strong>
								</td>
                            </tr>
                            <tr>
                                <td>&nbsp;</td>
                                <td>
                                    <div>Father:</div>
                                    <input type="text" name="Father_occu" id="Father_occu"  value="<? echo $row['Father_occu']; ?>"size="30" value="" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" />
                                </td>
                                <td>
                                    <div>Mother:</div>
                                    <input type="text"  name="Mother_occu" value="<? echo $row['Mother_occu'] ?>" id="Mother_occu" size="30" value="" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" />
                                </td>
                            </tr>
                            <tr>
                                <td colspan="3" background="butbg.gif" height="10" style="border-bottom:solid 1px #71befb; font-size:13px; color:#064582;"><strong>&nbsp;&nbsp;Siblings</strong></td>
                            </tr>
                            <tr>
                                <td>&nbsp;</td>
                                <td>
                                    <div>Brother:</div>
										<select name="Brother_sibl"  style="border:solid 1px #61b5f8; background-color:#FFFFFF; width:180px">
											<option value="" >---Select---</option>
											<option value="" <? if($row['Brother_sibl']=='') echo "selected" ?>>---Select---</option>
											<option value="0" <? if($row['Brother_sibl']=='0') echo "selected" ?>>None</option>
											<option value="1" <? if($row['Brother_sibl']=='1') echo "selected" ?>>1</option>
											<option value="2" <? if($row['Brother_sibl']=='2') echo "selected" ?>>2</option>
											<option value="3" <? if($row['Brother_sibl']=='3') echo "selected" ?>>3</option>
											<option value="4" <? if($row['Brother_sibl']=='4') echo "selected" ?>>4</option>
											<option value="5" <? if($row['Brother_sibl']=='5') echo "selected" ?>>5</option>
										</select>
                                </td>
                                <td>
                                    <div>Sister:</div>
										<select name="Sister_sibl"  style="border:solid 1px #61b5f8; background-color:#FFFFFF; width:180px">
											<option value="" <? if($row['Sister_sibl']=='') echo "selected" ?>>---Select---</option>
											<option value="0" <? if($row['Sister_sibl']=='0') echo "selected" ?>>None</option>
											<option value="1" <? if($row['Sister_sibl']=='1') echo "selected" ?>>1</option>
											<option value="2" <? if($row['Sister_sibl']=='2') echo "selected" ?>>2</option>
											<option value="3" <? if($row['Sister_sibl']=='3') echo "selected" ?>>3</option>
											<option value="4" <? if($row['Sister_sibl']=='4') echo "selected" ?>>4</option>
											<option value="5" <? if($row['Sister_sibl']=='5') echo "selected" ?>>5</option>
										</select>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="3"background="butbg.gif" height="10" style="border-bottom:solid 1px #71befb; font-size:13px; color:#064582;"><strong>&nbsp;&nbsp;Why Boarding School</strong></td>
                            </tr>
                            <tr>
                                <td>&nbsp;</td>
                                <td colspan="2"><textarea name="why_bor_school" id="why_bor_school" cols="" rows="" style="border:solid 1px #61b5f8; background-color:#FFFFFF; width:450px; height:40px;"><? echo $row['why_bor_school'] ?></textarea></td>
                            </tr>
                            <tr>
                                <td colspan="3"></td>
                            </tr>
                            <tr>
                                <td align="center" colspan="3"><input type="submit" name="submit" value="Update" />
                                </td>
                            </tr>
                            <tr>
                                <td colspan="3"></td>
                            </tr>
                        </table>
                    </form>
                    <div style="clear:both"></div>
                    <div id="assess" style="display:none">
                        <form name="assessment" method="post" action="" onSubmit="return ValidateForm2();">
                            <table width="100%" style="font-size:13px;border:#88c9fd 1px solid;" bgcolor="#f3f7fd">
                                <tr>
                                    <input type="hidden" name ="stud_id" value="<?= $_GET['stud_id']?>">
                                    <td height="25" colspan="2" bgcolor="#c0e4fc">
                                        <div style="margin-left:20px;"><strong>Is the school working with any testing body</strong></div>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2">
                                        <div style="margin-left:20px; margin-top:5px; float:left;">
                                            <select name="working" onChange="showhide(id)" id="working" style="border:solid 1px #61b5f8; background-color:#FFFFFF;">
                                                <option value="">--Select--</option>
                                                <option value="None">None</option>
                                                <option value="Asset">Asset</option>
                                                <option value="McMillan">McMillan</option>
                                                <option value="Other">Other</option>
                                            </select>
                                            &nbsp;<font color="#FF0000"><b>*</b></font>
                                        </div>
                                        <div id="otherbox" style="visibility:hidden; margin-left:20px;float:left;">
                                            <input type="text" name="other_working" size="50" value="" style="border:solid 1px #61b5f8; background-color:#FFFFFF;"/>
                                            &nbsp;<font color="#FF0000"><b>*</b></font> 
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div style="padding:7px 0px 10px 20px;">
                                            <input type="submit" name="submit" value="Update" />
                                        </div>
                                    </td>
                                    <td>
                                        <a href="#" onClick="MM_openBrWindow('assessmentreport.php?stud_id=<? echo $_GET['stud_id']?>','contactreport','toolbar=yes,location=yes,scrollbars=yes,resizable=yes,width=870,height=500')">
                                            <div style="padding:7px 0px 10px 0px;">
                                                <input type="button" name="showall" value="Show All" />
                                            </div>
                                        </a>
                                    </td>
                                </tr>
                            </table>
                        </form>
                    </div>
                </td>
                <td width="55%" valign="top">
                    <form name="contactdetails" method="post" action="" onSubmit="return ValidateForm4();">
                        <table width="99%" border="0" align="center" bgcolor="#f3f7fd" cellpadding="0" cellspacing="0" style="border:#88c9fd 1px solid;">
                            <tr>
                                <td>
                                    <table width="100%" border="0" align="center" bgcolor="#f3f7fd" cellpadding="5" cellspacing="0">
                                        <tr>
                                            <td align="right" colspan="3">
                                                <div style="display:block; width:100%;">
                                                    <table width="100%" border="0" cellpadding="4" cellspacing="1" bgcolor="#81cafd">
                                                        <tr bgcolor="#999999">
                                                            <td height="25" align="left"  background="butbg.gif"  style="padding-left:15px; border-bottom:solid 1px #71befb; font-size:13px; color:#064582;"><strong>Date</strong></td>
                                                            <td align="left" background="butbg.gif"  style="padding-left:15px; border-bottom:solid 1px #71befb; font-size:13px; color:#064582;"><strong>Status</strong></td>
                                                            <td align="left" background="butbg.gif"  style="padding-left:15px; border-bottom:solid 1px #71befb; font-size:13px; color:#064582;"><strong>Follow Up</strong></td>
                                                        </tr>
                                                        <? 
                                                            $sql_cust = "SELECT * FROM contact WHERE stud_id='".$_GET['stud_id']."' order by joined asc";
                                                            $result	= mysql_query($sql_cust) or die(mysql_error());
                                                            $count = 0;
                                                            while($res=mysql_fetch_array($result)) {
                                                            if($acol) {
                                                                    $x = "bgcolor='#e9f5ff'";
                                                                   } else {
                                                                     $x = "bgcolor='#d8effe'";
                                                                    }
                                                             $acol=!$acol;
                                                             $count++;
                                                        ?>
                                                        <tr <?=$x;?> align="left">
                                                            <td>
															   <?php if($res['joined']!='0000-00-00') echo date("d-M-y",strtotime($res['joined']));?>
															</td>
                                                            <td>
                                                                <?php if($res['status']=='Duplicate'){?>
                                                                   <img src="images/duplicate.jpg" border="0" name="plus_sign" alt="Click here to view positive report" align="center"/>
                                                                <? } else if($res['status']=='Positive'){?>
                                                                   <img src="image/green.gif" border="0" name="plus_sign" alt="Click here to view positive report" align="center"/>
                                                                <? } else if($res['status']=='Not Intrested'){ ?>
                                                                   <img src="image/red.gif" border="0" name="minus_sign" alt="Click here to view Not Intrested report" align="center"/>
                                                                <? }else if($res['status']=='Very Positive'){ ?>
                                                                   <img src="images/very_positive.jpg" border="0" name="minus_sign" alt="Click here to view Very Positive report" align="center"/>
                                                                <? }else if($res['status']=='Not Eligible'){ ?>
                                                                   <img src="images/not_eligible.jpg" border="0" name="minus_sign" alt="Click here to view Not Eligible report" align="center"/>
                                                                <?php }else if($res['status']=='Moderate'){ ?>
                                                                   <img src="image/mod.gif" border="0" name="minus_sign" align="center"/>
                                                                <? } else if($res['status']=='Paid'){ ?>
                                                                   <img src="image/paddy-smiley26.gif" border="0" name="paid" alt="Paid School" align="center" />
                                                                <? }else if($res['status']=='Admission'){ ?>
                                                                  <img src="image/admission.png" border="0" name="Admission" alt="Admission" align="center" />
                                                                <? }else if($res['status']=='NoContact'){ ?>
                                                                  <img src="image/nocontact.png" border="0" name="Admission" alt="Admission" align="center" />
                                                                <? }else if($res['status']=='Session2014-15'){ ?>
                                                                  <img src="image/2013-14.jpg.png" border="0" name="Admission" alt="Admission" align="center" />
                                                                <? }else echo "-";?>
                                                            </td>
                                                            <td>
                                                                <?php 
                                                                    if($res['followup']=='Other') echo $res['other']; else echo $res['followup'];
                                                                    if($res['remarkdate']!='0000-00-00')
                                                                    { ?>
                                                                next follow up on 
                                                                <?php echo date("d-M-y", strtotime($res['remarkdate']));?>   <?php echo $res['remarktime'];} ?>
                                                            </td>
                                                        </tr>
                                                        <? }?>
                                                    </table>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td height="23" colspan="3" background="butbg.gif"  style="padding-left:15px; border-bottom:solid 1px #71befb; font-size:13px; color:#064582;"><b>New Contact / Call  - <? echo $row['stud_name'] ?></b></td>
                                        </tr>
                                        <tr>
                                            <td style="width:150px;"  class="Border-botm">
                                                <div style="margin-left:10px;">Status</div>
                                            </td>
                                            <td width="3" class="Border-botm" style="width:20px;">:</td>
                                        <!--    <td class="Border-botm">
                                                <select name="status"  style="border:solid 1px #61b5f8; width:180px;   background-color:#FFFFFF;" >
                                                    <?
                                                        if($row['status']=='Paid')
                                                        {
                                                    ?>
                                                    <option value="Paid" <? if($row=='Paid') echo 'selected' ?>>Paid</option>
                                                    <option value="Admission">Admission</option>
                                                    <?
                                                        } else if($row['status']=='Admission') {
                                                        ?>
                                                    <option value="Admission" <? if($row=='Admission') echo 'selected' ?>>Admission</option>
                                                    <? 
                                                        }else{
                                                    ?>
														<option value="">--Select--</option>
														<option value="Very Positive">Very Positive</option>
														<option value="Positive">Positive</option>
														<option value="Not Eligible">Not Eligible</option>
														<option value="Not Intrested">Not Interested</option>
														<option value="Moderate">Moderate</option>
														<option value="Paid">Paid</option>
														<option value="Admission">Admission</option>
														<option value="Duplicate">Duplicate</option>
														<option value="NoContact">No Contact</option>
														<!--option value="Session2014-15">Session(2014-15)</option 
														<option value="Session2015-16">Session(2015-16)</option>
														<option value="Session2016-17">Session(2016-17)</option>
                                                    <? }?>
                                                </select>
                                                &nbsp;<font color="#FF0000"><b>*</b></font>
                                            </td> -->
											<td class="Border-botm">
                                             <select name="status" id="status" style="float:left;height:20px;line-height:18px;border:solid 1px #61b5f8;font-size:12px;width:120px; color:#0a5095;background-color:#ffffff; margin-top:10px;" >
					    <option value="">---Select---</option>
                        <?php
					    $drop_info = "select status from student WHERE status IN ('Admission' , 'Duplicate' , 'Moderate', 'Negative' , 'NoContact' , 'Not Eligible' , 'Not Intrested' , 'Paid' , 'Positive' , 'Session2018-19' , 'Session2019-20' , 'Very Positive' , 'Campus visit') group by status";
						 $result_info = mysql_query($drop_info);
						 $camp_vist ='';
						 while($row_info = mysql_fetch_array($result_info)){?>
						  <option value="<?= $row_info['status'];?>" <?php if($_GET['status'] == $row_info['status']) echo 'selected';?>><?=$row_info['status'];?></option>
						 <?php
						 
						 if($row_info['status'] == 'Campus visit' ){
							 $camp_vist = 1;
						 }
						 }
						 if( $camp_vist == ''){
						?>
						<option value="Campus visit">Campus visit</option>
						<?php } ?> 
                     </select>
&nbsp;<font color="#FF0000"><b>*</b></font>
                                            </td>					 
                                        </tr>
                                        <tr>
                                            <td class="Border-botm">
                                                <div style="margin-left:10px;">Follow Up</div>
                                            </td>
                                            <td class="Border-botm">:</td>
                                            <td class="Border-botm">
                                                <select name="followup" onchange="showhide1(this)" style="float:left; border:solid 1px #61b5f8; width:180px; background-color:#FFFFFF;" >
                                                    <option value="">--Select--</option>
                                                    <option value="Call">Call</option>
                                                    <option value="Meeting / Counselling">Meeting / Counselling</option>
                                                    <option value="Send Brochure">Send Brochure</option>
                                                    <option value="Other">Other</option>
                                                </select>
                                                <textarea name="other" rows="2" cols="30" id="divnb2" style="float:left;display:none"></textarea>
                                                <!--<input type="text" name="other" size="30" maxlength="2000"  id="divnb2" style="float:left;display:none"/>-->
                                                <font color="#FF0000"><b> &nbsp;* </b></font>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="Border-botm">
                                                <div style="margin-left:10px;">Date-Time</div>
                                            </td>
                                            <td class="Border-botm">:</td>
                                            <td class="Border-botm">
                                                <label>
                                                    <input type="text" name="remarkdate" size="20" id="remarkdate" readonly="readonly" style="border:solid 1px #61b5f8; background-color:#FFFFFF; width:180px;" />
                                                    <img src="CalendarIcon.gif" name="get_stud_date3" width="22" height="23" border="0" align="absmiddle" id="get_stud_date3" style="cursor: pointer;" title="Date selector" onmouseover="this.style.background='red';" onmouseout="this.style.background=''" />
                                                    <script type="text/javascript">
                                                        Calendar.setup({
                                                            inputField     :    "remarkdate",     // id of the input field
                                                         //ifFormat       :    "%Y/%m/%d %l:%M %P",      // format of the input field
                                                        //ifFormat       :    "%m-%d-%Y",      // format of the input field
                                                        ifFormat       :    "%d-%m-%Y",      // format of the input field
                                                            button         :    "get_stud_date3",  // trigger for the calendar (button ID)
                                                            align          :    "Tl",           // alignment (defaults to "Bl")
                                                            singleClick    :    true,
                                                        showsTime		:	true
                                                        });
                                                    </script>
                                                </label>
                                                &nbsp;<font color="#FF0000"><b>*&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                <input type="text" name="remarktime" size="20"  style="border:solid 1px #61b5f8; background-color:#FFFFFF;" />
                                                &nbsp;<font color="#FF0000"><b>*</b></font></b></font>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td class="Border-botm">
                                                <div style="margin-left:10px;">Student's Next Step</div>
                                            </td>
                                            <td class="Border-botm">:</td>
                                            <td class="Border-botm">
                                                <select name="nextstep" onchange="showhide5(this)" style="float:left; border:solid 1px #61b5f8; width:180px; background-color:#FFFFFF;" >
                                                    <option value="">--Select--</option>
                                                    <option value="Call">Call</option>
                                                    <option value="Submit Registration">Submit Registration</option>
                                                    <option value="Submit Fees">Submit Fees</option>
                                                    <option value="other">Other</option>
                                                </select>
                                                <textarea name="schoolother" rows="2" cols="30" id="divnb3" style="float:left; display:none"></textarea>
                                                <!--<input type="text" name="schoolother" size="30"  id="divnb3" style="float:left;display:none"/>-->
                                                <font color="#FF0000"><b> &nbsp;* </b></font> 
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="2" align="left">&nbsp;</td>
                                            <td height="30" align="left" valign="middle">
                                                <input type="hidden" name="stud_id" value="<?=$row['stud_id'] ?>" />
                                                <input type="submit" name="submit2" value=" Save " />                  
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </form>
                    <form name="walkin_frm" method="post" action="" onsubmit="return Validate_walkins();">
                        <table width="99%" border="0" align="center" bgcolor="#f3f7fd" cellpadding="2" cellspacing="0" style="border:#88c9fd 1px solid;">
                            <tr>
                                <td height="25" colspan="3" background="butbg.gif"  style="padding-left:15px; border-bottom:solid 1px #71befb; font-size:13px; color:#064582;"><b>Expected Walkin / Campus Visit</b></td>
                            </tr>
                            <tr>
                                <td style="width:150px;" class="Border-botm">
                                    <div style="margin-left:10px;">Date</div>
                                </td>
                                <td class="Border-botm" style="width:20px;">:</td>
                                <td class="Border-botm">
                                    <label>
                                        <input type="text" name="walkin_date" size="20" id="walkin_date" style="border:solid 1px #61b5f8; background-color:#FFFFFF; width:180px;" />
                                        <img src="CalendarIcon.gif" name="get_stud_date33" width="22" height="23" border="0" align="absmiddle" id="get_stud_date33" style="cursor: pointer;" title="Date selector" onmouseover="this.style.background='red';" onmouseout="this.style.background=''" />
                                        <script type="text/javascript">
                                            Calendar.setup({
                                                inputField     :    "walkin_date",     // id of the input field
                                             //ifFormat       :    "%Y/%m/%d %l:%M %P",      // format of the input field
                                            //ifFormat       :    "%m-%d-%Y",      // format of the input field
                                            ifFormat       :    "%d-%m-%Y",      // format of the input field
                                                button         :    "get_stud_date33",  // trigger for the calendar (button ID)
                                                align          :    "Tl",           // alignment (defaults to "Bl")
                                                singleClick    :    true,
                                            showsTime		:	true
                                            });
                                            
                                                
                                        </script>
                                    </label>
                                    &nbsp;<font color="#FF0000"><b>*</b></font>
                                </td>
                            </tr>
                            <tr>
                                <td class="Border-botm">
                                    <div style="margin-left:10px; width:150px;">Time</div>
                                </td>
                                <td class="Border-botm">:</td>
                                <td class="Border-botm">
                                    <input type="text" name="walkintime" id="walkintime" size="20"  style="border:solid 1px #61b5f8; background-color:#FFFFFF; width:180px;" />&nbsp;<font color="#FF0000"><b>*</b></font>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2" align="left">&nbsp;</td>
                                <td height="30" align="left" valign="middle">
                                    <input type="hidden" name="stud_id" value="<?=$row['stud_id'] ?>" />
                                    <input type="submit" name="walkin_submit" value=" Save " />                  
                                </td>
                            </tr>
                            <tr>
                                <td height="25" colspan="3" align="left" bgcolor="#c0e4fc" style="padding-left:10px;"><strong>Transferred Status</strong></td>
                            </tr>
                            <tr>
                                <td height="30" colspan="3" align="left">
                                    <table width="100%" border="0" cellpadding="4" cellspacing="1" bgcolor="#81cafd">
                                        <tr bgcolor="#999999">
                                            <td height="25" align="left" background="butbg.gif"  style="padding-left:15px; border-bottom:solid 1px #71befb; font-size:13px; color:#064582;"><strong>Date</strong></td>
                                            <td align="left" background="butbg.gif"  style="padding-left:15px; border-bottom:solid 1px #71befb; font-size:13px; color:#064582;"><strong>Transferred To</strong></td>
                                            <td align="left" background="butbg.gif"  style="padding-left:15px; border-bottom:solid 1px #71befb; font-size:13px; color:#064582;"><strong>Transferred From</strong></td>
                                            <td align="left" background="butbg.gif"  style="padding-left:15px; border-bottom:solid 1px #71befb; font-size:13px; color:#064582;"><strong>Transferred By</strong></td>
                                        </tr>
                                        <? 
                                            $sql_trans = "SELECT * FROM transferred_lead WHERE stud_id='".$_GET['stud_id']."' order by transfer_date asc";
                                            
                                            $res_trans	= mysql_query($sql_trans) or die(mysql_error());
                                            $count = 0;
                                            while($row_trans=mysql_fetch_array($res_trans))
                                            {
                                            if($acol)
                                            {
                                              					 $x = "bgcolor='#e9f5ff'";
                                             }
                                            else 
                                            {
                                                				$x = "bgcolor='#d8effe'";
                                               				}
                                            $acol=!$acol;
                                            $count++;
                                            
                                            ?>
                                        <tr <?=$x;?>>
                                            <td>
                                                <?php if($row_trans['transfer_date']!='0000-00-00 00:00:00') echo date("d-M-y",strtotime($row_trans['transfer_date']));?> 
                                                <?php //echo date("H:i A",strtotime($row_trans['transfer_date']));?>
                                            </td>
                                            <td><?php 
                                                $qry12 = "SELECT emp_name FROM members WHERE emp_id='".$row_trans['emp_to_id']."'";
                                                $res12 = mysql_query($qry12) or die(mysql_error());
                                                $row12 = mysql_fetch_array($res12);
                                                echo $row12['emp_name'];
                                                ?>
											</td>
                                            <td><?
                                                $qry11 = "SELECT emp_name FROM members WHERE emp_id='".$row_trans['emp_from_id']."'";
                                                $res11 = mysql_query($qry11) or die(mysql_error());
                                                $row11 = mysql_fetch_array($res11);
                                                echo $row11['emp_name'];
                                                ?>
											</td>
                                            <td><?php 
                                                $qry13 = "SELECT emp_name FROM members WHERE emp_id='".$row_trans['transferred_by_id']."'";
                                                $res13 = mysql_query($qry13) or die(mysql_error());
                                                $row13 = mysql_fetch_array($res13);
                                                echo $row13['emp_name'];
                                                ?>
											</td>
                                        </tr>
                                        <?}?>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </form>
                </td>
            </tr>
        </table>
    </body>
</html>