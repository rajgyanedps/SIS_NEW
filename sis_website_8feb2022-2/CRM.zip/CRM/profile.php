<?php
include("connection.php");
session_start();
if (isset($_POST['submit']))
{
  if (strcmp($_POST['password'],$_POST['confirmpassword']) || empty($_POST['password']) )
  { 
	//die ("Password does not match");
	header("Location: profile.php?msg=ERROR: Password does not match....Please try again");
	exit();
    }
	
	if (strcmp(md5($_POST['user_code']),$_SESSION['ckey']))
	{ 
	       header("Location: profile.php?msg=Invalid code entered. Please enter the correct code as shown in the Image");
		   exit();
			   		}
					
	$rs_duplicates = mysql_query("select empid from members where username='$_POST[username]'");
	$duplicates = mysql_num_rows($rs_duplicates);
	if ($duplicates > 0)
	{	
	//die ("ERROR: User account already exists.");
	header("Location: profile.php?msg=ERROR: User account already exists....Please choose another username");
	exit();
	}	
	
else
{

$r="SELECT max(emp_id) as maxid FROM members ";
$p=mysql_query($r) or die(mysql_error());
$row=mysql_fetch_array($p);
$y=$row['maxid'];
$w=$y+100000;

$sql="INSERT INTO $tbl_name(emp_id,joined,username,password,emp_name,email,user_type,gender,address,mobno,user_code) VALUES ($w,now(),'".$_POST['username']."','".$_POST['password']."','".$_POST['emp_name']."','".$_POST['email']."','".$_POST['user_type']."','".$_POST['gender']."','".$_POST['address']."','".$_POST['mobno']."','".$_POST['user_code']."')";

$result=mysql_query($sql) or die(mysql_error());
unset($_SESSION['ckey']);
header("Location: adminhome.php?msg=Account Create Successfully...");
}
}
?>
<?
$_SESSION['this_page']='userinfo.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Add New User</title>
<script type="text/javascript">
function ValidateForm()
{
// checking username field
      if (document.form2.username.value=="")
	{
		alert("The User Name field is blank. \nPlease enter user name in the text box.");
		document.form2.username.focus();
		return false;
      }	  
//checking user email field
	  
      if (document.form2.email.value=="")
	{
		alert("The e-mail ld is blank or \nan invalid value has been entered.");
        document.form2.email.focus();		
        return false;
    }
        var txt=(document.form2.email.value)
        if (txt.indexOf("@")<0)
        {
            alert("This email address in the 'e-mail' seems wrong. Please"
            +" check the prefix and '@' sign.");
            document.form2.email.focus();           
            return false;

        } 
        
           if(txt.indexOf(".")<0)
           {
            alert("Check your e-mail ID.\n It doesn't have '.' in it");
            document.form2.email.focus();           
            return false;
          } 
// checking password field
      if (document.form2.password.value=="")
	{
		alert("The Password field is blank. \nPlease enter password in the text box.");
		document.form2.password.focus();
		return false;
      }	 		   	  
// checking confirmpassword field
      if (document.form2.confirmpassword.value=="")
	{
		alert("The Confirm Password field is blank. \nPlease enter confirm password in the text box.");
		document.form2.confirmpassword.focus();
		return false;
      }	 
// checking password & confirm password match
    if (document.form2.confirmpassword.value!=document.form2.password.value)
	{
		alert("The Confirm Password does not match.");
		document.form2.confirmpassword.focus();
		return false;
      }	 			  
	  		   	  	  
// checking emp_name field
      if (document.form2.emp_name.value=="")
	{
		alert("The Employee Name field is blank. \nPlease enter employee name in the text box.");
		document.form2.emp_name.focus();
		return false;
      }	  	    
	  
//checking alphabetic values in name

    var iChars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ';
    for (i = 0; i < document.form2.emp_name.value.length; i++) {
      if (iChars.indexOf(document.form2.emp_name.value.charAt(i)) == -1) {
         alert('Please enter letters only in Employee Name field');
         document.form2.emp_name.focus();
         return false;
      }
      }	
// checking user_type field
      if (document.form2.user_type.value=="")
	{
		alert("The User Type field is blank. \nPlease select user type in the combo box.");
		document.form2.user_type.focus();
		return false;
      }	  
// checking gender field
      if (document.form2.gender.value=="")
	{
		alert("The Gender field is blank. \nPlease select gender in the combo box.");
		document.form2.gender.focus();
		return false;
      }	  	  
// checking address field
      if (document.form2.address.value=="")
	{
		alert("The Address field is blank. \nPlease enter address in the text box.");
		document.form2.address.focus();
		return false;
      }
// checking mobno field
	  
	  if (document.form2.mobno.value=="")
	 {
		alert("The Mob. No. is blank. \nPlease enter the Mob. No. field in the text box.");
        document.form2.mobno.focus();		
        return false;
      }
	  
//checking numeric value in mobno
     var n = document.form2.mobno.value;
    if(isNaN(n) == true) {
        alert('Your entry is not a numberic value in mob. no. field, Please try again');
        document.form2.mobno.focus();
        return false;
    }	  
// checking usercode field
	  
	  if (document.form2.user_code.value=="")
	 {
		alert("The User Code is blank. \nPlease enter the user code field in the text box.");
        document.form2.user_code.focus();		
        return false;
      }			  	  
	  	  
}
</script>
<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css">
</head>
<body>
<?php
include("header.php");
?>
<br />
<br />
<br />
<div align="center" class="msg">
  <?=$_GET['msg']; ?>
</div>
<table border="0" align="center" bgcolor="#f3f7fd" cellpadding="8" cellspacing="0" style="border:solid 1px #71befb; font-size:13px; color:#064582;">
  <tr>
    <td background="butbg.gif" height="10px">&nbsp;&nbsp;<b>New Members</b></td>
  </tr>
  <tr>
    <td><form name="form2" method="post" action="profile.php" onsubmit="return ValidateForm();">
        <table width="402" align="center" cellpadding="1" cellspacing="1" border="0" style="font-size:13px">
          <tr>
            <td colspan="3"></td>
          </tr>
          <tr>
            <td colspan="3"></td>
          </tr>
          <tr>
            <td height="25">User Name</td>
            <td>:</td>
            <td><input type="text" name="username" size="35" value="<? echo $_POST['username']?>"  />
              &nbsp;<font color="#FF0000"><b>*</b></font></td>
          </tr>
          <tr height="25">
            <td>Email</td>
            <td>:</td>
            <td><input type="text" name="email" size="35" value="<? echo $_POST['email']?>" />
              &nbsp;<font color="#FF0000"><b>*</b></font></td>
          </tr>
          <tr>
            <td height="25">Password</td>
            <td>:</td>
            <td><input type="password" name="password" size="35"/>
              &nbsp;<font color="#FF0000"><b>*</b></font></td>
          </tr>
          <tr>
            <td height="25">Confirm Password</td>
            <td>:</td>
            <td><input type="password" name="confirmpassword" size="35"/>
              &nbsp;<font color="#FF0000"><b>*</b></font></td>
          </tr>
          <tr>
            <td height="25">Employee Name</td>
            <td>:</td>
            <td><input type="text" name="emp_name" size="35" value="<? echo $_POST['emp_name']?>"/>
              &nbsp;<font color="#FF0000"><b>*</b></font></td>
          </tr>
          <tr>
            <td height="25">User Type</td>
            <td>:</td>
            <td><select name="user_type">
                <option value="">--Please Select--</option>
                <option value="School Login">School Login</option>
                <option value="Tele Caller">Tele Caller</option>
                <option value="Admin">Admin</option>
              </select>
              &nbsp;<font color="#FF0000"><b>*</b></font></td>
          </tr>
          <tr>
            <td height="25">Gender</td>
            <td>:</td>
            <td><select name="gender">
                <option value="">--Please Select--</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
              </select>
              &nbsp;<font color="#FF0000"><b>*</b></font></td>
          </tr>
          <tr>
            <td height="25">Address</td>
            <td>:</td>
            <td><input type="text" name="address" size="35" value="<? echo $_POST['address']?>"/>
              &nbsp;<font color="#FF0000"><b>*</b></font></td>
          </tr>
          <tr>
            <td height="25">Mob No.</td>
            <td>:</td>
            <td><input type="text" maxlength="11" name="mobno" size="35" value="<? echo $_POST['mobno']?>"/>
              &nbsp;<font color="#FF0000"><b>*</b></font></td>
          </tr>
          <tr>
            <td height="25">Code</td>
            <td>:</td>
            <td><input type="text" name="user_code" />
              <img src="pngimg.php" align="middle">&nbsp;<font color="#FF0000"><b>*</b></font></td>
          </tr>
          <tr>
            <td colspan="3" align="center"><input type="submit" name="submit" value="Submit" /></td>
          </tr>
          <tr>
            <td colspan="3"></td>
          </tr>
        </table>
      </form></td>
  </tr>
</table>
</body>
</html>
