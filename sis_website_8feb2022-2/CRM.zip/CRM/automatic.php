<?php 
include("connection.php");
$sql="UPDATE members SET last_active=now() WHERE emp_id='".$_SESSION['emp_id']."'";
$result=mysql_query($sql);

?>