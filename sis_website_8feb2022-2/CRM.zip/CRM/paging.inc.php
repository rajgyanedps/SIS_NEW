<?
    if($reccnt>$pagesize){
    $num_pages=ceil($reccnt/$pagesize);
    $PHP_SELF=$_SERVER['PHP_SELF'];
	
     $qry_str=$_SERVER['argv'][0];
    //echo $num_pages*$pagesize;
    $m=$_GET;
    unset($m['start']);
    unset($m['act']);
    $qry_str=qry_str($m);
    
  // echo "$qry_str : $p<br>";
    
    //$j=abs($num_pages/10)-1;
    $j=$start/$pagesize-5;
    //echo("<br>$j");
    if($j<0) {
    	$j=0;
    }
    $k=$j+10;
    if($k>$num_pages)	{
    	$k=$num_pages;
    }
    $j=intval($j);
    ?>
<? //="reccnt=$reccnt, start=$start, pagesize=$pagesize, num_pages=$num_pages : j=$j : k=$k"?>
<table align="center" width="100%" border="0" cellspacing="0" cellpadding="5">
	<tr>
		<td align="left" valign="top" style="margin:0; padding:0; width: 20px; float:left; display: block;"> 
			<?
			if($start!=0){
			?> 
				<a class="pagelinks" href="<?=$PHP_SELF?><?=$qry_str?>&start=<?=$start-$pagesize?>&&from=<?=$from;?>&&to=<?=$to;?>" ><img src='images/previous.png' border='0' style="margin-top:-px;">
				</a> 
			<?
			}
			?>    
		</td>
		<td width="80%" align="center" style="color: green; float:left; margin:0; padding:0;">&nbsp;  
			<? if($start!=0){ ?> 
			   <a href="<?=$PHP_SELF?><?=$qry_str?>&start=0&&from=<?=$from;?>&&to=<?=$to;?>" > First</a>&nbsp;&nbsp;
			<? } ?> <?
			for($i=$j;$i<$k;$i++)
				{
				 if($i==$j);
				 if(($pagesize*($i))!=$start){
				?>      
				   <a href="<?=$PHP_SELF?><?=$qry_str?>&start=<?=$pagesize*($i)?>&&from=<?=$from;?>&&to=<?=$to;?>" style="text-decoration:none;" > 
					<?=$i+1?>
				  </a>      <?
				}
				else{
				?>      <b> 
				<span class="page active">   <?=$i+1?></span>
				</b>      <?
				}
			}?>
			<? if($start+$pagesize < $reccnt){
			?> 
			<a href="<?=$PHP_SELF?><?=$qry_str?>&start=<?php echo $num_pages*$pagesize-50;?>&&from=<?=$from;?>&&to=<?=$to;?>" > Last</a><? } ?>
		</td>
		<td width="20%"  valign="top" align="right" style="margin:0; padding:0; width: 20px; float:left; display: block;"><?
			if($start+$pagesize < $reccnt){
			?>
			<a  class="pagelinks" href="<?=$PHP_SELF?><?=$qry_str?>&start=<?=$start+$pagesize?>&&from=<?=$from;?>&&to=<?=$to;?>"><img src='images/next.png' border='0' style="margin-top:-1px;"></a> 
			<?
			}
		?>      
		</td>
	</tr>
</table>
<? }
    ?>