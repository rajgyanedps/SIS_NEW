<?php
session_start();
include("connection.php");
if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='Project Manager' && $_SESSION['user_type']!='Tele Caller')
//if (!isset($_SESSION[myusername]))
{
 header("Location: index.php");
}
?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>CityWise Report</title>
<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php
include("reportheader.php");
?>
<br />
<form action="cityreport.php" method="post" name="cityreport">
<table><tr><td width="1000px" align="left"><font size="4.5" face="Verdana, Arial, Helvetica, sans-serif"><b>Citywise School Report</b></font></td></tr></table>

<br /><br />
<table width="100%" border="3" align="center" cellpadding="5" cellspacing="0" style="font-size:13px">
<tr bgcolor="#999999" align="center">
 
      <td align="left" background="footerbg.jpg" class="whitetxt11"><a href="cityreport.php?pageno=<?=$_REQUEST['pageno']?>">User Name</a></td>
      <?
	  $select_user = "SELECT emp_name,emp_id FROM members order by emp_id";
	  $user_result = mysql_query($select_user) or die(mysql_error());
	  $num_emp = mysql_num_rows($user_result);
	  $i=0;
	  while($row_user=mysql_fetch_array($user_result))
	  {
      ?>
      <td align="left" background="footerbg.jpg" class="whitetxt11"><?=$row_user['emp_name'];?></td>
      <? 
	  $empid[$i] = $row_user['emp_id'];
	  $i++;
	  }
	  
	  ?>
    </tr>
                <? 
	   $sql_cust = "SELECT DISTINCT city FROM addschool ORDER BY city asc";

		$result	= mysql_query($sql_cust) or die(mysql_error());
		$num_rows 	= mysql_num_rows($result);	
		$incr = 1;
		
		if(!$_REQUEST['pageno']){
			$pageno = 1;
		} else {
			$pageno= $_REQUEST['pageno'];
		}
		$pagesize=1000;
		$incr = (($pageno-1)*$pagesize)+1;
		$first=$pageno*$pagesize-($pagesize-1);
		$last=$first+$pagesize-1; 
		$temp=($num_rows%$pagesize);
		if ($temp==0)
		$pages=($num_rows/$pagesize);
		else
		$pages=($num_rows/$pagesize)+1;
		settype($pages, "integer"); 

		for($i=1;$i<$first;$i++)
			$row2000=mysql_fetch_row($result);
     
     
     
//<?php
//$query="SELECT * FROM addschool";
//$result=mysql_query($query) or die(mysql_error());
while($res=mysql_fetch_array($result) and ($first<=$last))
{
if($i%2==0) {
	           $x = "bgcolor='#F0F0F0'";
	          } else {
	            $x = "bgcolor='#D8D8D8'";
 	          }
?>

<tr <?=$x;?> align="left">
<td align="left"><?php echo $res['city'];?></td>

 <?


$select_city = "SELECT count(*) as num , city FROM addschool WHERE school_id >= $empid[0] AND school_id < $empid[0]+100000 GROUP BY city ORDER BY city";
$result_city = mysql_query($select_city) or die(mysql_error());
//echo mysql_num_rows($result_city);
//echo $row_city['num'];
?>
        <td align="left">
		<?
		$found=false;
		 while($row_city=mysql_fetch_array($result_city))
{

		if($res['city']==$row_city['city'])
		 {
		         $found=true;
		 		?>
                <a href="citywise_report.php?emp_id=<?=$empid[0]?>&city=<?=$row_city['city']?>"><?=$row_city['num']?></a>
		      <?
		 }
		 
}
if(!$found) echo"-";
?>
        </td>
        
        
      <?

$select_city1 = "SELECT count(*) as num , city FROM addschool WHERE school_id >= $empid[1] AND school_id < $empid[1]+100000 GROUP BY city ORDER BY city";
$result_city1 = mysql_query($select_city1) or die(mysql_error());
//echo mysql_num_rows($result_city);
//echo $row_city['num'];
?>
        <td align="left">
		<?
		$found1=false;
		 while($row_city1=mysql_fetch_array($result_city1))
{

		if($res['city']==$row_city1['city'])
		 {
		 		$found1=true;
				?>
                <a href="citywise_report.php?emp_id=<?=$empid[1]?>&city=<?=$row_city1['city']?>"><?=$row_city1['num']?></a>
		      <?
		 }
		 
		 
}
if(!$found1) echo"-";


?>
        </td>  
  
   
   <?

$select_city2 = "SELECT count(*) as num , city FROM addschool WHERE school_id >= $empid[2] AND school_id < $empid[2]+100000 GROUP BY city ORDER BY city";
$result_city2 = mysql_query($select_city2) or die(mysql_error());
//echo mysql_num_rows($result_city);
//echo $row_city['num'];
?>
        <td align="left">
		<?
		$found2=false;
		 while($row_city2=mysql_fetch_array($result_city2))
{

		if($res['city']==$row_city2['city'])
		 {
		 		$found2=true;
				?>
                <a href="citywise_report.php?emp_id=<?=$empid[2]?>&city=<?=$row_city2['city']?>"><?=$row_city2['num']?></a>
		       <?
		 }
		 
		 
}
if(!$found2) echo"-";


?>
        </td>                           
  
   
   <?

$select_city3 = "SELECT count(*) as num , city FROM addschool WHERE school_id >= $empid[3] AND school_id < $empid[3]+100000 GROUP BY city ORDER BY city";
$result_city3 = mysql_query($select_city3) or die(mysql_error());
//echo mysql_num_rows($result_city);
//echo $row_city['num'];
?>
        <td align="left">
		<?
		$found3=false;
		 while($row_city3=mysql_fetch_array($result_city3))
{

		if($res['city']==$row_city3['city'])
		 {
		 		$found3=true;
				?>
                <a href="citywise_report.php?emp_id=<?=$empid[3]?>&city=<?=$row_city3['city']?>"><?=$row_city3['num']?></a>
		       <?
		 }
		 
		 
}
if(!$found3) echo"-";


?>
        </td>                             
   
  
   
   <?

$select_city4 = "SELECT count(*) as num , city FROM addschool WHERE school_id >= $empid[4] AND school_id < $empid[4]+100000 GROUP BY city ORDER BY city";
$result_city4 = mysql_query($select_city4) or die(mysql_error());
//echo mysql_num_rows($result_city);
//echo $row_city['num'];
?>
        <td align="left">
		<?
		$found4=false;
		 while($row_city4=mysql_fetch_array($result_city4))
{

		if($res['city']==$row_city4['city'])
		 {
		 		$found4=true;
				?>
                <a href="citywise_report.php?emp_id=<?=$empid[4]?>&city=<?=$row_city4['city']?>"><?=$row_city4['num']?></a>
		       <?
		 }
		 
		 
}
if(!$found4) echo"-";


?>
        </td>    
                                
 
   
   <?

$select_city5 = "SELECT count(*) as num , city FROM addschool WHERE school_id >= $empid[5] AND school_id < $empid[5]+100000 GROUP BY city ORDER BY city";
$result_city5 = mysql_query($select_city5) or die(mysql_error());
//echo mysql_num_rows($result_city);
//echo $row_city['num'];
?>
        <td align="left">
		<?
		$found5=false;
		 while($row_city5=mysql_fetch_array($result_city5))
{

		if($res['city']==$row_city5['city'])
		 {
		 		$found5=true;
				?>
                <a href="citywise_report.php?emp_id=<?=$empid[5]?>&city=<?=$row_city5['city']?>"><?=$row_city5['num']?></a>
		       <?
		 }
		 
		 
}
if(!$found5) echo"-";


?>
        </td>   
  
  
   <?

$select_city6 = "SELECT count(*) as num , city FROM addschool WHERE school_id >= $empid[6] AND school_id < $empid[6]+100000 GROUP BY city ORDER BY city";
$result_city6 = mysql_query($select_city6) or die(mysql_error());
//echo mysql_num_rows($result_city);
//echo $row_city['num'];
?>
        <td align="left">
		<?
		$found6=false;
		 while($row_city6=mysql_fetch_array($result_city6))
{

		if($res['city']==$row_city6['city'])
		 {
		 		$found6=true;
				?>
                <a href="citywise_report.php?emp_id=<?=$empid[6]?>&city=<?=$row_city6['city']?>"><?=$row_city6['num']?></a>
		       <?
		 }
		 
		 
}
if(!$found6) echo"-";


?>
        </td>  
          
   
   <?

$select_city7 = "SELECT count(*) as num , city FROM addschool WHERE school_id >= $empid[7] AND school_id < $empid[7]+100000 GROUP BY city ORDER BY city";
$result_city7 = mysql_query($select_city7) or die(mysql_error());
//echo mysql_num_rows($result_city);
//echo $row_city['num'];
?>
        <td align="left">
		<?
		$found7=false;
		 while($row_city7=mysql_fetch_array($result_city7))
{

		if($res['city']==$row_city7['city'])
		 {
		 		$found7=true;
				?>
                <a href="citywise_report.php?emp_id=<?=$empid[7]?>&city=<?=$row_city7['city']?>"><?=$row_city7['num']?></a>
		       <?
		 }
		 
		 
}
if(!$found7) echo"-";


?>
        </td>
               
   
        <?

$select_city8 = "SELECT count(*) as num , city FROM addschool WHERE school_id >= $empid[8] AND school_id < $empid[8]+100000 GROUP BY city ORDER BY city";
$result_city8 = mysql_query($select_city8) or die(mysql_error());
//echo mysql_num_rows($result_city);
//echo $row_city['num'];
?>
        <td align="left">
		<?
		$found8=false;
		 while($row_city8=mysql_fetch_array($result_city8))
{

		if($res['city']==$row_city8['city'])
		 {
		 		$found8=true;
				?>
                <a href="citywise_report.php?emp_id=<?=$empid[8]?>&city=<?=$row_city8['city']?>"><?=$row_city8['num']?></a>
		       <?
		 }
		 
		 
}
if(!$found8) echo"-";


?>
        </td>
              
        <?

 $select_city9 = "SELECT count(*) as num , city FROM addschool WHERE school_id >= $empid[9] AND school_id < $empid[9]+100000 GROUP BY city ORDER BY city";
$result_city9 = mysql_query($select_city9) or die(mysql_error());
//echo mysql_num_rows($result_city);
//echo $row_city['num'];
?>
        <td align="left">
		<?
		$found9=false;
		 while($row_city9=mysql_fetch_array($result_city9))
{

		if($res['city']==$row_city9['city'])
		 {
		 		$found9=true;
				?>
                <a href="citywise_report.php?emp_id=<?=$empid[9]?>&city=<?=$row_city9['city']?>"><?=$row_city9['num']?></a>
		       <?
		 }
		 
		 
}
if(!$found9) echo"-";


?>
        </td>  
        
        
        
        <?

$select_city10 = "SELECT count(*) as num , city FROM addschool WHERE school_id >= $empid[10] AND school_id < $empid[10]+100000 GROUP BY city ORDER BY city";
$result_city10 = mysql_query($select_city10) or die(mysql_error());
//echo mysql_num_rows($result_city);
//echo $row_city['num'];
?>
        <td align="left">
		<?
		$found10=false;
		 while($row_city10=mysql_fetch_array($result_city10))
{

		if($res['city']==$row_city10['city'])
		 {
		 		$found10=true;
				?>
                <a href="citywise_report.php?emp_id=<?=$empid[10]?>&city=<?=$row_city10['city']?>"><?=$row_city10['num']?></a>
		       <?
		 }
		 
		 
}
if(!$found10) echo"-";


?>
        </td>
              
        
       <?

$select_city11 = "SELECT count(*) as num , city FROM addschool WHERE school_id >= $empid[11] AND school_id < $empid[11]+100000 GROUP BY city ORDER BY city";
$result_city11 = mysql_query($select_city11) or die(mysql_error());
//echo mysql_num_rows($result_city);
//echo $row_city['num'];
?>
        <td align="left">
		<?
		$found11=false;
		 while($row_city11=mysql_fetch_array($result_city11))
{

		if($res['city']==$row_city11['city'])
		 {
		 		$found11=true;
				?>
                <a href="citywise_report.php?emp_id=<?=$empid[11]?>&city=<?=$row_city11['city']?>"><?=$row_city11['num']?></a>
		       <?
		 }
		 
		 
}
if(!$found11) echo"-";


?>
        </td> 
        
        <?

$select_city12 = "SELECT count(*) as num , city FROM addschool WHERE school_id >= $empid[12] AND school_id < $empid[12]+100000 GROUP BY city ORDER BY city";
$result_city12 = mysql_query($select_city12) or die(mysql_error());
//echo mysql_num_rows($result_city);
//echo $row_city['num'];
?>
        <td align="left">
		<?
		$found12=false;
		 while($row_city12=mysql_fetch_array($result_city12))
{

		if($res['city']==$row_city12['city'])
		 {
		 		$found12=true;
				?>
                <a href="citywise_report.php?emp_id=<?=$empid[12]?>&city=<?=$row_city12['city']?>"><?=$row_city12['num']?></a>
		       <?
		 }
		 
		 
}
if(!$found12) echo"-";


?>
        </td>
        
         <?

$select_city13 = "SELECT count(*) as num , city FROM addschool WHERE school_id >= $empid[13] AND school_id < $empid[13]+100000 GROUP BY city ORDER BY city";
$result_city13 = mysql_query($select_city13) or die(mysql_error());
//echo mysql_num_rows($result_city);
//echo $row_city['num'];
?>
        <td align="left">
		<?
		$found13=false;
		 while($row_city13=mysql_fetch_array($result_city13))
{

		if($res['city']==$row_city13['city'])
		 {
		 		$found13=true;
				?>
                <a href="citywise_report.php?emp_id=<?=$empid[13]?>&city=<?=$row_city13['city']?>"><?=$row_city13['num']?></a>
		       <?
		 }
		 
		 
}
if(!$found13) echo"-";


?>
        </td>
        
        <?

$select_city14 = "SELECT count(*) as num , city FROM addschool WHERE school_id >= $empid[14] AND school_id < $empid[14]+100000 GROUP BY city ORDER BY city";
$result_city14 = mysql_query($select_city14) or die(mysql_error());
//echo mysql_num_rows($result_city);
//echo $row_city['num'];
?>
        <td align="left">
		<?
		$found14=false;
		 while($row_city14=mysql_fetch_array($result_city14))
{

		if($res['city']==$row_city14['city'])
		 {
		 		$found14=true;
				?>
                <a href="citywise_report.php?emp_id=<?=$empid[14]?>&city=<?=$row_city14['city']?>"><?=$row_city14['num']?></a>
		       <?
		 }
		 
		 
}
if(!$found14) echo"-";


?>
        </td>
        
        <?

$select_city15 = "SELECT count(*) as num , city FROM addschool WHERE school_id >= $empid[15] AND school_id < $empid[15]+100000 GROUP BY city ORDER BY city";
$result_city15 = mysql_query($select_city15) or die(mysql_error());
//echo mysql_num_rows($result_city);
//echo $row_city['num'];
?>
        <td align="left">
		<?
		$found15=false;
		 while($row_city15=mysql_fetch_array($result_city15))
{

		if($res['city']==$row_city15['city'])
		 {
		 		$found15=true;
				?>
                <a href="citywise_report.php?emp_id=<?=$empid[15]?>&city=<?=$row_city15['city']?>"><?=$row_city15['num']?></a>
		       <?
		 }
		 
		 
}
if(!$found15) echo"-";


?>
        </td>
        
        <?

$select_city16 = "SELECT count(*) as num , city FROM addschool WHERE school_id >= $empid[16] AND school_id < $empid[16]+100000 GROUP BY city ORDER BY city";
$result_city16 = mysql_query($select_city16) or die(mysql_error());
//echo mysql_num_rows($result_city);
//echo $row_city['num'];
?>
        <td align="left">
		<?
		$found16=false;
		 while($row_city16=mysql_fetch_array($result_city16))
{

		if($res['city']==$row_city16['city'])
		 {
		 		$found16=true;
				?>
                <a href="citywise_report.php?emp_id=<?=$empid[16]?>&city=<?=$row_city16['city']?>"><?=$row_city16['num']?></a>
		       <?
		 }
		 
		 
}
if(!$found16) echo"-";


?>
        </td>
        
        <?

$select_city17 = "SELECT count(*) as num , city FROM addschool WHERE school_id >= $empid[17] AND school_id < $empid[17]+100000 GROUP BY city ORDER BY city";
$result_city17 = mysql_query($select_city17) or die(mysql_error());
//echo mysql_num_rows($result_city);
//echo $row_city['num'];
?>
        <td align="left">
		<?
		$found17=false;
		 while($row_city17=mysql_fetch_array($result_city17))
{

		if($res['city']==$row_city17['city'])
		 {
		 		$found17=true;
				?>
                <a href="citywise_report.php?emp_id=<?=$empid[17]?>&city=<?=$row_city17['city']?>"><?=$row_city17['num']?></a>
		       <?
		 }
		 
		 
}
if(!$found17) echo"-";


?>
        </td>
        
        <?

$select_city18 = "SELECT count(*) as num , city FROM addschool WHERE school_id >= $empid[18] AND school_id < $empid[18]+100000 GROUP BY city ORDER BY city";
$result_city18 = mysql_query($select_city18) or die(mysql_error());
//echo mysql_num_rows($result_city);
//echo $row_city['num'];
?>
        <td align="left">
		<?
		$found18=false;
		 while($row_city18=mysql_fetch_array($result_city18))
{

		if($res['city']==$row_city18['city'])
		 {
		 		$found18=true;
				?>
                <a href="citywise_report.php?emp_id=<?=$empid[18]?>&city=<?=$row_city18['city']?>"><?=$row_city18['num']?></a>
		       <?
		 }
		 
		 
}
if(!$found18) echo"-";


?>
        </td>
            
          <?

$select_city19 = "SELECT count(*) as num , city FROM addschool WHERE school_id >= $empid[19] AND school_id < $empid[19]+100000 GROUP BY city ORDER BY city";
$result_city19 = mysql_query($select_city19) or die(mysql_error());
//echo mysql_num_rows($result_city);
//echo $row_city['num'];
?>
        <td align="left">
		<?
		$found19=false;
		 while($row_city19=mysql_fetch_array($result_city19))
{

		if($res['city']==$row_city19['city'])
		 {
		 		$found19=true;
				?>
                <a href="citywise_report.php?emp_id=<?=$empid[19]?>&city=<?=$row_city19['city']?>"><?=$row_city19['num']?></a>
		       <?
		 }
		 
		 
}
if(!$found19) echo"-";


?>
        </td>
            
            <?

$select_city20 = "SELECT count(*) as num , city FROM addschool WHERE school_id >= $empid[20] AND school_id < $empid[20]+100000 GROUP BY city ORDER BY city";
$result_city20 = mysql_query($select_city20) or die(mysql_error());
//echo mysql_num_rows($result_city);
//echo $row_city['num'];
?>
        <td align="left">
		<?
		$found20=false;
		 while($row_city20=mysql_fetch_array($result_city20))
{

		if($res['city']==$row_city20['city'])
		 {
		 		$found20=true;
				?>
                <a href="citywise_report.php?emp_id=<?=$empid[20]?>&city=<?=$row_city20['city']?>"><?=$row_city20['num']?></a>
		       <?
		 }
		 
		 
}
if(!$found20) echo"-";


?>
        </td>
            
            <?

$select_city21 = "SELECT count(*) as num , city FROM addschool WHERE school_id >= $empid[21] AND school_id < $empid[21]+100000 GROUP BY city ORDER BY city";
$result_city21 = mysql_query($select_city21) or die(mysql_error());
//echo mysql_num_rows($result_city);
//echo $row_city['num'];
?>
        <td align="left">
		<?
		$found21=false;
		 while($row_city21=mysql_fetch_array($result_city21))
{

		if($res['city']==$row_city21['city'])
		 {
		 		$found21=true;
				?>
                <a href="citywise_report.php?emp_id=<?=$empid[21]?>&city=<?=$row_city21['city']?>"><?=$row_city21['num']?></a>
		       <?
		 }
		 
		 
}
if(!$found21) echo"-";


?>
        </td>
            
            <?

$select_city22 = "SELECT count(*) as num , city FROM addschool WHERE school_id >= $empid[22] AND school_id < $empid[22]+100000 GROUP BY city ORDER BY city";
$result_city22 = mysql_query($select_city22) or die(mysql_error());
//echo mysql_num_rows($result_city);
//echo $row_city['num'];
?>
        <td align="left">
		<?
		$found22=false;
		 while($row_city22=mysql_fetch_array($result_city22))
{

		if($res['city']==$row_city22['city'])
		 {
		 		$found22=true;
				?>
                <a href="citywise_report.php?emp_id=<?=$empid[22]?>&city=<?=$row_city22['city']?>"><?=$row_city22['num']?></a>
		       <?
		 }
		 
		 
}
if(!$found22) echo"-";


?>
        </td>
                                               
    </tr>
                         
 <? 
	 	  $incr++;
	$first++;	
  $i=$i+1;
  } 
	?>
  </table>
        
  <? if($num_rows > 0){	?>
  <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
			  
<tr><td colspan="3"></td></tr>
			  <tr>
				<td   height="26"  valign="middle" background="newbar.jpg" class="table_td_heading" style="padding-left:5px;">
					<span class="table_td_heading">Pages:
					<? if ($pageno==1) { ?>
					&nbsp; 
					<? } else {?> 
					<a href="cityreport.php?pageno=<?=$pageno-1?>" class="table_td_heading">Previous</a>
				    <? } 
					for ($i=1; $i<=$pages;$i++)
					{
					if($pageno==$i)	{?>
				    <strong class="table_td_heading"><? echo $i;?></strong>
				    <? }
						else
					{
					?>
				    <strong><a class="table_td_heading" href="cityreport.php?pageno=<?=$i?>">
					<?=$i?>
					</a></font></strong>
				    <? }
					}
					?>
				    <? if ($pageno<$pages) { ?>
				    <a href="cityreport.php?pageno=<?=$pageno+1?>" class="table_td_heading">Next</a>
				    <? } else {?>
				    <? } ?>				
		        </span></td>
				<td width="40" align="right" valign="middle" background="newbar.jpg" class="data">&nbsp;</td>
				<td width="125" align="center" valign="middle" background="newbar.jpg" class="data"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td align="right" valign="middle" class="table_td_heading" style="padding-right:5px;"><strong>Page</strong>&nbsp;
                    <?=$pageno?>
&nbsp;of&nbsp;
<?=$pages?>                    </td>
                  </tr>
                  
                </table>				  
			    <strong></strong></td>
			  </tr>
</table>
<table width="100%" align="center">
<tr>
<td class="footer" width="942" >&copy; 2009 TeacherSITY. All rights reserved</td>
</tr>

</table>
  <? }?>

</form>

</body>
</html>
