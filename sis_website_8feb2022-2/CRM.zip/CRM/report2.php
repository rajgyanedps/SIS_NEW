<?php 
ob_start();
require_once('connection.php'); 
?>
<?php
//$today = date("Y-m-d");
//$thisMonth=date("Y-m%");
//$time = time("H:i:s");
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Cumulative_Report.xls");
header("Pragma: no-cache");
header("Expires: 0");
$now=date("j-n-Y");
echo "\t \t Report ON ".$now."\t";



$infosrc="";
	if($_GET['information_source']!='')
	{
	$infosrc=" and information_source='".$_GET['information_source']."'";
	}
	
	if (strlen($_GET['date1'])>0)
    {
		$fmt_date1 = date('Y-m-d',strtotime($_GET['date1'])); 
		$strdate1=" and student.joined >='$fmt_date1'";
		$strdate11=" and student.contact_date >='$fmt_date1'";
		$strdate111=" and contact.joined >='$fmt_date1'";
	}
				
   if (strlen($_GET['date2'])>0)
   {
   		$fmt_date2 = date('Y-m-d',strtotime($_GET['date2'])); 
		$strdate2=" and student.joined <='$fmt_date2'";
		$strdate22=" and student.contact_date <='$fmt_date2'";
		$strdate222=" and contact.joined <='$fmt_date2'";
	}

$sql_cust = "SELECT emp_name,emp_id FROM members WHERE username!='Open Data' and user_type!='Admin' and username!='del_school' order by emp_name";


/*	
 $sql_cust = "SELECT emp_name,emp_id, (SELECT count(*) FROM student WHERE student.emp_id=members.emp_id $infosrc $strdate1 $strdate2) as school,(SELECT count(*) from contact INNER JOIN student ON student.stud_id=contact.stud_id where student.emp_id=members.emp_id and contact_date!='0000-00-00 00:00:00' $infosrc $strdate1 $strdate2) as totcnt, (SELECT count(*) from student where student.emp_id=members.emp_id and contact_date!='0000-00-00 00:00:00' $infosrc $strdate11 $strdate22) as totcnt1 ,(SELECT count(*) from student where student.emp_id=members.emp_id $infosrc $strdate1 $strdate2  and status='Positive') as positive, (SELECT count(*) from student where student.emp_id=members.emp_id $infosrc $strdate1 $strdate2 and status='Negative') as negative, (SELECT count(*) from student where student.emp_id=members.emp_id $infosrc $strdate1 $strdate2 and status='Moderate') as moderate, (SELECT count(*) from student where student.emp_id=members.emp_id $infosrc $strdate1 $strdate2 and status='Paid') as paid, (SELECT count(*) from student where student.emp_id=members.emp_id $infosrc $strdate1 $strdate2 and status='Admission') as Admission FROM members WHERE username!='Open Data' and user_type!='Admin' and username!='del_school' order by emp_name";
*/	

$result	= mysql_query($sql_cust) or die(mysql_error());
		$count = 0;
		$total1=0;
		$total22=0;
		$total2=0;
		$total3=0;
		$total4=0;
		$total5=0;
		$total51=0;
		$total52=0;
		$total6=0;
		$total7=0;
		$total8=0;
		$total9=0;


print("\n");
print("\n");
	    echo "S.No."."\t";
		echo "Emp Name"."\t";
		echo "No. of Student"."\t";
		
		echo "Students Contacted"."\t";	
		echo "No. of Calls"."\t";
		echo "Admission"."\t";	
					
		echo "Paid Student"."\t";
		echo "Positive Student"."\t";
		echo "Moderate Student"."\t";
		echo "Negative Student"."\t";
		echo "No Contacted Student"."\t";
		echo "Session(2013-14) Student"."\t";
						
		print("\n"); 
		$i=1;
 while($res=mysql_fetch_array($result))
{

$total1=$total1+$res ['school'];
$total22=$total22+$res ['Admission'];
$total2=$total2+$res ['paid'];
$total3=$total3+$res ['positive'];
$total4=$total4+$res ['moderate'];
$total5=$total5+$res ['negative'];
$total51=$total51+$res ['NoContact'];
$total52=$total52+$res ['Session2013-14'];
$total6=$total6+$res ['test'];
$total7=$total7+$res ['totalamt'];
$total8=$total8+$res ['paidamt'];
$total10=$total10+$res ['totcnt'];
$total101=$total101+$res ['totcnt1'];
$total9=$total9+$res['totalamt'] - $res['paidamt'];

    // echo $count;
     //echo $res['emp_name'];
     
      $qry_stud = "SELECT count(*) as studno FROM student WHERE student.emp_id='".$res ['emp_id']."' $infosrc $strdate1 $strdate2";
	  $res_stud = mysql_query($qry_stud) or die(mysql_error());
	 
	  
	  $row_stud = mysql_fetch_array($res_stud );
	  //echo $row_stud['studno'];
	  
	  $total_studno=$total_studno+$row_stud['studno'];
	  
	  
	  $qry_contact = "SELECT count(*) as stud_contact from student where student.emp_id='".$res ['emp_id']."' and contact_date!='0000-00-00 00:00:00' $infosrc $strdate11 $strdate22";
	  $res_contact = mysql_query($qry_contact) or die(mysql_error());
	 
	  
	  $row_contact = mysql_fetch_array($res_contact);
	  //echo $row_contact['stud_contact'];
	  
	  $total_contact=$total_contact+$row_contact['stud_contact'];
	  
  
	  $qry_calls = "SELECT count(*) as calls from contact INNER JOIN student ON student.stud_id=contact.stud_id where student.emp_id='".$res ['emp_id']."' $infosrc $strdate111 $strdate222";
	 $res_calls = mysql_query($qry_calls) or die(mysql_error());
	 
	  
	  $row_calls = mysql_fetch_array($res_calls);
	  //echo $row_calls['calls'];
	  
	  $total_calls=$total_calls+$row_calls['calls'];
	  
    
	  $qry_admit = "SELECT count(*) as admit from student where student.emp_id='".$res ['emp_id']."' $infosrc $strdate11 $strdate22 and status='Admission'";
	 $res_admit = mysql_query($qry_admit) or die(mysql_error());
	 
	  
	  $row_admit = mysql_fetch_array($res_admit);
	  //echo $row_admit['admit'];
	  
	  $total_admit=$total_admit+$row_admit['admit'];
	  
    
	  
	  $qry_paid = "SELECT count(*) as paid_stud from student where student.emp_id='".$res ['emp_id']."' $infosrc $strdate11 $strdate22 and status='Paid'";
	 $res_paid = mysql_query($qry_paid) or die(mysql_error());
	 
	  
	  $row_paid = mysql_fetch_array($res_paid);
	  //echo $row_paid['paid_stud'];
	  
	  $total_paid=$total_paid+$row_paid['paid_stud'];
	  
  
	  $qry_positive = "SELECT count(*) as positive_stud from student where student.emp_id='".$res ['emp_id']."' $infosrc $strdate11 $strdate22 and status='Positive'";
	 $res_positive = mysql_query($qry_positive) or die(mysql_error());
	 
	  
	  $row_positive = mysql_fetch_array($res_positive);
	  //echo $row_positive['positive_stud'];
	  
	  $total_positive=$total_positive+$row_positive['positive_stud'];
	  
	  $qry_mod = "SELECT count(*) as mod_stud from student where student.emp_id='".$res ['emp_id']."' $infosrc $strdate11 $strdate22 and status='Moderate'";
	 $res_mod = mysql_query($qry_mod) or die(mysql_error());
	 
	  
	  $row_mod = mysql_fetch_array($res_mod);
	  //echo $row_mod['mod_stud'];
	  
	  $total_mod=$total_mod+$row_mod['mod_stud'];
	
	  $qry_neg = "SELECT count(*) as neg_stud from student where student.emp_id='".$res ['emp_id']."' $infosrc $strdate11 $strdate22 and status='Negative'";
	 $res_neg = mysql_query($qry_neg) or die(mysql_error());
	 
	  
	  $row_neg = mysql_fetch_array($res_neg);
	  //echo $row_neg['neg_stud'];
	  
	  $total_neg=$total_neg+$row_neg['neg_stud'];
	  
	 $qry_nocontacted = "SELECT count(*) as nocontacted_stud from student where student.emp_id='".$res ['emp_id']."' $infosrc $strdate11 $strdate22 and status='NoContact'";
	 $res_nocontacted = mysql_query($qry_nocontacted) or die(mysql_error());
	 
	  
	  $row_nocontacted = mysql_fetch_array($res_nocontacted);
	  echo $row_nocontacted['nocontacted_stud'];
	  
	  $total_nocontacted=$total_nocontacted+$row_nocontacted['nocontacted_stud'];
	  
	  
	  
	  $qry_newsession = "SELECT count(*) as newsession_stud from student where student.emp_id='".$res ['emp_id']."' $infosrc $strdate11 $strdate22 and status='Session2013-14'";
	  $res_newsession = mysql_query($qry_newsession) or die(mysql_error());
	 
	  
	  $row_newsession = mysql_fetch_array($res_newsession);
	  //echo $row_neg['neg_stud'];
	  
	  $total_newsession=$total_newsession+$row_newsession['newsession_stud'];

        echo $i."\t";
		echo $res['emp_name']."\t";
		echo $row_stud['studno']."\t";
		echo $row_contact['stud_contact']."\t";
		echo $row_calls['calls']."\t";
		echo $row_admit['admit']."\t";
		
		//echo $row['Admission']."\t";
		echo $row_paid['paid_stud']."\t";
		echo $row_positive['positive_stud']."\t";
		echo $row_mod['mod_stud']."\t";
		echo $row_neg['neg_stud']."\t";
		echo $row_nocontacted['nocontacted_stud']."\t";
		echo $row_newsession['newsession_stud']."\t";
		print "\n";
		$i+=1;	
}

?>