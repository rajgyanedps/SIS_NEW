<? 
    session_start();
    error_reporting(0);
    if($_SESSION['loggedin']!=1 && $_SESSION['username']!=""){
        header("location:login.php");
     }
    
    date_default_timezone_set('Asia/Calcutta');
    @extract($_GET);
    @extract($_POST);
    @extract($_REQUEST);
    
    include("connection.php");
    if(isset($_REQUEST['save_reg_comment'])){
    $today_date = date('Y-m-d H:i:s');
    $added_by = $_SESSION['user_id'];
      $ins = "insert into application_comments SET
                                             app_id           = '".$_REQUEST['app_id']."',
    										 added_by         = '".$added_by."',
    										 comment_msg      = '".$_REQUEST['message']."',
    										 comment_date     = '".$today_date."'";
      $qry = mysql_query($ins);
                                            
    
     }
   //echo "select stud_name, followup from student where stud_id = '".$_REQUEST['app_id']."' ORDER BY `stud_id` ASC"; die;
 
    ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <title>Administrator Home Page</title>
        <link href="DD-menu.css" rel="stylesheet" type="text/css" />
        <script type="text/javascript" src="js/jquery.js"></script>
        <link rel="stylesheet" href="css/screen.css" type="text/css" media="screen" title="default" />
        <!--[if IE]>
        <link rel="stylesheet" media="all" type="text/css" href="css/pro_dropline_ie.css" />
        <![endif]-->
        <!--  jquery core -->
        <link type="text/css" href="jscal/themes/start/ui.all.css" rel="stylesheet" />
        <!--   <script type="text/javascript" src="../js/jquery-1.4.4.min.js"></script>-->
        <script type="text/javascript" src="jscal/ui/ui.core.js"></script>
        <script type="text/javascript" src="jscal/ui/ui.datepicker.js"></script>
        <style type="text/css">
            .mytable td { border:none !important; }
            input[type="submit"] {
            border:0;
            border-radius:5px;
            padding:5px 10px;
            color:#ffffff;
            cursor:pointer;
            background: #078542;
            background: -moz-linear-gradient(#078542 0%, #006532 100%);
            background: -webkit-gradient(linear, left top, left bottom, color-stop(0%, #078542), color-stop(100%, #006532));
            background: -webkit-linear-gradient(#078542 0%, #006532 100%);
            background: linear-gradient(#078542 0%, #006532 100%);
            }
            input[type="submit"]:hover {
            background: #0ea253;
            background: -moz-linear-gradient(#0ea253 0%, #078542 100%);
            background: -webkit-gradient(linear, left top, left bottom, color-stop(0%, #0ea253), color-stop(100%, #078542));
            background: -webkit-linear-gradient(#0ea253 0%, #078542 100%);
            background: linear-gradient(#0ea253 0%, #078542 100%);
            }
        </style>
    </head>
    <body>
        <div id="container">
            <form  id="japplication" name="japplication" method="post" action="">
				<div class="cl"></div>
				<div class="cl"></div>
				<div id="contenttop"></div>
				<div id="content">
				<!-- <h1>View Applications</h1>-->
				<div class="cl"></div>
				<br><br>
				<div class="cl"></div>
					<table width="100%" border="0" cellspacing="0" cellpadding="0" class="mytable">
					<?php
					  //echo "select stud_name, followup from student where stud_id = '".$_REQUEST['app_id']."'";die;
					$sel_app = "select stud_name from student where stud_id = '".$_REQUEST['app_id']."'";
					$qry_app = mysql_query($sel_app); 
					$res_stu = mysql_fetch_assoc($qry_app);
					
					
					?>
						<tr>
							<td><strong>Name</strong></td>
							<td><?=$res_stu['stud_name']?></td>
						</tr>
					</table>
					<br>
                    <table width="100%" border="1" cellspacing="0" cellpadding="0" class="mytable">
                        <tr>
                            <th style="background:#333333; color:#ffffff;"><strong>Comment</strong></th>
                        </tr>
                        <?php 
                   $sel="select t1.followup, t1.other, t1.joined , t1.remarktime from contact as t1 inner join student as t2 on t1.stud_id= t2.stud_id where t1.stud_id = '".$_REQUEST['app_id']."' order by joined desc ";
                            $qry = mysql_query($sel);
                            $i=1;
                            while($res = mysql_fetch_assoc($qry))
                            {?>
                        <tr>
                            <td>
                                <div style="font-size:13px; height:auto; background:#eaeaea; border-radius:5px; margin:2px 0; padding:5px 10px; width:500px;">
						
								<?php 
                   								if($res['followup'] == 'Other'){
												echo $res['other'];}
												else{
													echo $res['remarktime'];
								}
								?>
								
								<br>
                                    <div style="font-size:10px; text-align:right;"><?=date("d-M-Y, g:i a", strtotime($res['joined']))?></div>
                                </div>
                            </td>
                        </tr>
                        <?php $i++;}?>
                    </table>
					
				</div>
            </form>
        </div>
    </body>
</html>