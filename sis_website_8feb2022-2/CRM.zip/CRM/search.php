<?php
include("connection.php");
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Search School</title>
<script type="text/javascript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
</head>
<body bgcolor="#66CCFF">
<input name="tsity" type="image" src="tsity.JPG"/>
<?php
if ($_SESSION['user_type']=="Project Manager")
{
include("links.php");
}
else if ($_SESSION['user_type']=="Tele Caller")
{
include("tclink.php");
}
else
{
include("adminlink.php");
}
?>
<form name="search" method="post" action="search.php">
<table border="1" align="center"> 
<tr><td bgcolor="#0099FF">&nbsp;&nbsp;<strong>Search School</strong></td></tr>
<tr><td>
<table width="491" align="center">
<tr><td colspan="3"></td></tr>
<tr><td>Search By</td>
<td>:</td>
<td><select name="searchby">
<option>Please Select One Criteria</option>
<option>School Name</option>
<option>City</option>
<option>School Id</option>
</select>
</td></tr>
<tr><td>Enter School Name</td>
<td>:</td>
<td><input type="text" name="schoolname1" size="35" /></td></tr>
<tr><td>Enter City</td>
<td>:</td>
<td><input type="text" name="city1" size="35" /></td></tr>
<tr><td>Enter School Id</td>
<td>:</td>
<td><input type="text" name="schoolid1" size="35" /></td></tr>
<tr><td colspan="3"></td></tr>
<tr><td colspan="3"></td></tr>
<tr><td colspan="3" align="center"><input type="submit" name="submit" value="Search" /></td></tr>
</table></td></tr></table>



<table width="945" align="center" border="1">
<tr bgcolor="#999999" align="center">
      <td width="37" background="footerbg.jpg" class="whitetxt11">S.No.</td>
       <td width="59" background="footerbg.jpg" class="whitetxt11"><a href="search.php?pageno=<?=$_REQUEST['pageno']?>">School Id</a></td>
       <td width="190" background="footerbg.jpg" class="whitetxt11"><a href="search.php?pageno=<?=$_REQUEST['pageno']?>">School Name</a></td>
       <td width="163" background="footerbg.jpg" class="whitetxt11"><a href="search.php?pageno=<?=$_REQUEST['pageno']?>">Address 1</a></td>
      <td width="161" background="footerbg.jpg" class="whitetxt11"><a href="search.php?pageno=<?=$_REQUEST['pageno']?>">Address 2</a></td>
      <td width="112" background="footerbg.jpg" class="whitetxt11"><a href="search.php?pageno=<?=$_REQUEST['pageno']?>">City</a></td>
       <td width="86" background="footerbg.jpg" class="whitetxt11"><a href="search.php?pageno=<?=$_REQUEST['pageno']?>">Phone No.</a></td>
                                     
       <td width="85" background="footerbg.jpg" class="whitetxt11"><a href="search.php?pageno=<?=$_REQUEST['pageno']?>">Mob No.</a></td>
    </tr>
       
     	<? 
		if(isset($_POST['submit']))
{
$sql_cust="SELECT * FROM addschool WHERE school_name like '".$_POST['schoolname1']."%' and school_id like '".$_POST['schoolid1']."%' and city like '".$_POST['city1']."%'";
}

		$result	= mysql_query($sql_cust) or die(mysql_error());
		$num_rows 	= mysql_num_rows($result);	
		$incr = 1;
		
		if(!$_REQUEST['pageno']){
			$pageno = 1;
		} else {
			$pageno= $_REQUEST['pageno'];
		}
		$pagesize=15;
		$incr = (($pageno-1)*$pagesize)+1;
		$first=$pageno*$pagesize-($pagesize-1);
		$last=$first+$pagesize-1; 
		$temp=($num_rows%$pagesize);
		if ($temp==0)
		$pages=($num_rows/$pagesize);
		else
		$pages=($num_rows/$pagesize)+1;
		settype($pages, "integer"); 

		for($i=1;$i<$first;$i++)
			$row2000=mysql_fetch_row($result);
     
     
     
//<?php
//$query="SELECT * FROM addschool";
//$result=mysql_query($query) or die(mysql_error());
while($res=mysql_fetch_array($result) and ($first<=$last))
{

if($i%2==0) {
	           $x = "bgcolor='#F0F0F0'";
	          } else {
	            $x = "bgcolor='#D8D8D8'";
 	          }
?>
     <tr <?=$x;?> align="left">
        <td><? echo $i;?>.</td>
             <td><?php echo $res['school_id'];?></td>
                <td><a href="#" onClick="MM_openBrWindow('schoolinfo.php?school_id=<? echo $res['school_id'];?>','SchoolInfo','width=650,height=400')"><?php echo $res['school_name'];?></a></td>
                     <td><?php echo $res['add1'];?></td>
                         <td><?php echo $res['add2'];?></td>
                             <td><?php echo $res['city'];?></td>
                                 <td><?php echo $res['phone_code']." ".$res['phone_no']; ?></td>
                                     <td><?php echo $res['mobno'];?></td>
     </tr>
    <? 
	 	  $incr++;
	$first++;	
  $i=$i+1;
  } 
	?>
    </table>
        
  <? if($num_rows > 0){	?>
  <table width="95%" border="0" align="center" cellpadding="0" cellspacing="0">
			  
<tr><td colspan="3"></td></tr>
			  <tr>
				<td   height="26"  valign="middle" background="newbar.jpg" class="table_td_heading" style="padding-left:5px;">
					<span class="table_td_heading">Pages:
					<? if ($pageno==1) { ?>
					&nbsp; 
					<? } else {?> 
					<a href="search.php?pageno=<?=$pageno-1?>&orderby=<?=$orderby?>&sortby=<?=$sortby?>" class="table_td_heading">Previous</a>
				    <? } 
					for ($i=1; $i<=$pages;$i++)
					{
					if($pageno==$i)	{?>
				    <strong class="table_td_heading"><? echo $i;?></strong>
				    <? }
						else
					{
					?>
				    <strong><a class="table_td_heading" href="search.php?pageno=<?=$i?>&orderby=<?=$orderby?>&sortby=<?=$sortby?>">
					<?=$i?>
					</a></font></strong>
				    <? }
					}
					?>
				    <? if ($pageno<$pages) { ?>
				    <a href="search.php?pageno=<?=$pageno+1?>&orderby=<?=$orderby?>&sortby=<?=$sortby?>" class="table_td_heading">Next</a>
				    <? } else {?>
				    <? } ?>				
		        </span></td>
				<td width="40" align="right" valign="middle" background="newbar.jpg" class="data">&nbsp;</td>
				<td width="125" align="center" valign="middle" background="newbar.jpg" class="data"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td align="right" valign="middle" class="table_td_heading" style="padding-right:5px;"><strong>Page</strong>&nbsp;
                    <?=$pageno?>
&nbsp;of&nbsp;
<?=$pages?>                    </td>
                  </tr>
                  
                </table>				  
			    <strong></strong></td>
			  </tr>
</table>
<table align="center">
<tr><td class="footer" width="917" >&copy; 2009 TeacherSITY. All rights reserved</td></tr>

</table>
  <? }?>









</form>

</body>
</html>