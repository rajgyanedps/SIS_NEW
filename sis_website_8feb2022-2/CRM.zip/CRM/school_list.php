<?php
session_start();
include("connection.php");
if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='Project Manager' && $_SESSION['user_type']!='Tele Caller')
//if (!isset($_SESSION[myusername]))
{
 header("Location: index.php");
}
$school_id =  $_GET['school_id']+100000;
?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Employee School Report</title>
<script type="text/javascript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php
include("reportheader.php");
?>
<?php
$sql1 = "select * from members WHERE emp_id='".$_GET['emp_id']."'";
$result11 = mysql_query($sql1);
$res1 = mysql_fetch_array($result11);

$sql = "SELECT addschool.school_id,school_name, add1, city, phone_code, phone_no, mobno, 
status FROM addschool
LEFT JOIN last_contact ON addschool.school_id = last_contact.school_id
having addschool.school_id >='".$_GET['school_id']."' AND addschool.school_id <'$school_id'";
$result1 = mysql_query($sql) or die(mysql_error());;
$num_rows = mysql_num_rows($result1);

?>
<form action="contactreport.php" method="post" name="contactreport">
<table><tr><td align="left"><font size="4.5" face="Verdana, Arial, Helvetica, sans-serif"><b>School List:- <? echo $res1['emp_name'];?> </b></font></td></tr></table>


<br /><br />

<table width="100%" border="1" align="center" cellpadding="5" cellspacing="2" style="font-size:13px">

<tr bgcolor="#999999" align="center">

      <td align="left" background="footerbg.jpg" class="whitetxt11" width="5%">S.No.</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="20%"><a href="school_list.php?pageno=<?=$_REQUEST['pageno']?>">School Name</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="15%">Address</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="10%"><a href="school_list.php?pageno=<?=$_REQUEST['pageno']?>">City</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="12%">Phone No</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="13%">Mob No</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="13%">Status</td>
      </tr>
                <? 
	  
		$incr = 1;
		
		if(!$_REQUEST['pageno']){
			$pageno = 1;
		} else {
			$pageno= $_REQUEST['pageno'];
		}
		$pagesize=100;
		$incr = (($pageno-1)*$pagesize)+1;
		$first=$pageno*$pagesize-($pagesize-1);
		$last=$first+$pagesize-1; 
		$temp=($num_rows%$pagesize);
		if ($temp==0)
		$pages=($num_rows/$pagesize);
		else
		$pages=($num_rows/$pagesize)+1;
		settype($pages, "integer"); 

		for($i=1;$i<$first;$i++)
			$row2000=mysql_fetch_row($result1);
     
     
     
//<?php
//$query="SELECT * FROM addschool";
//$result=mysql_query($query) or die(mysql_error());
while($res1=mysql_fetch_array($result1) and ($first<=$last))
{
if($i%2==0) {
	           $x = "bgcolor='#F0F0F0'";
	          } else {
	            $x = "bgcolor='#D8D8D8'";
 	          }
?>

<tr <?=$x;?> align="left">
        <td width="5%"><? echo $i;?>.</td>
      <td width="20%"><?php echo $res1['school_name'];?></td>
                <td width="15%"><?php echo $res1['add1'];?></td>
                    
                         <td width="12%"><?php echo $res1['city'];?></td>
                             <td width="13%"><?php echo $res1['phone_code']." ".$res1['phone_no'];?></td>

                                 <td width="12%"><?php echo $res1['mobno'];?></td>
                                  <td width="12%"><?php if($res1['status']=='Positive'){?> <img src="image/green.gif" border="0" name="plus_sign" alt="Click here to view positive report" align="center"/><? } else if($res1['status']=='Negative'){ ?><img src="image/red.gif" border="0" name="minus_sign" alt="Click here to view negative report" align="center"/><? } else if($res1['status']=='Moderate'){ ?><img src="image/mod.gif" border="0" name="minus_sign" align="center"/><? }else echo "-";?></td>
    </tr>
                         
 <? 
	 	  $incr++;
	$first++;	
  $i=$i+1;
  } 
	?>
  </table>
        
  <? if($num_rows > 0){	?>
  <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
			  
<tr><td colspan="3"></td></tr>
			  <tr>
				<td   height="26"  valign="middle" background="newbar.jpg" class="table_td_heading" style="padding-left:5px;">
					<span class="table_td_heading">Pages:
					<? if ($pageno==1) { ?>
					&nbsp; 
					<? } else {?> 
					<a href="school_list.php?pageno=<?=$pageno-1?>&school_id=<?=$_GET['school_id']?>" class="table_td_heading">Previous</a>
				    <? } 
					for ($i=1; $i<=$pages;$i++)
					{
					if($pageno==$i)	{?>
				    <strong class="table_td_heading"><? echo $i;?></strong>
				    <? }
						else
					{
					?>
				    <strong><a class="table_td_heading" href="school_list.php?pageno=<?=$i?>&school_id=<?=$_GET['school_id']?>">
					<?=$i?>
					</a></font></strong>
				    <? }
					}
					?>
				    <? if ($pageno<$pages) { ?>
				    <a href="school_list.php?pageno=<?=$pageno+1?>&school_id=<?=$_GET['school_id']?>" class="table_td_heading">Next</a>
				    <? } else {?>
				    <? } ?>				
		        </span></td>
				<td width="40" align="right" valign="middle" background="newbar.jpg" class="data">&nbsp;</td>
				<td width="125" align="center" valign="middle" background="newbar.jpg" class="data"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td align="right" valign="middle" class="table_td_heading" style="padding-right:5px;"><strong>Page</strong>&nbsp;
                    <?=$pageno?>
&nbsp;of&nbsp;
<?=$pages?>                    </td>
                  </tr>
                  
                </table>				  
			    <strong></strong></td>
			  </tr>
</table>
<table width="100%" align="center">
<tr>
<td class="footer" width="955" >&copy; 2009 TeacherSITY. All rights reserved</td>
</tr>

</table>
  <? }?>

</form>

</body>
</html>