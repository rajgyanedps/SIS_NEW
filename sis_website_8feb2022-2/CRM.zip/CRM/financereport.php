<?php
session_start();
include("connection.php");
if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='Project Manager' && $_SESSION['user_type']!='Tele Caller')
//if (!isset($_SESSION[myusername]))
{
 header("Location: index.php");
}
$_SESSION['this_page']='financereport.php';
?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>School Payment Report</title>

<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />

</head>
<body>
<?php
include("header.php");
?>
<?
$sql_cust = "SELECT * , (SELECT sum(advanceamm) FROM addammount WHERE addammount.school_id=addschool.school_id limit 1) as totalamt, (SELECT duedate FROM addammount WHERE addammount.school_id=addschool.school_id order by joined desc limit 1) as due FROM addschool, addparticipation, last_totalamm WHERE addschool.school_id=last_totalamm.school_id and addparticipation.school_id=last_totalamm.school_id";

		$result	= mysql_query($sql_cust) or die(mysql_error());
		$num_rows=mysql_num_rows($result);
		?>

<form action="financereport.php" method="post" name="financereport">



<table width="100%">
  <tr>
<td align="right" valign="top" bgcolor="#e9f5ff" style="padding-right:10px"><strong>Records Found: <? echo $num_rows ?></strong></td>
</tr>
<tr>
<td></td>
</tr>
</table>
<table width="100%" border="0" align="center" cellpadding="5" cellspacing="1" bgcolor="#81cafd" style="font-size:12px">
<tr bgcolor="#999999" align="center">

      <td align="left" background="footerbg.jpg" class="whitetxt11">S.No.</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11">School Name</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11">Address</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11">Student</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11">Test</td>
      <td align="left" width="7%" background="footerbg.jpg" class="whitetxt11">Date of Test</td>
      <td align="left" width="6%"background="footerbg.jpg" class="whitetxt11">Total Amt</td>
      <td align="left" width="8%"background="footerbg.jpg" class="whitetxt11">Ammount Paid</td>
      <td align="left" width="7%" background="footerbg.jpg" class="whitetxt11">Balance Amt</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11">Due Date</td>
      
    </tr>
                <? 
	 if($num_rows==0)
{
echo "<div align=center><font color=red size=+1>No Record Found</font></div>";
}
		$count = 0;
		$total1=0;
		$total2=0;
		$total3=0;
		$total4=0;
		$total5=0;
		
while($res=mysql_fetch_array($result))
{
$total1=$total1+$res ['actstudent'];
$total2=$total2+$res ['acttest'];
$total3=$total3+$res ['totalamm'];
$total4=$total4+$res ['totalamt'];
$total5=$total5+$res ['totalamm']-$res ['totalamt'];

if($acol) {
	           $x = "bgcolor='#e9f5ff'";
	          } else {
	            $x = "bgcolor='#d8effe'";
 	          }
			  $acol=!$acol;
			  $count++;
?>

<tr <?=$x;?> align="left">
        <td><? echo $count;?>.</td>
                       
      <td><a href="ammreport.php?school_id=<?=$res['school_id'];?>">
	  <?php echo $res['school_name'];?></a></td>
          <td><?php echo $res['add1'];?><br /><?php echo $res['add2'];?><br /><?php echo $res['city'];?></td>             
      <td><?php echo $res['actstudent'];?></td>
      <td><?php echo $res['acttest'];?></td>
      <td><?php echo date("d-M-y",strtotime($res['datetest']));?></td>
      <td><?php echo $res['totalamm'];?></td>
      <td><?php echo $res['totalamt'];?></td>
      <td><?php echo $res['totalamm']-$res['totalamt'];?></td>
      <td><?php echo date("d-M-y", strtotime($res['due']));?></td>
      
    </tr>
                         
 <? }?>
	<tr bgcolor="#CCFFCC">
 <td colspan="3" style="padding-left:57px"><font size="3px"><b>Sum</b></font></td>
 <td><strong><? echo $total1;?></strong></td>
 <td><strong><? echo $total2;?></strong></td>
 <td>&nbsp;</td>
 <td><strong><? echo $total3;?></strong></td>
 <td><strong><? echo $total4;?></strong></td>
 <td><strong><? echo $total5;?></strong></td>
 <td>&nbsp;</td>

 </tr>		
</table>
<table width="100%" align="center">
<tr>
      <td><img src="image/spacer.gif" height="5" /></td>
    </tr>
<tr>
<td class="footer" width="944" >&copy; 2009 TeacherSITY. All rights reserved</td>
</tr>

</table>
  

</form>

</body>
</html>