<?php
session_start();
include("connection.php");
if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='Project Manager' && $_SESSION['user_type']!='Tele Caller')
//if (!isset($_SESSION[myusername]))
{
 header("Location: index.php");
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>School Complete Report</title>
<script type="text/javascript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php
include("header.php");
?>
<br />
<?php
$query="SELECT * FROM addschool WHERE school_id ='".$_GET['school_id']."'";
$result=mysql_query($query) or die(mysql_error());
$row=mysql_fetch_array($result);
?>
<br />
<br />
<form name="completereport" method="post" action="completereport.php">
  <table width="100%" border="0" align="center" cellpadding="0" cellspacing="5">
    <tr>
      <td width="50%" valign="top"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="font-size:13px; border:solid 1px #71befb;">
          <tr>
            <td height="26" background="footerbg.jpg" class="whitetxt11" style="border-bottom:solid 1px #71befb; font-size:13px; color:#ffffff;">&nbsp;&nbsp;&nbsp;School Profile</td>
          </tr>
          <tr>
            <td><table width="100%" border="0" cellpadding="4" cellspacing="0" bgcolor="#f3f7fd">
                <tr>
                  <td class="dothr" colspan="2" style="padding-left:30px"><font color="#CC0000" size="2px"><? echo $row['school_name'] ?><br />
                    <? echo $row['add1'] ?>,&nbsp;<? echo $row['add2'] ?><br />
                    <? echo $row['city'] ?></font></td>
                </tr>
                <tr>
                  <td width="184" class="dothr"><font color="#CC0000" size="2px"> <img src="images5.jpg" />&nbsp;&nbsp;<? echo $row['phone_code'] ?>-&nbsp;<? echo $row['phone_no'] ?></font></td>
                  <td width="214" class="dothr"><font color="#CC0000" size="2px"><img src="epiphany(32x32).png" border="0" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<? echo $row['website'] ?></font></td>
                </tr>
                <tr>
                  <td width="184" class="dothr"><font color="#CC0000" size="2px"><img src="fax_icon.jpg" />&nbsp;&nbsp;&nbsp;<? echo $row['fax_code'] ?>-&nbsp;<? echo $row['fax_no'] ?></font></td>
                  <td width="214" class="dothr"><font color="#CC0000" size="2px"><font color="#000000"><b>State :</b></font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<? echo $row['state'] ?></font></td>
                </tr>
                <tr>
                  <td width="184" class="dothr"><font color="#CC0000" size="2px"><img src="mobile_icon.gif" />&nbsp;&nbsp;&nbsp;&nbsp;<? echo $row['mobno'] ?></font></td>
                  <td width="214" class="dothr"><font color="#CC0000" size="2px"><img src="pin-48x48.png" border="0" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<? echo $row['pin'] ?></font></td>
                </tr>
                <tr>
                  <td width="184" class="dothr"><font color="#CC0000" size="2px"><img src="email.JPG" />&nbsp;&nbsp;&nbsp;<? echo $row['email'] ?></font></td>
                  <td width="214" class="dothr"><font color="#CC0000" size="2px"><font color="#000000"><b>Affiliation :</b></font>&nbsp;<? echo $row['boardaff'] ?>&nbsp;-&nbsp;<? echo $row['nameboard'] ?></font></td>
                </tr>
                <tr>
                  <td class="dothr" colspan="2"><font color="#000000"><b>School Type :</b></font><font color="#CC0000" size="2px">&nbsp;&nbsp;<? echo $row['schooltype'] ?></font></td>
                </tr>
              </table></td>
          </tr>
        </table></td>
      <td width="50%" valign="top"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="font-size:13px; border:solid 1px #71befb;">
          <tr>
            <td height="26" background="footerbg.jpg" class="whitetxt11" style="border-bottom:solid 1px #71befb; font-size:13px; color:#ffffff;">&nbsp;&nbsp;&nbsp;Dashboard:&nbsp;<? echo $row['school_name'] ?></td>
          </tr>
          <tr>
            <td valign="top"><table width="100%" bgcolor="#FFFFFF">
                <tr>
                  <td width="33%" height="80" align="center" valign="middle"><a href="addcontact.php?school_id=<? echo $row['school_id'];?>"><img src="pennystreet.net_contact_icon2.gif" border="0" /><br />
                    <b>Add Contact</b></a></td>
                  <td width="33%" align="center" valign="middle"><a href="participation.php?school_id=<? echo $row['school_id'];?>"><img src="50px-Handshake_icon.jpg.png" border="0" /><br />
                    <b>Add Participation</b></a></td>
                  <td width="33%" align="center" valign="middle"><a href="ammount.php?school_id=<? echo $row['school_id'];?>"><img src="Green-Dollar-icon.jpg" border="0" /><br />
                    <b>Add Payment</b></a></td>
                </tr>
                <tr>
                  <td width="33%" height="80" align="center" valign="middle"><a href="assessment.php?school_id=<? echo $row['school_id'];?>"><img src="assessment.jpg" border="0" /><br />
                    <b>Add Assessment</b></a></td>
                  <td width="33%" align="center" valign="middle"><a href="addperson.php?school_id=<? echo $row['school_id'];?>"><img src="icon-48x48-person_add.png" border="0" /><br />
                    <b>Add Person</b></a></td>
                  <td width="33%" align="center" valign="middle"><a href="editschool.php?school_id=<? echo $row['school_id'];?>"><img src="edit.png" border="0" /><br />
                    <b>Edit School</b></a></td>
                </tr>
              </table></td>
          </tr>
        </table></td>
    </tr>
    <?php
$qry="SELECT * FROM last_contact WHERE school_id ='".$_GET['school_id']."'";
$res=mysql_query($qry) or die(mysql_error());
$row=mysql_fetch_array($res);
?>
    <tr>
      <td valign="top" align="center"><table width="98%" border="0" cellpadding="5" cellspacing="0" bgcolor="#f3f7fd" style="border:solid 1px #71befb;">
          <tr>
            <td height="26" background="footerbg.jpg" class="whitetxt11" style="border-bottom:solid 1px #71befb; font-size:13px; color:#ffffff;">&nbsp;&nbsp;&nbsp;Contact Report</td>
          </tr>
          <tr>
            <td style="padding-left:20px"><b>Last Contact</b><br />
              on&nbsp;<? echo $row['joined'];?> and Status is&nbsp; <? echo $row['status'];?><br />
              Action :&nbsp;<? echo $row['followup'];?><br />
              <br />
            </td>
          </tr>
          <tr>
            <td align="center"><a href="#" onClick="MM_openBrWindow('contactreport.php?school_id=<? echo $_GET['school_id']?>','contactreport','width=870,height=500')"><img src="butshow.gif" border="0" /></a></td>
          </tr>
        </table></td>
      <?php
$qry1=" SELECT sum( advanceamm ) AS paidamt FROM addammount  WHERE school_id ='".$_GET['school_id']."'";
$res1=mysql_query($qry1) or die(mysql_error());
$row=mysql_fetch_array($res1);
$q="SELECT totalamm FROM addammount WHERE school_id ='".$_GET['school_id']."' order by joined desc";
$a=mysql_query($q) or die(mysql_error());
$row2=mysql_fetch_array($a);
$qr="SELECT expstudent,exptest FROM addparticipation WHERE school_id ='".$_GET['school_id']."'";
$z=mysql_query($qr) or die(mysql_error());
$row3=mysql_fetch_array($z);
?>
      <td align="center" valign="top"><table width="98%" border="0" cellpadding="5" cellspacing="0" bgcolor="#f3f7fd" style="border:solid 1px #71befb;">
          <tr>
            <td height="26" background="footerbg.jpg" class="whitetxt11" style="border-bottom:solid 1px #71befb; font-size:13px; color:#ffffff;">&nbsp;&nbsp;&nbsp;Payment Details</td>
          </tr>
          <tr>
            <td style="padding-left:20px"> Expected No. of Students :&nbsp;<? echo $row3['expstudent'];?><br />
              Expected No. of Tests :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<? echo $row3['exptest'];?><br />
              Toatal Amount Payble :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<? echo (int)$row2['totalamm'];?><br />
              Total Amount Received :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<? echo $row['paidamt'];?><br />
              Due Amount :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<? echo $row2['totalamm'] - $row['paidamt']?> </td>
          </tr>
          <tr>
            <td align="center"><a href="#" onClick="MM_openBrWindow('ammreport.php?school_id=<? echo $_GET['school_id']?>','contactreport','width=870,height=420')"><img src="butshow.gif" border="0" /></a></td>
          </tr>
        </table></td>
    </tr>
  </table>
</form>
</body>
</html>
