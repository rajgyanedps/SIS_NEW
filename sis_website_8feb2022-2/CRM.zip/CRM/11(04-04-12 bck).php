<?php
ob_start();
session_start();
include("connection.php");
if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='School Login' && $_SESSION['user_type']!='Tele Caller')
//if (!isset($_SESSION[myusername]))
{
 header("Location: index.php");
}

if(isset($_POST['walkin_submit']))
{
	$walkin_date = date('Y-m-d',strtotime($_POST['walkin_date']));
	$sql_walkin = "INSERT INTO walkins (stud_id, expected_date, expected_time, walkin_status) VALUES('".$_POST['stud_id']."','$walkin_date','".$_POST['walkintime']."',0)";
	$res_walkin = mysql_query($sql_walkin) or die(mysql_error());
    header("Location: 11.php?stud_id=".$_POST['stud_id']."&walk=Expected Walkin Added Successfully.....");


}


if (isset($_POST['addfees']))
{

$fee_status=$_POST['fee_status'];
if($fee_status=='0')
{
	$fee_amt = '0';

}
else
{
	$fee_amt = $_POST['fee_box'];
	
}

$sql = "UPDATE student SET fee_status='".$_POST['fee_status']."', amount='$fee_amt' WHERE stud_id ='".$_POST['stud_id']."'";
$result=mysql_query($sql) or die(mysql_error());

if($_POST['fee_status']==1)
{
	header("Location: 11.php?stud_id=".$_POST['stud_id']."&msg=Student Fees Added Successfully......");
}
else
{
header("Location: 11.php?stud_id=".$_POST['stud_id']."&msg=");
}


}


if (isset($_POST['submit2']))
{

$remarkdate = $_POST['remarkdate'];
$dd = explode('-',$remarkdate);
$upd_remarkdate = $dd[2].'-'.$dd[1].'-'.$dd[0];


$sql="INSERT INTO contact(stud_id,joined,status,remarkdate,remarktime,followup,other,nextstep,schoolnextstep) VALUES ('".$_POST['stud_id']."',now(),'".$_POST['status']."','$upd_remarkdate','".$_POST['remarktime']."','".$_POST['followup']."','".$_POST['other']."','".$_POST['nextstep']."','".$_POST['schoolother']."')";
$result=mysql_query($sql) or die(mysql_error());

$a="UPDATE student SET contact_date=now(), status='".$_POST['status']."',followup='".$_POST['followup']."',remarkdate='$upd_remarkdate' WHERE stud_id='".$_GET['stud_id']."'";
$x=mysql_query($a) or die(mysql_error());

header("Location: 11.php?stud_id=".$_GET['stud_id']."&msg=Contact Details Added Successfully......");
}

if (isset($_POST['submit4']))
{
$sql="INSERT INTO addammount(stud_id,joined,totalamm,advanceamm,balanceamm,senddate,duedate,chequeno,bankname,city) VALUES ('".$_POST['stud_id']."', now(),'".$_POST['totalamm']."','".$_POST['advanceamm']."','".$_POST['balanceamm']."','".$_POST['senddate']."','".$_POST['duedate']."','".$_POST['chequeno']."','".$_POST['bankname']."','".$_POST['city']."')";
$result=mysql_query($sql) or die(mysql_error());
$q="DELETE FROM last_totalamm WHERE stud_id='".$_GET['stud_id']."'";
$d=mysql_query($q) or die(mysql_error());
$a="INSERT INTO last_totalamm(stud_id,totalamm) VALUES ('".$_GET['stud_id']."','".$_POST['totalamm']."')";
$x=mysql_query($a) or die(mysql_error());
header("Location: 11.php?stud_id=".$_GET['stud_id']."&msg=Payment Details Added Successfully......");
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Student Complete Dashboard</title>
<link rel="stylesheet" type="text/css" href="calendar-blue.css">
<script type="text/javascript" src="calendar.js"></script>
<script type="text/javascript" src="calendar-en.js"></script>
<script type="text/javascript" src="calendar-setup.js"></script>
<script language="javascript1.2" src="tabber.js"></script>
<link rel="stylesheet" type="text/css" href="jquery.fancybox/jquery.fancybox.css" media="screen" />
<link href="css/admin.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="jquery.fancybox/jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="jquery.fancybox/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="jquery.fancybox/jquery.fancybox-1.2.1.pack.js"></script>
<script type="text/javascript">
	$(document).ready(function() {

					  $("a.prnc").fancybox({ 'hideOnContentClick': false ,
					  'overlayShow':true  ,
					  'frameWidth':510 ,
					  'frameHeight':360,
					  'overlayOpacity':0.7}); 


	});
		$(document).ready(function() {

					  $("a.edit").fancybox({ 'hideOnContentClick': false ,
					  'overlayShow':true  ,
					  'frameWidth':500 ,
					  'frameHeight':282,
					  'overlayOpacity':0.7}); 


	});

	$(document).ready(function() {

					  $("a.del").fancybox({ 'hideOnContentClick': false ,
					  'overlayShow':true  ,
					  'frameWidth':530 ,
					  'frameHeight':410,
					  'overlayOpacity':0.7}); 


	});

	</script>
<script type="text/javascript">
/*fees_validation()
{

	if (document.addfee.fee_status.value=="")
	 {
		alert("The Fee Status is blank. \nPlease select the status field in the combo box.");
        document.addfee.fee_status.focus();		
        return false;
      }	
	  return true;

}*/


function showhide5(val)
{
if(val.value=='other')
document.getElementById('divnb3').style.display='block';
else
document.getElementById('divnb3').style.display='none';
}
</script>
<script type="text/javascript">
function showhide1(val)
{
if(val.value=='Other')
document.getElementById('divnb2').style.display='block';
else
document.getElementById('divnb2').style.display='none';
}
</script>
<script type="text/javascript">
function showhide(id)
{
	var obje1=document.getElementById('working');
	
	if(obje1.value=="Other")
	{
	document.getElementById('otherbox').style.visibility = 'visible'; 
	}
	else
	{
	document.getElementById('otherbox').style.visibility = 'hidden'; 
	}
	}

	
function showhide2(val)
{
if(val)
document.getElementById('assess').style.display='block';
else
document.getElementById('assess').style.display='none';
}







function fee_boxshow()
{
if(document.addfee.fee_status.value=="1")
		{
			document.addfee.fee_box.style.visibility = 'visible';
		}
	else
		{
			document.addfee.fee_box.style.visibility = 'hidden'; 
		}
}





function showhide10(val)
{
if(val)
document.getElementById('det').style.display='block';
else
document.getElementById('det').style.display='none';
}

function showhide3()
{

document.getElementById('dnewperson').style.display='block';
}
</script>
<script type="text/javascript">
function showhide4(val)
{
if(val.value=='OTHER')
document.getElementById('divw').style.display='block';
else
document.getElementById('divw').style.display='none';
}
</script>
<script type="text/javascript">
function ValidateForm4()
{
// checking status field	  
if (document.contactdetails.status.value=="")
	 {
		alert("The Status is blank. \nPlease select the status field in the combo box.");
        document.contactdetails.status.focus();		
        return false;
      }	
// checking followup field	  
if (document.contactdetails.followup.value=="")
	 {
		alert("The Followup is blank. \nPlease select the followup field in the combo box.");
        document.contactdetails.followup.focus();		
        return false;
      }		  
// checking other in followup (other)
    if (document.contactdetails.followup.value=="Other")
	   {
	   	  if (document.contactdetails.other.value=="")
	 {
		alert("The other field is blank. \nPlease enter the other followup field in the text box.");
        document.contactdetails.other.focus();		
        return false;
      }		
	  }	  
// checking remark date field
 if (document.contactdetails.followup.value!="Other")
	   {
      if (document.contactdetails.remarkdate.value=="")
	{
		alert("The remark date field is blank. \nPlease enter remark date in the text box.");
		document.contactdetails.remarkdate.focus();
		return false;
      }	 
// checking remark time field
      if (document.contactdetails.remarktime.value=="")
	{
		alert("The Remark time field is blank. \nPlease enter remark time in the text box.");
		document.contactdetails.remarktime.focus();
		return false;
      }	  	}
	  // checking other in schoolnextstep (other)
    if (document.contactdetails.nextstep.value=="other")
	   {
	   	  if (document.contactdetails.schoolother.value=="")
	 {
		alert("The other field is blank. \nPlease enter the other school next step field in the text box.");
        document.contactdetails.schoolother.focus();		
        return false;
      }		
	  }	   	    	      	  
	  }
</script>

<script type="text/javascript">
function Validate_walkins()
{

    if (document.walkin_frm.walkin_date.value=="")
	{
		alert("The Walkin Date field is blank. \nPlease enter Walkin Date in the text box.");
		document.walkin_frm.walkin_date.focus();
		return false;
      }	 
   if (document.walkin_frm.walkintime.value=="")
	{
		alert("The Walkin time field is blank. \nPlease enter Walkin time in the text box.");
		document.walkin_frm.walkintime.focus();
		return false;
      }	  	
	 	    	      	  
}
</script>

<script type="text/javascript">
function ValidateForm2()
{
// checking workingorg. field
	  
	  if (document.assessment.working.value=="")
	 {
		alert("The Working Org. is blank. \nPlease select the working field in the combo box.");
        document.assessment.working.focus();		
        return false;
      }		
// checking nameorg field (if Yes)
      
    if (document.assessment.working.value=="Other")
	   {
	   	  if (document.assessment.other_working.value=="")
	 {
		alert("The Name of the org. field is blank. \nPlease enter the name of the org. field in the text box.");
        document.assessment.other_working.focus();		
        return false;
      }		
	  }	 

      }
     </script>
<script type="text/javascript">
function ValidateForm1()
{
// checking datetest field
      if (document.participation.datetest.value=="")
	{
		alert("The date of test field is blank. \nPlease enter date of test in the text box.");
		document.participation.datetest.focus();
		return false;
      }	 
// checking expstudent field
	  
	  if (document.participation.expstudent.value=="")
	 {
		alert("The Expected Student is blank. \nPlease enter the Expected Student field in the text box.");
        document.participation.expstudent.focus();		
        return false;
      }
	  
//checking numeric value in expstudent
     var n = document.participation.expstudent.value;
    if(isNaN(n) == true) {
        alert('Your entry is not a numberic value in expected student field, Please try again');
        document.participation.expstudent.focus();
        return false;
    }	  	
// checking exptest field
	  
	  if (document.participation.exptest.value=="")
	 {
		alert("The Expected Test is blank. \nPlease enter the Expected Test field in the text box.");
        document.participation.exptest.focus();		
        return false;
      }
	  
//checking numeric value in exptest
     var n = document.participation.exptest.value;
    if(isNaN(n) == true) {
        alert('Your entry is not a numberic value in expected test field, Please try again');
        document.participation.exptest.focus();
        return false;
    }	  
	// checking expstudent field
	  
	  if (document.participation.actstudent.value=="")
	 {
		alert("The Actual Student is blank. \nPlease enter the Actual Student field in the text box.");
        document.participation.actstudent.focus();		
        return false;
      }
	  
//checking numeric value in actstudent
     var n = document.participation.actstudent.value;
    if(isNaN(n) == true) {
        alert('Your entry is not a numberic value in actual student field, Please try again');
        document.participation.actstudent.focus();
        return false;
    }	  
	// checking exptest field
	  
	  if (document.participation.acttest.value=="")
	 {
		alert("The Actual Test is blank. \nPlease enter the Actual Test field in the text box.");
        document.participation.acttest.focus();		
        return false;
      }	  	
//checking numeric value in acttest
     var n = document.participation.acttest.value;
    if(isNaN(n) == true) {
        alert('Your entry is not a numberic value in actual test field, Please try again');
        document.participation.acttest.focus();
        return false;
    }	  	  						   	
	  }
</script>
<script type="text/javascript">
function ValidateForm3()
{
// checking surname field
	  
	  if (document.contactperson.surname.value=="")
	 {
		alert("The Surname is blank. \nPlease select the surname field in the combo box.");
        document.contactperson.surname.focus();		
        return false;
      }		
// checking name field
      if (document.contactperson.name2.value=="")
	{
		alert("The Name field is blank. \nPlease enter name in the text box.");
		document.contactperson.name2.focus();
		return false;
      }	  	    
	  
//checking alphabetic values in name

    var iChars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ';
    for (i = 0; i < document.contactperson.name2.value.length; i++) {
      if (iChars.indexOf(document.contactperson.name2.value.charAt(i)) == -1) {
         alert('Please enter letters only in Name field');
         document.contactperson.name2.focus();
         return false;
      }
      }	
// checking designation field	  
if (document.contactperson.desig.value=="")
	 {
		alert("The designation is blank. \nPlease select the designation field in the combo box.");
        document.contactperson.desig.focus();		
        return false;
      }	
  
// checking otherdesig in designation (OTHER)
    if (document.contactperson.desig.value=="OTHER")
	   {
	   	  if (document.contactperson.otherdesig.value=="")
	 {
		alert("The other designation field is blank. \nPlease enter the other designation field in the text box.");
        document.contactperson.otherdesig.focus();		
        return false;
      }		
	  }	  

//checking numeric value in phonecode
     var n = document.contactperson.phonecode.value;
    if(isNaN(n) == true) {
        alert('Your entry is not a numberic value in code no. field, Please try again');
        document.contactperson.phonecode.focus();
        return false;
    }	  

//checking numeric value in phoneno
     var n = document.contactperson.phoneno.value;
    if(isNaN(n) == true) {
        alert('Your entry is not a numberic value in phone no. field, Please try again');
        document.contactperson.phoneno.focus();
        return false;
    }	  	

//checking numeric value in mobno
     var n = document.contactperson.mobno.value;
    if(isNaN(n) == true) {
        alert('Your entry is not a numberic value in mob. no. field, Please try again');
        document.contactperson.mobno.focus();
        return false;
    }	  		  
//checking numeric value in faxcode
     var n = document.contactperson.faxcode.value;
    if(isNaN(n) == true) {
        alert('Your entry is not a numberic value in code no. field, Please try again');
        document.contactperson.faxcode.focus();
        return false;
    }	  
//checking numeric value in faxno
     var n = document.contactperson.faxno.value;
    if(isNaN(n) == true) {
        alert('Your entry is not a numberic value in fax no. field, Please try again');
        document.contactperson.faxno.focus();
        return false;
    }	  	  		
	  }
</script>
<script language="javascript">
function calc()
{
var a = document.addammount.advanceamm.value;
var t = document.addammount.totalamm.value;
var p = document.addammount.alreadypaid.value;
document.addammount.balanceamm.value = (t-p)-a;

}



function ValidateForm()
{
// checking advanceammount field
	  
	  if (document.addammount.advanceamm.value=="")
	 {
		alert("The Advance Ammount is blank. \nPlease enter the Advance Ammount field in the text box.");
        document.addammount.advanceamm.focus();		
        return false;
      }
	  
//checking numeric value in advanceammount
     var n = document.addammount.advanceamm.value;
    if(isNaN(n) == true) {
        alert('Your entry is not a numberic value in advance ammount field, Please try again');
        document.addammount.advanceamm.focus();
        return false;
    }	
// checking balanceammount field
	  
	  if (document.addammount.balanceamm.value=="")
	 {
		alert("The Balance Ammount is blank. \nPlease click the Balance button.");
        document.addammount.balanceamm.focus();		
        return false;
      }	 
// checking senddate field
	  
	  if (document.addammount.senddate.value=="")
	 {
		alert("The Send Date is blank. \nPlease click the calander button.");
        document.addammount.senddate.focus();		
        return false;
      }	
// checking duedate field
	  
	  if (document.addammount.duedate.value=="")
	 {
		alert("The Due Date is blank. \nPlease click the calander button.");
        document.addammount.duedate.focus();		
        return false;
      }	
// checking chequeno. field
	  
	  if (document.addammount.chequeno.value=="")
	 {
		alert("The Cheque No. is blank. \nPlease enter the cheque no. in the text box.");
        document.addammount.chequeno.focus();		
        return false;
      }		
// checking bankname field
	  
	  if (document.addammount.bankname.value=="")
	 {
		alert("The Bank Name is blank. \nPlease enter the bank name in the text box.");
        document.addammount.bankname.focus();		
        return false;
      }		  	  
// checking city field
	  
	  if (document.addammount.city.value=="")
	 {
		alert("The City is blank. \nPlease enter the city in the text box.");
        document.addammount.city.focus();		
        return false;
      }			  		  	   		  
}
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
function MM_goToURL() { //v3.0
  var i, args=MM_goToURL.arguments; document.MM_returnValue = false;
  for (i=0; i<(args.length-1); i+=2) eval(args[i]+".location='"+args[i+1]+"'");
}
</script>
<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
td {
	font-size: 11px;
}
input, select {
	font-size: 12px;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php
include("header.php");
?>
<br />
<div align="center" class="msg">
  <?=$_GET['msg']; ?>
   <?=$_GET['walk']; ?>
</div>
<? if($_SESSION['user_type']=='Admin') {
}
else
{?>

<form action="var.php" method="post" style="margin:0;padding:0">
  <input type="hidden" name="stud_id" value="<?=$_GET['stud_id'] ?>" />
  
  <table width="725" align="left">
    <tr>   
      <td width="57"><div align="left" style="margin-left:15px"><a href="Javascript:history.go(-2)"><img src="images/back11.gif" width="42" height="44" border="0" /></a></div></td><td width="226">&nbsp;</td>
      <td width="119"><b>Lead Transfer To:</b></td>
      <td width="39"><select name="emp">
          <?
$sql8 = "select emp_id, emp_name from members where user_type='Admin' order by emp_id";
$result8 = mysql_query($sql8);
while($row8 = mysql_fetch_row($result8))
		{
		?>
          <option value="<?=$row8[0];?>">
          <?=$row8[1];?>
          </option>
          <?
}
?>
        </select>      </td>
      <td width="12">&nbsp;</td>
      <td width="244"><input type="submit" name="submit5" value="Transfer" /></td>
   
    </tr>
  </table>
</form>
<? }?>
<?php
$query = "SELECT * FROM student where stud_id='".$_GET['stud_id']."'";

$result=mysql_query($query) or die(mysql_error());
$row=mysql_fetch_array($result);



?>
 
<br style="clear:both" />
<table width="99%" align="center">
  <tr>
    <td><font size="5"><? echo $row['stud_name'] ?></font></td>
  </tr>
  <tr>
    <td width="45%" valign="top"><form name="addfee" method="post" action="11.php" onsubmit="return fees_validation();">
        <table width="100%" align="left" bgcolor="#f3f7fd" style="border:#88c9fd 1px solid;">
          <tr>
            <td background="footerbg.jpg" class="whitetxt11" colspan="2" height="26" style="padding-left:15px"><font size="2px">Student ID&nbsp;&nbsp;<? echo $_GET['stud_id'];?></font></td>
          </tr>
          <tr>
            <td class="Border-botm" colspan="2" style="padding-left:25px"><font color="#CC0000" size="2px"><? echo $row['add1'] ?>,&nbsp;<? echo $row['add2'] ?><br />
              <? echo $row['city'] ?></font></td>
          </tr>
          <tr >
            <td width="184" height="30" class="Border-botm" style="padding-left:25px;"><font color="#CC0000" size="2px"> <img src="image/telephone.png" border="0" />&nbsp;&nbsp;<? echo $row['phone_code'] ?>-&nbsp;<? echo $row['phone_no'] ?></font></td>
            <td width="231" class="Border-botm"><font color="#CC0000" size="2px"><font color="#000000"><b>City</b></font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<? echo $row['city'] ?></font></td>
          </tr>
          <tr>
            <td width="184" height="30" class="Border-botm" style="padding-left:25px;"><font color="#CC0000" size="2px"><img src="image/phone.png" border="0" />&nbsp;&nbsp;&nbsp;&nbsp;
                <? if($num_contact>0) echo $row['school_mob']; else echo $row['mobno'];?>
            </font></td>
            <td width="231" class="Border-botm"><font color="#CC0000" size="2px"><font color="#000000"><b>State :</b></font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<? echo $row['state'] ?></font></td>
          </tr>
          <tr>
            <td width="184" height="30" class="Border-botm" style="padding-left:25px;"><font color="#CC0000" size="2px"><img src="image/email.png" border="0" />&nbsp;&nbsp;&nbsp;<span style="padding-left:25px;"><font color="#CC0000" size="2px"><? echo $row['email'] ?></font></span></font></td>
            <td width="231" class="Border-botm"><font color="#CC0000" size="2px"><font color="#000000"><b>Pin :</b></font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<? echo $row['pin'] ?></font></td>
          </tr>
          <tr>
            <td width="184" height="30" class="Border-botm" style="padding-left:25px;"><font color="#CC0000" size="2px"><font color="#000000"><b>Information Source :</b></font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<? echo $row['information_source'] ?></font></td>
            <td width="231" class="Border-botm"><font color="#CC0000" size="2px"><font color="#000000"><b>Class:</b></font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;					             <? 
			       echo $row['course'];
				   if($row['stream']!="")
				   {
				   		echo " - ".$row['stream'];
				   }
				   else
				   {
				   		echo "";
				   }
			
			
			 ?></font></td>
          </tr>
          <!--<tr>
       
          <td width="184" height="30" class="Border-botm" style="padding-left:25px;"><font color="#CC0000" size="2px"><font color="#000000"><b>Percentage :</b></font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<? //echo $row['percentage'] ?></font></td>
          <td width="231" class="Border-botm">&nbsp;</td>
          </tr>-->
          <tr>
            <td height="30" class="Border-botm" style="padding-left:20px">&nbsp;</td>
            <td align="left" class="Border-botm"><input name="edit" type="button" onclick="MM_goToURL('parent','editschool.php?stud_id=<? echo $row['stud_id'];?>');return document.MM_returnValue" value="Edit Profile" /></td>
          </tr>
          <tr>
            <td height="25" colspan="2" align="left" bgcolor="#c0e4fc" style="padding-left:10px;"><strong>Transferred Status</strong></td>
          </tr>
          <tr>
                  <td align="left" colspan="2"><div style="display:block; width:100%;">
                 
                  
                      <table width="100%" border="0" cellpadding="4" cellspacing="1" bgcolor="#81cafd">
                        <tr bgcolor="#999999">
                          <td height="25" align="left" background="footerbg.jpg" style="font-size:13px;color:#FFFFFF"><strong>Date</strong></td>
                         <td align="left" background="footerbg.jpg" style="font-size:13px;color:#FFFFFF"><strong>Transferred To</strong></td>
                          <td align="left" background="footerbg.jpg" style="font-size:13px;color:#FFFFFF"><strong>Transferred From</strong></td>
                          
                          <td align="left" background="footerbg.jpg" style="font-size:13px;color:#FFFFFF"><strong>Transferred By</strong></td>
                        </tr>
                         <? 
	   					$sql_trans = "SELECT * FROM transferred_lead WHERE stud_id='".$_GET['stud_id']."' order by transfer_date asc";

						$res_trans	= mysql_query($sql_trans) or die(mysql_error());
						$count = 0;
						while($row_trans=mysql_fetch_array($res_trans))
						{
							if($acol)
							{
	          					 $x = "bgcolor='#e9f5ff'";
						    }
							else 
							{
	            				$x = "bgcolor='#d8effe'";
 	          				}
			  				$acol=!$acol;
			 				$count++;
						
						?>
                        <tr <?=$x;?>>
                          <td>
						  <?php if($row_trans['transfer_date']!='0000-00-00 00:00:00') echo date("d-M-y",strtotime($row_trans['transfer_date']));?> 
                          <?php //echo date("H:i A",strtotime($row_trans['transfer_date']));?>
                          </td>
                          
                          <td><?php 
						  
						  $qry12 = "SELECT emp_name FROM members WHERE emp_id='".$row_trans['emp_to_id']."'";
						  $res12 = mysql_query($qry12) or die(mysql_error());
						  $row12 = mysql_fetch_array($res12);
						  echo $row12['emp_name'];
						  
						  
						  
						  ?></td>
                          <td><?
						  
                          $qry11 = "SELECT emp_name FROM members WHERE emp_id='".$row_trans['emp_from_id']."'";
						  $res11 = mysql_query($qry11) or die(mysql_error());
						  $row11 = mysql_fetch_array($res11);
						  echo $row11['emp_name'];
						  
						  
						  ?></td>
                          
                          <td><?php 
						  
						  $qry13 = "SELECT emp_name FROM members WHERE emp_id='".$row_trans['transferred_by_id']."'";
						  $res13 = mysql_query($qry13) or die(mysql_error());
						  $row13 = mysql_fetch_array($res13);
						  echo $row13['emp_name'];
						  
						  
						  ?></td>
                        </tr>
                       
                            <?
						}
						
						?>
                      </table>
                   
                    </div></td>
                </tr>
        </table>
      </form>
      <div style="clear:both"></div>
      <div id="assess" style="display:none">
        <form name="assessment" method="post" action="" onSubmit="return ValidateForm2();">
          <table width="100%" style="font-size:13px;border:#88c9fd 1px solid;" bgcolor="#f3f7fd">
            <tr>
              <input type="hidden" name ="stud_id" value="<?= $_GET['stud_id']?>">
              <td height="25" colspan="2" bgcolor="#c0e4fc"><div style="margin-left:20px;"><strong>Is the school working with any testing body</strong></div></td>
            </tr>
            <tr>
              <td colspan="2"><div style="margin-left:20px; margin-top:5px; float:left;">
                  <select name="working" onChange="showhide(id)" id="working" style="border:solid 1px #61b5f8; background-color:#FFFFFF;">
                    <option value="">--Select--</option>
                    <option value="None">None</option>
                    <option value="Asset">Asset</option>
                    <option value="McMillan">McMillan</option>
                    <option value="Other">Other</option>
                  </select>
                  &nbsp;<font color="#FF0000"><b>*</b></font></div>
                <div id="otherbox" style="visibility:hidden; margin-left:20px;float:left;">
                  <input type="text" name="other_working" size="50" value="" style="border:solid 1px #61b5f8; background-color:#FFFFFF;"/>
                  &nbsp;<font color="#FF0000"><b>*</b></font> </div></td>
            </tr>
            <tr>
              <td><div style="padding:7px 0px 10px 20px;">
                  <input type="submit" name="submit" value="Update" />
                </div></td>
              <td><a href="#" onClick="MM_openBrWindow('assessmentreport.php?stud_id=<? echo $_GET['stud_id']?>','contactreport','toolbar=yes,location=yes,scrollbars=yes,resizable=yes,width=870,height=500')">
                <div style="padding:7px 0px 10px 0px;">
                  <input type="button" name="showall" value="Show All" />
                </div>
                </a></td>
            </tr>
          </table>
        </form>
      </div>
     
      </td>
    <td width="55%" valign="top"><form name="contactdetails" method="post" action="" onSubmit="return ValidateForm4();">
        <table width="99%" border="0" align="center" bgcolor="#f3f7fd" cellpadding="0" cellspacing="0" style="border:#88c9fd 1px solid;">
          <tr>
            <td><table width="100%" border="0" align="center" bgcolor="#f3f7fd" cellpadding="5" cellspacing="0">
                  
                <tr>
                  <td align="right" colspan="3"><div style="display:block; width:100%;">
                      <table width="100%" border="0" cellpadding="4" cellspacing="1" bgcolor="#81cafd">
                        <tr bgcolor="#999999">
                          <td height="25" align="left" background="footerbg.jpg" style="font-size:13px;color:#FFFFFF"><strong>Date</strong></td>
                          <td align="left" background="footerbg.jpg" style="font-size:13px;color:#FFFFFF"><strong>Status</strong></td>
                          <td align="left" background="footerbg.jpg" style="font-size:13px;color:#FFFFFF"><strong>Follow Up</strong></td>
                        </tr>
                        <? 
	   $sql_cust = "SELECT * FROM contact WHERE stud_id='".$_GET['stud_id']."' order by joined asc";

		$result	= mysql_query($sql_cust) or die(mysql_error());
		$count = 0;
		
while($res=mysql_fetch_array($result))
{
if($acol) {
	           $x = "bgcolor='#e9f5ff'";
	          } else {
	            $x = "bgcolor='#d8effe'";
 	          }
			  $acol=!$acol;
			  $count++;
?>
                        <tr <?=$x;?> align="left">
                          <td><?php if($res['joined']!='0000-00-00') echo date("d-M-y",strtotime($res['joined']));?></td>
                          <td><?php if($res['status']=='Positive'){?>
                            <img src="image/green.gif" border="0" name="plus_sign" alt="Click here to view positive report" align="center"/>
                            <? } else if($res['status']=='Negative'){ ?>
                            <img src="image/red.gif" border="0" name="minus_sign" alt="Click here to view negative report" align="center"/>
                            <? } else if($res['status']=='Moderate'){ ?>
                            <img src="image/mod.gif" border="0" name="minus_sign" align="center"/>
                            <? } else if($res['status']=='Paid'){ ?>
                            <img src="image/paddy-smiley26.gif" border="0" name="paid" alt="Paid School" align="center" />
                            <? }else if($res['status']=='Admission'){ ?>
                            <img src="image/admission.png" border="0" name="Admission" alt="Admission" align="center" />
                            <? }else echo "-";?></td>
                          <td>
						  <?php 
						  	
							if($res['followup']=='Other') echo $res['other']; else echo $res['followup'];
							
							if($res['remarkdate']!='0000-00-00')
							{		
						  ?>
                            on 
						 <?php echo date("d-M-y", strtotime($res['remarkdate']));?> at <?php echo $res['remarktime'];
							}
						 ?></td>
                        </tr>
                        <? }?>
                      </table>
                    </div></td>
                </tr>
                <tr>
                  <td height="25" colspan="3" background="footerbg.jpg" class="whitetxt11" style="padding-left:15px"><b>New Contact / Call  - <? echo $row['stud_name'] ?></b></td>
                </tr>
                
                <tr>
                  <td width="75" class="Border-botm"><div style="margin-left:10px;">Status</div></td>
                  <td width="3" class="Border-botm">:</td>
                  <td width="355" class="Border-botm">
                  <select name="status"  style="border:solid 1px #61b5f8; background-color:#FFFFFF;" >
                   
                  <?
                 
				  if($row['status']=='Paid')
				  {
				  ?>
                  <option value="Paid" <? if($row=='Paid') echo 'selected' ?>>Paid</option>
                  <option value="Admission">Admission</option>
				  <?
				  }
				  else if($row['status']=='Admission')
				  {
				  ?>
				  <option value="Admission" <? if($row=='Admission') echo 'selected' ?>>Admission</option>
				 <? 
				  }
				  else
				  {
                  ?>
                     <option value="">--Select--</option>
                      <option value="Positive">Positive</option>
                      <option value="Negative">Negative</option>
                      <option value="Moderate">Moderate</option>
                      <option value="Paid">Paid</option>
                      <option value="Admission">Admission</option>
                      
                      <?
					  }
					  ?>
                    </select>
                    &nbsp;<font color="#FF0000"><b>*</b></font></td>
                </tr>
                <tr>
                  <td class="Border-botm"><div style="margin-left:10px;">Follow Up</div></td>
                  <td class="Border-botm">:</td>
                  <td class="Border-botm"><select name="followup" onchange="showhide1(this)" style="float:left; border:solid 1px #61b5f8; background-color:#FFFFFF;" >
                      <option value="">--Select--</option>
                      <option value="Call">Call</option>
                      <option value="Meeting / Counselling">Meeting / Counselling</option>
                      <option value="Send Brochure">Send Brochure</option>
                      <option value="Other">Other</option>
                    </select>
                    <textarea name="other" rows="2" cols="30" id="divnb2" style="float:left;display:none"></textarea>
                    <!--<input type="text" name="other" size="30" maxlength="2000"  id="divnb2" style="float:left;display:none"/>-->
                    <font color="#FF0000"><b> &nbsp;* </b></font> </td>
                </tr>
                <tr>
                  <td class="Border-botm"><div style="margin-left:10px;">Date-Time</div></td>
                  <td class="Border-botm">:</td>
                  <td class="Border-botm"><label>
                    <input type="text" name="remarkdate" size="20" id="remarkdate" readonly="readonly" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" />
                    <img src="CalendarIcon.gif" name="get_stud_date3" width="22" height="23" border="0" align="absmiddle" id="get_stud_date3" style="cursor: pointer;" title="Date selector" onmouseover="this.style.background='red';" onmouseout="this.style.background=''" />
                    <script type="text/javascript">
	  	Calendar.setup({
        inputField     :    "remarkdate",     // id of the input field
	    //ifFormat       :    "%Y/%m/%d %l:%M %P",      // format of the input field
	  	//ifFormat       :    "%m-%d-%Y",      // format of the input field
	  	ifFormat       :    "%d-%m-%Y",      // format of the input field
        button         :    "get_stud_date3",  // trigger for the calendar (button ID)
        align          :    "Tl",           // alignment (defaults to "Bl")
        singleClick    :    true,
		showsTime		:	true
    });

        </script>
                    </label>
                    &nbsp;<font color="#FF0000"><b>*&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <input type="text" name="remarktime" size="20"  style="border:solid 1px #61b5f8; background-color:#FFFFFF;" />
                    &nbsp;<font color="#FF0000"><b>*</b></font></b></font></td>
                </tr>
                <tr>
                  <td class="Border-botm"><div style="margin-left:10px;">Student's Next Step</div></td>
                  <td class="Border-botm">:</td>
                  <td class="Border-botm"><select name="nextstep" onchange="showhide5(this)" style="float:left; border:solid 1px #61b5f8; background-color:#FFFFFF;" >
                      <option value="">--Select--</option>
                      <option value="Call">Call</option>
                      <option value="Submit Registration">Submit Registration</option>
                      <option value="Submit Fees">Submit Fees</option>
                      <option value="other">Other</option>
                    </select>
                    <textarea name="schoolother" rows="2" cols="30" id="divnb3" style="float:left; display:none"></textarea>
                    <!--<input type="text" name="schoolother" size="30"  id="divnb3" style="float:left;display:none"/>-->
                    <font color="#FF0000"><b> &nbsp;* </b></font> </td>
                </tr>
                <tr>
                  <td colspan="2" align="left">&nbsp;</td>
                  <td height="30" align="left" valign="middle">
                  <input type="hidden" name="stud_id" value="<?=$row['stud_id'] ?>" />
                    <input type="submit" name="submit2" value=" Save " />                  </td>
                </tr>
                
                
                
               
            </table></td>
          </tr>
        </table>
      </form>
      <form name="walkin_frm" method="post" action="" onsubmit="return Validate_walkins();">
      <table width="99%" border="0" align="center" bgcolor="#f3f7fd" cellpadding="2" cellspacing="0" style="border:#88c9fd 1px solid;">
       <tr>
                  <td height="25" colspan="3" background="footerbg.jpg" class="whitetxt11" style="padding-left:15px"><b>Expected Walkin </b></td>
                </tr>
                <tr>
                  <td class="Border-botm"><div style="margin-left:10px;">Date</div></td>
                  <td class="Border-botm">:</td>
                  <td class="Border-botm"><label>
                    <input type="text" name="walkin_date" size="20" id="walkin_date" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" />
                    <img src="CalendarIcon.gif" name="get_stud_date33" width="22" height="23" border="0" align="absmiddle" id="get_stud_date33" style="cursor: pointer;" title="Date selector" onmouseover="this.style.background='red';" onmouseout="this.style.background=''" />
                    <script type="text/javascript">
	  	Calendar.setup({
        inputField     :    "walkin_date",     // id of the input field
	    //ifFormat       :    "%Y/%m/%d %l:%M %P",      // format of the input field
	  	//ifFormat       :    "%m-%d-%Y",      // format of the input field
	  	ifFormat       :    "%d-%m-%Y",      // format of the input field
        button         :    "get_stud_date33",  // trigger for the calendar (button ID)
        align          :    "Tl",           // alignment (defaults to "Bl")
        singleClick    :    true,
		showsTime		:	true
    });

        </script>
                    </label>
                    &nbsp;<font color="#FF0000"><b>*</b></font></td>
                </tr>
                <tr>
                  <td class="Border-botm"><div style="margin-left:10px;">Time</div></td>
                  <td class="Border-botm">:</td>
                  <td class="Border-botm">
                    <input type="text" name="walkintime" id="walkintime" size="20"  style="border:solid 1px #61b5f8; background-color:#FFFFFF;" />&nbsp;<font color="#FF0000"><b>*</b></font>
                  </td>
                </tr>
                <tr>
                  <td colspan="2" align="left">&nbsp;</td>
                  <td height="30" align="left" valign="middle">
                  <input type="hidden" name="stud_id" value="<?=$row['stud_id'] ?>" />
                    <input type="submit" name="walkin_submit" value=" Save " />                  </td>
                </tr>
      </table>
      </form>
      
      </td>
  </tr>
</table>

</body>
</html>
