<?php 
session_start();
include("connection.php");
@extract($_GET);
@extract($_POST);


//$sql="SELECT student.*  FROM student WHERE student.`joined` >= '2011-01-01 00:00:00' limit 1000";
$sql="SELECT student.* FROM  student INNER JOIN (SELECT `stud_id` FROM contact GROUP BY `stud_id` HAVING count(`contact_id`) >= 3) contact ON student.stud_id= contact.stud_id where student.`joined` >= '2011-01-01 00:00:00' and student.course LIKE '%XI Science%'";
    
	header("Pragma: public");
    header("Expires: 0");
    header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
    header("Content-Type: application/force-download");
    header("Content-Type: application/octet-stream");
    header("Content-Type: application/download");;
    header("Content-Disposition: attachment;filename=leads_with_3_comment.xls"); 
    header("Content-Transfer-Encoding: binary ");



//$enqqry;
$enqres=mysql_query($sql) or die(mysql_error());
	?>
    <table border="1" cellpadding="1" cellspacing="1" ><tr bgcolor="#E8E8E8" style="font:Verdana, Arial, Helvetica, sans-serif">
    <?
		echo "<th>S.No.</th>"."\t";
		echo "<th>Name</th>"."\t";
		echo "<th>City</th>"."\t";
		echo "<th>State</th>"."\t";
		echo "<th>Course</th>"."\t";
		echo "<th>Phone No. / Mob No</th>"."\t";
		echo "<th>Email</th>"."\t";
	/*	echo "<th>Reports</th>"."\t";*/
		echo "<th>Status</th>"."\t";
		echo "<th>Information Source </th>"."\t";
		echo "<th>Date</th>"."\t";
	/*	echo "<th>Coordinator</th>"."\t";*/
		echo "<th>Feedback</th>"."\t";
		print("\n"); 
	?>
    </tr>
    
    <?	
		
		$i=1;
		
 while($row_application = mysql_fetch_array($enqres))
    {    
	     // if($row_application['payment']=='Paid'){  echo '<tr bgcolor="#7FBFAA" style="font:Verdana, Arial, Helvetica, sans-serif" >';}
		// elseif($row_application['payment']=='Unsuccessful'){  echo '<tr bgcolor="#FFBFFF" style="font:Verdana, Arial, Helvetica, sans-serif" >//';}
		//else{ echo "<tr>";}
	   
		echo "<td>".$i."</td>"."\t";
		echo "<td>".$row_application['stud_name']."</td>"."\t";
		
//	if($row_application['Mobileno']==0){ $row_application['Mobileno'] = '-';} if($row_application['Phoneno']==0){ $row_application['Phoneno'] = //'-';}		            
		echo "<td>".$row_application['city']."</td>"."\t";
		echo "<td>".$row_application['state']."</td>"."\t";
		echo "<td>".$row_application['course']."</td>"."\t";
		if($row_application['mobno']!=0) { $row_application['mobno']=$row_application['mobno'];} else { $row_application['mobno']= '-';}
			
		echo "<td>".$row_application['phone_code']." ".$row_application['phone_no'].", ".$row_application['mobno']."</td>"."\t";
		echo "<td>".$row_application['email']."</td>"."\t";
		echo "<td>".$row_application['status']."</td>"."\t";
		echo "<td>".$row_application['information_source']."</td>"."\t";
		 if($row_application['joined']!='0000-00-00')
			  {
			  $date=date('d-M-Y',strtotime($row_application['joined']));
			  }
			  else
			  {
				  $date='-';
				  }
		echo "<td>".$date."</td>"."\t";
	/*	echo "<td>".$row_application['emp_name']."</td>"."\t";*/
		echo '<td><table border="1">';
		$sql_cust11 = "SELECT * FROM contact WHERE contact.stud_id='".$row_application['stud_id']."' order by joined asc";
				$result11= mysql_query($sql_cust11) or die(mysql_error());
				
				//print "\n";
				
				while($res11=mysql_fetch_array($result11))
				{
				echo "<tr>";	
				if($res11['joined']!='0000-00-00')
						  {
						 echo "<td>".date("d-M-y", strtotime($res11['joined']))."</td>"."\t";
						  }
						  if($res11['followup']=='Other') 
						  {
						 echo "<td>".$res11['other']."</td>"."\t";
						  }
					 else
				         { 
						   echo "<td>".$res11['followup']."</td>"."\t";
						 }
				         print "\n";
				        echo "</tr>";
						}
					echo "</table></td>";	
			print "\n";	
		   echo "</tr>";
		   $i++;
	}
	
		
?>

 </table>
    