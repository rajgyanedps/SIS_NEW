<?php
session_start();
include("connection.php");
if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='Project Manager' && $_SESSION['user_type']!='Tele Caller')
//if (!isset($_SESSION[myusername]))
{
 header("Location: index.php");
}
$_SESSION['this_page']='monthlyreport1.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Employee Total Call Report</title>
<link rel="stylesheet" type="text/css" href="calendar-blue.css">
<script type="text/javascript" src="calendar.js"></script>
<script type="text/javascript" src="calendar-en.js"></script>
<script type="text/javascript" src="calendar-setup.js"></script>
<script language="javascript1.2" src="tabber.js"></script>
<script type="text/javascript">
function showhide(val)
{
if(val.value=='Daily')
document.getElementById('divnb').style.display='block';
else
document.getElementById('divnb').style.display='none';
if(val.value=='Monthly')
document.getElementById('divmb').style.display='block';
else
document.getElementById('divmb').style.display='none';
}
</script>
<script type="text/javascript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php
include("header.php");
?>
<br />
<div style="float:left;width:75%;">
  <form action="" method="get" name="dailyreport">
    <div style="float:left;line-height:20px"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Select Type:</b>&nbsp;&nbsp;&nbsp;
      <select name="mod" onchange="showhide(this)" >
        <option value="">-Select-</option>
        <option value="Daily">Daily</option>
        <option value="Monthly">Monthly</option>
      </select>
    </div>
    <div id="divnb" style="display:none;float:left;line-height:20px"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Select Date</b> <img src="CalendarIcon.gif" name="get_stud_date1" width="22" height="23" border="0" align="absmiddle" id="get_stud_date1" style="cursor: pointer;" title="Date selector" onMouseOver="this.style.background='red';" onMouseOut="this.style.background=''" /> &nbsp;
      <input type="text" name="date1" size="10" id="date1" />
      <script type="text/javascript">
	  	Calendar.setup({
        inputField     :    "date1",     // id of the input field
	    //ifFormat       :    "%Y/%m/%d %l:%M %P",      // format of the input field
	  	//ifFormat       :    "%m-%d-%Y",      // format of the input field
	  	ifFormat       :    "%Y-%m-%d",      // format of the input field
        button         :    "get_stud_date1",  // trigger for the calendar (button ID)
        align          :    "Tl",           // alignment (defaults to "Bl")
        singleClick    :    true,
		showsTime		:	true
    });

        </script>
    </div>
    <div id="divmb" style="display:none;float:left;line-height:20px"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Select Month:</b>
      <select name="month1" id="month1">
        <option value="">-Select Month-</option>
        <option value="1">January</option>
        <option value="2">February</option>
        <option value="3">March</option>
        <option value="4">April</option>
        <option value="5">May</option>
        <option value="6">June</option>
        <option value="7">July</option>
        <option value="8">August</option>
        <option value="9">September</option>
        <option value="10">October</option>
        <option value="11">November</option>
        <option value="12">December</option>
      </select>
    </div>
    <input type="submit" value="Search" style="margin-left:20px; float:left; line-height:20px; height:25px;" />
  </form>
</div>
<div style="float:left;width:20%;line-height:20px; height:30px; vertical-align:top;"> <font color="#000000" size="3px" style="padding-left:15px"><b>Convert to Excel</b>&nbsp;&nbsp;<a href="report11.php?date1=<?= $_GET['date1']?>&month1=<?= $_GET['month1']?>"><img src="logo_excel.gif" alt="Export" border="0"></a></font></div>
<div style="float:left; width:100%">
  <table width="100%" border="0" align="center" cellpadding="5" cellspacing="1" bgcolor="#81cafd" style="font-size:12px">
    <tr bgcolor="#999999" align="center">
      <td width="4%" align="left" background="footerbg.jpg" class="whitetxt11">S.No.</td>
      <td width="21%" align="left" background="footerbg.jpg" class="whitetxt11">Employee name</td>
      <td width="11%" align="left" background="footerbg.jpg" class="whitetxt11">No of Leads</td>
      <td width="9%" align="left" background="footerbg.jpg" class="whitetxt11">No. of Calls</td>
      <td width="10%" align="left" background="footerbg.jpg" class="whitetxt11">Admission</td>
      <td width="11%" align="left" background="footerbg.jpg" class="whitetxt11">Paid</td>
      <td width="11%" align="left" background="footerbg.jpg" class="whitetxt11">Positive</td>
      <td width="12%" align="left" background="footerbg.jpg" class="whitetxt11">Moderate</td>
      <td width="11%" align="left" background="footerbg.jpg" class="whitetxt11">Negative</td>
    </tr>
    <? 


if (strlen($_GET['date1'])>0)
{
$strqry=" and DATE(contact_date)='".$_GET['date1']."'";
$strqry1=" and DATE(contact.joined)='".$_GET['date1']."'";
$strqry2=" and DATE(joined)='".$_GET['date1']."'";
}
				
elseif (strlen($_GET['month1'])>0)
{
$strqry=" and MONTH(contact_date)='".$_GET['month1']."'";
$strqry1=" and MONTH(contact.joined)='".$_GET['month1']."'";
$strqry2=" and MONTH(joined)='".$_GET['month1']."'";

}



echo $sql_cust = "SELECT emp_id,emp_name,(select count(*) from student where student.emp_id=members.emp_id ". $strqry2." ) as lcontact, (select count(*) from contact inner join student on contact.stud_id=student.stud_id where student.emp_id=members.emp_id ". $strqry1.") as scontact, (select count(*) from student where status='Positive' ". $strqry." and student.emp_id=members.emp_id) as pcontact, (select count(*) from student where status='Negative' ". $strqry." and student.emp_id=members.emp_id) as ncontact, (select count(*) from student where status='Moderate' ". $strqry." and student.emp_id=members.emp_id) as mcontact, (select count(*) from student where status='Paid' ". $strqry." and student.emp_id=members.emp_id) as paidcontact, (select count(*) from student where status='Admission' ". $strqry." and student.emp_id=members.emp_id) as admitcontact FROM members WHERE username!='Open Data' and username!='del_school' order by emp_name";




/*				
$sql_cust = "SELECT emp_id,emp_name, (select count(*) from addcontact where school_id>emp_id and school_id<(emp_id+100000) ". $strqry.") as scontact, (select count(*) from addcontact where status='Positive' ". $strqry." and school_id>emp_id and school_id<(emp_id+100000)) as pcontact, (select count(*) from addcontact where status='Negative' ". $strqry." and school_id>emp_id and school_id<(emp_id+100000)) as ncontact, (select count(*) from addcontact where status='Moderate' ". $strqry." and school_id>emp_id and school_id<(emp_id+100000)) as mcontact, (select count(*) from addcontact where status='Paid' ". $strqry." and school_id>emp_id and school_id<(emp_id+100000)) as paidcontact, (select count(*) from addcontact where status='Admission' ". $strqry." and school_id>emp_id and school_id<(emp_id+100000)) as admitcontact FROM members WHERE username!='Open Data' and username!='del_school' order by emp_name";
*/
		$result	= mysql_query($sql_cust) or die(mysql_error());
		$count = 0;
		$total1=0;
		$positive=0;
		$negative=0;
		$moderate=0;
		$paid=0;
		$total_lead=0;
		
		while($res=mysql_fetch_array($result))
{         
   
   $total_lead=$total_lead+$res['lcontact'];  
   $total1=$total1+$res['scontact'];  
   $positive=$positive+$res['pcontact'];
   $negative=$negative+$res['ncontact'];
   $moderate=$moderate+$res['mcontact'];
   $paid=$paid+$res['paidcontact'];
   $Admission=$Admission+$res['admitcontact'];
$dd = date("d-M-y",strtotime($res['remarkdate']));

if($acol) {
	           $x = "bgcolor='#e9f5ff'";
	          } else {
	            $x = "bgcolor='#d8effe'";
 	          }
			  $acol=!$acol;
			  $count++;
?>
    <tr <?=$x;?> align="left">
      <td><? echo $count;?>.</td>
      <td><strong><?php echo $res['emp_name'];?></strong></td>
      <td><a href="dailycallreport.php?emp_id=<?php echo $res['emp_id'];?>&amp;fromdate=<?= $_GET['date1']?>&amp;frommonth=<?= $_GET['month1']?>"><?php echo $res['lcontact'];?></a></td>
      <td><a href="dailycallreport.php?emp_id=<?php echo $res['emp_id'];?>&amp;fromdate=<?= $_GET['date1']?>&amp;frommonth=<?= $_GET['month1']?>"><?php echo $res['scontact'];?></a><a href="dailycallreport.php?emp_id=<?php echo $res['emp_id'];?>&amp;fromdate=<?= $_GET['date1']?>&amp;frommonth=<?= $_GET['month1']?>"></a></td>
      <td><a href="dailycallreport.php?emp_id=<?php echo $res['emp_id'];?>&amp;stat=Admission&amp;fromdate=<?= $_GET['date1']?>&amp;frommonth=<?= $_GET['month1']?>"><?php echo $res['admitcontact'];?></a></td>
      <td><a href="dailycallreport.php?emp_id=<?php echo $res['emp_id'];?>&amp;stat=Paid&amp;fromdate=<?= $_GET['date1']?>&amp;frommonth=<?= $_GET['month1']?>"><?php echo $res['paidcontact'];?></a></td>
      <td><a href="dailycallreport.php?emp_id=<?php echo $res['emp_id'];?>&amp;stat=Positive&amp;fromdate=<?= $_GET['date1']?>&amp;frommonth=<?= $_GET['month1']?>"><?php echo $res['pcontact'];?></a></td>
      <td><a href="dailycallreport.php?emp_id=<?php echo $res['emp_id'];?>&amp;stat=Moderate&amp;fromdate=<?= $_GET['date1']?>&amp;frommonth=<?= $_GET['month1']?>"><?php echo $res['mcontact'];?></a></td>
      <td><a href="dailycallreport.php?emp_id=<?php echo $res['emp_id'];?>&amp;stat=Negative&amp;fromdate=<?= $_GET['date1']?>&amp;frommonth=<?= $_GET['month1']?>"><?php echo $res['ncontact'];?></a></td>
    </tr>
    <?
}
?>
    <tr bgcolor="#CCFFCC">
      <td colspan="2" style="padding-left:57px"><font size="3px"><b>Sum</b></font></td>
      <td><strong><? echo $total_lead;?></strong> </td>
      <td><strong><? echo $total1;?></strong></td>
      <td><strong><? echo $Admission;?></strong></td>
      <td><strong><? echo $paid;?></strong></td>
      <td><strong><? echo $positive;?></strong></td>
      <td><strong><? echo $moderate;?></strong></td>
      <td><strong><? echo $negative;?></strong></td>
    </tr>
  </table>
  <table width="100%" align="center">
  <tr>
      <td><img src="image/spacer.gif" height="5" /></td>
    </tr>
    <tr>
      <td class="footer" width="942" >&copy; 2009 TeacherSITY. All rights reserved</td>
    </tr>
  </table>
</div>
</body>
</html>
