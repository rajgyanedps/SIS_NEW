<?php
session_start();
include('functions.inc.php');
include("connection.php");
if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='School Login' && $_SESSION['user_type']!='Tele Caller' && $_SESSION['temp_type']!='y')
{
 header("Location: index.php");
}
$_SESSION['this_page']='crm_contact_us.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Contact Us</title>
<script type="text/javascript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
.checkbox label:after, 
.radio label:after {
    content: '';
    display: table;
    clear: both;
}

.checkbox .cr,
.radio .cr {
    position: relative;
    display: inline-block;
    border: 1px solid #a9a9a9;
    border-radius: .25em;
    width: 1.3em;
    height: 1.3em;
    float: left;
    margin-right: .5em;
}

.radio .cr {
    border-radius: 50%;
}

.checkbox .cr .cr-icon,
.radio .cr .cr-icon {
    position: absolute;
    font-size: .8em;
    line-height: 0;
    top: 50%;
    left: 20%;
}

.radio .cr .cr-icon {
    margin-left: 0.04em;
}

.checkbox label input[type="checkbox"],
.radio label input[type="radio"] {
    display: none;
}

.checkbox label input[type="checkbox"] + .cr > .cr-icon,
.radio label input[type="radio"] + .cr > .cr-icon {
    transform: scale(3) rotateZ(-20deg);
    opacity: 0;
    transition: all .3s ease-in;
}

.checkbox label input[type="checkbox"]:checked + .cr > .cr-icon,
.radio label input[type="radio"]:checked + .cr > .cr-icon {
    transform: scale(1) rotateZ(0deg);
    opacity: 1;
}

.checkbox label input[type="checkbox"]:disabled + .cr,
.radio label input[type="radio"]:disabled + .cr {
    opacity: .5;
}
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php

include("header.php");
if($_REQUEST['action']=='delete')
{
	$del_id=$_REQUEST['delid'];
	mysql_query("delete from contact_us where id='".$del_id."'");
	echo "<script>window.location.href='crm_contact_us.php';</script>";
}


?>
<link href="https://cdn.datatables.net/1.10.15/css/dataTables.bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/responsive/2.1.1/css/responsive.bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script> 
<script src="https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js"></script> 
<script src="https://cdn.datatables.net/responsive/2.1.1/js/dataTables.responsive.min.js"></script> 
<script src="https://cdn.datatables.net/responsive/2.1.1/js/responsive.bootstrap.min.js"></script> 
<div class="container" >

    <?php if(!empty($statusMsg)){
        echo '<div class="alert '.$statusMsgClass.'">'.$statusMsg.'</div>';
    } ?>
    <div style="width:100%; height:30px; float:left;"></div>
    <div class="panel panel-default">
        
        <div class="panel-body">
            
            
    
            <table id="listitemdata"  class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                <thead>
                    <tr>
                    <th>Sr.No.</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Contact</th>
                       <th>Seeking</th>
                       <!--<th>Information</th>-->
                       <th>Date</th>
                       <?php if($_SESSION['user_type']=='Admin')
					   {?>
                       <th>Delete</th>
                       <?php }?>
                       
                    </tr>
                </thead>
                <tbody>
                <?php
                    //get records from database
					$convert=array('FP'=>'Faculty Position','AP'=>'Administration Position','Admission'=>'Admission','Registration'=>'Registration','GI'=>'General information');
                    $query = mysql_query("SELECT * FROM contact_us ORDER BY id DESC");
					$count=mysql_num_rows($query);
                    if($count > 0){
						$k=1; 
                        while($row = mysql_fetch_array($query)){ ?>
                    <tr <?php if($k%2==0){?> style="background-color:#EFEFEF;" <?php }?>>
                      <td>
                      
			<?php echo $k;$k++;?></td>
                      <td><?php  echo $row['name']; ?></td>
                       <td><?php echo $row['email']; ?></td>
                       <td><?php echo $row['contact'];?></td>
                       <td><?php echo $convert[$row['seeking']]; ?></td>
                        <!--<td><?php echo $row['information']; ?></td>-->
                         <td><?php echo $row['contact_date']; ?></td>
                        
                      <?php if($_SESSION['user_type']=='Admin')
					   {?>
                       <td><span  id="<?php echo $row['id'];?>" onclick="del(this.id)" style="cursor:pointer;">Delete</span></td>
                       <?php }?>
                        
                        
                    </tr>
                    <?php } }else{ ?>
                    <tr><td colspan="7">No Record found.....</td></tr>
                    <?php } ?>
                </tbody>
            </table>
            <script>
			var id=new Array();
			function toggle(source) {
    var checkboxes = document.querySelectorAll('input[type="checkbox"]');
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i] != source)
            checkboxes[i].checked = source.checked;
    }
}
function delete_all()
{
	var del_id = [];
   $('[name=chkbox]:checked').each(function() {
      del_id.push($(this).val());
   });
		if(del_id.length==0)
		{
			alert('No Row Selected To Perform Action');
		}
		else
		{
			var r = confirm("Do You Want To Remove Records!");
			var action="remove_all";
			if (r == true) {
	            $.ajax({
                type: "POST",
                url: "fb_lead_del.php",
                data: "id="+del_id+"&action="+action, 
                cache: false,
                success: function(data){
			    if(data!='')
                        {
						alert(data);
						location.reload();
						
						 
                        }		
 	                  }
                  });
   
} else {
   alert('Fine')
}

			
		}
}
			$(document).ready(function() {
      var table = $('#listitemdata').DataTable(); } );

function range_search()
{
	var table = $('#listitemdata').DataTable();
	table.draw();
}
function del(v)
{
	var action="remove";
var r = confirm("Do You Want To Remove This Record!");
if (r == true) {
	window.location.href="crm_contact_us.php?delid="+v+"&action=delete";
	} else {
   alert('Fine')
}
	
}
</script>

<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.2/themes/smoothness/jquery-ui.css"/>
<script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script> 
<script>
$(function()
 {
                $("#min").datepicker({
                   
                    dateFormat: 'dd-mm-yy'
                         });
						  $("#max").datepicker({
                   
                    dateFormat: 'dd-mm-yy'
                         });
				               
            });


</script>        </div>
    </div>
</div>
</body>
</html>