<?php 
require_once('connection.php'); 
$schoolid = $_GET['stud_id'];
?>
<?php
//$today = date("Y-m-d");
//$thisMonth=date("Y-m%");
//$time = time("H:i:s");
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Data_Report.xls");
header("Pragma: no-cache");
header("Expires: 0");
$now=date("j-n-Y");
echo "\t \t Report ON ".$now."\t";


$sql_model=mysql_query("SELECT contact.*, student.stud_name FROM contact INNER JOIN student ON student.stud_id=contact.stud_id WHERE contact.stud_id=$schoolid order by contact.joined asc");
print("\n");
print("\n");
	    echo "S.No."."\t";
		echo "Student Id"."\t";
		echo "Date & Time"."\t";
		echo "Person name"."\t";
		echo "Status"."\t";
		echo "Follow Up"."\t";
		echo "Followup Date"."\t";
		echo "Followup Time"."\t";
		echo "Next Step"."\t";
		
		print("\n"); 
		$i=1;
 while($row = mysql_fetch_array($sql_model))
    {
        echo $i."\t";
		echo $row['stud_id']."\t";
		echo date('d-M-Y', strtotime($row['joined']))." ".date('H:i A', strtotime($row['joined']))."\t";
		echo $row['stud_name']."\t";
		echo $row['status']."\t";
		echo $row['followup']."\t";
		echo date('d-M-Y',strtotime($row['remarkdate']))."\t";
		echo $row['remarktime']."\t";
		echo $row['nextstep']."\t";
		
		print "\n";
		$i+=1;		
    }

?>