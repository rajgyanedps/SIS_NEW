<? session_start();
include("connection.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Student Profile</title>
<link rel="stylesheet" type="text/css" href="msg.css">
   <script type="text/javascript" src="jquery.fancybox/jquery-1.3.2.min.js"></script>





<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


   
<script>
function PrintDiv() {  

var divToPrint = document.getElementById('divToPrint');
var popupWin = window.open('', '_blank', 'width=1200,height=800');
// popupWin.document.open();
popupWin.document.write('<html><body onload="window.print()">' + divToPrint.innerHTML + '</html>');
popupWin.document.close();
}
</script>

</head>
<body bgcolor="#ffffff">
<?php
$query="SELECT * FROM student WHERE stud_id ='".$_GET['school_id']."'";
$result=mysql_query($query) or die(mysql_error());
$row=mysql_fetch_array($result);

$query2="SELECT * FROM application WHERE app_id ='".$row['app_id']."'";
$result2=mysql_query($query2) or die(mysql_error());
$row2=mysql_fetch_array($result2);
?>

<table align="center">
  <tr>
    <td width="600" height="25" bgcolor="#93d3fd"><div style="hight:25px; border:#045c9f solid 1px; padding:5px 0px 5px 0px; font-size:22px; color:#cc0000;">
<div style="float:right; font-size:28px;color:black"> <a href="javascript:void(0)" alt="Print"> <i class="fa fa-print" style="font-size:48px;color:black"  onclick="PrintDiv();"></i> </a>Print</div> 
  <marquee behavior="slide" direction="left">
        <? echo $row['stud_name'] ?>
        </marquee>
      </div></td>
  </tr>
</table>
<div id="divToPrint">
<form name="schoolinfo" method="post" action="schoolinfo.php" style="margin-top:0;">
  <table width="600" border="0" align="center" cellpadding="6" cellspacing="1" style="font-size:13px; color:#015b9f; background:#81cafd;">
    
    <tr bgcolor="#e9f5ff">
      <td><b>Student Name</b></td>
      <td><b>:</b></td>
      <td class="dothr" colspan="4"><font color="#CC0000"><? echo $row['stud_name'] ?></font></td>
      
    </tr>
    <tr bgcolor="#d8effe">
      <td><b>Email Id</b></td>
      <td><b>:</b></td>
      <td class="dothr"><font color="#CC0000"><? echo $row['email'] ?></font></td>
      <td>&nbsp;&nbsp;<b>Phone No.</b></td>
      <td><b>:</b></td>
      <td class="dothr"><font color="#CC0000"><? echo $row['phone_code']." ".$row['phone_no']; ?></font></td>
    </tr>
   
  <tr bgcolor="#e9f5ff">
   
       <td><b>Course</b></td>
       <td><b>:</b></td>
    <td class="dothr"><font color="#CC0000"><? echo $row['course'] ?></font></td>
      <td>&nbsp;&nbsp;<b>School</b></td>
      <td><b>:</b></td>
      <td class="dothr"><font color="#CC0000"><? echo $row2['schoolname'] ?></font></td>
    </tr>
   
   
   
      <tr bgcolor="#e9f5ff">
      <td><b>Information Source</b></td>
      <td><b>:</b></td>
      <td class="dothr"><font color="#CC0000"><? echo $row['information_source'] ?></font></td>
      <td>&nbsp;&nbsp;<b>Percentage</b></td>
      <td><b>:</b></td>
      <td class="dothr"><font color="#CC0000"><? echo $row['percentage']; ?></font></td>
    </tr>
    
<!--  Add BY Roopesh on 03-May-2012 to show more info. as required by bevelene.-->  
  <tr bgcolor="#e9f5ff">
      <td><b>D.O.B.</b></td>
      <td><b>:</b></td>
      <td class="dothr"><font color="#CC0000"><? echo date('d-m-Y',strtotime($row2['student_dob'])); ?></font></td>
      <td>&nbsp;&nbsp;<b>Class</b></td>
      <td><b>:</b></td>
      <td class="dothr"><font color="#CC0000"><? echo $row2['classname'] ?></font></td>
    </tr>
    
    
     <tr bgcolor="#e9f5ff">
      <td><b>Father Name</b></td>
      <td><b>:</b></td>
      <td class="dothr"><font color="#CC0000"><? echo $row2['father_fname'].' '.$row2['father_midname'].' '.$row2['father_lname']; ?></font></td>
      <td><b>Father Mobile</b></td>
      <td><b>:</b></td>
      <td class="dothr"><font color="#CC0000"><? echo $row2['father_mobile'] ?></font></td>
    </tr>
    
    
    
 
    <tr bgcolor="#e9f5ff">
      <td><b>Address</b></td>
      <td><b>:</b></td>
      <td class="dothr" colspan="4"><font color="#CC0000"><? echo $row2['father_add1'].' '.$row2['father_add1']; ?></font></td>
    </tr>    
    
   <tr bgcolor="#e9f5ff">
      <td><b>Annual Income</b></td>
      <td><b>:</b></td>
      <td class="dothr" colspan="4"><font color="#CC0000"><? echo $row['annual_income'] ?></font></td>
    </tr>    
    
   <tr bgcolor="#e9f5ff">
      <td><b>Father Occupation</b></td>
      <td><b>:</b></td>
      <td class="dothr"><font color="#CC0000"><? echo $row2['father_occupation'] ?></font></td>
      <td>&nbsp;&nbsp;<b>Father's Organization</b></td>
      <td><b>:</b></td>
      <td class="dothr"><font color="#CC0000"><? echo $row['father_org']; ?></font></td>
    </tr>  

     <tr bgcolor="#e9f5ff">
      <td><b>Father's Designation</b></td>
      <td><b>:</b></td>
      <td class="dothr"><font color="#CC0000"><? echo $row['father_desig'] ?></font></td>
      <td>&nbsp;&nbsp;<b>Country</b></td>
      <td><b>:</b></td>
      <td class="dothr"><font color="#CC0000"><? echo $row2['father_country']; ?></font></td>
    </tr>  
   
    <tr bgcolor="#e9f5ff">
      <td><b>City</b></td>
      <td><b>:</b></td>
      <td class="dothr"><font color="#CC0000"><? echo $row2['father_city'] ?></font></td>
      <td>&nbsp;&nbsp;<b>State</b></td>
      <td><b>:</b></td>
      <td class="dothr"><font color="#CC0000"><? echo $row2['father_state']; ?></font></td>
    </tr>    
    <tr bgcolor="#e9f5ff">
      <td colspan="6" align="center"><b>Message</b></td>
      
    </tr>
   <tr bgcolor="#e9f5ff">
      <td colspan="6"><p><? if($row['message']!=''){echo $row['message']; } else { echo "NA"; } ?></p></td>
      
    </tr>
  </table>
</form>
</div>
</body>
</html>



