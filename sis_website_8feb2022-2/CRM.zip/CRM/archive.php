<?php
session_start();
include("connection.php");
if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='Project Manager' && $_SESSION['user_type']!='Tele Caller')
{
 header("Location: index.php");
}
$_SESSION['this_page']='tasks.php';
@extract($_GET);

if($order_by!="")
{	
	$KEYWORD_SEARCH_5="ORDER BY $order_by $img_name"; 
}
else
{
	$KEYWORD_SEARCH_5="ORDER BY msg_date desc";
}	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>My Tasks</title>
<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php
include("header.php");
?>
<br />
<br />
<table width="100%" border="0" align="center" cellpadding="5" cellspacing="1" bgcolor="#0b99fd" style="font-size:13px">
  <tr bgcolor="#999999" align="center">
    <td align="left" background="footerbg.jpg" class="whitetxt11">S.No.</td>
    <td align="left" background="footerbg.jpg" class="whitetxt11">Tasks</td>
    <td align="left" background="footerbg.jpg" class="whitetxt11"><? if($_GET['img_name']=='desc' && $_GET['order_by']=='msg_date')
   { 
 ?>
      <a href="archive.php?order_by=msg_date&img_name=asc"><strong>Date&nbsp;</strong><img src="image/asc.gif" alt="Descending Order" border="0"></a>
      <? 
    } 
	else 
	{ 
	?>
      <a href="archive.php?order_by=msg_date&img_name=desc"><strong>Date&nbsp;</strong><img src="image/dsc.gif" alt="Ascending Order" border="0"></a>
      <?
	}
	?>
    </td>
    <td align="left" background="footerbg.jpg" class="whitetxt11"><? if($_GET['img_name']=='desc' && $_GET['order_by']=='emp_name')
   { 
 ?>
      <a href="archive.php?order_by=emp_name&img_name=asc"><strong>To&nbsp;</strong><img src="image/asc.gif" alt="Descending Order" border="0"></a>
      <? 
    } 
	else 
	{ 
	?>
      <a href="archive.php?order_by=emp_name&img_name=desc"><strong>To&nbsp;</strong><img src="image/dsc.gif" alt="Ascending Order" border="0"></a>
      <?
	}
	?>
    </td>
    <td align="left" background="footerbg.jpg" class="whitetxt11"><? if($_GET['img_name']=='desc' && $_GET['order_by']=='status')
   { 
 ?>
      <a href="archive.php?order_by=status&img_name=asc"><strong>Status&nbsp;</strong><img src="image/asc.gif" alt="Descending Order" border="0"></a>
      <? 
    } 
	else 
	{ 
	?>
      <a href="archive.php?order_by=status&img_name=desc"><strong>Status&nbsp;</strong><img src="image/dsc.gif" alt="Ascending Order" border="0"></a>
      <?
	}
	?>
    </td>
    <td align="left" background="footerbg.jpg" class="whitetxt11">Notes</td>
  </tr>
  <?php

 $sql_cust = "SELECT * FROM archive inner join members on members.emp_id=archive.recipient_id WHERE sender_id='".$_SESSION['emp_id']."' $KEYWORD_SEARCH_5";
	
$result	= mysql_query($sql_cust) or die(mysql_error());
		$num_rows 	= mysql_num_rows($result);	
		$incr = 1;
		
		if(!$_REQUEST['pageno']){
			$pageno = 1;
		} else {
			$pageno= $_REQUEST['pageno'];
		}
		$pagesize=25;
		$incr = (($pageno-1)*$pagesize)+1;
		$first=$pageno*$pagesize-($pagesize-1);
		$last=$first+$pagesize-1; 
		$temp=($num_rows%$pagesize);
		if ($temp==0)
		$pages=($num_rows/$pagesize);
		else
		$pages=($num_rows/$pagesize)+1;
		settype($pages, "integer"); 

		for($i=1;$i<$first;$i++)
			$row2000=mysql_fetch_row($result);
     
while($res=mysql_fetch_array($result) and ($first<=$last))
{

if($i%2==0) {
	           $x = "bgcolor='#F0F0F0'";
	          } else {
	            $x = "bgcolor='#D8D8D8'";
 	          }
?>
  <? if($res['status']=='Pending')
	{?>
  <tr align="left" bgcolor="#FFB3B3">
    <? }
	else
	{?>
  <tr align="left" bgcolor="#9BFF9B" >
    <? }?>
    <td style="font-size:11px; font-family:Arial, Helvetica, sans-serif;"><? echo $i;?>.&nbsp;</td>
    <td style="font-size:11px; font-family:Arial, Helvetica, sans-serif;"><?php echo $res['msg'];?>&nbsp;</td>
    <td style="font-size:11px; font-family:Arial, Helvetica, sans-serif;"><?php echo date("d-M-y", strtotime($res['msg_date']));?><br />
      <?php echo date("H:i A", strtotime($res['msg_date']));?>&nbsp;</td>
    <td style="font-size:11px; font-family:Arial, Helvetica, sans-serif;"><?php echo $res['emp_name'];?>&nbsp;</td>
    <td style="font-size:11px; font-family:Arial, Helvetica, sans-serif;"><?php echo $res['status'];?> </td>
    <td style="font-size:11px; font-family:Arial, Helvetica, sans-serif;"><?php echo $res['notes'];?>&nbsp;</td>
  </tr>
  <? 
	 	  $incr++;
	$first++;	
  $i=$i+1;
  } 
	?>
</table>
<? if($num_rows > 0){	?>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td colspan="3"><img src="image/spacer.gif" height="3" /></td>
  </tr>
  <tr>
    <td   height="26"  valign="middle" background="newbar.jpg" class="table_td_heading" style="padding-left:5px;" width="60%"><span class="table_td_heading">Pages:
      <? if ($pageno==1) { ?>
      &nbsp;
      <? } else {?>
      <a href="archive.php?pageno=<?=$pageno-1?>&orderby=<?=$orderby?>&sortby=<?=$sortby?>" class="table_td_heading">Previous</a>
      <? } 
					for ($i=1; $i<=$pages;$i++)
					{
					if($pageno==$i)	{?>
      <strong class="table_td_heading"><? echo $i;?></strong>
      <? }
						else
					{
					if($i%5==0)
{
					?>
      <strong><a class="table_td_heading" href="archive.php?pageno=<?=$i?>&orderby=<?=$orderby?>&sortby=<?=$sortby?>">
      <?=$i?>
      </a></strong>
      <? 
					}
					}
					}
					?>
      <? if ($pageno<$pages) { ?>
      <a href="archive.php?pageno=<?=$pageno+1?>&orderby=<?=$orderby?>&sortby=<?=$sortby?>" class="table_td_heading">Next</a>
      <? } else {?>
      <? } ?>
      </span></td>
    <td width="10%" align="right" valign="middle" background="newbar.jpg" class="data"><!--DWLayoutEmptyCell-->&nbsp;</td>
    <td width="30%" align="center" valign="middle" background="newbar.jpg" class="data"><table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td align="right" valign="middle" class="table_td_heading" style="padding-right:5px;" width="100%"><strong>Page</strong>&nbsp;
            <?=$pageno?>
            &nbsp;of&nbsp;
            <?=$pages?>
          </td>
        </tr>
      </table>
      <strong></strong></td>
  </tr>
</table>
<? }?>
<table align="center" width="100%">
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td class="footer" width="100%" >&copy; 2009 TeacherSITY. All rights reserved</td>
  </tr>
</table>
</body>
</html>
