<?php
session_start();
include('functions.inc.php');
include("connection.php");
if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='Project Manager' && $_SESSION['user_type']!='Tele Caller' && $_SESSION['temp_type']!='y')
//if (!isset($_SESSION[myusername]))
{
 header("Location: index.php");
}
$_SESSION['this_page']='download_golf_lead.php';

require_once 'PHPExcel/Classes/PHPExcel.php';



// create new PHPExcel object
$objPHPExcel = new PHPExcel();
// writer already created the first sheet for us, let's get it
$objSheet = $objPHPExcel->getActiveSheet();
// rename the sheet
$objSheet->setTitle('Download Golf Lead');

// let's bold and size the header font and write the header
// as you can see, we can specify a range of cells, like here: cells from A1 to A4
$objSheet->getStyle('A1:Y1')->getFont()->setBold(true)->setSize(12);

$char = 66;
// write header]
$query=mysql_query("SHOW COLUMNS FROM golf_lead");
$ct=mysql_num_rows($query);
 $objSheet->getCell(A.'1')->setValue('SR.NO.');
while($col_name = mysql_fetch_array($query))
    {
		if($col_name['Field']!='id')
		{
			if($col_name['Field']=='compain_type')
			{
				$col_name['Field']='campaign type';
			}
      $objSheet->getCell(chr($char).'1')->setValue(strtoupper($col_name['Field']));
      $char++;
		}
    }
$objSheet->getCell(X.'1')->setValue('FOLLOWUP');
$objSheet->getCell(Y.'1')->setValue('STATUS');
// Now we need to get the data from the DB. While we have a row in the result:
$rowIterator=2; //our row number. We begin from 2 because the first one is the title.
$data=mysql_query("select * from golf_lead ORDER BY id DESC");
$char = 65;
$j=1;
while ($RowInfo = mysql_fetch_array($data))
{
	$status=mysql_fetch_array(mysql_query("select * from golf_followups
	where golf_id='".$RowInfo['id']."'
	 order by id desc limit 1"));

    $objSheet->getCell('A'.$rowIterator)->setValue($j);
	
	$objSheet->getCell('B'.$rowIterator)->setValue($RowInfo['name']);

	$objSheet->getCell('C'.$rowIterator)->setValue($RowInfo['mobno']);
	
	$objSheet->getCell('D'.$rowIterator)->setValue($RowInfo['email']);
	
	$objSheet->getCell('E'.$rowIterator)->setValue($RowInfo['address']);
	
	$objSheet->getCell('F'.$rowIterator)->setValue($RowInfo['age']);
	
	$objSheet->getCell('G'.$rowIterator)->setValue($RowInfo['occupation']);

	$objSheet->getCell('H'.$rowIterator)->setValue($RowInfo['study_at']);
	$objSheet->getCell('I'.$rowIterator)->setValue($RowInfo['s_c_name']);
	$objSheet->getCell('J'.$rowIterator)->setValue($RowInfo['class']);
	
	 $objSheet->getCell('K'.$rowIterator)->setValue($RowInfo['interested_course']);
	 $objSheet->getCell('L'.$rowIterator)->setValue(date("d-m-Y",strtotime($RowInfo['date'])));
	 $objSheet->getCell('M'.$rowIterator)->setValue($RowInfo['ip_address']);
	 $objSheet->getCell('N'.$rowIterator)->setValue($RowInfo['PSE']);
	 $objSheet->getCell('O'.$rowIterator)->setValue($RowInfo['PAC']);
	 $objSheet->getCell('P'.$rowIterator)->setValue($RowInfo['PCA']);
	 $objSheet->getCell('Q'.$rowIterator)->setValue($RowInfo['PAG']);
	 $objSheet->getCell('R'.$rowIterator)->setValue($RowInfo['PKW']);
	 $objSheet->getCell('S'.$rowIterator)->setValue($RowInfo['PMT']);
	 $objSheet->getCell('T'.$rowIterator)->setValue($RowInfo['PDS']);
	 $objSheet->getCell('U'.$rowIterator)->setValue($RowInfo['PPC']);
	 $objSheet->getCell('V'.$rowIterator)->setValue($RowInfo['PAD']);
	 $objSheet->getCell('W'.$rowIterator)->setValue($RowInfo['information_source']);
	 $objSheet->getCell('X'.$rowIterator)->setValue($status['follow_ups']);
	 $objSheet->getCell('Y'.$rowIterator)->setValue($status['status']);
	
   
$j++;
$rowIterator++;
}



// autosize the columns
$char = 65;
for ($i=1;$i<=12;$i++){
    $objSheet->getColumnDimension(chr($char))->setAutoSize(true);
    $char++;
}
header("Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
header("Content-Disposition: attachment; filename=\"download_golf_lead.xlsx\"");
header("Cache-Control: max-age=0");
// create the writer
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, "Excel2007");
ob_clean();
$objWriter->save("php://output");


?>
