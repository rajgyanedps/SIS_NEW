<?php
session_start();
include("connection.php");
if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='Project Manager' && $_SESSION['user_type']!='Tele Caller')
//if (!isset($_SESSION[myusername]))
{
 header("Location: index.php");
}
?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Total Contact Report</title>
<script type="text/javascript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php
include("header.php");
?>
<?php
$sql = "SELECT stud_id, stud_name FROM student WHERE stud_id='".$_GET['stud_id']."'";
$result1 = mysql_query($sql);
$res1 = mysql_fetch_array($result1);
?>
<form action="contactreport.php" method="post" name="contactreport">
<table width="100%" align="center">
  <tr><td height="25" align="left" bgcolor="#e9f5ff" style="padding-left:10px"><font size="3px" face="Verdana, Arial, Helvetica, sans-serif"><b>Student Contact Report (<? echo $res1['stud_name'];?>)</b></font></td>
</tr>
</table>

<br />
<!--<font color="#000000" size="3px" style="padding-left:15px"><b>Convert to Excel</b>&nbsp;&nbsp;<a href="report4.php?stud_id=<? echo $res1['stud_id'];?>"><img src="logo_excel.gif" alt="Export" border="0"></a></font>-->



<table width="100%" border="0" align="center" cellpadding="5" cellspacing="1" bgcolor="#81cafd" style="font-size:12px">

<tr bgcolor="#999999" align="center">

      <td width="5%" height="20" align="left" background="footerbg.jpg" class="whitetxt11">S.No.</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="20%">Call Date</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="15%">Person</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="8%">Status</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="14%">Follow Up</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="13%">Followup Date</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="12%">Followup Time</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="13%">Next Step</td>
    </tr>
                <? 
	   $sql_cust = "SELECT * FROM contact WHERE stud_id='".$_GET['stud_id']."' order by joined asc";

		$result	= mysql_query($sql_cust) or die(mysql_error());
		$count = 0;
		
while($res=mysql_fetch_array($result))
{
if($acol) {
	           $x = "bgcolor='#e9f5ff'";
	          } else {
	            $x = "bgcolor='#d8effe'";
 	          }
			  $acol=!$acol;
			  $count++;
?>

<tr <?=$x;?> align="left">
        <td width="5%"><? echo $count;?>.</td>
      <td width="20%"><?php if($res['joined']!='0000-00-00 00:00:00') echo date("d-M-y",strtotime($res['joined']));?><br />
      <?php echo date("H:i A", strtotime($res['joined']));?>&nbsp;</td>
                <td width="15%"><?php echo $res1['stud_name'];?></td>
                     <td width="8%" align="center"><?php if($res['status']=='Positive'){?>
              <img src="image/green.gif" border="0" name="plus_sign" alt="Positive School" align="center"/>
              <? } else if($res['status']=='Negative'){ ?>
              <img src="image/red.gif" border="0" name="minus_sign" alt="Negative School" align="center"/>
              <? }else if($res['status']=='Admission'){ ?>
              <img src="image/admission.png" border="0" name="admission" alt="Admission" align="center"/>
              <? } else if($res['status']=='Moderate'){ ?>
              <img src="image/mod.gif" border="0" name="minus_sign" alt="Moderate School" align="center" />
              <? } else if($res['status']=='Paid'){ ?>
              <img src="image/paddy-smiley26.gif" border="0" name="paid" alt="Paid School" align="center" />
              <? }else echo "-";?></td>
      <td width="14%"><?php echo $res['followup'];?></td>
      <td width="13%"><?php if($res['remarkdate']!='0000-00-00') echo date("d-M-y", strtotime($res['remarkdate']));?></td>
                                 <td width="12%"><?php echo $res['remarktime'];?></td>
                                     <td width="13%"><?php echo $res['nextstep'];?></td>
    </tr>
                         
 <? }?>
</table>
<table width="100%" align="center">
<tr>
<td><img src="image/spacer.gif" height="5" /></td>
</tr>
<tr>
<td class="footer" width="955" >&copy; 2009 TeacherSITY. All rights reserved</td>
</tr>

</table>
  

</form>

</body>
</html>