<?php
session_start();
include("automatic.php");
include("connection.php");
if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='Project Manager' && $_SESSION['user_type']!='Tele Caller')
//if (!isset($_SESSION[myusername]))
{
 header("Location: index.php");
}
?>
<?
$_SESSION['this_page']='pmhome.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Project Manager Home Page</title>
<script type="text/javascript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php
include("header.php");
?>
<div align="center" class="msg">
  <?=$_GET['msg1']; ?>
</div>
<?php
$sql = "select count(*) as totalmsg from message WHERE `to`='".$_SESSION['emp_id']."'";
$result1 = mysql_query($sql) ;
$res1 = mysql_fetch_array($result1);
?>
<div style="margin-left:10px;width:415px;height:100px;background-color:#f3f7fd;border:solid 1px #88c9fd;float:left">
  <div style="border-bottom:solid 1px #88c9fd;padding-left:10px;height:20px;background:url(image/headbg.png) repeat-x;font-size:12px; color:#064582;line-height:20px;font-weight:bold;">Search options </div>
  <div style="width:415px; margin-top:10px; float:left;">
    <form name="pmhome" action="pmhome.php" method="post" style="margin:0;padding:0;padding-top:5px">
      <div style="padding-left:6px;width:228px;float:left;font-size:11px;line-height:20px;">School Name:
        <input type="text" name="schoolname1" style="height:17px;line-height:18px;border:solid 1px #61b5f8;font-size:12px;width:135px; color:#0a5095;background-color:#ffffff" />
      </div>
      <div style="padding-left:5px;width:170px;float:left;font-size:11px;line-height:20px;">City:
        <input type="text" name="city1"  style="height:17px;line-height:18px;border:solid 1px #61b5f8;font-size:12px;width:135px; color:#0a5095;background-color:#ffffff" />
      </div>
      <div style="clear:both"></div>
      <div style="margin-right:15px;margin-top:5px" align="right">
        <input type="submit" name="submit" value="Search" />
      </div>
    </form>
  </div>
</div>
<? 
$sql_cust10 = "SELECT * FROM task inner join members on members.emp_id=task.recipient_id WHERE recipient_id='".$_SESSION['emp_id']."' and status='Pending'";
	
$result10	= mysql_query($sql_cust10) or die(mysql_error());
		$num_rows10 = mysql_num_rows($result10);
		$res10=mysql_fetch_array($result10);
?>
<div style="margin-left:10px;width:215px;height:100px;background-color:#f3f7fd;border:solid 1px #88c9fd;float:left">
  <div style="border-bottom:solid 1px #88c9fd;padding-left:10px;height:20px;background:url(image/headbg.png) repeat-x;font-size:12px; color:#064582;line-height:20px;font-weight:bold;">Notifications </div>
  <div align="center" style="font-size:12px"> <br />
    <? if($res1['totalmsg']=='0')
{
}
else
{?>
    You have received&nbsp;<strong><? echo $res1['totalmsg'];?></strong>&nbsp;Leads&nbsp;&nbsp;<a href="seemsg.php">View All</a><br />
    <br />
    <? }?>
    <font  color="#FF0000">
    <?= $num_rows10 ?>
    &nbsp;Pending Task <a href="taskuser.php">Click here to view</a><br />
    </font> </div>
</div>
<div style="margin-left:10px;width:230px;height:100px;background-color:#f3f7fd;border:solid 1px #88c9fd;float:left">
  <div style="border-bottom:solid 1px #88c9fd;padding-left:10px;height:20px;background:url(image/headbg.png) repeat-x;font-size:12px; color:#064582;line-height:20px;font-weight:bold;">Downloads</div>
  <br />
  <div align="center"> <a href="#" onclick="MM_openBrWindow('Brochure TeacherSITY-ACER.pdf','CallReport','toolbar=yes,location=yes,status=yes,menubar=yes,scrollbars=yes,resizable=yes')"><b>Download TeacherSITY-ACER Brochure</b></a><br />
    <a href="#" onclick="MM_openBrWindow('Doc ACER.pdf','CallReport','toolbar=yes,location=yes,status=yes,menubar=yes,scrollbars=yes,resizable=yes')"><b>Download Frequently Asked Question(FAQ)</b></a></div>
</div>
<div style="clear:both"></div>
<table width="100%">
  <tr>
    <td style="padding-left:20px"></td>
  </tr>
</table>
<table align="center" width="100%">
  <tr>
    <td width="100%"><form action="pmhome.php" method="post" name="pmhome">
        <table align="center" width="100%">
          <tr>
            <td width="50%" valign="top"><table width="100%" border="0" align="center" cellpadding="5" cellspacing="1" bgcolor="#81cafd" style="font-size:11px" >
                <tr bgcolor="#999999" align="center">
                  <td width="2%" height="25" align="left" background="footerbg.jpg" class="whitetxt11">S.No.</td>
                  <td align="left" background="footerbg.jpg" class="whitetxt11"><a href="pmhome.php?pageno=<?=$_REQUEST['pageno']?>">School Name</a></td>
                  <td align="left" background="footerbg.jpg" class="whitetxt11"><a href="pmhome.php?pageno=<?=$_REQUEST['pageno']?>">City</a></td>
                  <td align="left" background="footerbg.jpg" class="whitetxt11">Last Status</td>
                  <td align="left" background="footerbg.jpg" class="whitetxt11">Lead Date</td>
                </tr>
                <?php

$sql_cust = "SELECT addschool.school_id, addschool.school_name, addschool.city, last_contact.status, (SELECT msgdate from message WHERE message.school_id=addschool.school_id ORDER BY msgdate Desc LIMIT 1) as leaddate FROM addschool
LEFT JOIN last_contact ON addschool.school_id = last_contact.school_id where addschool.school_id >'".$_SESSION['emp_id']."' and addschool.school_id <'".($_SESSION['emp_id'] + 100000)."' and school_name like '".trim($_POST['schoolname1'])."%' and city like '".trim($_POST['city1'])."%' order by addschool.school_id asc";
	
$result	= mysql_query($sql_cust) or die(mysql_error());
		$num_rows 	= mysql_num_rows($result);	
		if($num_rows==0)
		{
		echo "<div align=center><font color=red size=+1>No Record Found</font></div>";
		}
		$incr = 1;
		
		if(!$_REQUEST['spageno']){
			$spageno = 1;
		} else {
			$spageno= $_REQUEST['spageno'];
		}
		$spagesize=50;
		$incr = (($spageno-1)*$spagesize)+1;
		$first=$spageno*$spagesize-($spagesize-1);
		$last=$first+$spagesize-1; 
		$temp=($num_rows%$spagesize);
		if ($temp==0)
		$spages=($num_rows/$spagesize);
		else
		$spages=($num_rows/$spagesize)+1;
		settype($spages, "integer"); 

		for($i=1;$i<$first;$i++)
			$row2000=mysql_fetch_row($result);
     
     
     
//<?php
//$query="SELECT * FROM addschool";
//$result=mysql_query($query) or die(mysql_error());
while($res=mysql_fetch_array($result) and ($first<=$last))
{
if($res['leaddate']=="")$dd ='-'; else $dd = date("d-M-y",strtotime($res['leaddate']));
if($i%2==0) {
	           $x = "bgcolor='#e9f5ff'";
	          } else {
	            $x = "bgcolor='#d8effe'";
 	          }
?>
                <tr <? if (date("Y-M-d",strtotime($res['leaddate']))==date("Y-M-d",strtotime("-1 days")) || date("Y-M-d",strtotime($res['leaddate']))==date("Y-M-d"))
 { echo 'bgcolor="#FFCCCC"'; } else { echo $x; } ?> align="left">
                  <td><? echo $i;?>.</td>
                  <td><a href="11.php?school_id=<? echo $res['school_id'];?>"><?php echo $res['school_name'];?></a></td>
                  <td><?php echo $res['city'];?></td>
                  <td align="center"><?php if($res['status']=='Positive'){?>
                    <img src="image/green.gif" border="0" name="plus_sign" alt="Click here to view positive report" align="center"/>
                    <? } else if($res['status']=='Negative'){ ?>
                    <img src="image/red.gif" border="0" name="minus_sign" alt="Click here to view negative report" align="center"/>
                    <? } else if($res['status']=='Moderate'){ ?>
                    <img src="image/mod.gif" border="0" name="minus_sign" align="center"/>
                    <? } else if($res['status']=='Paid'){ ?>
                    <img src="image/paddy-smiley26.gif" border="0" name="paid" alt="Paid School" align="center" />
                    <? }else echo "-";?></td>
                  <td><?php echo $dd;?></td>
                </tr>
                <? 
	 	  $incr++;
	$first++;	
  $i=$i+1;
  } 
	?>
              </table>
              <? if($num_rows > 0){	?>
              <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                <tr>
                  <td colspan="3"><img src="image/spacer.gif" height="3" /></td>
                </tr>
                <tr>
                  <td   height="26"  valign="middle" background="newbar.jpg" class="table_td_heading" style="padding-left:5px;" width="60%"><span class="table_td_heading">Pages:
                    <? if ($spageno==1) { ?>
                    &nbsp;
                    <? } else {?>
                    <a href="pmhome.php?spageno=<?=$spageno-1?>&tpageno=<?=$_REQUEST['tpageno']?>" class="table_td_heading">Previous</a>
                    <? } 
					for ($i=1; $i<=$spages;$i++)
					{
					if($spageno==$i)	{?>
                    <strong class="table_td_heading"><? echo $i;?></strong>
                    <? }
						else
					{
					if($i%5==0)
{
					?>
                    <strong><a class="table_td_heading" href="pmhome.php?spageno=<?=$i?>&tpageno=<?=$_REQUEST['tpageno']?>">
                    <?=$i?>
                    </a></strong>
                    <? 
					}
					}
					}
					?>
                    <? if ($spageno<$spages) { ?>
                    <a href="pmhome.php?spageno=<?=$spageno+1?>&tpageno=<?=$_REQUEST['tpageno']?>" class="table_td_heading">Next</a>
                    <? } else {?>
                    <? } ?>
                    </span></td>
                  <td width="10%" align="right" valign="middle" background="newbar.jpg" class="data">&nbsp;</td>
                  <td width="30%" align="center" valign="middle" background="newbar.jpg" class="data"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td align="right" valign="middle" class="table_td_heading" style="padding-right:5px;" width="100%"><strong>Page</strong>&nbsp;
                          <?=$spageno?>
                          &nbsp;of&nbsp;
                          <?=$spages?>
                        </td>
                      </tr>
                    </table></td>
                </tr>
                <tr>
                  <td colspan="3">&nbsp;</td>
                </tr>
                <tr>
                  <td align="center" valign="middle" colspan="3"><input type="button" name="Back" value="  Back  " onclick="javascript:history.go(-1)" /></td>
                </tr>
              </table></td>
            <td width="50%" valign="top"><table width="100%" border="0" align="center" cellpadding="5" cellspacing="1" bgcolor="#81cafd" style="font-size:11px" >
                <tr bgcolor="#999999" align="center">
                  <td width="2%" height="25" align="left" background="footerbg.jpg" class="whitetxt11">S.No.</td>
                  <td width="18%" align="left" background="footerbg.jpg" class="whitetxt11">School Name</td>
                  <td align="left" background="footerbg.jpg" class="whitetxt11">Person</td>
                  <td align="left" background="footerbg.jpg" class="whitetxt11">Date</td>
                  <td align="left" background="footerbg.jpg" class="whitetxt11">Time</td>
                  <td align="left" background="footerbg.jpg" class="whitetxt11">Foll. Up</td>
                  <td align="left" background="footerbg.jpg" class="whitetxt11">Next</td>
                </tr>
                <?php

	$sql_cust = "SELECT *, (select other from addcontact where  addcontact.school_id=addschool.school_id order by joined desc limit 1) as othernextstep, (select remarktime from addcontact where  addcontact.school_id=addschool.school_id order by joined desc limit 1) as remtime FROM addschool,last_contact where last_contact.school_id >'".$_SESSION['emp_id']."' and last_contact.school_id <'".($_SESSION['emp_id'] + 100000)."' and last_contact.school_id=addschool.school_id and last_contact.status!='Negative' order by remarkdate desc";
	
$result	= mysql_query($sql_cust) or die(mysql_error());
		$num_rows 	= mysql_num_rows($result);	
		
		$incr = 1;
		
		if(!$_REQUEST['tpageno']){
			$tpageno = 1;
		} else {
			$tpageno= $_REQUEST['tpageno'];
		}
		$tpagesize=50;
		$incr = (($tpageno-1)*$tpagesize)+1;
		$first=$tpageno*$tpagesize-($tpagesize-1);
		$last=$first+$tpagesize-1; 
		$temp=($num_rows%$tpagesize);
		if ($temp==0)
		$tpages=($num_rows/$tpagesize);
		else
		$tpages=($num_rows/$tpagesize)+1;
		settype($tpages, "integer"); 

		for($i=1;$i<$first;$i++)
			$row2000=mysql_fetch_row($result);
     
     
     
//<?php
//$query="SELECT * FROM addschool";
//$result=mysql_query($query) or die(mysql_error());
while($res=mysql_fetch_array($result) and ($first<=$last))
{
if($i%2==0) {
	           $x = "bgcolor='#e9f5ff'";
	          } else {
	            $x = "bgcolor='#d8effe'";
 	          }
?>
                <tr <?=$x;?> align="left">
                  <td><? echo $i;?>.</td>
                  <td><?
 if (date("Y-M-d",strtotime($res['remarkdate']))<=date("Y-M-d") && $res['status']!='Paid')
 {
 ?>
                    <font color="#FF0000"><blink><strong><a href="11.php?school_id=<? echo $res['school_id'];?>"><?php echo $res['school_name'];?></a></strong></blink></font>
                    <? 
 }
 else 
 {
 ?>
                    <a href="11.php?school_id=<? echo $res['school_id'];?>"><?php echo $res['school_name'];?></a>
                    <? 
 } 
 ?>
                  </td>
                  <td><? if(date("Y-M-d",strtotime($res['remarkdate']))<=date("Y-M-d") && $res['status']!='Paid')
 {
 ?>
                    <font color="#009900"><blink><strong><?php echo $res['name'];?></strong></blink></font>
                    <? 
 }
 else 
 {
 ?>
                    <?php echo $res['name'];?>
                    <? 
 } 
 ?>
                  </td>
                  <td><? if(date("Y-M-d",strtotime($res['remarkdate']))<=date("Y-M-d") && $res['status']!='Paid')
 {?>
                    <font color="#FF0000"><blink><strong>
                    <?php if($res['remarkdate']=='0000-00-00') echo " - "; else echo date("d-M-y",strtotime($res['remarkdate']));?>
                    </strong></blink></font>
                    <? }
 else 
 {?>
                    <?php if($res['remarkdate']=='0000-00-00') echo " - "; else echo date("d-M-y",strtotime($res['remarkdate']));?>
                    <? 
 } ?>
                  </td>
                  <td><?php echo $res['remtime'];?></td>
                  <td><?php echo $res['followup'];?></td>
                  <td><?php echo $res['othernextstep'];?></td>
                </tr>
                <? 
	 	  $incr++;
	$first++;	
  $i=$i+1;
  } 
	?>
              </table>
              <? if($num_rows > 0){	?>
              <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
              <tr>
                  <td colspan="3"><img src="image/spacer.gif" height="3" /></td>
                </tr>
                <tr>
                  <td   height="26"  valign="middle" background="newbar.jpg" class="table_td_heading" style="padding-left:5px;" width="60%"><span class="table_td_heading">Pages:
                    <? if ($tpageno==1) { ?>
                    &nbsp;
                    <? } else {?>
                    <a href="pmhome.php?tpageno=<?=$pageno-1?>&spageno=<?=$spageno?>" class="table_td_heading">Previous</a>
                    <? } 
					for ($i=1; $i<=$tpages;$i++)
					{
					if($tpageno==$i)	{?>
                    <strong class="table_td_heading"><? echo $i;?></strong>
                    <? }
						else
					{
					if($i%5==0)
{
					?>
                    <strong><a class="table_td_heading" href="pmhome.php?tpageno=<?=$i?>&spageno=<?=$spageno?>">
                    <?=$i?>
                    </a></font></strong>
                    <? 
					}
					}
					}
					?>
                    <? if ($tpageno<$tpages) { ?>
                    <a href="pmhome.php?tpageno=<?=$tpageno+1?>&spageno=<?=$spageno?>" class="table_td_heading">Next</a>
                    <? } else {?>
                    <? } ?>
                    </span></td>
                  <td width="10%" align="right" valign="middle" background="newbar.jpg" class="data"><!--DWLayoutEmptyCell-->&nbsp;</td>
                  <td width="30%" align="center" valign="middle" background="newbar.jpg" class="data"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td align="right" valign="middle" class="table_td_heading" style="padding-right:5px;" width="100%"><strong>Page</strong>&nbsp;
                          <?=$tpageno?>
                          &nbsp;of&nbsp;
                          <?=$tpages?>
                        </td>
                      </tr>
                    </table>
                    <strong></strong></td>
                </tr>
              </table></td>
          </tr>
        </table>
        <table align="center" width="100%">
          <tr>
            <td class="footer" width="100%" >&copy; 2009 TeacherSITY. All rights reserved</td>
          </tr>
        </table>
        <? }?>
        <? }?>
      </form></td>
  </tr>
</table>
</body>
</html>
