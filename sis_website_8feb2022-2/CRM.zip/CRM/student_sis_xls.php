<?php
    error_reporting(0);
	ob_start();
	include('connection.php');
	@extract($_GET);
	header("Content-Type: application/vnd.ms-excel");
	header("Content-Disposition: attachment; filename=Data_Report.xls");
	header("Pragma: no-cache");
	header("Expires: 0"); 
	
	$now=date("j-n-Y");
	//echo $_REQUEST; die;
	echo "\t \t Report ON ".$now."\t";
	$from=date('Y-m-d',strtotime($_REQUEST['from']));
	$to1=$_REQUEST['to'];
	$to=date('Y-m-d',strtotime("$to1,+1 day"));
	$empid=$_REQUEST['empid'];
	$keyword=$_REQUEST['keyword'];
	$infosearch=$_REQUEST['info_search'];
	if(isset($_REQUEST['empid']) && $_REQUEST['empid']!=''){
		$strqry=" and student.emp_id='". $empid."'";
	}
	 if($_GET['info_search']!= '') {
				$key2="and student.status = '".$_GET['info_search']."'";
				$_GET['info_search']="";
			} else {
			$key2=" ";}
	if(strlen($_REQUEST['keyword'])>0){
		$key="%".$_GET['keyword'];
	}  if($order_by != "") {
		$KEYWORD_SEARCH_5="ORDER BY $order_by $img_name";
	} else {
		$KEYWORD_SEARCH_5="ORDER BY joined DESC, student.stud_id DESC";
	}
	if($_REQUEST['from']!="" && $_REQUEST['to']!="") {
				$from1=$_REQUEST['from'];
				$to1=$_REQUEST['to'];
				$from=date('Y-m-d',strtotime("$from1"));
				$to=date('Y-m-d',strtotime("$to1"));
				$t=" and date(student.joined)>='$from' AND date(student.joined)<='$to'"; 
				
			} else {
				$t="";
			}
/*	if(($_REQUEST['from']!='') && ($_REQUEST['to']!='')) {
		$t=" and date(student.joined)>='$from' AND date(student.joined)<='$to'";
	} else {
		$t=" "; 
	} */
	if( $empid > 0) {
		 $sql="SELECT student. * ,members.emp_id, members.emp_name FROM members inner join student on members.emp_id =student.emp_id WHERE student.project_id!='5' and student.emp_id = '$empid'  ".$key2." ".$strqry.$t." $KEYWORD_SEARCH_5";
	} else {
     $sql="SELECT student.* ,members.emp_name FROM members inner join student on members.emp_id =student.emp_id WHERE student.project_id!='5' and stud_name LIKE '".$_REQUEST['schoolname1']."%'  ".$key2."  and (add1 like '".$key."%' or add2 like '".$key."%' or state like '".$key."%' or city like '".$key."%') ". $strqry.$t." $KEYWORD_SEARCH_5";
		
	
	} 
	$result	= mysql_query($sql) or die(mysql_error());
	print("\n");
	print("\n");
	echo "S.No."."\t";
	echo "Student Name"."\t";
	echo "Address"."\t";
	echo "City"."\t";
	echo "State"."\t";
	echo "Contact no."."\t";
	echo "Mobile no."."\t";
	echo "Email-ID"."\t";
	echo "status"."\t";
	echo "Course"."\t";
	echo "Information Source"."\t";
	echo "Query/comments"."\t";
	echo "Coordinator"."\t";
	echo "Payment Status"."\t";
	echo "PKW"."\t";	
	echo "utm_keyword"."\t";
    echo "Visitor Type"."\t";
	echo "Feedback Date"."\t";
	echo "Feedback"."\t";
	
	print("\n");
	$i=1;
	while($res=mysql_fetch_assoc($result)) {
		
        echo $i."\t";
		echo $res['stud_name']."\t";
		echo $res['add1'].$res['add2']."\t";
		echo $res['city']."\t";
		echo $res['state']."\t";
		echo $res['phone_no']."\t";
		echo $res['mobno']."\t";
		echo $res['email']."\t";
		echo $res['status']."\t";
		echo $res['course'].$res['grade']."\t";
		echo $res['information_source'].",".$res['joined']."\t";
		echo $res['comment']."\t";
		echo $res['emp_name']."\t";
		$ress  =   @mysql_fetch_array(mysql_query("select * from ordermanagement where memberid = '".$res['stud_id']."'"),MYSQL_ASSOC);
		echo $res['paymentstatus']."\t";
		echo $res['PKW']."\t";
		echo $ress['utm_keyword']."\t";
        echo $res['v_type']."\t";
		$sql_cust11 = "SELECT * FROM contact WHERE contact.stud_id='".$res['stud_id']."' order by joined asc";
		$result11= mysql_query($sql_cust11) or die(mysql_error());
		//print "\n";
		$j=0;
		if(mysql_num_rows($result11) >0){
		while($res11 = mysql_fetch_assoc($result11)) {
			//echo "<pre>"; print_R($res11);
			/*if($j>0){
				echo "\t"."\t"."\t"."\t"."\t"."\t"."\t"."\t"."\t"."\t"."\t"."\t";
			}*/
			if($res11['joined']!='0000-00-00') {
				echo date("d-M-y", strtotime($res11['joined']))."\t";
			}
			if($res11['followup'] == 'Other'){
				//echo trim($res11['other'])."\t";
				echo str_replace(array("\r\n", "\r", "\n", "\t"), ' ',$res11['other'])."\t";
			}else{
				echo str_replace(array("\r\n", "\r", "\n", "\t"), ' ', $res11['remarktime'])."\t";
				//echo trim($res11['followup'])."\t";
			
		}
		//print "\n";
		$j++;
    }
		}else{
			
		}
	$i+=1;
	print "\n";
	}
?>