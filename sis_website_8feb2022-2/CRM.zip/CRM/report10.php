<?php 
session_start();
ob_start();


require_once('connection.php'); 
$schoolid = $_GET['school_id'];

?>
<?php
//$today = date("Y-m-d");
//$thisMonth=date("Y-m%");
//$time = time("H:i:s");
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Data_Report.xls");
header("Pragma: no-cache");
header("Expires: 0");
$now=date("j-n-Y");




if (strlen($_GET['fromdate'])>0)
{

if (strlen($_GET['todate'])>0)
{
$strqry=" and date(contact.joined) between '".$_GET['fromdate']."' AND '".$_GET['todate']."' ";
}
else
{
$strqry=" and date(contact.joined)='".$_GET['fromdate']."'";
}
}

/*<table width="424" border="0" cellspacing="0" cellpadding="0" align="right"><tr>
    <th width="72" scope="col">Admission</th>
    <th width="15" scope="col" bgcolor="#00C100">&nbsp;</th>
    <th width="34" scope="col">Paid</th>
    <th width="17" scope="col" bgcolor="#008484">&nbsp;</th>
    <th width="66" scope="col">Positive</th>
    <th width="14" scope="col" bgcolor="#7FFFAA">&nbsp;</th>
    <th width="75" scope="col">Moderate</th>
    <th width="14" scope="col" bgcolor="#FFDF55">&nbsp;</th>
    <th width="68" scope="col">Negative</th>
    <th width="12" scope="col" bgcolor="#FF0000">&nbsp;</th>
    <th width="13" scope="col">&nbsp;</th>
  </tr></table>*/
echo ' <table border="1" cellpadding="1" cellspacing="1" >';
echo '<tr><td align="left" colspan="4" >Report ON :<strong>'.$now.'</strong></td><td align="right" colspan="1" ></td><td align="right" colspan="4" ></td></tr><tr>';
//echo "\t \t "."<th>"."Report ON ".$now."</th></tr>"."\t";

$sql_model = mysql_query("SELECT contact.*,contact.joined as jdate,student.stud_name,student.phone_no, student.stud_id FROM  student INNER JOIN contact ON student.stud_id=contact.stud_id WHERE student.emp_id ='".$_SESSION['emp_id']."' and contact.stud_id=student.stud_id ". $strqry." order by contact.joined desc");


/*
$sql_model=mysql_query("SELECT *,addcontact.joined as jdate, members.emp_id,addschool.school_name, addschool.school_id FROM addcontact, members, addschool WHERE emp_id ='".$_GET['emp_id']."' and addcontact.school_id >'".$_GET['emp_id']."' and addcontact.school_id <'".($_GET['emp_id'] + 100000)."' and addcontact.school_id=addschool.school_id ". $strqry." order by addcontact.joined desc");
*/

//print("<tr><td>\n</td></tr>");
print("\n"); 
print("\n"); 
echo '<tr bgcolor="#E8E8E8" style="font:Verdana, Arial, Helvetica, sans-serif">';
	    echo "<th>S.No.</th>"."\t";
		echo "<th>Student Name</th>"."\t";
		echo "<th>Phone Number</th>"."\t";
		echo "<th>Date & Time</th>"."\t";
		
		//echo "Person name"."\t";
		echo "<th>Status</th>"."\t";
		echo "<th>Remark Date</th>"."\t";
		echo "<th>Remark Time</th>."."\t";
		echo "<th>Follow Up</th>"."\t";
		echo "<th>Next Step</th></tr>"."\t";
		
		print("\n"); 
		
		$i=1;
 while($row = mysql_fetch_array($sql_model))
    {
        echo "<tr>";
		echo "<td>".$i."</td>"."\t";
		echo "<td>".$row['stud_name']."</td>"."\t";
		echo "<td>".$row['phone_no']."</td>"."\t";
		echo "<td>".$row['joined']."</td>"."\t";
		
		//echo $row['name']."\t";
		/*if($row['status']=='Negative')
		 {
		echo '<td bgcolor="#FF0000">'.$row['status']."</td>"."\t";
		 }
		elseif($row['status']=='Moderate')
		 {
		 echo'<td bgcolor="#FFDF55">'.$row['status']."</td>"."\t";
		 }
		 elseif($row['status']=='Positive')
		 {
		echo '<td bgcolor="#7FFFAA">'.$row['status']."</td>"."\t";
		 }
		 elseif($row['status']=='Admission')
		 {
		echo '<td bgcolor="#00C100">'.$row['status']."</td>"."\t";
		 }
		 elseif($row['status']=='Paid')
		 {
		echo '<td bgcolor="#008484">'.$row['status']."</td>"."\t";
		 }
		 else
		   {
		 echo '<td >'.$row['status']."</td>"."\t";
		   }
		*/
		echo "<td>".$row['status']."</td>"."\t";
		echo "<td>".$row['remarkdate']."</td>"."\t";
		echo "<td>".$row['remarktime']."</td>"."\t";
		echo "<td>".$row['followup']."</td>"."\t";
		echo "<td>".$row['other']."</td>"."\t";
		echo "</tr>";
		print "\n";
		
		$i+=1;		
    }
echo '</table>';
?>