<?php
session_start();
include('functions.inc.php');
include("connection.php");
if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='Project Manager' && $_SESSION['user_type']!='Tele Caller' && $_SESSION['temp_type']!='y' && $_SESSION['user_type']!='golf')
//if (!isset($_SESSION[myusername]))
{
 header("Location: index.php");
}
$_SESSION['this_page']='golf_follow_ups.php';
if(isset($_REQUEST['update']))
{
	
	extract($_POST);
	//echo "INSERT INTO fb_std_followups(std_id,follow_ups,status,date,time,follow_up_date) VALUES ('".$_REQUEST['id']."','".$follow_ups."','".$status."','".date('Y-m-d',strtotime($date))."','".$time."','".date('Y-m-d')."')";
	
	//die;
	if(isset($date))
	{
		$dt=mysql_query("INSERT INTO golf_followups(golf_id,follow_ups,status,date,time,follow_up_date) VALUES ('".$_REQUEST['id']."','".$follow_ups."','".$status."','".date('Y-m-d',strtotime($date))."','".$time."','".date('Y-m-d')."')") or die(mysql_error());
		
		
	}
	else
	{
		
		$dt=mysql_query("INSERT INTO golf_followups(golf_id,follow_ups,status,date,time,follow_up_date) VALUES ('".$_REQUEST['id']."','".$follow_ups."','".$status."','','".$time."','".date('Y-m-d')."')")or die(mysql_error());
		
	
	}
	
	if($dt)
	{
		$msg="Add Followup successfully";
	}
	
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Golf Data</title>

<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />
<link href="https://cdn.datatables.net/1.10.15/css/dataTables.bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/responsive/2.1.1/css/responsive.bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script> 
<script src="https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js"></script> 
<script src="https://cdn.datatables.net/responsive/2.1.1/js/dataTables.responsive.min.js"></script> 
<script src="https://cdn.datatables.net/responsive/2.1.1/js/responsive.bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="calendar-blue.css">
<script type="text/javascript" src="calendar.js"></script>
<script type="text/javascript" src="calendar-en.js"></script>
<script type="text/javascript" src="calendar-setup.js"></script>

</head>
<body>
<?php include("header.php");
$ed=mysql_fetch_array(mysql_query("select * from golf_lead where id='".$_REQUEST['id']."'"));

?>
</body>
<br />
<?php
 $statusMsgClass = 'alert-success';
if(isset($msg))
{
	 echo '<div class="alert '.$statusMsgClass.'">'.$msg.'</div>';
}
?>
<form name="follow_ups" method="post" action="">
<table align="center" width="40%" style="border:#EFEFEF solid 1px; background-color:#EFEFEF">
<tr><td colspan="2" align="left" style="background-color:#43a2da; padding-left:10px; color:#FFF; height:30px;">User Details</td></tr>
<tr><td colspan="2" align="center" style="height:15px;"></td></tr>
<tr><td style="padding-left:5px;">Enquiry Date:</td><td><?php echo $ed['date']?></td></tr>
<tr><td colspan="2" style="height:10px;"></td></tr>
<tr><td style="padding-left:5px;">Name:</td><td><?php echo $ed['name']?></td></tr>
<tr><td colspan="2" style="height:10px;"></td></tr> 
<tr><td style="padding-left:5px;">Mobile:</td><td><?php echo $ed['mobno']?></td></tr>
<tr><td colspan="2" style="height:10px;"></td></tr>
<tr><td style="padding-left:5px;">E-mail:</td><td><?php echo $ed['email']?></td></tr>
<tr><td colspan="2" style="height:10px;"></td></tr>
<tr><td style="padding-left:5px;">Address:</td><td><?php echo $ed['address']?></td></tr>
<tr><td colspan="2" style="height:10px;"></td></tr>
<tr><td style="padding-left:5px;">Age:</td><td><?php echo $ed['age']?></td></tr>
<tr><td colspan="2" style="height:10px;"></td></tr>
<tr><td style="padding-left:5px;">Occupation:</td><td><?php echo $ed['occupation']?> </td></tr>
<tr><td colspan="2" style="height:10px;"></td></tr>
<tr><td style="padding-left:5px;">Study At:</td><td><?php echo $ed['study_at']?> </td></tr>
<tr><td colspan="2" style="height:10px;"></td></tr>
<tr><td style="padding-left:5px;">School/College Name:</td><td><?php echo $ed['s_c_name']?> </td></tr>
<tr><td colspan="2" align="center" style="height:15px;"></td></tr>
<tr><td style="padding-left:5px;">Class:</td><td><?php echo $ed['class']?> </td></tr>
<tr><td colspan="2" align="center" style="height:15px;"></td></tr>
<tr><td style="padding-left:5px;">Interested in Course:</td><td><?php echo $ed['interested_course']?> </td></tr>
<tr><td colspan="2" align="center" style="height:15px;"></td></tr>
<tr><td style="padding-left:5px;">Information Source:</td><td><?php echo $ed['information_source']?> </td></tr>
<tr><td colspan="2" align="center" style="height:15px;"></td></tr>
<?php if($_SESSION['user_type']=='golf')
{?>  
<tr><td align="left" style="height:15px;padding-left:5px;">Follow Up:</td><td><textarea name="follow_ups" style="width:250px; height:100px;border:none; border:#CCC solid 1px;" required="required"></textarea></td></tr>
<tr><td colspan="2" align="center" style="height:15px;"></td></tr>
<tr><td align="left" style="height:15px;padding-left:5px;">Status:</td><td><select name="status" style="height:25px;" required="required"><option value="">Select Status</option>
<option value="Postive">Postive</option>
<option value="Not Interested">Not Interested</option>
<option value="Moderate">Moderate</option>
<option value="Paid">Paid</option>
<option value="Registration">Registration</option>
<option value="Duplicate">Duplicate</option>
<option value="No Contact">No Contact</option>
<!--<option value="Session 2016-17">Session 2016-17</option>
<option value="Session 2017-18">Session 2017-18</option>-->
<option value="Session 2018-19">Session 2018-19</option>
<option value="Session 2019-20">Session 2019-20</option>
</select></td></tr>
<tr><td colspan="2" align="center" style="height:15px;"></td></tr>
<tr><td style="height:15px;padding-left:5px;">Reminder:</td><td><input type="checkbox" onclick="s_data()" id="show_data"/></td></tr>
<tr><td colspan="2" align="center" style="height:15px;"></td></tr>
<tr><td></td><td><div style="width:100%;height:30px;" id="dt"></div></td></tr>
<tr><td colspan="2" align="center" style="height:15px;"></td></tr>

<tr><td></td><td><input type="submit" name="update"  class="btn btn-primary" value="Submit"/></td></tr>
<?php }?>
<tr><td colspan="2" align="center" style="height:15px;"></td></tr>
<tr><td colspan="2" align="left" style="height:15px;padding-left:5px;">
<table id="listitemdata"  class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
<thead>
                    <tr>
                    <th>Sr.No.</th><th>Follow Up</th><th>Status</th><th>Follow Up date</th><th>Reminder (Date Time)</th></tr></thead>
                    <tbody>
                     <?php $query = mysql_query("SELECT * FROM golf_followups where golf_id='".$_REQUEST['id']."' ORDER BY id DESC");
					 $count=mysql_num_rows($query);
					 $i=1;
					 if($count>0)
					 {
					  while($row = mysql_fetch_array($query))
					  {
					  ?>
                    <tr><td><?php echo $i;$i++;?></td><td><?php echo $row['follow_ups'];?></td>
                    <td><?php echo $row['status'];?></td>
                    <td><?php  if($row['follow_up_date']=='0000-00-00' or $row['follow_up_date']=='')
					{echo "--";}else{ echo date('d-m-Y',strtotime($row['follow_up_date']));}?></td><td><?php if($row['date']=='0000-00-00' or $row['date']=='')
					{
						echo '--';
					}else{echo date('d-m-Y',strtotime($row['date']));
					}
					echo "&nbsp";
					if($row['time']=='00:00:00'){ echo "--";}else{echo $row['time'];}
					?></td></tr>
                    <?php }}
					else
					{?>
                    <tr><td colspan="5" align="center" style="font-weight:bold;">No Data Found</td></tr>
					<?php }
					?></tbody>
</table>


</td></tr>
</table>
</form>

<script>
$(document).ready(function() {
    
	$('#listitemdata').DataTable();
	
	
});
function s_data()
{
	if(document.getElementById("show_data").checked==true)
	//if($("#show_data").is(':checked'))
	{
		//alert('checked');
		document.getElementById("dt").innerHTML='<div style="float:left; width:120px;">Date:&nbsp;&nbsp;<input type="text" style="width:90px;" name="date" id="date" required="required"/>&nbsp;<img src="CalendarIcon.gif" name="get_stud_date33" width="22" height="23" border="0" align="absmiddle" id="get_stud_date33" style="cursor: pointer;" title="Date selector"   /></div><div style="float:left;width:100px;">Time:&nbsp;&nbsp;<input type="text" name="time" id="time" required="required" style="width:70px;"/></div>';
		
		Calendar.setup({
        inputField     :    "date",     // id of the input field
	    //ifFormat       :    "%Y/%m/%d %l:%M %P",      // format of the input field
	  	//ifFormat       :    "%m-%d-%Y",      // format of the input field
	  	ifFormat       :    "%d-%m-%Y",      // format of the input field
        button         :    "get_stud_date33",  // trigger for the calendar (button ID)
        align          :    "Tl",           // alignment (defaults to "Bl")
        singleClick    :    true,
		showsTime		:	true
    });

	
		
	}
	else
	{
		document.getElementById("dt").innerHTML='';
		//$("#dt").html('');
		//$("#dt").hide();
		//alert('unchecked');
		
		
	}
}


</script>



 
</html>