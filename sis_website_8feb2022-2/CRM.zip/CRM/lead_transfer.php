<?php
session_start();
include("connection.php");
if (isset($_POST['submit5']))
{
$school_ids = $_POST['school_id'];
$emp_ids_from = $_POST['emp_id'];
 
//print_r($school_ids);
$sid_cnt = count($school_ids);
//for($i=0;$i<$sid_cnt;$i++)
$emp=$_POST['employee_id'];
$from_id=$_SESSION['emp_id'];

// For Admin we are using the if part
for($i=0;$i<$sid_cnt;$i++)
{

$insert_transfer = "INSERT INTO transferred_lead(stud_id, emp_from_id, emp_to_id, transfer_date, transferred_by_id) VALUES('$school_ids[$i]', '$emp_ids_from[$i]','$emp' , now(), '$emp_ids_from[$i]')";

$res_transfer = mysql_query($insert_transfer) or die(mysql_error());

$update_id = "UPDATE student SET emp_id='$emp' where stud_id='$school_ids[$i]'";
$result_id=mysql_query($update_id) or die(mysql_error());


$empid=$_SESSION['emp_id'];
$msg='You have been transfered a lead by '.$_SESSION['myusername'].' <a href="11.php?stud_id='.$school_ids.'">Click here to see the Lead</a>';

}
header("Location: adminhome.php?empid=".$_SESSION['emp_id']."&msg1=Lead Transfer Successfully......");
}

if (isset($_POST['delete']))
{
$school_ids = $_POST['school_id'];
$emp_ids_from = $_POST['emp_id'];
 
//print_r($school_ids);
$sid_cnt = count($school_ids);
//for($i=0;$i<$sid_cnt;$i++)
$emp=$_POST['employee_id'];
$from_id=$_SESSION['emp_id'];

// For Admin we are using the if part
for($i=0;$i<$sid_cnt;$i++)
{

$deletequery=mysql_query("delete from student where stud_id='$school_ids[$i]' ");
$msg='You have been deleted a lead';

}
header("Location: adminhome.php?msg1=Lead Deleted Successfully......");
}

?>