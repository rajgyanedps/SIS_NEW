<?php
session_start();
include("connection.php");
if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='Project Manager' && $_SESSION['user_type']!='Tele Caller')
//if (!isset($_SESSION[myusername]))
{
 header("Location: index.php");
}
?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Employee School Report</title>
<script type="text/javascript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php
include("reportheader.php");
?>
<form action="empreport.php" method="post" name="empreport">
<table align="center"><tr><td width="1000px" align="center"><marquee behavior="slide" direction="left"><font size="4.5" face="Verdana, Arial, Helvetica, sans-serif"><b>Total <?php echo $_GET['stat'];?> School</b></font></marquee></td></tr></table>

<font color="#000000" style="padding-left:15px"><b>Convert to Excel(+Ve)</b>&nbsp;&nbsp;<a href="#" onClick="javascript:window.open('report3.php?stat=Positive','myReport','');"><img src="logo_excel.gif" alt="Export" border="0"></a></font>

&nbsp;
<font color="#000000"><b>Convert to Excel(-Ve)</b>&nbsp;&nbsp;<a href="#" onClick="javascript:window.open('report3.php?stat=Negative','myReport','');"><img src="logo_excel.gif" alt="Export" border="0"></a></font>

&nbsp;
<font color="#000000"><b>Convert to Excel(Mod.)</b>&nbsp;&nbsp;<a href="#" onClick="javascript:window.open('report3.php?stat=Moderate','myReport','');"><img src="logo_excel.gif" alt="Export" border="0"></a></font>
<br /><br />
<table width="100%" border="0" align="center" cellpadding="5" cellspacing="0" bgcolor="#81cafd" style="font-size:13px">
<tr bgcolor="#999999" align="center">

      <td align="left" background="footerbg.jpg" class="whitetxt11" width="4%">S.No.</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="8%"><a href="empreport.php?pageno=<?=$_REQUEST['pageno']?>">School Id</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="25%"><a href="empreport.php?pageno=<?=$_REQUEST['pageno']?>">School Name</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="19%"><a href="empreport.php?pageno=<?=$_REQUEST['pageno']?>">Address 1</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="19%"><a href="empreport.php?pageno=<?=$_REQUEST['pageno']?>">Address 2</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="15%"><a href="empreport.php?pageno=<?=$_REQUEST['pageno']?>">City</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="10%"><a href="empreport.php?pageno=<?=$_REQUEST['pageno']?>">Phone No</a></td>
    </tr>
                <? 
	   $sql_cust = "SELECT last_contact.school_id, last_contact.status, addschool.school_id, addschool.school_name, addschool.add1,addschool.add2, addschool.city, addschool.phone_code, addschool.phone_no FROM last_contact, addschool WHERE last_contact.status='".$_GET['stat']."' and addschool.school_id=last_contact.school_id order by last_contact.school_id asc";

		$result	= mysql_query($sql_cust) or die(mysql_error());
		$num_rows 	= mysql_num_rows($result);	
		$incr = 1;
		
		if(!$_REQUEST['pageno']){
			$pageno = 1;
		} else {
			$pageno= $_REQUEST['pageno'];
		}
		$pagesize=800;
		$incr = (($pageno-1)*$pagesize)+1;
		$first=$pageno*$pagesize-($pagesize-1);
		$last=$first+$pagesize-1; 
		$temp=($num_rows%$pagesize);
		if ($temp==0)
		$pages=($num_rows/$pagesize);
		else
		$pages=($num_rows/$pagesize)+1;
		settype($pages, "integer"); 

		for($i=1;$i<$first;$i++)
			$row2000=mysql_fetch_row($result);
     
     
     
//<?php
//$query="SELECT * FROM addschool";
//$result=mysql_query($query) or die(mysql_error());
while($res=mysql_fetch_array($result) and ($first<=$last))
{
if($i%2==0) {
	           $x = "bgcolor='#e9f5ff'";
	          } else {
	            $x = "bgcolor='##d8effe'";
 	          }
?>

<tr <?=$x;?> align="left">
        <td width="4%"><? echo $i;?>.</td>
        <td width="8%"><?php echo $res['school_id'];?></td>
                <td width="25%"><?php echo $res['school_name'];?></td>
                     <td width="19%"><?php echo $res['add1'];?></td>
                         <td width="19%"><?php echo $res['add2'];?></td>
                         <td width="15%"><?php echo $res['city'];?></td>
                         <td width="10%"><?php echo $res['phone_code']." ".$res['phone_no']; ?></td>
    </tr>
                         
 <? 
	 	  $incr++;
	$first++;	
  $i=$i+1;
  } 
	?>
  </table>
        
  <? if($num_rows > 0){	?>
  <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
			  
<tr><td colspan="3"></td></tr>
			  <tr>
				<td   height="26"  valign="middle" background="newbar.jpg" class="table_td_heading" style="padding-left:5px;">
					<span class="table_td_heading">Pages:
					<? if ($pageno==1) { ?>
					&nbsp; 
					<? } else {?> 
					<a href="empreport.php?pageno=<?=$pageno-1?>" class="table_td_heading">Previous</a>
				    <? } 
					for ($i=1; $i<=$pages;$i++)
					{
					if($pageno==$i)	{?>
				    <strong class="table_td_heading"><? echo $i;?></strong>
				    <? }
						else
					{
					?>
				    <strong><a class="table_td_heading" href="empreport.php?pageno=<?=$i?>">
					<?=$i?>
					</a></font></strong>
				    <? }
					}
					?>
				    <? if ($pageno<$pages) { ?>
				    <a href="empreport.php?pageno=<?=$pageno+1?>" class="table_td_heading">Next</a>
				    <? } else {?>
				    <? } ?>				
		        </span></td>
				<td width="40" align="right" valign="middle" background="newbar.jpg" class="data">&nbsp;</td>
				<td width="125" align="center" valign="middle" background="newbar.jpg" class="data"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td align="right" valign="middle" class="table_td_heading" style="padding-right:5px;"><strong>Page</strong>&nbsp;
                    <?=$pageno?>
&nbsp;of&nbsp;
<?=$pages?>                    </td>
                  </tr>
                  
                </table>				  
			    <strong></strong></td>
			  </tr>
</table>
<table width="100%" align="center">
<tr>
<td><img src="image/spacer.gif" height="5" /></td>
</tr>
<tr>
<td class="footer" width="935" >&copy; 2009 TeacherSITY. All rights reserved</td>
</tr>

</table>
  <? }?>

</form>

</body>
</html>