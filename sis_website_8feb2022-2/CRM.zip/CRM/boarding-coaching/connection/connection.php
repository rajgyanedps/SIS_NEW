<?php 

/*

$hostname = "siscoching.db.5227155.hostedresource.com";
$user     = "siscoching";
$password = "Sischo1#";
$DataBase = "siscoching"; 
*/

$hostname = "localhost";
$user     = "root";
$password = "";
$DataBase = "siscoching";
//$DataBase ="crm";

$connection = mysql_connect($hostname,$user,$password);
if(!$connection){
                        echo "Connection Not Establish ";
                 }
else {
            $database = mysql_select_db($DataBase,$connection);
			if(!$database){
			                   echo "DataBase Not Found";
			               }
     }
	
?>