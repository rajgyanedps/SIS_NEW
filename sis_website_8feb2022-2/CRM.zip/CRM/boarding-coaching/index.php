<?php ob_start();
@session_start();
error_reporting(0);
include("connection/connection.php");
$name = $_POST['name']; // Name Input Box Value
$mail = $_POST['email']; // Mial Input Box Value
$Phon = $_POST['telephone']; // Phon Input Box Value
$city = $_POST['city']; // City Input Box Value
$state = $_POST['state']; // State Input Box Value
$class = $_POST['stclass']; // Class Input Box Value
$Info = $_POST['stclass2'];
$sch_class=$class;
$email=$mail;
$mobile=$Phon;
//echo "<pre>";
//print_r($_REQUEST);  die('dfdf');
////http://www.selaqui.org/iit-jee/landing/index.php?PSE=Google&PAC=selaquiindia&PCA=ResonanceCampaign&PAG=ResonenceIIT&PKW=Residential%20iit%20coaching&PMT=b&PDS=S&PPC=&PAD=35078563184&gclid=CPCB8--fyLkCFSFV4god3FAAKQ

/*if(!empty($_REQUEST['PSE']) || !empty($_REQUEST['PAC']) || !empty($_REQUEST['PCA']) && !empty($_REQUEST['PAG']) && !empty($_REQUEST['PKW']) && !empty($_REQUEST['PMT']) && !empty($_REQUEST['PDS']) || !empty($_REQUEST['PPC']) || !empty($_REQUEST['PAD']) )
{*/
if($_REQUEST['PSE'] || $_REQUEST['PAC'] || $_REQUEST['PCA'] && $_REQUEST['PAG'] && $_REQUEST['PKW'] && $_REQUEST['PMT'] || $_REQUEST['PDS'] || $_REQUEST['PPC'] || $_REQUEST['PAD'] )
{
$_SESSION['campaign_key']=array(
							'PSE' => $_REQUEST['PSE'],
							'PAC' => $_REQUEST['PAC'],
							'PCA' => $_REQUEST['PCA'],
							'PAG' => $_REQUEST['PAG'],
							'PKW' => $_REQUEST['PKW'],
							'PMT' => $_REQUEST['PMT'],
							'PDS' => $_REQUEST['PDS'],
							'PPC' => $_REQUEST['PPC'],
							'PAD' => $_REQUEST['PAD']);

}
$_SESSION['v_type']='PPC';
$visitor=$_SESSION['v_type']; 
// Information Source Select Box Value
$VarificationCode = md5(time().rand(9,20)); // Random  code use for varification input Box Value


if(isset($_POST['continue_reg']))
    {     
	if(empty($_SESSION['6_letters_code']) || strcasecmp($_SESSION['6_letters_code'], $_POST['6_letters_code']) != 0)
				{ 
				   $errors = "\n The Image code does not match!";
				}
                if(!$errors)
				 {    
		  		  if(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) 
        		 { 
         			 $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
         		 } 
      				 else if(!empty($_SERVER['REMOTE_ADDR'])) 
       		      { 
       				  $ip = $_SERVER['REMOTE_ADDR']; 
        	      } 
      			     
		   			$filed = $_SESSION['campaign_key'];
                  
					   $QueryStatementForRegistration = "insert into registration set
												  Name             =     '".$name."',
												  Email            =     '".$mail."',
												  Mobileno          =     '".$Phon."',
												  City             =     '".$city."',
												  ClassStudying    =     '".$class."',
												  varificationcode =     '".$VarificationCode."',
												  Informationsource =     '".$Info."',
												  State             =     '".$state."',
												  ip_address		=     '".$ip."',
												  v_type         	 ='".$visitor."',
												  PSE ='".$filed['PSE']."',
													PAC='".$filed['PAC']."',
													PCA ='".$filed['PCA']."',
													PAG ='".$filed['PAG']."',
													PKW = '".$filed['PKW']."',
													PMT = '".$filed['PMT']."',
													PDS = '".$filed['PDS']."',
													PPC = '".$filed['PPC']."',
													PAD = '".$filed['PAD']."',
												  date              =     NOW()"; 
				$RegistrationQuery = mysql_query($QueryStatementForRegistration) or die(mysql_error());
                                       $stud_id= mysql_insert_id();
									   									   
									   
									 /*  if($_SESSION['campaign_key'] and  $stud_id!="")
									   {
									   		insert_Campaign_SearchKey($_SESSION['campaign_key'],$stud_id);
											unset($_SESSION['campaign_key']);
									   }
									*/
                                       //$query_stud="insert into student set `stud_id`='$stud_id',`joined`=NOW(),`stud_name`='$name',`city`='$city',`mobno`='$Phon',`email`='$mail',`state`='$state',`course`='$class',`stream`='$class',`information_source`='$Info',`emp_id`='100100'";
									   //$queryy=mysql_query($query_stud) or die(mysql_error());
//echo $QueryStatementForRegistration;die;
//////Send E-mail
			  $subject = 'Verification Mail by Selaqui.org';
			    $message = '
			    <html>
			    <body>
			     
			    
				<table cellspacing="0" width="600" cellpadding="4" border="0" align="left" style="border:1px solid #CCC">
                                           <tr>
                                             <td align="left"><img src="http://www.selaqui.org/IIT-JEE/landing/images/mailheader.jpg" width="600" height="107"/></td>
                                           </tr>
                                           <tr>
                                             <td align="left"><img src="http://www.selaqui.org/IIT-JEE/landing/images/result_iit_jee.png" width="600" height="91"/></td>
                                           </tr>
                                           <tr>
                                             <td align="left"><table width="550" border="0" align="center" cellpadding="0" cellspacing="0" style="font-family:Tahoma, Geneva, sans-serif; font-size:14px; line-height:18px;">
                                               <tr>
                                                 <td><strong>Hi '.ucwords($name).',</strong></td>
                                               </tr>
                                               <tr>
                                                 <td>&nbsp;</td>
                                               </tr>
                                               <tr>
                                                 <td>Thank you for showing interest in Gurukul IIT-JEE program By SelaQui-Resonance. Our counsellor will get in touch with you shortly.</td>
                                               </tr>
                                               <tr>
                                                 <td>&nbsp;</td>
                                               </tr>
                                               <tr>
                                                 <td>Your details we received are as given below:</td>
                                               </tr>
                                               <tr>
                                                 <td>Name:'.ucwords($name).'</td>
                                               </tr>
                                               <tr>
                                                 <td>Email Id: '.$mail.'</td>
                                               </tr>
                                               <tr>
                                                 <td>Mobile:  '.$Phon.'</td>
                                               </tr>
                                               <tr>
                                                 <td>City:  '.$city.'</td>
                                               </tr>
                                               <tr>
                                                 <td>State:  '.$state.'</td>
                                               </tr>
                                               <tr>
                                                 <td>Class:  '.$class.'</td>
                                               </tr>
                                               <tr>
                                                 <td>&nbsp;</td>
                                               </tr>
                                               <tr>
                                                 <td>Please <a href="http://selaqui.org/iit-jee/verification.php?mailid='.$mail.'&&varcode='.$VarificationCode.'">click here</a> to confirm your details or write us at gurukul.iit@selaqui.org in case of any change in your personal details.</td>
                                               </tr>
                                               <tr>
                                                 <td>&nbsp;</td>
                                               </tr>
                                               <tr>
                                                 <td><strong>Thanks,<br/>
Team  Gurukul IIT-JEE</strong></td>
                                               </tr>
                                             </table></td>
                                           </tr>
                       <tr>
                         <td align="left">&nbsp;</td>
                       </tr>
                       </table>
			  </body>
			</html>';
			  $headers  = 'MIME-Version: 1.0' . "\r\n";
			  $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
			  $headers .= 'From:  Gurukul IIT-JEE<gurukul.iit@selaqui.org>' . "\r\n";
			 $sendmail= mail($mail,$subject,$message,$headers);
                          header("location:index.php?succ=s");
                          if($sendmail)
         {
           include('../../mailcontent/message.php');
             mail($to,$subject1,$txt1,$headers);   }
			 // header("location:index.php?succ=s");
			 if($sendmail){
			   echo '<script>window.location ="index.php?succ=s";</script>';
			   
			  }
	  
		}
	}
	function insert_Campaign_SearchKey($filed,$id="")
	{
		$sql= "update registration set 
				PSE ='".$filed['PSE']."',
				PAC='".$filed['PAC']."',
				PCA ='".$filed['PCA']."',
				PAG ='".$filed['PAG']."',
				PKW = '".$filed['PKW']."',
				PMT = '".$filed['PMT']."',
				PDS = '".$filed['PDS']."',
				PPC = '".$filed['PPC']."',
				PAD = '".$filed['PAD']."'
				where id=$id ";
		mysql_query($sql);
				
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>IIT-JEE</title>

<link rel="stylesheet" type="text/css" href="css/jquery.fancybox.css">
<link rel="stylesheet" type="text/css" href="css/jquery.fancybox-buttons.css">
<style type="text/css">
/* this demo specifc styles */
.imgContainer {
  width:144px;
  height: 105px;
  overflow: hidden;
  text-align: center;
  margin: 10px 16px 10px 0;
  float: left;
  border: solid 1px #999;
  display: block;
}
.imgContainer:hover{
  border-bottom: solid 1px #444;
    border-left: solid 1px #444;
 -webkit-box-shadow: -3px 3px 10px 1px #777;
    -moz-box-shadow: -3px 3px 10px 1px #777;
         box-shadow: -3px 3px 10px 1px #777;
         margin: 9px 19px 11px 1px;
}
#galleryTab {
  top: 26px;
  width:1000px;
}
}

.filter {
  border: 1px solid #ccc;
  color: #333333;
  float: left;
  font-size: 12px;
  margin: 0 12px 0 0;
  padding:12px 35px;
  text-align: center;
  text-decoration: none;
 -webkit-border-radius: 3px;
    -moz-border-radius: 3px;
         border-radius: 3px;
		 background:#DEDCCF;
}
.filter:hover {
  background-color: #f8f8f8;
 -webkit-box-shadow: -2px 2px 5px 1px #a3a3a3;
    -moz-box-shadow: -2px 2px 5px 1px #a3a3a3;
         box-shadow: -2px 2px 5px 1px #a3a3a3;
  margin: -1px 11px 1px 1px;
  border-bottom: solid 1px #aaa;
  border-left: solid 1px #aaa;
   background:url(images/active.png)0 -51px repeat-x;
   display:block;
}
.filter.active {
  background-color: #0080e3;
  background:url(images/active.png)0 0 repeat-x;
  border: 1px solid #ccc;
  color: #000;
  cursor: default;
  margin: 0 12px 0 0;
 -webkit-box-shadow: none;
    -moz-box-shadow: none;
         box-shadow: none;
		 color:#FFF;
}
</style>
<script src="js/jquery-1.8.3.min.js"></script>

<script src="js/jquery.fancybox.pack.js"></script>
<script src="js/jquery.fancybox-buttons.js"></script>
<script>
jQuery(function($){
  $(".fancybox").fancybox({
    modal: true,
    helpers : { buttons: { } }
  });
  $(".filter").on("click", function () {
    var $this = $(this);
    // if we click the active tab, do nothing
    if (!$this.hasClass("active")) {
      $(".filter").removeClass("active");
      $this.addClass("active"); // set the active tab
      var $filter = $this.data("rel"); // get the data-rel value from selected tab and set as filter
      $filter == 'all' ? // if we select "view all", return to initial settings and show all
        $(".fancybox").attr("data-fancybox-group", "gallery").not(":visible").fadeIn() 
        : // otherwise
        $(".fancybox").fadeOut(0).filter(function () { 
          return $(this).data("filter") == $filter; // set data-filter value as the data-rel value of selected tab
        }).attr("data-fancybox-group", $filter).fadeIn(1000); // set data-fancybox-group and show filtered elements
    } // if
  }); // on
}); // ready
</script>

<link href="css/style.css" rel="stylesheet" type="text/css" /><script type="text/javascript" src="js/html5shiv.js"></script>
<link href="css/bootstrap.css" rel="stylesheet">
<script src="js/jquery.js"></script>
<script src="js/bootstrap-tab.js"></script>

<script>
function validate_udetail()
{
	if(document.userdetails.name.value=="" || document.userdetails.name.value=="Student Name")
	{
		alert("Enter name");
		document.userdetails.name.focus();
		return false;
	}
	
	var emailID=document.userdetails.email
	
	if (document.userdetails.email.value=="" || document.userdetails.email.value=="Email")
	{
		alert("The e-mail ld is blank or \n an invalid value has been entered.");
        document.userdetails.email.focus();		
        return false;
    }
	if (echeck(emailID.value)==false)
	{
		emailID.value=""
		emailID.focus()
		return false
	}
	
	
	if(document.userdetails.telephone.value=="" || document.userdetails.telephone.value=="Mobile")
	{
		alert("Enter Mobile No");
		document.userdetails.telephone.focus();
		return false;
	}
	
	if(document.userdetails.telephone.value!="")
		{
			var stripped1 = document.userdetails.telephone.value.replace(/[\(\)\.\-\ ]/g, '');
			if(isNaN(parseInt(stripped1)))
			{
				alert("The mobile number contains illegal characters");
				document.userdetails.telephone.focus();
				return false;			
			}
			else if ((stripped1.length < 10) || (stripped1.length > 12))
			{
        	
				alert("The mobile number is the wrong length.");
				document.userdetails.telephone.focus();
				return false;
			
    		} 
		
	} 
	if(document.userdetails.state.value=="" || document.userdetails.state.value=="State")
	{
		alert("Enter State");
		document.userdetails.state.focus();
		return false;
	}
	
	if(document.userdetails.city.value=="" || document.userdetails.city.value=="City")
	{
		alert("Enter City");
		document.userdetails.city.focus();
		return false;
	}
	
	


	if(document.userdetails.stclass.value=="" || document.userdetails.stclass.value=="Only for Class Xth Students")
	{
		alert("Select Class");
		document.userdetails.stclass.focus();
		return false;
	}
        if(document.userdetails.stclass2.value=="" || document.userdetails.stclass2.value=="Information Source")
	{
		alert("Select Information Source");
		document.userdetails.stclass2.focus();
		return false;
	}
		if(document.userdetails.letters_code.value=="" || document.userdetails.letters_code.value=="Enter code")
	{
		alert("Enter Verification Code");
		document.userdetails.letters_code.focus();
		return false;
	}
	return true;
}


function echeck(str) {

		var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
		   alert("Invalid E-mail ID")
		   return false
		}

		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   alert("Invalid E-mail ID")
		   return false
		}

		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    alert("Invalid E-mail ID")
		    return false
		}

		 if (str.indexOf(at,(lat+1))!=-1){
		    alert("Invalid E-mail ID")
		    return false
		 }

		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    alert("Invalid E-mail ID")
		    return false
		 }

		 if (str.indexOf(dot,(lat+2))==-1){
		    alert("Invalid E-mail ID")
		    return false
		 }
		
		 if (str.indexOf(" ")!=-1){
		    alert("Invalid E-mail ID")
		    return false
		 }

 		 return true					
	}


</script>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-4634742-2']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>



</head>
<body>
<div class="main_cont">

  <div class="main">
    <div class="header">
      <div class="reso_logo"><img src="images/reso_logo.jpg" width="315" height="93" /></div>
      <div class="right_header">
        <div class="call_us"> 9873743433<br />
          9811955524</div>
        <div class="email"><a href="mailto:gurukul.iit@selaqui.org">gurukul.iit@selaqui.org</a></div>
      </div>
      <div class="selaqui_logo"><img src="images/selaqui_logo.png" width="67" height="94" /></div>
    </div>
    <div id="enqiryform">

<h2> <?php 
if(isset($_GET['succ'])=='s')
   {  
     $Data = '<div  style="font-size:11px; color:#F3D943; padding:5px 0px;"><b>'."Thank you for showing your interest."."<br/>".

"Kindly check your email for verification.".'</b></div>';
     echo $Data;
     ?>

<!-- Google Code for Visitor Conversion Page -->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 1040837567;
var google_conversion_language = "en";
var google_conversion_format = "2";
var google_conversion_color = "ffffff";
var google_conversion_label = "xZqHCK2G9QEQv9en8AM";
var google_conversion_value = 1.000000;
var google_remarketing_only = false;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//www.googleadservices.com/pagead/conversion/1040837567/?value=1.000000&amp;label=xZqHCK2G9QEQv9en8AM&amp;guid=ON&amp;script=0"/>
</div>
</noscript>


<?php
    }
   ?>
   <? //print_r($_REQUEST);
   //print_r($_SESSION);
   if($_REQUEST['succ']=='s'){ 
		   
		   if ($_SESSION['leaddone']==1){
		   		   ?> 
                   

             <? // $_SESSION['leaddone']=0;
			 } ?>
<!--           <div align="center" style="padding:30px;" class="ari13"> 
             <p><strong>Thank you for showing your interest.
             </strong><br />
             <br />
        
Kindly check your email for verification.</p>
             <p>You may want to visit <br />
               <a href="http://www.selaqui.org"><strong>www.SelaQui.org </strong></a><br />
             for more details</p>
        </div>-->
            <?  } else{ ?>
              <?php if($errors){ ?>
                  <div ><font color="red"><?php print $errors; unset($errors); ?></font></div>
                  <? }}?>
     <form name="userdetails" id="form" action="" method="post" onSubmit="return validate_udetail();" >
    <table width="250" border="0" cellspacing="0" cellpadding="0">
  
  <tr>
    <td>
      <input name="name" id="name" type="text"  value="<? if($name!=''){ echo $name; }else { echo "Student Name"; }?>" class="txtfield"  onfocus="if(this.value=='Student Name'){this.value=''};" onBlur="if(this.value==''){this.value='Student Name'};"/>    </td>
    </tr>
  
  <tr>
    <td>   <input name="email" type="text" value="<? if($Email!=''){ echo $Email; }else { echo "Email"; }?>" onFocus="if(this.value=='Email'){this.value=''};" onBlur="if(this.value==''){this.value='Email'};" value="Email" class="txtfield" /></td>
    </tr>
  
  <tr>
    <td>  <input name="telephone" type="text" value="<? if($mobile!=''){ echo $mobile; }else { echo "Mobile"; }?>" onFocus="if(this.value=='Mobile'){this.value=''};" onBlur="if(this.value==''){this.value='Mobile'};" value="Mobile" class="txtfield" /></td>
    </tr>
             
             <tr>
    <td>   <input name="state" type="text" value="<? if($state!=''){ echo $state; }else { echo "State"; }?>" onFocus="if(this.value=='State'){this.value=''};" onBlur="if(this.value==''){this.value='State'};" value="State" class="txtfield" /></td>
    </tr>
          
   
          <tr>
    <td>   <input name="city" type="text" value="<? if($city!=''){ echo $city; }else { echo "City"; }?>"  onFocus="if(this.value=='City'){this.value=''};" onBlur="if(this.value==''){this.value='City'};" value="City" class="txtfield" /></td>
    </tr>
          
          <tr>
    <td>  <input name="stclass" type="text" value="<? if($class!=''){ echo $class; }else { echo "Only for Class Xth Students"; }?>" onFocus="if(this.value=='Only for Class Xth Students'){this.value=''};" onBlur="if(this.value==''){this.value='Only for Class Xth Students'};" value="Only for Class Xth Students" class="txtfield" /></td>
    </tr>
          
          <tr>
    <td class="stclass2"> <select name="stclass2" >
      <option value="">Information Source</option>
      <option value="Google" <? if($Info=='Google'){ echo "selected=selected";} ?>>Google</option>
      <option value="Facebook" <? if($Info=='Facebook'){ echo "selected=selected";} ?>>Facebook</option>
      <option value="Referral" <? if($Info=='Referral'){ echo "selected=selected";} ?>>Referral</option>
      <option value="Seminar" <? if($Info=='Seminar'){ echo "selected=selected";} ?>>Seminar</option>
      <option value="Newspaper Article" <? if($Info=='Newspaper Article'){ echo "selected=selected";} ?>>Newspaper Article</option>
    </select></td>
    </tr>
  <tr>
      <td>
          <div class="capcha float_l"> <img src="Capcha/captcha_code_file.php?rand=<?php echo rand(); ?>" id='captchaimg' class="float_l capcha-img" />
                 <input id="letters_code" name="6_letters_code" type="text" value="Enter code" onClick="this.value='';"  style="width:132px; height:32px; margin-left:10px; float:left;" class="txtfield " />
                <div class="float_l">

                 
                  <div style="float:left; font-size:11px; font-weight:normal; padding:2px 0 17px 0;">Can't read the image? <a href='javascript: refreshCaptcha();'>Click here</a> to refresh</div>
</div>

 </div>
      </td>
  </tr>
  
  <tr>
    <td align="center"><input type="Submit" name="continue_reg" id="button" value="" class="button" /></td>
  </tr>
  </table></form>

</h2>



</div>
    <div class="banner">
      <div class="features">
        <ul>
          <li class="cbse">CBSE + Medical Curriculum</li>
          <li class="safe">Safe &amp; Secure Campus</li>
          <li class="separate">Separate Hostels</li>
        </ul>
        <ul>
          <li class="healthy">Healthy &amp; Nutritious Food</li>
          <li class="extra">Extra Curricular Activities</li>
          <li class="teachers">24x7 Teachers Guidance</li>
        </ul>
      </div>
    </div>
    
    <br />
    <div class="online_test">Online Admission Test - 23 March &amp; 06 April. 2014<span><a href="http://www.selaqui.org/IIT-JEE/apply-online.php" target="_blank">&nbsp;</a></span></div>
    <div class="float_l"><img src="images/world_class.png" width="680" height="97" /></div>
    <div class="float_r"><img src="images/cbse.png" /></div>
    <div class="cl"></div>
    <div id="bottom_wrapper">

<div class="highlight">
<h1>Academics</h1>
<h2><img src="images/acadmic.jpg">
<p><strong>SelaQui classrooms</strong> and labs are equipped with the latest audio video  equipement. Rich and spacious digital libraries. Teachers live on the campus.</p></h2>
</div>
<div class="highlight">
<h1>Health Care</h1>
<h2><img src="images/health.jpg">
<p><strong>AROGYA</strong>, the school infirmary and health center provides medical cover round the clock.<br>
  SelaQui ensures timely support in case of emergency
</p></h2>
</div>
<div class="highlight">
<h1>Hostel</h1>
<h2><img src="images/hostel.jpg">
<p><strong>Modern &amp; comfortable hostels. </strong><br>
  Separate hostels for boys and girls attached modern bathroom. Running hot water during winters. 24x7 electricity. </p></h2>
</div>
<div class="highlight">
<h1>Safety &amp; Security</h1>
<h2><img src="images/safety.jpg">
<p>The campus is guarded by trained ex-army personnel 24x7. All entries and exits are regulated. CCTV records all movement ensuring safety &amp; security of students.</p></h2>
</div>
<div class="highlight" style="margin-right:0;">
<h1>Sports</h1>
<h2><img src="images/extra.jpg">
<p>Extensive playgrounds and world- class infrastructure for sports.<br>
  <strong>Sports</strong> - Football, Tennis, Swimming, Cricket, Yoga, Basketball, Volley ball, Shooting &amp; Trekking. </p></h2>
</div>


</div><div class="cl"></div>
<div class="testimonials_cont" style="padding:10px 10px; margin:8px 0px; width:980px; background:url(images/divider.jpg) top no-repeat; border:none;">

<div id="wrap" class="cf">

<div id="galleryTab" class="cf">
 <h1 style="padding:0px 0px 20px 0px; margin:0px; text-align:center;">Gallery</h1>
  <!--<a data-rel="anim" href="javascript:;" class="filter">Academic</a>
  <a data-rel="land" href="javascript:;" class="filter active">Activies</a>
  <a data-rel="arch" href="javascript:;" class="filter">Health-Care</a>
    <a data-rel="hostel" href="javascript:;" class="filter">Hostel</a>
      <a data-rel="kitch" href="javascript:;" class="filter">Kitchen</a>
        <a data-rel="sport" href="javascript:;" class="filter">Sports</a>-->
</div>

<div class="galleryWrap cf">


<?php 
for ($j=1; $j<=18; $j++)
  { ?>
	   <a class="fancybox imgContainer" href="gallery/academic/a<?=$j;?>.jpg" data-fancybox-group="anim" data-filter="anim" style="display:block;"><img src="gallery/academic/a<?=$j;?>.jpg" width="100%" height="100%" ></a>
       
       
	   <?
  } 
?>














<br>
</div>

</div>
</div>
<div class="cl" style="background:url(images/divider_opp.jpg) top no-repeat; padding-top:80px;"></div>
<div class="testimonials_cont">
<div class="tabbable tabs-left">
        
        <div class="tab-content" style="padding-bottom: 9px; border: 1px solid #ddd; padding:10px; background:#ffffff;">
          <div class="tab-pane active" id="">
            <ul class="nav nav-tabs">
          <li class="active"><a href="#tab_civil_1" data-toggle="tab">Proud Parents</a></li>
          <li><a href="#tab_civil_2" data-toggle="tab">Students Speak </a></li>
        </ul><br />
<div class="tab-content">
            <div class="tab-pane active" id="tab_civil_1">
          <br />
<div class="tab-content">
            <div class="tab-pane active" id="tab_mechanics_1">
            <h1>Proud Parents</h1>
            
            <div>
              <p><strong>We are proud of the relationships we build with our students and believe these testimonials show how GURUKUL works effectively in providing education and helping them to achieve their goals.</strong></p>
              <div class="cl"></div>
            <div class="left_testi"><img src="images/par1.png" /><p><strong>Dhiren &amp; Priti Tharnari<br />
                Parents of Devansh Tharnari<br />
                Surat, Gujarat</strong></p></div>
              <p>&quot;We are happy about teaching system of all Gurukul faculties. Their style of teaching and explaining all concepts is excellent and easy to understand for every student. We also appreciate the discipline of school. It is required for each one who has goal for IIT. Students here save at least 2-3 hours per day due to all facilities like study, tuition, food, hostel, recreation etc. being in one campus. One of the best mentoring system in any school.</p>
              <p>We can see our ancient <strong>GURUKUL</strong> system in a new way where our child gains confidence, becomes self dependant, acquires decision making skills, and works with discipline.&quot;</p>
              
              <div class="cl line"></div>
            <div class="right_testi"><img src="images/par2.png" /><p><strong>H. Nandakumar Singh<br />
                Father of Rudali Huidrom<br />
                New Delhi</strong></p></div>
              <p>&quot;Today's preparation determines tomorrow's achievement. Being an IITian and father of an IIT aspirant (2014), initially, I was a bit apprehensive about her future, when I got her admitted in your school but the way the faculty and all the people associated with your school shape the future of students - I am proud to declare that I have got my daughter admission in one of the best schools.GURUKUL -is the best combination of faculties under the peaceful and comfortable boarding school environment of SelaQui International School, Dehradun.</p>
              <p>I will not be wrong if I remember Peter A Cohen who said &quot;There is no one giant step that does it, it's a lot of little steps.&quot;</p>
              
              <div class="cl line"></div>
            <div class="left_testi"><img src="images/par3.png" />
            <p><strong>Dr. M. Ranjit Singh<br />
                Father of M. Deva Neil Singh<br />
                Silchar, Assam</strong></p></div>
              <p>&quot;I am really delighted that my son M. Deva Neil Singh is studying under the new project &quot;GURUKUL IIT-JEE&quot; at SelaQui International School. While searching for a good school after Class X, I found SelaQui International School, the right Institute for better education and especially the &quot;GURUKUL IIT-JEE&quot; which started this year-2012, the most appropriate platform for my son who aspires to be engineer in the future.&quot;</p>
              
            </div>
           
            <div>
            </p>
        
            </div>
            </div>
            
            
          </div>
        </div>
            <div class="tab-pane" id="tab_civil_2"><br />

            <h1>Students Speak</h1>
            
            <p><strong>We are proud of the relationships we build with our students and believe these testimonials show how GURUKUL works effectively in providing education and helping them to achieve their goals.</strong></p>
            <div class="left_testi"><img src="images/stu1.png" /><p>
              <strong>Anshul Bisen<br />
              Class-XI , INDORE</strong></p></div>
            <p>&quot;When I joined Gurukul, I was very happy to see the school and all the facilities provided by the school. I like the environment at GURUKUL and specially the fact that teachers would always answer all questions related to their subject, even those unlikely to come in IIT-JEE. I also liked how other students would freely discuss each others doubts. The teaching as well as testing quality were really good, and I am grateful to GURUKUL for it. Also I had a comfortable stay in GURUKUL Hostel. The congenial atmosphere over here is suitable for us to concentrate on studies.</p>
            <p>Furthermore, the services at the hostel are very good. Last but not least, I wish GURUKUL success in their future endeavours.&quot;</p>
            <div class="cl line"></div>
            <div class="right_testi"><img src="images/stu2.png" /><p>
              <strong>Yash Agarwal<br />
              Class-XI , Kolkata</strong></p></div>
            <p>&quot;The main weapon needed to crack the tough shell of JEE is that of self confidence, and GURUKUL is doing a brilliant job in boosting our confidence by conducting appropriate tests at just the right time. The lectures have always proved to be a treasure of knowledge and quintessential fundamentals. The time that I have spent in the sanctum sanctorum of this temple of learning has been one of the most enriching yet enjoyable moments of my life. GURUKUL has provided me with excellent opportunities to develop to my full potential.</p>
            <p>The conducive environment for our growth along with the state-of-the art infrastructure facilities available helps bring out the best in each of us. I consider myself really lucky to be a student of this school, which has undoubtedly been the best decision.&quot;</p>
            <div class="cl line"></div>
            <div class="left_testi"><img src="images/stu3.png" /><p>
              <strong>Anam Ahmed<br />
              Class-XI ,Gujarat</strong></p></div>
            <p>&quot;GURUKUL gave direction to the innovative ways of learning and gaining knowledge which completely revolutionized my way of thinking .The study material provided by GURUKUL is carefully made in a sequential manner and was a great help .The teachers are also motivating and always ready to help the students in any way they could . The environment, the people, classrooms and teachers all make it one of the most ideal places to study for. The labs are good, teachers are co-operative and students are high-spirited, they study hard. The well equipped infrastructure provides an ambience for the young minds to bloom. I thank GURUKUL for providing me this platform.</p>
            <p align="justify">&nbsp;</p>
          </div>
            </div>
           
          </div>
        </div>
      </div>
      </div>
      <div class="right_col">
<!--<div class="testimonials">
<div class="testimonials_head"><img src="images/testimonials_head.jpg" width="253" height="46" /></div>
<p><em>“Lorem ipsum dolor sit amet Lorem ipsum dolor sit amet Lorem ipsum dolor sit amet�?</em></p>
<p align="right"><em><strong>Neha Wadhawan</strong></em></p>
</div>-->

<div class="tofel"></div>
<a href="admission_procedure.pdf" target="_blank">
<div class="admission_procedure"><img src="images/download_btn.png" width="27" height="26" /></div></a>
<a href="fee_structure.pdf" target="_blank">
<div class="fee_structure"><img src="images/download_btn.png" width="27" height="26" /></div></a>
<a href="application_form.pdf" target="_blank">
<div class="application_form"><img src="images/download_btn.png" width="27" height="26" /></div></a>
<div class="virtual_tour"> <a href="http://selaqui.org/virtualtour/" target="_blank"><img src="images/3dtour.gif" width="219" height="47" /></a></div></div>

<div class="cl"></div>
  </div>
</div>
<div class="copyright">Copyright 2014, All Rights Reserved</div>
</body>
</html>
