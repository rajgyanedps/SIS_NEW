<?php
	//$conn_str = mysql_connect('selaquicrm.db.5227155.hostedresource.com', 'selaquicrm','Siscrm1#');
	$conn_str = mysql_connect('localhost', 'root','');
	mysql_select_db('selaquicrm'); 

?>