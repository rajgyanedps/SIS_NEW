<?php 
ob_start();
require_once('connection.php'); 

@extract($_GET);

if($order_by!="")
{	
	$KEYWORD_SEARCH_1="ORDER BY $order_by $img_name"; 
}
else
{
	$KEYWORD_SEARCH_1="ORDER BY student.contact_date DESC";
}	

if($course_keyword!="")
{	
	$KEYWORD_SEARCH_2="and student.course like '".$_GET['course_keyword']."%'"; 
}
else
{
	$KEYWORD_SEARCH_2="";
}	

if($city_keyword!="")
{	
	$KEYWORD_SEARCH_3="and student.city like '".$_GET['city_keyword']."%'"; 
}
else
{
	$KEYWORD_SEARCH_3="";
}	

header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Data_Report.xls");
header("Pragma: no-cache");
header("Expires: 0");
$now=date("j-n-Y");
echo "\t \t Report ON ".$now."\t";



 $sql_cust = "SELECT *  FROM `student` WHERE `information_source` NOT LIKE '%Registration%' and `emp_id`='400100' and `joined`>='2013-05-20 00:00:00'";
 
	   
		$result	= mysql_query($sql_cust) or die(mysql_error());
print("\n");
print("\n");
echo ' <table width="100%" border="1" cellspacing="0" cellpadding="0" class="border" align="center">
     
        <tr>';
	    echo "<td>S.No.</td>"."\t";
		echo "<td>Student Name </td>"."\t";
		echo "<td>Email Id </td>"."\t";
		//echo "Course / Stream"."\t";
		//echo "Percentage"."\t";
		echo "<td>Phone No./Mobile No </td>"."\t";
		echo "<td>City </td>"."\t";
		echo "<td>Information Source </td>"."\t";	
		echo "<td>Join Date </td>"."\t";	
		
	   echo "<td>Feedback Date and Comment </td>"."\t";	
		
		
		echo '</tr>';	
		print("\n"); 
		$i=1;
 while($res=mysql_fetch_array($result))
    {  echo '<tr>';
        echo "<td>".$i."</td>"."\t";
		echo "<td>".$res['stud_name']."</td>"."\t";
		echo "<td>".$res['email']."</td>"."\t";
		//echo $res['course']." - ".$res['stream']."\t";
		//echo $res['percentage']."\t";
		echo "<td>".$res['phone_code']."-".$res['phone_no'].", ".$res['mobno']."</td>"."\t";
		echo "<td>".trim($res['city'])."</td>"."\t";
		echo "<td>".trim($res['information_source'])."</td>"."\t";
		
		if($res['joined']!='0000-00-00 00:00:00')   
		   echo "<td>".date('d-M-Y',strtotime($res['joined']))."</td>"."\t";	
		   else
		   echo "<td>"."-"."</td>"."\t";	;
		
			
	
		$sql_cust11 = "SELECT * FROM contact WHERE stud_id='".$res['stud_id']."' order by joined asc";
				$result11	= mysql_query($sql_cust11) or die(mysql_error());
				echo "<td>";
				while($res11=mysql_fetch_array($result11))
				{
				        if(($res11['remarkdate']!='0000-00-00') and ($res11['remarkdate']!='1970-01-01')) echo $res11['remarkdate']."&nbsp; -"; else echo "-";
					   
					    if($res11['other']!='') echo trim($res11['other']); else echo trim($res11['followup']);
						echo '<br/>';
						
				
				}
				echo "</td>"."\t";
				echo "</tr>";
						
		print "\n";
		$i+=1;		
    }

?>