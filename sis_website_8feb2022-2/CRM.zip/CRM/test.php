<?php
session_start();
include("connection.php");
if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='Project Manager' && $_SESSION['user_type']!='Tele Caller')
//if (!isset($_SESSION[myusername]))
{
 header("Location: index.php");
}
$_SESSION['this_page']='test.php';
?> 

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Participation Detail Report</title>

<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="jquery.fancybox/jquery.fancybox.css" media="screen" />
   <script type="text/javascript" src="jquery.fancybox/jquery-1.3.2.min.js"></script>
	<script type="text/javascript" src="jquery.fancybox/jquery.easing.1.3.js"></script>
	<script type="text/javascript" src="jquery.fancybox/jquery.fancybox-1.2.1.pack.js"></script>
	<script type="text/javascript">
	$(document).ready(function() {

					  $("a.detail").fancybox({ 'hideOnContentClick': false ,
					  'overlayShow':true  ,
					  'frameWidth':750 ,
					  'frameHeight':710,
					  'overlayOpacity':0.7}); 


	});

<!--
function MM_goToURL() { //v3.0
  var i, args=MM_goToURL.arguments; document.MM_returnValue = false;
  for (i=0; i<(args.length-1); i+=2) eval(args[i]+".location='"+args[i+1]+"'");
}
//-->
</script>
<script type="text/javascript">
function showhide(val)
{
if(val)
document.getElementById('import').style.display='block';
else
document.getElementById('import').style.display='none';
}


function validate_file()
{
var upfilename=document.uploadstudentname.uploadfile.value;
var format = new Array();
format = upfilename.split('.');
	if(document.uploadstudentname.uploadfile.value=="")
	{
	alert("Pls upload a csv file");
	document.uploadstudentname.uploadfile.focus();
	return false;
	}

	if(format[1].value != 'csv')
	{
	alert("Pls upload a CSV file");
	document.uploadstudentname.uploadfile.focus();
	return false;
	}
return true;
}

</script>
</head>
<body>
<?php
include("header.php");
?>
<?
$sql_cust = "SELECT DISTINCT subject FROM testdetail";

		$result	= mysql_query($sql_cust) or die(mysql_error());
		$num_rows=mysql_num_rows($result);
		?>
        <br />
        <? 
        $schoolname1="SELECT * FROM addschool WHERE school_id='".$_GET['school_id']."'";
		$r=mysql_query($schoolname1);
		$t=mysql_fetch_array($r);
		?>
        <? if($_GET['school_id']>0)
		{
		?>
        <table><tr><td align="left" style="padding-left:10px">
          <font color="#000000" size="3px"><? echo $t['school_name'];?></font>
        </td>
        </tr></table>
        <? }
		else
		{
		?>
<table><tr><td align="left" style="padding-left:10px; font-weight:bold;">
        <font color="#000000" size="3px"><? echo "Total School";?></font>
        </td>
</tr></table>
<?
}
?>

<table width="100%" border="0" align="center" cellpadding="5" cellspacing="1" bgcolor="#81cafd" style="font-size:12px">
    <tr bgcolor="#999999" align="center">
      <td align="left" background="footerbg.jpg" class="whitetxt11">Subject</td>
      <?

	  for($i=0;$i<=7;$i++)
	  {
	 $sumt[$i]=0;
      ?>
      <td align="left" background="footerbg.jpg" class="whitetxt11">Class
        <?=$i+3;?></td>
      <?
	  
	  }
	  
	  ?>
      <td background="footerbg.jpg" class="whitetxt11"><b>Sum</b></td>
    </tr>
    <? 
	 if($num_rows==0)
{
echo "<div align=center><font color=red size=+1>No Record Found</font></div>";
}
		$count = 0;
		
while($res=mysql_fetch_array($result))
{
if($acol) {
	           $x = "bgcolor='#e9f5ff'";
	          } else {
	            $x = "bgcolor='#d8effe'";
 	          }
			  $acol=!$acol;
			  $count++;
?>
    <tr <?=$x;?> align="left">
      <td><?php echo $res['subject'];?></td>
      <?  
   if(isset($_GET['school_id']))
  {
  $strqry="and school_id='".$_GET['school_id']."'";
  }
  
  for($i=0;$i<=7;$i++)
  {
 $abc="SELECT sum(test) FROM testdetail WHERE subject='".$res['subject']."' and class=".($i+3)." ".$strqry."";
  $xyz=mysql_query($abc);
  $w=mysql_fetch_array($xyz);
  
  
  if($res['subject']=='English') $sumteste+= $w[0];
  if($res['subject']=='Maths') $sumtestm+= $w[0];
  if($res['subject']=='Science') $sumtests+= $w[0];
  echo "<td><a href='test_detail.php?subject=".$res['subject']."&class=".($i+3)."' class='iframe detail' id='detail'> ".$w[0]."</a></td>";
  $sumt[$i]+=$w[0];
   }
  if($res['subject']=='English') echo "<td><b>". $sumteste."</b></td>";
    if($res['subject']=='Maths') echo "<td><b>". $sumtestm."</b></td>";
  if($res['subject']=='Science') echo "<td><b>". $sumtests."</b></td>";
   
  ?>
    </tr>
    <? }?>
    <tr bgcolor="#CCFFCC">
      <td><font size="3px"><b>Sum</b></font></td>
      <? for($i=0;$i<=7;$i++)
  { echo "<td><b> ".$sumt[$i]."</b></td>";  }?>
      <td><font size="3px" color="#000099"><b>
        <?=$sumteste+$sumtestm+$sumtests ?>
      </b></font></td>
    </tr>
    
</table>
  
  <?
  $strtoprn="";
  if(isset($_FILES['uploadfile']['name']))
{
$target_path = "uploads/";
$target_path = $target_path . basename( $_FILES['uploadfile']['name']);
$_FILES['uploadfile']['tmp_name']; 
$target_path = "uploads/";
$target_path = $target_path . basename( $_FILES['uploadfile']['name']);
if(move_uploaded_file($_FILES['uploadfile']['tmp_name'], $target_path)) 
{
    
	$strtoprn.= "<table width=800px border=1 align=center><tr bgcolor=#dddddd><td>Student id</td><td>School ID</td><td>Student Name</td><td>Class</td><td>Section</td><td>English</td><td>Maths</td><td>Science</td></tr>";
	$columns_user = "`stud_id`,`school_id`,`stud_name`,`stud_class`,`stud_section`,`parte`,`partm`,`parts`,`attende`,`attendm`,`attends`,`test_date`";
	$handle = fopen("uploads/".basename( $_FILES['uploadfile']['name']), "r");
	while (($data = fgetcsv($handle, 1000, ",")) !== FALSE)
	{
     $uid=$data[0];
     $schoolid=$data[1];
	 $studname=$data[2]; 
	 $studclass=$data[3];
	 $studsection=$data[4];
	 $partenglish=$data[5];
	 $partmaths=$data[6];
	 $partscience=$data[7];
	 $attendenglish=$data[8];
	 $attendmaths=$data[9];
	 $attendscience=$data[10];
	 $testdate=$data[11];
	 $uid++;
		 mysql_query("insert into student(".$columns_user.") values ('$uid','$schoolid','$studname','$studclass','$studsection','$partenglish','$partmaths','$partscience','$attendenglish','$attendmaths','$attendscience','$testdate');") or die(mysql_error());
		 //$teacher_id = $uid;
 $strtoprn.= "<tr><td>".$uid."</td><td>".$schoolid."</td><td>".$studname."</td><td>".$studclass."</td><td>".$studsection."</td><td>".$partenglish."</td><td>".$partmaths."</td><td>".$partscience."</td></tr>";		
 }

 } 

	$strtoprn.= "</table>";
	fclose($handle); 
 
}

?>	 
	
  <table width="100%">
  <tr><td>&nbsp;</td></tr>
  <tr>
  <td height="50" align="center" valign="middle" bgcolor="#e9f5ff"><input type="button" name="importname" value="Import Student Record" style="height:35px;font-size:14px;font-weight:bold" onclick="showhide(true)" /></td></tr>
  <tr><td>&nbsp;</td></tr>
  <tr><td align="center">
<div id="import" style="display:none"><form name="uploadstudentname" action="test.php" method="post" enctype="multipart/form-data" onsubmit="return validate_file();">
<font size="3px"><b>Location of the text file:</b></font>&nbsp;<b>(In csv Format)</b>&nbsp; <input type="file" name="uploadfile" id="uploadfile" /><br /><br /><div style="padding-left:110px"><input type="submit" value=" Submit " /></div></form> </div></td></tr>
  </table>
  
	<? if($strtoprn!="") {?>
  <font size="3px" style="padding-left:275px"><b>Records Imported</b></font><br /><? } ?>
  <?=$strtoprn?>
  <table width="100%" align="center">
  <tr>
      <td><img src="image/spacer.gif" height="5" /></td>
    </tr>
<tr>
<td class="footer" width="944" >&copy; 2009 TeacherSITY. All rights reserved</td>
</tr>
</table>

</body>
</html>