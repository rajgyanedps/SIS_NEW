<?php
    session_start();
    error_reporting(0);
    //echo "<pre>"; print_R($_SESSION);
    include('functions.inc.php');
    include("automatic.php");
    include("connection.php");
    
    date_default_timezone_set('Asia/Calcutta');
    if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='Project Manager' && $_SESSION['user_type']!='Tele Caller' && $_SESSION['user_type']!='School Login')
    //if (!isset($_SESSION[myusername]))
    {
     header("Location: index.php");
    }
    ?>
<?
    $_SESSION['this_page']='tc_offline_lead.php';
    
    @extract($_GET);
    
    if($_GET['fromdate']!=''){
    if (strlen($_GET['fromdate'])>0)
    {
    
    if (strlen($_GET['todate'])>0)
    {
    $strqry="  date(student.joined) between '".$_GET['fromdate']."' AND '".$_GET['todate']."' and ";
    }
    else
    {
    $strqry="  date(student.joined)='".$_GET['fromdate']."' and ";
    }
    } }
    else{
    $strqry = '';
    }
    
    
    if($_GET['Class']!=''){
        // print_r($_GET['Class']);die;
    	
    	
    	if(!isset($_GET['spageno']))
    	{
    	  $classs = implode(',',$_GET['Class']); 
    	}
    	else
    	{
    	$classs = $_GET['Class'];
    	}
    	$URLClass = explode(',',$classs);
    	$classdetails=  "student.course IN (".$classs.") and";
     
         $string = '';
         for($m=0;$m<count($URLClass);$m++)
          {
    	   // 
            $strings.= $URLClass[$m].',';
          }
         $Urlsendclass = substr($strings,0,-1);
       }
    else
    {
    	$classdetails = '';
    }
    if($order_by!="")
    {	
    	$KEYWORD_SEARCH_5="ORDER BY $order_by $img_name"; 
    }
    else
    {
    	$KEYWORD_SEARCH_5="ORDER BY student.joined DESC, stud_id DESC";
    }	
    
	         if($_GET['mobilenum']!= '') {
		  $keymob="and (student.mobno like '".$_GET['mobilenum']."%' or student.phone_no like '".$_GET['mobilenum']."%') ";
           }else{ $keymob="";}
           if($_GET['st_email']!= '') {
             $keyemail="and student.email='".$_GET['st_email']."'  ";
           }else{  $keyemail="";}
	
    //print_r($strqry );die;
    
    
    ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Tele Caller Home Page</title>
        <link rel="shortcut icon" href="http://www.selaqui.org/images/favicon.ico" type="image/x-icon">
        <link rel="stylesheet" type="text/css" href="calendar/calendar-blue.css">
        <script type="text/javascript" src="calendar/calendar.js"></script>
        <script type="text/javascript" src="calendar/calendar-en.js"></script>
        <script type="text/javascript" src="calendar/calendar-setup.js"></script>
        <script type="text/javascript">
            <!--
            function MM_openBrWindow(theURL,winName,features) { //v2.0
              window.open(theURL,winName,features);
            }
            //-->
        </script>
        <style type="text/css">
            <!--
                body {
                	font-family: Arial, Helvetica, sans-serif;
                	font-size: 12px;
                	background-color: #FFFFFF;
                	background-repeat: no-repeat;
                }
                a {
                	color: #333333;
                }
                -->
        </style>
        <link href="msg.css" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" type="text/css" href="jquery.fancybox/jquery.fancybox.css" media="screen" />
        <script type="text/javascript" src="jquery.fancybox/jquery-1.3.2.min.js"></script>
        <script type="text/javascript" src="jquery.fancybox/jquery.easing.1.3.js"></script>
        <script type="text/javascript" src="jquery.fancybox/jquery.fancybox-1.2.1.pack.js"></script>
        <script type="text/javascript">
            function MM_openBrWindow(theURL,winName,features) {
              window.open(theURL,winName,features);
            }
            
            	$(document).ready(function()
            
            	 {
                 $("a.pmodee").fancybox({ 'hideOnContentClick': false ,
            
            					  'overlayShow':true  ,
            
            					  'frameWidth':950 ,
            
            					  'frameHeight':250,
            
            					  'overlayOpacity':0.7 }); 
            	});
        </script>
    <!-- Global site tag (gtag.js) - AdWords: 1040837567 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-1040837567"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-1040837567');
</script>
</head>

    <body>
        <?php
            include("header.php");
            ?>
        <div align="center" class="msg">
            <?=$_GET['msg1']; ?>
        </div>
        <?php
            $sql = "select count(*) as totalmsg from message WHERE `to`='".$_SESSION['emp_id']."'";
            $result1 = mysql_query($sql);
            $res1 = mysql_fetch_array($result1);
            ?>
        <? if($res1['totalmsg']=='0')
            {
            }
            else
            {?>
        <div align="center"><font size="3px">You have received&nbsp;<strong><? echo $res1['totalmsg'];?></strong>&nbsp;Leads&nbsp;&nbsp;<a href="seemsg.php">View All</a></font></div>
        <? }?>
        <!--<div align="right"><font size="3px" style="padding-right:10px"><a href="#" onClick="MM_openBrWindow('Brochure TeacherSITY-ACER.pdf','CallReport','toolbar=yes,location=yes,status=yes,menubar=yes,scrollbars=yes,resizable=yes')"><b>Download TeacherSITY-ACER Brochure</b></a></font><br />
            <font size="3px" style="padding-right:10px"><a href="#" onClick="MM_openBrWindow('Doc ACER.pdf','CallReport','toolbar=yes,location=yes,status=yes,menubar=yes,scrollbars=yes,resizable=yes')"><b>Download Frequently Asked Question(FAQ)</b></a></font></div>-->
        <div style="clear:both"></div>
        <? 
            $sql_cust10 = "SELECT * FROM task inner join members on members.emp_id=task.recipient_id WHERE recipient_id='".$_SESSION['emp_id']."' and status='Pending'";
            	
            $result10	= mysql_query($sql_cust10) or die(mysql_error());
            		$num_rows10 = mysql_num_rows($result10);
            		$res10=mysql_fetch_array($result10);
            ?>
        <script type="text/javascript">
            function valid()
            {
            
            if((document.tchome.schoolname1.value=='')&&(document.tchome.city1.value=='')&&(document.tchome.info_search.value=='')&&(document.tchome.st_email.value=='')&&(document.tchome.mobilenum.value=='')&&(document.tchome.fromdate.value=='')&&(document.tchome.todate.value=='')&&(document.getElementById("multiple").value==''))
            {
            alert('Please Choose Any One Fields !!!!');return false;
            }
            }
        </script>
        <table width="100%">
            <tr>
                <td style="padding-left:20px; padding-bottom:5px; background-color:#f3f7fd;"><font size="3px" color="#FF0000">
                    <?=$num_rows10 ?>
                    &nbsp;Pending Task <a href="taskuser.php">Click here to view</a></font>
                </td>
            </tr>
        </table>
        <table align="center" width="100%">
            <tr>
                <td width="100%">
                    <form action="tc_offline_lead.php" method="get" name="tchome" onsubmit="return valid(this);">
                        <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#f3f7fd;border:solid 1px #88c9fd;">
                            <tr>
                                <td height="20" colspan="9" align="center" valign="middle" background="butbg.gif">
                                    <marquee behavior="slide" direction="left">
                                        <font size="4.5" face="Verdana, Arial, Helvetica, sans-serif"><b>Search Student</b></font>
                                    </marquee>
                                </td>
                            </tr>
                            <tr>
                                <td width="6%" height="35" valign="middle" style="padding-left:15px"><b>Search By </b></td>
                                <td width="3%" valign="middle"><b>:</b></td>
                                <td width="6%" valign="middle"><b>Student Name</b></td>
                                <td width="12%" valign="middle"><input type="text" name="schoolname1" size="30" style="border:solid 1px #61b5f8;font-size:12px;width:145px; color:#0a5095;background-color:#ffffff;" /></td>
                                <td width="3%" valign="middle"><b>City</b></td>
                                <td width="24%" valign="middle"><input type="text" name="city1" size="25" style="border:solid 1px #61b5f8;font-size:12px;width:145px; color:#0a5095;background-color:#ffffff;"/>
                                    &nbsp;
                                </td>
                              <!--   <td width="7%" valign="middle"><strong>Information Source</strong></td>
                               <td width="12%" valign="middle">
                                    <select name="info_search"  style="border:solid 1px #61b5f8;font-size:12px;width:145px; color:#0a5095;background-color:#ffffff;">
                                        <option value="">---Select---</option>
                                        <option value="Application">Application</option>
                                        <option value="Registration">Registration</option>
                                        <option value="Enquiry">Enquiry</option>
                                        <option value="Telephone">Telephone</option>
                                        <option value="SMS">SMS</option>
                                        <option value="Google">Google</option>
                                        <option value="Internet">Internet</option>
                                        <option value="Hoarding">Hoarding</option>
                                        <option value="Newspaper">Newspaper</option>
                                        <option value="Fair/Exhibition">Fair/Exhibition</option>
                                        <option value="Seminar">Seminar</option>
                                        <option value="Word of Mouth">Word of Mouth</option>
                                        <option value="Data">Data</option>
                                        <option value="Counselling Associate">Counselling Associate</option>
                                        <option value="Magzine">Magzine</option>
                                    </select>
                                    &nbsp;
                                    <!--<input type="submit" name="submit" value="Search" />
                                </td>-->
								<td width="7%" valign="middle"><strong>Status</strong></td>
								 <td width="12%" valign="middle">
								 <select name="info_search" id="info_search" style="float:left;height:20px;line-height:18px;border:solid 1px #61b5f8;font-size:12px;width:120px; color:#0a5095;background-color:#ffffff; margin-top:10px;" >
					    <option value="">---Select---</option>
                        <?php
					     $drop_info = "select status from student WHERE status IN ('Admission' , 'Duplicate' , 'Moderate', 'Negative' , 'NoContact' , 'Not Eligible' , 'Not Intrested' , 'Paid' , 'Positive' , 'Session2018-19' , 'Session2019-20' ,'Session2020-21' ,'Session2021-22' ,'Session2022-23' , 'Very Positive') group by status";
						 $result_info = mysql_query($drop_info);
						 while($row_info = mysql_fetch_array($result_info)){?>
						  <option value="<?= $row_info['status'];?>" <?php if($_GET['info_search'] == $row_info['status']) echo 'selected';?>><?=$row_info['status'];?></option>
						 <?php
						 }
						?>
                     </select>
								 </td>
                                <td width="27%" align="right" valign="middle"><font size="3px" color="#FF0000"><b>PENDING TASKS &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></td>
                            </tr>
                            <tr>
                                <td width="6%" height="35" valign="middle" style="padding-left:15px">&nbsp;</td>
                                <td width="3%" valign="middle">&nbsp;</td>
                                <td width="6%" valign="middle"><b>Date From:</b></td>
                                <td valign="middle" colspan="3">
                                    <table width="492">
                                        <tr>
                                            <td width="208" height="37" align="left" valign="middle">
                                                <input type="text" name="fromdate"  id="fromdate" style="width:150px;" readonly="readonly" <?php if($_GET['fromdate']) { echo 'selected'; }?> value="<?=$_GET['fromdate']?>"/>&nbsp;<label for="from"><img src="CalendarIcon.gif" name="get_stud_date1" width="22" height="23" border="0" align="absmiddle" id="get_stud_date1" style="cursor: pointer;" title="Date selector" onMouseOver="this.style.background='red';" onMouseOut="this.style.background=''" /></label>
                                                <script type="text/javascript">
                                                    Calendar.setup({
                                                        inputField     :    "fromdate",     // id of the input field
                                                     //ifFormat       :    "%Y/%m/%d %l:%M %P",      // format of the input field
                                                    //ifFormat       :    "%m-%d-%Y",      // format of the input field
                                                    ifFormat       :    "%Y-%m-%d",      // format of the input field
                                                        button         :    "get_stud_date1",  // trigger for the calendar (button ID)
                                                        align          :    "Tl",           // alignment (defaults to "Bl")
                                                        singleClick    :    true,
                                                    showsTime		:	true
                                                    });
                                                    
                                                        
                                                </script>							
                                            </td>
                                            <td width="272" align="left" valign="middle">
                                                <strong>To: </strong> 
                                                <input type="text" name="todate"  id="todate" style="width:200px;" readonly="readonly"  <?php if($_GET['todate']) { echo 'selected'; }?> value="<?=$_GET['todate']?>" /> 
                                                <label for="to"><img src="CalendarIcon.gif" name="get_stud_date2" width="22" height="23" border="0" align="absmiddle" id="get_stud_date2" style="cursor: pointer;" title="Date selector" onMouseOver="this.style.background='red';" onMouseOut="this.style.background=''" /></label>
                                                <script type="text/javascript">
                                                    Calendar.setup({
                                                        inputField     :    "todate",     // id of the input field
                                                        //ifFormat       :    "%Y/%m/%d %l:%M %P",      // format of the input field
                                                      	//ifFormat       :    "%m-%d-%Y",      // format of the input field
                                                      	ifFormat       :    "%Y-%m-%d",      // format of the input field
                                                           button         :    "get_stud_date2",  // trigger for the calendar (button ID)
                                                           align          :    "Tl",           // alignment (defaults to "Bl")
                                                           singleClick    :    true,
                                                    	showsTime		:	true
                                                       });
                                                    
                                                           
                                                </script>							
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                                <td width="7%" valign="middle"><b>Class</b></td>
                                <td width="12%" valign="middle">
                                    <select name="Class[]" id="multiple" multiple="multiple"  style="border:solid 1px #61b5f8;font-size:12px;width:145px; color:#0a5095;background-color:#ffffff;">
                                        <option value="">---Select---</option>
                                        <option value="'V'">V</option>
                                        <option value="'VI'">VI</option>
                                        <option value="'VII'">VII</option>
                                        <option value="'VIII'">VIII</option>
                                        <option value="'IX'">IX</option>
                                        <option value="'X'">X</option>
                                        <!-- <option value="'XI'">XI</option>-->
                                        <option value="'XI Science / Medical'">XI &shy; Science / Medical</option>
                                        <option value="'XI Science / Non-Medical'">XI &shy; Science / Non-Medical</option>
                                        <option value="'XI Commerce'">XI &shy; Commerce</option>
                                        <option value="'XI Humanities'" style="font-family:Georgia, 'Times New Roman', Times, serif">XI &shy; Humanities</option>
                                    </select>
                                    &nbsp;
                                </td>
                                <td width="27%" align="right" valign="middle"><font size="3px" color="#FF0000"><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b></font></td>
                            </tr>
							<tr>
                                <td width="6%" height="35" valign="middle" style="padding-left:15px">&nbsp;</td>
                                <td width="3%" valign="middle">&nbsp;</td>
                                <td width="6%" valign="middle"><b>Email Id</b></td>
								<td width="6%" valign="middle"><b><input type="text" name="st_email" size="15"  value="<?= $_GET['st_email'] ?>" style="width:150px;"></b></td>
								
                                <td width="3%" valign="middle">&nbsp;</td>
                                <td width="6%" valign="middle"><b>Mobile/Phone No</b></td>
								<td width="6%" valign="middle"><b> <input type="text" name="mobilenum" size="15" value="<?= $_GET['mobilenum'] ?>" style="width:150px;"></b></td>
								</tr>
                            <tr>
                                <td colspan="5" style="padding-left:200px;"><input type="submit" name="submit2" value="Search" />&nbsp;&nbsp;<a href="tc_offline_lead.php">Clear Search</a>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="10">
                                    <br/>
                                    <br/>
                                    <div style="float:left;">
									    <img src="images/walk.png" border="0" name="minus_sign" alt="Click here to view Very Positive report" align="center">&nbsp;&nbsp;Campus visit&nbsp;&nbsp;
									    <img  src="images/very_positive.jpg" border="0" name="minus_sign" alt="Click here to view Very Positive report" align="center"/>&nbsp;&nbsp;Very Positive&nbsp;&nbsp; 
                                        <img src="image/green.gif" border="0" name="minus_sign" alt="Click here to view negative report" align="center"/>&nbsp;&nbsp;Positive&nbsp;&nbsp;
                                        <img src="image/mod.gif" border="0" name="minus_sign" align="center"/>&nbsp;&nbsp;Moderate&nbsp;&nbsp;
                                        <img src="images/not_interested.jpg" border="0" name="minus_sign" alt="Click here to view Not Intrested report" align="center"/>
                                        &nbsp;&nbsp;  Not Interested&nbsp;&nbsp;
                                        <img src="images/not_eligible.jpg" border="0" name="minus_sign" alt="Click here to view Not Eligible report" align="center"/>&nbsp;&nbsp;Not Eligible&nbsp;&nbsp;
                                        <img src="image/nocontact.png" border="0" name="Admission" alt="Admission" align="center" />&nbsp;&nbsp; No Contact&nbsp;&nbsp; 
                                        <img src="image/paddy-smiley26.gif" border="0" name="paid" alt="Paid School" align="center" />&nbsp;&nbsp;Paid&nbsp;&nbsp;    
                                        <img src="image/admission.png" border="0" name="Admission" alt="Admission" align="center" />&nbsp;&nbsp;Admission&nbsp;&nbsp;
                                        <img src="images/duplicate.jpg" border="0" name="Duplicate" alt="Duplicate" align="center" />&nbsp;&nbsp;Duplicate&nbsp;&nbsp;
                                        <img src="image/red.gif" border="0" name="minus_sign" alt="Click here to view negative report" align="center"/>&nbsp;&nbsp;Negative&nbsp;&nbsp; 
                                        <img src="image/2013-14.jpg.png" border="0" name="Admission" alt="Admission" align="center"> &nbsp;&nbsp;Session 2019-20 
                                    </div>
                                </td>
                            </tr>
							<tr>
                                <td colspan="5"></td>
                            </tr>
                        </table>
                        <br />
                        <table align="center" width="100%">
                            <tr>
                                <td width="53%" valign="top">
								
								
                                    <table width="100%" border="0" align="center" cellpadding="5" cellspacing="1" bgcolor="#81cafd" style="font-size:13px">
                                        <tr bgcolor="#999999" align="center">
                                            <td width="7%" height="25" align="left" background="footerbg.jpg" class="whitetxt11">S.No.</td>
                                            <td align="left" background="footerbg.jpg" class="whitetxt11" width="23%">
                                                <? if($_GET['img_name']=='desc' && $_GET['order_by']=='stud_name')
                                                    { 
                                                    ?>
                                                <a href="tc_offline_lead.php?order_by=stud_name&img_name=asc&info_search=<?= $_GET['info_search'] ?>"><strong>Student Name&nbsp;</strong><img src="image/asc.gif" alt="Descending Order" border="0"></a>
                                                <? 
                                                    } 
                                                    else 
                                                    { 
                                                    ?>
                                                <a href="tc_offline_lead.php?order_by=stud_name&img_name=desc&info_search=<?= $_GET['info_search'] ?>"><strong>Student Name&nbsp;</strong><img src="image/dsc.gif" alt="Ascending Order" border="0"></a>
                                                <?
                                                    }
                                                    ?>                  
                                            </td>
                                            <td align="left" background="footerbg.jpg" class="whitetxt11" width="17%">Class </td>
                                            <td align="left" background="footerbg.jpg" class="whitetxt11" width="17%">
                                                <? if($_GET['img_name']=='desc' && $_GET['order_by']=='city')
                                                    { 
                                                    ?>
                                                <a href="tc_offline_lead.php?order_by=city&img_name=asc&info_search=<?= $_GET['info_search'] ?>"><strong>City&nbsp;</strong><img src="image/asc.gif" alt="Descending Order" border="0"></a>
                                                <? 
                                                    } 
                                                    else 
                                                    { 
                                                    ?>
                                                <a href="tc_offline_lead.php?order_by=city&img_name=desc&info_search=<?= $_GET['info_search'] ?>"><strong>City&nbsp;</strong><img src="image/dsc.gif" alt="Ascending Order" border="0"></a>
                                                <?
                                                    }
                                                    ?>                  
                                            </td>
                                                       <td align="left" background="footerbg.jpg" class="whitetxt11" width="13%">Email Id.</td>
                                                       <td align="left" background="footerbg.jpg" class="whitetxt11" width="13%">Phone No./Mob No.</td>


                                            <td align="left" background="footerbg.jpg" class="whitetxt11" width="12%">
                                                <? if($_GET['img_name']=='desc' && $_GET['order_by']=='status')
                                                    { 
                                                    ?>
                                                <a href="tc_offline_lead.php?order_by=status&img_name=asc&info_search=<?= $_GET['info_search'] ?>"><strong>Last Status&nbsp;</strong><img src="image/asc.gif" alt="Descending Order" border="0"></a>
                                                <? 
                                                    } 
                                                    else 
                                                    { 
                                                    ?>
                                                <a href="tc_offline_lead.php?order_by=status&img_name=desc&info_search=<?= $_GET['info_search'] ?>"><strong>Last Status&nbsp;</strong><img src="image/dsc.gif" alt="Ascending Order" border="0"></a>
                                                <?
                                                    }
                                                    ?>
                                            </td>
                                            <td align="left" background="footerbg.jpg" class="whitetxt11" >Payment Status</td>
                                            <td align="left" background="footerbg.jpg" class="whitetxt11" width="25%">
                                                <? if($_GET['img_name']=='desc' && $_GET['order_by']=='information_source')
                                                    { 
                                                    ?>
                                                <a href="tc_offline_lead.php?order_by=information_source&img_name=asc&info_search=<?= $_GET['info_search'] ?>"><strong>Information Source&nbsp;</strong><img src="image/asc.gif" alt="Descending Order" border="0"></a>
                                                <? 
                                                    } 
                                                    else 
                                                    { 
                                                    ?>
                                                <a href="tc_offline_lead.php?order_by=information_source&img_name=desc&info_search=<?= $_GET['info_search'] ?>"><strong>Information Source&nbsp;</strong><img src="image/dsc.gif" alt="Ascending Order" border="0"></a>
                                                <?
                                                    }
                                                    ?>
                                            </td>
                                            <td align="left" background="footerbg.jpg" class="whitetxt11" width="16%">
                                                <? if((!isset($_GET['img_name'])) || $_GET['img_name']=='desc' && $_GET['order_by']=='student.joined')
                                                    { 
                                                    ?>
                                                <a href="tc_offline_lead.php?order_by=student.joined&img_name=asc&info_search=<?= $_GET['info_search'] ?>"><strong>Date&nbsp;</strong><img src="image/asc.gif" alt="Descending Order" border="0"></a>
                                                <? 
                                                    } 
                                                    else 
                                                    { 
                                                    ?>
                                                <a href="tchome.php?order_by=student.joined&img_name=desc&info_search=<?= $_GET['info_search'] ?>"><strong>Date&nbsp;</strong><img src="image/dsc.gif" alt="Ascending Order" border="0"></a>
                                                <?
                                                    }
                                                    ?>
                                            </td>
                                        </tr>
                                        <?php
                                            $start=0;
                                            $pagesize=50;
                                            
                                            if(isset($_GET['start'])) 
                                            $start=$_GET['start'];
                                            
                                            if(isset($_GET['pagesize'])) 
                                            $pagesize=$_GET['pagesize'];
                                                           
                                            $sql_cust = "SELECT student.stud_id, student.course,student.email,student.mobno,student.phone_no, student.stud_name,student.information_source, student.city, student.status,student.req_type, student.joined as leaddate FROM student where".$strqry.' '.$classdetails." student.emp_id='".$_SESSION['emp_id']."' and stud_name like '".trim($_GET['schoolname1'])."%' and student.status like '".trim($_GET['info_search'])."%' and req_type='Offline' and city like '".trim($_GET['city1'])."%'  $keymob $keyemail $KEYWORD_SEARCH_5  limit $start,$pagesize";
                                            $selectcount = "SELECT student.stud_id, student.course,student.email,student.mobno,student.phone_no, student.stud_name,student.information_source, student.city, student.status,student.req_type, student.joined as leaddate FROM student where".$strqry.' '.$classdetails." student.emp_id='".$_SESSION['emp_id']."' and stud_name like '".trim($_GET['schoolname1'])."%' and student.status like '".trim($_GET['info_search'])."%' and req_type='Offline' and city like '".trim($_GET['city1'])."%'  $keymob $keyemail $KEYWORD_SEARCH_5";
                                            //echo $sql_cust ;
                                            $abc=  mysql_query($selectcount);
                                                   $no_of_results=  mysql_num_rows($abc);
                                                     
                                             $reccnt=$no_of_results; 
                                            
                                            $result	= mysql_query($sql_cust) or die(mysql_error());
                                            $num_rows = $reccnt;	
                                            if($num_rows==0)
                                            	{
                                            	echo "<div align=center><font color=red size=+1>No Record Found</font></div>";
                                            	}
                                            //		$incr = 1;
                                            //		
                                            //		if(!$_REQUEST['spageno']){
                                            //			$spageno = 1;
                                            //		} else {
                                            //			$spageno= $_REQUEST['spageno'];
                                            //		}
                                            //		$spagesize=50;
                                            //		$incr = (($spageno-1)*$spagesize)+1;
                                            //		$first=$spageno*$spagesize-($spagesize-1);
                                            //		$last=$first+$spagesize-1; 
                                            //		$temp=($num_rows%$spagesize);
                                            //		if ($temp==0)
                                            //		$spages=($num_rows/$spagesize);
                                            //		else
                                            //		$spages=($num_rows/$spagesize)+1;
                                            //		settype($spages, "integer"); 
                                            //
                                            //		for($i=1;$i<$first;$i++)
                                            //			$row2000=mysql_fetch_row($result);
                                                
                                            //<?php
                                                //$query="SELECT * FROM addschool";
                                                //$result=mysql_query($query) or die(mysql_error());
                                                                if($start==''){
                                                    $j=1;}else{$j=$start+1;}
                                                while($res=mysql_fetch_array($result) and ($first<=$last))
                                                {
                                                 if($res['leaddate'] >='2014-05-01 02:00:00' && $res['leaddate']!="0000-00-00 00:00:00")
                                                    {
                                                  
                                                    
                                                    $dd = date("d-M-y",strtotime($res['leaddate']));
                                                    
                                                    }
                                                    
                                                    
                                                    else if($res['leaddate'] <='2014-05-01 02:00:00' && $res['leaddate']!="0000-00-00 00:00:00")
                                                    {
                                                        
                                                          $dd = date("d-M-y",strtotime($res['leaddate']."+12 hours +32 minutes"));
                                                        
                                                    }
                                                    else {  $dd='-'; }
                                                    
                                                if($i%2==0) {
                                                	           $x = "bgcolor='#e9f5ff'";
                                                	          } else {
                                                	            $x = "bgcolor='#d8effe'";
                                                 	          }
                                                ?>
                                        <tr <? if (date("Y-M-d",strtotime($res['leaddate']))==date("Y-M-d",strtotime("-1 days")) || date("Y-M-d",strtotime($res['leaddate']))==date("Y-M-d"))
                                            { echo 'bgcolor="#FFCCCC"'; } else { echo $x; } ?> align="left">
                                            <td width="7%"><? echo $j++;?>.</td>
                                            <td width="23%"><a href="11.php?stud_id=<? echo $res['stud_id'];?>"><?php echo ucwords(strtolower($res['stud_name']));?></a></td>
                                            <td width="17%"><?php echo $res['course'];?></td>
                                            <td width="17%"><?php echo ucwords(strtolower($res['city']));?></td>
                              
                                            <td width="13%"><?php echo $res['email']; ?></td>
                                            <td width="13%"><?php echo $res['phone_code']." ".$res['phone_no']; ?><br />
                                               <?php if($res['mobno']!='0') echo $res['mobno']; else echo '-'; ?>
                                            </td>

      
                                            <td width="12%" align="center"><?php if($res['status']=='Positive'){?>
                                                <img src="image/green.gif" border="0" name="plus_sign" alt="Click here to view positive report" align="center"/>
                                                <? } else if($res['status']=='Not Intrested'){ ?>
                                                <img src="images/not_interested.jpg" border="0" name="minus_sign" alt="Click here to view Not Intrested report" align="center"/>
                                                <? } else if($res['status']=='Negative'){ ?>
                                                <img src="image/red.gif" border="0" name="minus_sign" alt="Click here to view negative report" align="center"/>
                                                <? }
                                                    else if($res['status']=='Very Positive'){ ?>
                                                <img src="images/very_positive.jpg" border="0" name="minus_sign" alt="Click here to view Very Positive report" align="center"/>
                                                <? }
                                                    else if($res['status']=='Not Eligible'){ ?>
                                                <img src="images/not_eligible.jpg" border="0" name="minus_sign" alt="Click here to view Not Eligible report" align="center"/>
                                                <? }else if($res['status']=='Admission'){ ?>
                                                <img src="image/admission.png" border="0" name="admission" alt="Click here to view admission report" align="center"/>
                                                <? }
                                                    else if($res['status']=='Duplicate'){ ?>
                                                <img src="images/duplicate.jpg" border="0" name="Duplicate" alt="Duplicate" align="center" />
                                                <? }
                                                    else if($res['status']=='Moderate'){ ?>
                                                <img src="image/mod.gif" border="0" name="minus_sign" align="center"/>
                                                <? } else if($res['status']=='Paid'){ ?>
                                                <img src="image/paddy-smiley26.gif" border="0" name="paid" alt="Paid School" align="center" />
                                                <? }else if($res['status']=='NoContact'){ ?>
                                                <img src="image/nocontact.png" border="0" name="Admission" alt="Admission" align="center" />
                                                <? }else if($res['status']=='Session2018-19'){ ?>
                                                <img src="image/nocontact.png" border="0" name="Admission" alt="Admission" align="center" />
                                                <? }else if($res['status']=='Session2019-20'){ ?>
                                                <img src="image/2013-14.jpg.png" border="0" name="Admission" alt="Admission" align="center" />
                                                <? }else if($res['status']=='Campus visit'){ ?>
                                                <img src="images/walk.png" border="0" name="Admission" alt="Admission" align="center" />
                                                <? }
else if($res['status']=='Session2020-21'){ echo 'Session 2020-21';}
else if($res['status']=='Session2021-22'){ echo 'Session 2021-22';}
else if($res['status']=='Session2022-23'){ echo 'Session 2022-23';}
else {echo "-";}?>
                                            </td>
                                            <td width="16%">
                                                <?php
                                                    $ress  =   @mysql_fetch_array(mysql_query("select * from ordermanagement where memberid = '".$res['stud_id']."'"),MYSQL_ASSOC);
                                                    
                                                       if(($res['information_source']=='Registration')){?>
                                                <!--    <a href="#" style="text-decoration:none"  onclick="window.open('editapp_detail.php?app_id=<?=$res['stud_id']?>','popup','width=800,height=800,scrollbars=yes,resizable=no,toolbar=no,directories=no,location=no,menubar=no,status=no,left=350,top=180'); return false"> <img src="images/edit.png" border="0" /> </a> 
                                                    ||-->
                                                <?php    
                                                    //print_r($ress['payment']);die;
                                                     if($ress['paymentstatus']=='pending' ){ ?><span style="font-weight:bold; color:#777"><a href="pmode_detail.php?reg_id=<?=$res['stud_id']?>" style="text-decoration:none;font-weight:bold; color:#999999" class="pmodee iframe">Pending</a></span><?  }
                                                    if($ress['paymentstatus']=='Paid'){  ?><a href="pmode_detail.php?reg_id=<?=$res['stud_id']?>" style="text-decoration:none;font-weight:bold; color:#009900" class="pmodee iframe">Paid</a> <? } 
                                                    if($ress['paymentstatus']=='Underprocess'){ ?> <span style="font-weight:bold; color:#cc9900;"><a href="pmode_detail.php?reg_id=<?=$res['stud_id']?>" style="text-decoration:none;font-weight:bold; color:#330066" class="pmodee iframe">Underprocess</a></span><? }
                                                    if($ress['paymentstatus']=='Unsuccessful') {  ?> <span style="font-weight:bold; color:#ff0000"><a href="pmode_detail.php?reg_id=<?=$res['stud_id']?>" style="text-decoration:none;font-weight:bold; color:#ff0000" class="pmodee iframe">Unsuccessful</a></span><? }
                                                    ?>
                                                <!--  || 
                                                    <a href="reg_detail.php?app_id=<?=$res['stud_id']?>" style="text-decoration:none" onclick="window.open('reg_detail.php?reg_id=<?=$res['stud_id']?>','popup','width=800,height=800,scrollbars=yes,resizable=no,toolbar=no,directories=no,location=no,menubar=no,status=no,left=350,top=180'); return false"><img src="images/print.jpg" width="19" height="20" border="0" /></a>--><? }?>
                                            </td>
                                            <td width="25%" align="center"><?php if($res['information_source']!='') echo ucwords($res['information_source']); else echo '-'; ?></td>
                                            <td width="16%"><?php echo $dd;?></td>
                                        </tr>
                                        <? 
                                            //	 	  $incr++;
                                            //	$first++;	
                                              $i=$i+1;
                                              } 
                                            	?>
                                    </table>
									
									
                                    <? if($num_rows > 0){	?>
                                    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                                        <tr>
                                            <td colspan="3"><img src="image/spacer.gif" height="3" /></td>
                                        </tr>
                                        <tr>
                                            <td valign="middle" background="newbar.jpg" class="table_td_heading" style="padding-left:30px;" width="18%">&nbsp;</td>
                                            <td width="70%" height="26" valign="middle" background="newbar.jpg" class="table_td_heading" style="padding-top:2px;"><span class="table_td_heading">
                                                <? include("paging.inc.php"); ?>
                                                </span>
                                            </td>
                                            <td width="12%" align="center" valign="middle" background="newbar.jpg" class="data">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                    <!--                      <tr>
                                                        <td align="right" valign="middle" class="table_td_heading" style="padding-right:5px;" width="100%"><strong>Page</strong>&nbsp;
                                                          <?=$spageno?>
                                                          &nbsp;of&nbsp;
                                                          <?=$spages?>
                                                        </td>
                                                        </tr>-->
                                                </table>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="3">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td align="center" valign="middle" colspan="3"><input type="button" name="Back" value="  Back  " onclick="javascript:history.go(-1)" /></td>
                                        </tr>
                                    </table>
                                </td>
                                <td width="47%" valign="top">
								
								
								
                                    <table width="100%" border="0" align="center" cellpadding="5" cellspacing="1" bgcolor="#81cafd" style="font-size:13px">
                                        <tr bgcolor="#999999" align="center">
                                            <td width="7%" height="25" align="left" background="footerbg.jpg" class="whitetxt11">S.No.</td>
                                            <td align="left" background="footerbg.jpg" class="whitetxt11" width="22%">Student Name</td>
                                            <td align="left" background="footerbg.jpg" class="whitetxt11" width="9%">Person</td>
                                            <td align="left" background="footerbg.jpg" class="whitetxt11" width="14%">Date</td>
                                            <td align="left" background="footerbg.jpg" class="whitetxt11" width="19%">Time</td>
                                            <td align="left" background="footerbg.jpg" class="whitetxt11" width="12%">Follow Up</td>
                                            <td align="left" background="footerbg.jpg" class="whitetxt11" width="17%">Next Step</td>
                                        </tr>
                                        <?php
                                            $sql_cust = "SELECT *, (select other from contact where  contact.stud_id=student.stud_id order by joined desc limit 1) as othernextstep, (select remarktime from contact where  contact.stud_id=student.stud_id order by joined desc limit 1) as remtime FROM student where student.req_type='Offline' and student.emp_id ='".$_SESSION['emp_id']."' AND remarkdate <=(CURDATE())  and remarkdate!='0000-00-00'order by remarkdate DESC";
                                            //	echo $sql_cust;
                                            $result	= mysql_query($sql_cust) or die(mysql_error());
                                            $num_rows 	= mysql_num_rows($result);	
                                            
                                            $incr = 1;
                                            
                                            if(!$_REQUEST['tpageno']){
                                            	$tpageno = 1;
                                            } else {
                                            	$tpageno= $_REQUEST['tpageno'];
                                            }
                                            $tpagesize=50;
                                            $incr = (($tpageno-1)*$tpagesize)+1;
                                            $first=$tpageno*$tpagesize-($tpagesize-1);
                                            $last=$first+$tpagesize-1; 
                                            $temp=($num_rows%$tpagesize);
                                            if ($temp==0)
                                            $tpages=($num_rows/$tpagesize);
                                            else
                                            $tpages=($num_rows/$tpagesize)+1;
                                            settype($tpages, "integer"); 
                                            
                                            for($i=1;$i<$first;$i++)
                                            	$row2000=mysql_fetch_row($result);
                                               
                                               
                                               
                                            //<?php
                                                //$query="SELECT * FROM addschool";
                                                //$result=mysql_query($query) or die(mysql_error());
                                                while($res=mysql_fetch_array($result) and ($first<=$last))
                                                {
                                                if($i%2==0) {
                                                	           $x = "bgcolor='#e9f5ff'";
                                                	          } else {
                                                	            $x = "bgcolor='#d8effe'";
                                                 	          }
                                                ?>
                                        <tr <?=$x;?> align="left">
                                            <td width="7%"><? echo $i;?>.</td>
                                            <td width="22%">
                                                <?
                                                    if(date("Y-M-d",strtotime($res['remarkdate']))<=date("Y-M-d") && $res['status']!='Paid')
                                                    {
                                                    ?>
                                                <font color="#FF0000">
                                                    <blink><strong><a href="11.php?stud_id=<? echo $res['stud_id'];?>"><?php echo $res['stud_name'];?></a></strong></blink>
                                                </font>
                                                <? 
                                                    }
                                                    else 
                                                    {
                                                    ?>
                                                <a href="11.php?stud_id=<? echo $res['stud_id'];?>"><?php echo $res['stud_name'];?></a>
                                                <? 
                                                    } 
                                                    ?>
                                            </td>
                                            <td width="9%">
                                                <? if(date("Y-M-d",strtotime($res['remarkdate']))<=date("Y-M-d") && $res['status']!='Paid')
                                                    {
                                                    ?>
                                                <font color="#009900">
                                                    <blink><strong><?php echo $res['name'];?></strong></blink>
                                                </font>
                                                <? 
                                                    }
                                                    else 
                                                    {
                                                    ?>
                                                <?php echo $res['name'];?>
                                                <? 
                                                    } 
                                                    ?>                  
                                            </td>
                                            <td width="14%">
                                                <? 
                                                    if($res['remarkdate'] >='2014-05-01 02:00:00')
                                                    {
                                                    if(date("Y-M-d",strtotime($res['remarkdate']))<=date("Y-M-d") && $res['status']!='Paid')
                                                    {?>
                                                <font color="#FF0000">
                                                    <blink><strong><?php echo date("d-M-y",strtotime($res['remarkdate']));?></strong></blink>
                                                </font>
                                                <? }
                                                    else 
                                                    {?>
                                                <?php echo date("d-M-y",strtotime($res['remarkdate']."+12 hours +32 minutes"));?>
                                                <? 
                                                    } } else {if(date("Y-M-d",strtotime($res['remarkdate']))<=date("Y-M-d") && $res['status']!='Paid')
                                                    {?>
                                                <font color="#FF0000">
                                                    <blink><strong><?php echo date("d-M-y",strtotime($res['remarkdate']."+12 hours +32 minutes"));?></strong></blink>
                                                </font>
                                                <? }
                                                    else 
                                                    {?>
                                                <?php echo date("d-M-y",strtotime($res['remarkdate']."+12 hours +32 minutes"));?>
                                                <? 
                                                    }}?>                   
                                            </td>
                                            <td width="19%"><?php echo $res['remtime'];?></td>
                                            <td width="12%"><?php echo $res['followup'];?></td>
                                            <td width="17%"><?php echo $res['othernextstep'];?></td>
                                        </tr>
                                        <? 
                                            $incr++;
                                            $first++;	
                                            $i=$i+1;
                                            } 
                                            ?>
                                    </table>
                                    <? if($num_rows > 0){	?>
                                    <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                                        <tr>
                                            <td colspan="3"><img src="image/spacer.gif" height="3" /></td>
                                        </tr>
                                        <tr>
                                            <td height="26" valign="middle" background="newbar.jpg" width="60%" class="table_td_heading" style="padding-left:5px;"><span class="table_td_heading">Pages:
                                                <? if ($tpageno==1) { ?>
                                                &nbsp;
                                                <? } else {?>
                                                <a href="tchome.php?tpageno=<?=$tpageno-1?>&spageno=<?=$spageno?>" class="table_td_heading">Previous</a>
                                                <? } 
                                                    for ($i=1; $i<=$tpages;$i++)
                                                    {
                                                    if($tpageno==$i)	{?>
                                                <strong class="table_td_heading"><? echo $i;?></strong>
                                                <? }
                                                    else
                                                    {
                                                    if($i%5==0)
                                                    {
                                                    ?>
                                                <strong><a class="table_td_heading" href="tchome.php?tpageno=<?=$i?>&spageno=<?=$spageno?>">
                                                <?=$i?>
                                                </a></font></strong>
                                                <? 
                                                    }
                                                    }
                                                    }
                                                    ?>
                                                <? if ($tpageno<$tpages) { ?>
                                                <a href="tchome.php?tpageno=<?=$tpageno+1?>&spageno=<?=$spageno?>" class="table_td_heading">Next</a>
                                                <? } else {?>
                                                <? } ?>
                                                </span>
                                            </td>
                                            <td width="10%" align="right" valign="middle" background="newbar.jpg" class="data">
                                                <!--DWLayoutEmptyCell-->&nbsp;
                                            </td>
                                            <td width="30%" align="center" valign="middle" background="newbar.jpg" class="data">
                                                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                                    <tr>
                                                        <td align="right" width="100%" valign="middle" class="table_td_heading" style="padding-right:5px;"><strong>Page</strong>&nbsp;
                                                            <?=$tpageno?>
                                                            &nbsp;of&nbsp;
                                                            <?=$tpages?>
                                                        </td>
                                                    </tr>
                                                </table>
                                                <strong></strong>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                        <table align="center" width="100%">
                            <tr>
                                <td class="footer" width="100%" >&copy; 2009 TeacherSITY. All rights reserved</td>
                            </tr>
                        </table>
                        <? }?>
                        <? }?>
                    </form>
                </td>
            </tr>
        </table>
    </body>
</html>