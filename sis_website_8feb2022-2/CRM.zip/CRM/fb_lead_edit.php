<?php
session_start();
include('functions.inc.php');
include("connection.php");
if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='Project Manager' && $_SESSION['user_type']!='Tele Caller' && $_SESSION['temp_type']!='y')
//if (!isset($_SESSION[myusername]))
{
 header("Location: index.php");
}
$_SESSION['this_page']='fb_lead_edit.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Fb Student Data</title>

<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />
</head>
<body>

<?php
if(isset($_REQUEST['update']))
{
	extract($_POST);
	$q1=mysql_query("update fb_lead_data set enquiry_date='".$enquiry_date."',student_name='".$std_name."',mobile_no='".$mobile."',student_email='".$email."',city='".$city."',ad_name='".$ad_name."',ac_year='".$ac_year."',compain_type='".$Campaign."',
	is_organic='".$type."' where id='".$_REQUEST['edit_id']."' ");
	if($q1)
	{
		$msg="Update Data Succussfully";
	}
}
include("header.php");
$ed=mysql_fetch_array(mysql_query("select * from fb_lead_data where id='".$_REQUEST['edit_id']."'"));



?>
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.2/themes/smoothness/jquery-ui.css"/>
<script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script> 
<script>
$(function()
 {
                $("#date").datepicker({
                   
                    dateFormat: 'yy-mm-dd'
                         });
				               
            });

</script>
<br />
<?php
 $statusMsgClass = 'alert-success';
if(isset($msg))
{
	 echo '<div class="alert '.$statusMsgClass.'">'.$msg.'</div>';
	 echo'<script>window.location.href="Fb_lead.php";</script>';
}
?>
<form name="edit_data" method="post" action="">
<table align="center" width="40%" style="border:#EFEFEF solid 1px; background-color:#EFEFEF">
<tr><td colspan="2" align="center" style="background-color:#43a2da; color:#FFF; height:30px;">FB Lead Edit Data</td></tr>
<tr><td colspan="2" align="center" style="height:15px;"></td></tr>
<tr><td style="padding-left:5px;">Enquiry Date:</td><td><input type="text" name="enquiry_date"  required="required" value="<?php echo $ed['enquiry_date']?>" style="height:28px; width:300px;" readonly="readonly" id="date"/></td></tr>
<tr><td colspan="2" style="height:10px;"></td></tr>
<tr><td style="padding-left:5px;">Student Name:</td><td><input type="text" name="std_name" value="<?php echo $ed['student_name']?>" required="required" style="height:28px; width:300px;"/></td></tr>
<tr><td colspan="2" style="height:10px;"></td></tr>
<tr><td style="padding-left:5px;">Mobile:</td><td><input type="text" name="mobile" value="<?php echo $ed['mobile_no']?>"  required="required" style="height:28px; width:300px;" maxlength="10"/></td></tr>
<tr><td colspan="2" style="height:10px;"></td></tr>
<tr><td style="padding-left:5px;">E-mail:</td><td><input type="text"  name="email"  value="<?php echo $ed['student_email']?>" required="required" style="height:28px; width:300px;"/></td></tr>
<tr><td colspan="2" style="height:10px;"></td></tr>
<tr><td style="padding-left:5px;">City:</td><td><input type="text" name="city"  value="<?php echo $ed['city']?>" required="required" style="height:28px; width:300px;"/></td></tr>
<tr><td colspan="2" style="height:10px;"></td></tr>
<tr><td style="padding-left:5px;">Ad Name:</td><td><input type="text" name="ad_name" value="<?php echo $ed['ad_name']?>" required="required"  style="height:28px; width:300px;"/></td></tr>
<tr><td colspan="2" style="height:10px;"></td></tr>
<tr><td style="padding-left:5px;">Ac Year:</td><td><input type="text" name="ac_year" value="<?php echo $ed['ac_year']?>" required="required" style="height:28px; width:300px;"/></td></tr>
<tr><td colspan="2" style="height:10px;"></td></tr>
<tr><td style="padding-left:5px;">Campaign Type:</td><td><input type="text" name="Campaign" value="<?php echo $ed['compain_type']?>" required="required" style="height:28px; width:300px;"/></td></tr>
<tr><td colspan="2" style="height:10px;"></td></tr>
<tr><td style="padding-left:5px;">Is Organic:</td><td><input type="text" name="type" value="<?php echo $ed['is_organic']?>" required="required" style="height:28px; width:300px;"/></td></tr>
<tr><td colspan="2" align="center" style="height:15px;"></td></tr>
<tr><td colspan="2" align="center" style="height:15px;"><input type="submit" name="update" class="btn btn-primary" value="update"/></td></tr>
<tr><td colspan="2" align="center" style="height:15px;"></td></tr>

</table>
</form>

</body>

</html>