<?php

//$hostname = "localhost";
//$user    = "root";
//$password = "";
//
$db ="iitjeecrm";

$connection = mysql_connect('iitjeecrm.db.5227155.hostedresource.com','iitjeecrm','Iitjee@1',true);

$db1=mysql_select_db($db,$connection);


//$hostname = "localhost";
//$user    = "root";
//$password = "";

$db1 ="neetcrm";

$connection1 = mysql_connect('68.178.139.6','neetcrm','Neetcrm1@',true);

mysql_select_db($db1,$connection1);

//$hostname = "localhost";
//$user    = "root";
//$password = "";

$db2 ="selaquicrm";

$connection2 = mysql_connect('selaquicrm.db.5227155.hostedresource.com','selaquicrm','Siscrm1#',true);

mysql_select_db($db2,$connection2);

     @extract($_GET);
     @extract($_POST);

     date_default_timezone_set('Asia/Calcutta');
 $filename="crmcornjob";
$csv_filename = $filename.".xls";

 //$csv_filename = chmod($filename.".xls",0755);


$fd = fopen($csv_filename, "w");
// $dd=date("Y-m-d") ;
//$first_date = strtotime($dd);

 $dd= date('Y-m-d',strtotime('last day')); 
//$result=mysql_query("SELECT student.* ,members.emp_name FROM members inner join student on members.emp_id =student.emp_id WHERE  DATE( student.joined ) = DATE( '$dd' ) and page_group  NOT LIKE '%IIT%' and page_group NOT LIKE '%NEET%' ");
//for neet
$neetresult=mysql_query("SELECT student.* ,members.emp_name FROM members inner join student on members.emp_id =student.emp_id WHERE DATE( student.joined ) = DATE( '$dd' ) and  student.v_type='' ",$connection1);
$neetresultpaid=mysql_query("SELECT student.* ,members.emp_name FROM members inner join student on members.emp_id =student.emp_id WHERE DATE( student.joined ) = DATE( '$dd' ) and   student.v_type !='' ",$connection1);
 $neetnum_organic=mysql_num_rows($neetresult);

 $neetnum_paid=mysql_num_rows($neetresultpaid);

//for crm
 
// echo "SELECT student.* ,members.emp_name FROM members inner join student on members.emp_id =student.emp_id WHERE DATE( student.joined ) = DATE( '$dd' ) and   student.v_type=''";
$resulcrm=mysql_query("SELECT student.* ,members.emp_name FROM members inner join student on members.emp_id =student.emp_id WHERE DATE( student.joined ) = DATE( '$dd' ) and   student.v_type=''",$connection2);
$num_crm_organic=mysql_num_rows($resulcrm);
//echo '<br/>';
//echo "SELECT student.* ,members.emp_name FROM members inner join student on members.emp_id =student.emp_id WHERE DATE( student.joined ) = DATE( '$dd' ) and   student.v_type!=''"; die;
$result_crmpaid=mysql_query("SELECT student.* ,members.emp_name FROM members inner join student on members.emp_id =student.emp_id WHERE DATE( student.joined ) = DATE( '$dd' ) and   student.v_type!=''",$connection2);
 $num_crmpaid=mysql_num_rows($result_crmpaid);
 
 //for iitjeecrm
$resuliit=mysql_query("SELECT student.* ,members.emp_name FROM members inner join student on members.emp_id =student.emp_id WHERE DATE( student.joined ) = DATE( '$dd' ) and   student.v_type=''",$connection);
$num_iit_organic=mysql_num_rows($resuliit);

$result_iitpaid=mysql_query("SELECT student.* ,members.emp_name FROM members inner join student on members.emp_id =student.emp_id WHERE DATE( student.joined ) = DATE( '$dd' ) and   student.v_type!=''",$connection);
 $num_iitpaid=mysql_num_rows($result_iitpaid);
 
 $reportdate=date('d-m-Y', strtotime($dd));
 

 $fileContent="<table  border='0' width='100%' border='1'>";


 	$fileContent .="<tr>";
	$fileContent .= '<td  colspan="4" align="center"><b>SIS Lead Report On- '.$reportdate.' '."</b></td></tr><tr>";       
        $fileContent .='<td ><font color="#fff"><b>'."</b></font></td>";
  $fileContent .='<td><b> SCHOOL'."</b></td>";
  $fileContent .=' <td><b>IIT-JEE '."</b></td>";
 $fileContent .='<td ><b>NEET'."</b></td></tr>";
   $fileContent .="<tr>";
      $fileContent .='<td><b>Organic'."</b></td><td>";
 $fileContent.=$num_crm_organic;
 $fileContent.="</td><td>";
  $fileContent.=$num_iit_organic;
  $fileContent.="</td><td>";
 $fileContent.=$neetnum_organic;
 $fileContent.="</td></tr>";
 
    $fileContent .="<tr>";
      $fileContent .='<td ><b>Paid'."</b></td><td>";
 $fileContent.=$num_crmpaid;
 $fileContent.="</td><td>";
  $fileContent.= $num_iitpaid;
  $fileContent.="</td><td>";
 $fileContent.=$neetnum_paid;
 $fileContent.="</td></tr>";
 
    $fileContent .="<tr bgcolor='gray'>";
      $fileContent .='<td ><b>Total'."</b></td><td>";
 $fileContent.=$num_crm_organic+$num_crmpaid;
 $fileContent.="</td><td>";
  $fileContent.= $num_iit_organic+$num_iitpaid;
  $fileContent.="</td><td>";
 $fileContent.=$neetnum_organic+$neetnum_paid;
 $fileContent.="</td></tr>";

    $headers  = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
		$headers .= "From: SelaQui <info@selaqui.org>". "\r\n";
		$headers .= "Return-Path: <info@selaqui.org>". "";
  
         
                
                
 
$fileContent.= "</table>";  
$toemail = "vs.btechit@gmail.com";
//$toemail = "yogesh.gururani@tsei.co.in,CITO.dpsgs@dpsgs.org,sarvadarshi@tsei.co.in,sandeep.bisht@tsei.co.in";
$my_subject = "SIS  LEAD REPORT".'('.date("d-M-Y",strtotime($dd)).')';


if (mail($toemail, $my_subject, $fileContent, $headers)) {
        echo "mail send ... OK"; // or use booleans here
    } else {
        echo "mail send ... ERROR!";
    }






//print_r($fileContent);die;

    
?>
<?php
//fputs($fd, $fileContent);
//fclose($fd);
////mail atachment
//
//
// function mail_attachment($filename, $path, $mailto, $from_mail, $from_name, $replyto, $subject, $message) {
//     $file = $path.$filename;
//    $file_size = filesize($file);
//    $handle = fopen($file, "r");
//    $content = fread($handle, $file_size);
//    fclose($handle);
//    $content = chunk_split(base64_encode($content));
//    $uid = md5(uniqid(time()));
// $name = basename($file);
//    $header = "From: ".$from_name." <".$from_mail.">\r\n";
//    $header .= "Reply-To: ".$replyto."\r\n";
//    $header .= "MIME-Version: 1.0\r\n";
//    $header .= "Content-Type: multipart/mixed; boundary=\"".$uid."\"\r\n\r\n";
//    $header .= "This is a multi-part message in MIME format.\r\n";
//    $header .= "--".$uid."\r\n";
//    $header .= "Content-type:text/plain; charset=iso-8859-1\r\n";
//    $header .= "Content-Transfer-Encoding: 7bit\r\n\r\n";
//    $header .= $message."\r\n\r\n";
//    $header .= "--".$uid."\r\n";
//    $header .= "Content-Type: application/octet-stream; name=\"".$filename."\"\r\n"; // use different content types here
//    $header .= "Content-Transfer-Encoding: base64\r\n";
//    $header .= "Content-Disposition: attachment; filename=\"".$filename."\"\r\n\r\n";
//    $header .= $content."\r\n\r\n";
//    $header .= "--".$uid."--";
//    if (mail($mailto, $subject, "", $header)) {
//        echo "mail send ... OK"; // or use booleans here
//    } else {
//        echo "mail send ... ERROR!";
//    }
//    
//  // mail($mailto, $subject, '', $header);
//   
//}
//
// //$toemail = "yogesh.gururani@tsei.co.in,CITO.dpsgs@dpsgs.org,sarvadarshi@tsei.co.in";
//$toemail = "sandeep.bisht@tsei.co.in,vs.btechit@gmail.com,bishtmca83@gmail.com";
//$my_file = "crmcornjob.xls";
////$my_path = "";//$_SERVER['DOCUMENT_ROOT']."/your_path_here/";
//$my_path = $_SERVER['DOCUMENT_ROOT']."/CRM/";
//$my_name = "SIS Addword Report";
//$my_mail = "noreply@selaquieducation.org";
//$my_replyto = "noreply@selaquieducation.org";
//$my_subject = "SIS  LEAD REPORT".'('.date("d-M-Y",strtotime($dd)).')';
//$my_message = "";
//  
//
//mail_attachment($my_file, $my_path,$toemail, $my_mail, $my_name, $my_replyto, $my_subject, $my_message);



die();
 