<?php 
ob_start();
session_start();
require_once('connection.php'); 
?>
<?php
//$today = date("Y-m-d");
//$thisMonth=date("Y-m%");
//$time = time("H:i:s");
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Cumulative_Report.xls");
header("Pragma: no-cache");
header("Expires: 0");
$now=date("j-n-Y");
echo "\t \t Report ON ".$now."\t";

if (strlen($_GET['date1'])>0)
{
$strqry=" and DATE(contact_date)='".$_GET['date1']."'";
$strqry1=" and DATE(contact.joined)='".$_GET['date1']."'";
$strqry2=" and DATE(joined)='".$_GET['date1']."'";
}
				
elseif (strlen($_GET['month1'])>0)
{
$strqry=" and MONTH(contact_date)='".$_GET['month1']."'";
$strqry1=" and MONTH(contact.joined)='".$_GET['month1']."'";
$strqry2=" and MONTH(joined)='".$_GET['month1']."'";

}


$sql_cust = "SELECT emp_id,emp_name,(select count(*) from student where student.emp_id='".$_SESSION['emp_id']."' ". $strqry2." ) as lcontact, (select count(*) from contact inner join student on contact.stud_id=student.stud_id where student.emp_id='".$_SESSION['emp_id']."' ". $strqry1.") as scontact, (select count(*) from student where status='Positive' ". $strqry." and student.emp_id='".$_SESSION['emp_id']."') as pcontact, (select count(*) from student where status='Negative' ". $strqry." and student.emp_id='".$_SESSION['emp_id']."') as ncontact, (select count(*) from student where status='Moderate' ". $strqry." and student.emp_id='".$_SESSION['emp_id']."') as mcontact, (select count(*) from student where status='Paid' ". $strqry." and student.emp_id='".$_SESSION['emp_id']."') as paidcontact, (select count(*) from student where status='Admission' ". $strqry." and student.emp_id='".$_SESSION['emp_id']."') as admitcontact FROM members WHERE members.emp_id='".$_SESSION['emp_id']."'";



/*
$sql_cust = "SELECT emp_id,emp_name, (select count(*) from addcontact where school_id>'".$_SESSION['emp_id']."' and school_id<('".$_SESSION['emp_id']."'+100000) ". $strqry.") as scontact, (select count(*) from addcontact where status='Positive' ". $strqry." and school_id>'".$_SESSION['emp_id']."' and school_id<('".$_SESSION['emp_id']."'+100000)) as pcontact, (select count(*) from addcontact where status='Negative' ". $strqry." and school_id>'".$_SESSION['emp_id']."' and school_id<('".$_SESSION['emp_id']."'+100000)) as ncontact, (select count(*) from addcontact where status='Moderate' ". $strqry." and school_id>'".$_SESSION['emp_id']."' and school_id<('".$_SESSION['emp_id']."'+100000)) as mcontact, (select count(*) from addcontact where status='Paid' ". $strqry." and school_id>'".$_SESSION['emp_id']."' and school_id<('".$_SESSION['emp_id']."'+100000)) as paidcontact FROM members WHERE emp_id='".$_SESSION['emp_id']."'";


*/
		

		$result	= mysql_query($sql_cust) or die(mysql_error());
		
print("\n");
print("\n");
	    echo "S.No."."\t";
		echo "Emp Name"."\t";
		echo "No of Leads"."\t";
		
		
		echo "No of Calls"."\t";
		echo "Admission"."\t";
		echo "Paid Student"."\t";
		echo "Positive Student"."\t";
		echo "Moderate Student"."\t";
		echo "Negative Student"."\t";
		
		
		print("\n"); 
		$i=1;
   while($res=mysql_fetch_array($result))
    {
        echo $i."\t";
		echo $res['emp_name']."\t";
		echo $res['lcontact']."\t";
		
		echo $res['scontact']."\t";
		echo $res['admitcontact']."\t";
		
		
		echo $res['paidcontact']."\t";
		echo $res['pcontact']."\t";
		echo $res['mcontact']."\t";
		echo $res['ncontact']."\t";
		
			print "\n";
		$i+=1;		
    }

?>
					
	