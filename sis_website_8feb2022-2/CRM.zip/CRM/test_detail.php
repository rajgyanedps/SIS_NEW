<?php
session_start();
include("connection.php");
if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='Project Manager' && $_SESSION['user_type']!='Tele Caller')
//if (!isset($_SESSION[myusername]))
{
 header("Location: index.php");
}
$_SESSION['this_page']='test.php';
?> 

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Participation Detail Report</title>

<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?
$test_detail = "SELECT add1, school_name, add2, city,state,phone_code,phone_no,mobno, test FROM addschool INNER JOIN testdetail ON addschool.school_id = testdetail.school_id 
WHERE class='".$_GET['class']."'
AND subject = '".$_GET['subject']."'";

		$result_detail = mysql_query($test_detail) or die(mysql_error());
		$num_rows=mysql_num_rows($result_detail);
		?>
        <table><tr><td align="left" style="padding-left:10px; font-weight:bold;">
          <font color="#000000" size="3px">Test Details for Class <? echo $_GET['class']." and Subject is ".$_GET['subject'];?></font>
        </td>
        </tr></table>
       

     <table width="100%" border="0" align="center" cellpadding="5" cellspacing="1" bgcolor="#81cafd" style="font-size:12px">
      <tr bgcolor="#999999" align="center">
      <td align="left" background="footerbg.jpg" class="whitetxt11">S.No.</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11">School Name</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11">Address</td>
      <td background="footerbg.jpg" class="whitetxt11">City / State</td>
      <td background="footerbg.jpg" class="whitetxt11">Phone/ Mobile</td>
      <td background="footerbg.jpg" class="whitetxt11">Test Count</td>
    </tr>
    <? 
	 if($num_rows==0)
		{
		echo "<div align=center><font color=red size=+1>No Record Found</font></div>";
		}
		$count = 0;
		$i=1;
		
while($res_detail=mysql_fetch_array($result_detail))
{

if($acol) {
	           $x = "bgcolor='#e9f5ff'";
	          } else {
	            $x = "bgcolor='#d8effe'";
 	          }
			  $acol=!$acol;
			  $count++;
?>
    <tr <?=$x;?> align="left">
   	  <td><?=$i;?></td>
      <td><?php echo $res_detail['school_name'];?></td>
      <td><?php echo $res_detail['add1']." , ".$res_detail['add2'];?></td>
      <td><?php echo $res_detail['city']." , ".$res_detail['state'];?></td>
	  <td><?php echo $res_detail['phone_code'].$res_detail['phone_no']." , ".$res_detail['mobno'];?></td>
      <td><?php echo $res_detail['test'];?></td>
    </tr>
      <?
	  $i++;
	  }
	  ?>
    <tr><td align="center" colspan="10"><input name="showall" type="button" onclick="MM_goToURL('parent','studentreport.php?school_id=<?=$_GET['school_id']?>');return document.MM_returnValue" value="Show All" /></td></tr>
</table>
  
	
  <table width="100%" align="center">
  <tr>
      <td><img src="image/spacer.gif" height="5" /></td>
    </tr>
<tr>
<td class="footer" width="944" >&copy; 2009 TeacherSITY. All rights reserved</td>
</tr>
</table>

</body>
</html>