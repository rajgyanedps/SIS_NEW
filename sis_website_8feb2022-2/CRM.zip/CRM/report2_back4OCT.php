<?php 
ob_start();
require_once('connection.php'); 
?>
<?php
//$today = date("Y-m-d");
//$thisMonth=date("Y-m%");
//$time = time("H:i:s");
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Cumulative_Report.xls");
header("Pragma: no-cache");
header("Expires: 0");
$now=date("j-n-Y");
echo "\t \t Report ON ".$now."\t";



$sql_model=mysql_query("SELECT emp_name,emp_id, (SELECT count(*)
FROM addschool WHERE school_id>emp_id and school_id<emp_id+100000) as school, (SELECT count(*) from last_contact where status='Positive' and school_id>emp_id and school_id<emp_id+100000) as positive, (SELECT count(*) from last_contact where status='Negative' and school_id>emp_id and school_id<emp_id+100000) as negative, (SELECT count(*) from last_contact where status='Moderate' and school_id>emp_id and school_id<emp_id+100000) as moderate, (SELECT count(*) from last_contact where status='Paid' and school_id>emp_id and school_id<emp_id+100000) as paid, (SELECT sum(acttest) FROM addparticipation WHERE school_id>emp_id and school_id<emp_id+100000) as test, (SELECT sum(totalamm) FROM last_totalamm WHERE school_id>emp_id and school_id<emp_id+100000) as totalamt, (SELECT sum(advanceamm) FROM addammount WHERE school_id>emp_id and school_id<emp_id+100000) as paidamt 
FROM members WHERE username!='Open Data' and username!='del_school' order by emp_name");
print("\n");
print("\n");
	    echo "S.No."."\t";
		echo "Emp Name"."\t";
		echo "No. of Student"."\t";
		echo "Paid Student"."\t";
		echo "Positive Student"."\t";
		echo "Moderate Student"."\t";
		echo "Negative Student"."\t";
						
		print("\n"); 
		$i=1;
 while($row = mysql_fetch_array($sql_model))
    {
        echo $i."\t";
		echo $row['emp_name']."\t";
		echo $row['school']."\t";
		echo $row['paid']."\t";
		echo $row['positive']."\t";
		echo $row['moderate']."\t";
		echo $row['negative']."\t";
			
		print "\n";
		$i+=1;		
    }

?>