<?php 
require_once('connection.php'); 
?>
<?php
//$today = date("Y-m-d");
//$thisMonth=date("Y-m%");
//$time = time("H:i:s");
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Data_Report.xls");
header("Pragma: no-cache");
header("Expires: 0");
$now=date("j-n-Y");
echo "\t \t Report ON ".$now."\t";

$sql_model=mysql_query(stripslashes ($_POST['qry']));
print("\n");
print("\n");
	    echo "S.No."."\t";
		echo "School Id"."\t";
		echo "School Name"."\t";
		echo "Address 1"."\t";
		echo "Address 2"."\t";
		echo "City"."\t";
		echo "Phone No."."\t";
		echo "Mob No."."\t";
		echo "Email"."\t";
		echo "Website"."\t";
		echo "School Type"."\t";
		echo "No. of Students"."\t";
		echo "No. of Teachers"."\t";
		echo "State"."\t";
		echo "Pin"."\t";
		echo "Affiliation"."\t";
		print("\n"); 
		$i=1;
 while($row = mysql_fetch_array($sql_model))
    {
        echo $i."\t";
		echo $row['school_id']."\t";
		echo $row['school_name']."\t";
		echo $row['add1']."\t";
		echo $row['add2']."\t";
		echo $row['city']."\t";
		echo $row['phone_code'].", ".$row['phone_no']."\t";
		echo $row['mobno']."\t";
		echo $row['email']."\t";
		echo $row['website']."\t";
		echo $row['schooltype']."\t";
		echo $row['nostudents']."\t";
		echo $row['noteachers']."\t";
		echo $row['state']."\t";
		echo $row['pin']."\t";
		echo $row['boardaff']."\t";
		print "\n";
		$i+=1;		
    }

?>