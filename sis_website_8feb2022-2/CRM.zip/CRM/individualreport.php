<?php
session_start();
include("connection.php");
if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='Project Manager' && $_SESSION['user_type']!='Tele Caller')
//if (!isset($_SESSION[myusername]))
{
 header("Location: index.php");
}
?> 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Total School Contact Report</title>
<script type="text/javascript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />
</head>
</head>
<body>
<?php
include("header.php");
?>
<?php
$sql = "select * from members WHERE emp_id='".$_GET['emp_id']."'";
$result1 = mysql_query($sql);
$res1 = mysql_fetch_array($result1);
$res1['emp_id'];
?>
<form action="individualreport.php" method="post" name="individualreport">
<table width="100%" align="center">
  <tr><td height="25" align="left" bgcolor="#f3f7fd"><font size="3px" face="Verdana, Arial, Helvetica, sans-serif">
  <div style="margin-left:15px;"><b>Student Last Contact (<? echo $res1['emp_name'];?>)</b></div></font></td></tr></table>
<br />
<?php

$sql_cust = "SELECT student.*, (SELECT count(*) FROM contact WHERE contact.stud_id=student.stud_id) as contact, (SELECT other FROM contact WHERE contact.stud_id=student.stud_id  order by contact.joined DESC limit 1) as otherstep, (SELECT remarktime FROM contact WHERE contact.stud_id=student.stud_id order by contact.joined DESC limit 1) as remtime FROM student WHERE student.emp_id ='".$_GET['emp_id']."' and student.contact_date!='0000-00-00 00:00:00' order by joined asc";

/*

$sql_cust = "SELECT addschool.school_id, addschool.school_name, addschool.add1, addschool.add2, addschool.city, last_contact.school_id, last_contact.joined, last_contact.status, last_contact.name, last_contact.followup, last_contact.remarkdate, members.emp_id, (SELECT count(*) FROM addcontact WHERE school_id>'".$_GET['emp_id']."' and school_id<'".($_GET['emp_id']+100000)."' and last_contact.school_id=addcontact.school_id) as contact, (SELECT other FROM addcontact WHERE school_id>'".$_GET['emp_id']."' and school_id<'".($_GET['emp_id']+100000)."' and last_contact.school_id=addcontact.school_id limit 1) as otherstep, (SELECT remarktime FROM addcontact WHERE school_id>'".$_GET['emp_id']."' and school_id<'".($_GET['emp_id']+100000)."' and last_contact.school_id=addcontact.school_id limit 1) as remtime FROM addschool, last_contact, members WHERE emp_id ='".$_GET['emp_id']."' and last_contact.school_id >'".$_GET['emp_id']."' and last_contact.school_id <'".($_GET['emp_id'] + 100000)."' and addschool.school_id=last_contact.school_id order by joined asc";
*/
		$result	= mysql_query($sql_cust) or die(mysql_error());
		$num_rows= mysql_num_rows($result);
?>
<div style="float:left;line-height:20px;width:50%; margin-bottom:10px;">
<font color="#000000" size="3px" style="padding-left:15px"><b>Convert to Excel</b>&nbsp;&nbsp;<a href="report8.php?emp_id=<? echo $res1['emp_id'];?>"><img src="logo_excel.gif" alt="Export" border="0"></a></font></div>
<div style="float:left;line-height:20px;width:49%" align="right">
<b>Records Found :</b>&nbsp;<strong><? echo $num_rows?></strong></div>
<br />
<table width="100%" border="0" align="center" cellpadding="5" cellspacing="1" bgcolor="#81cafd" style="font-size:12px">
<tr bgcolor="#999999" align="center">

      <td height="20" align="left" background="footerbg.jpg" bgcolor="#999999" class="whitetxt11">S.No.</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="165">Student Name</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" style="width:100px">Call Date/Time</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11">Name</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11">Status</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" style="width:110px">Follow Up</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" style="width:110px">Remark Date</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" style="width:110px">Remark Time</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11">Next Step</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" style="width:110px">No. of Contact</td>
      
      
    </tr>
                <? 
	
		$count = 0;
		
while($res=mysql_fetch_array($result))
{
if($acol) {
	           $x = "bgcolor='#e9f5ff'";
	          } else {
	            $x = "bgcolor='#d8effe'";
 	          }
			  $acol=!$acol;
			  $count++;
?>

<tr <?=$x;?> align="left">
        <td><? echo $count;?>.</td>
        
        
      <td><strong> <a href="11.php?stud_id=<? echo $res['stud_id'];?>"> <?php echo $res['stud_name'];?><br />
      <?php echo $res['add1'];?><br />
	  <? if ($res['add2']==0)
	  {?>
	  <?php echo $res['city'];?>
	  <? }
	  else
	  {?>
	  <?php echo $res['add2'];?>
      <? }?>
      <br />
      <?php echo $res['city'];?> </a></strong></td>
<td>
<?php 
	if($res['contact_date']!='0000-00-00 00:00:00')
	{ 
		echo date("d-M-y", strtotime($res['contact_date']));
?><br />
     <?php 
	 echo date("H:i A",strtotime($res['contact_date']));
	}		
	?>
                </td>
      <td>
	  <? if($res['stud_name']=='0')
	{
	echo " &nbsp;";
	}
	else
	{?>
	  <?php echo $res['stud_name'];?>
      <? }?>
      </td>
      <td align="center"><?php if($res['status']=='Positive'){?> <img src="image/green.gif" border="0" name="plus_sign" alt=" Positive School" align="center"/><? } else if($res['status']=='Admission'){ ?><img src="image/admission.png" border="0" name="Admission" alt="Admission" align="center"/><? } else if($res['status']=='Negative'){ ?><img src="image/red.gif" border="0" name="minus_sign" alt="Negative School" align="center"/><? } else if($res['status']=='Moderate'){ ?><img src="image/mod.gif" border="0" name="minus_sign" alt="Moderate School" align="center"/>
	  <? } else if($res['status']=='Paid'){ ?><img src="image/paddy-smiley26.gif" border="0" name="paid" alt="Paid School" align="center" />
	  
	   <? }else if($res['status']=='NoContact'){ ?>
                   <img src="image/nocontact.png" border="0" name="Admission" alt="Admission" align="center" />
                   <? }else if($res['status']=='Session2013-14'){ ?>
                   <img src="image/2013-14.jpg.png" border="0" name="Admission" alt="Admission" align="center" />
	  
	  <? }else echo "-";?></td>
      <td><?php echo $res['followup'];?></td>
      <td><?php if($res['remarkdate']!='0000-00-00 00:00:00') echo date("d-M-y",strtotime($res['remarkdate']));?></td>
      <td><?php echo $res['remtime'];?></td>
      <td><?php echo $res['otherstep'];?></td>
      <td><?php echo $res['contact'];?></td>
                                      
                         
    </tr>
                         
 <? }?>
</table>
<table width="100%" align="center">
<tr>
<td>&nbsp;</td>
</tr>
<tr>
<td class="footer" width="958" >&copy; 2009 TeacherSITY. All rights reserved</td>
</tr>

</table>
  

</form>

</body>
</html>