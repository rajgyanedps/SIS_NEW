<?php
session_start();
include('functions.inc.php');
include("connection.php");
if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='School Login' && $_SESSION['user_type']!='Tele Caller' && $_SESSION['temp_type']!='y')
//if (!isset($_SESSION[myusername]))
{
 header("Location: index.php");
}
$_SESSION['this_page']='Fb_lead.php';
if(!empty($_GET['status'])){
    switch($_GET['status']){
        case 'succ':
            $statusMsgClass = 'alert-success';
            $statusMsg = 'Fb Lead data has been inserted successfully.';
            break;
        case 'err':
            $statusMsgClass = 'alert-danger';
            $statusMsg = 'Some problem occurred, please try again.';
            break;
        case 'invalid_file':
            $statusMsgClass = 'alert-danger';
            $statusMsg = 'Please upload a valid CSV file.';
            break;
        default:
            $statusMsgClass = '';
            $statusMsg = '';
    }
}

if(isset($_POST['importSubmit'])){
    
    //validate whether uploaded file is a csv file
    $csvMimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain');
    if(!empty($_FILES['file']['name']) && in_array($_FILES['file']['type'],$csvMimes)){
        if(is_uploaded_file($_FILES['file']['tmp_name'])){
            
            //open uploaded csv file with read only mode
            $csvFile = fopen($_FILES['file']['tmp_name'], 'r');
            
            //skip first line
            fgetcsv($csvFile);
            
            //parse data from csv file line by line
            while(($line = fgetcsv($csvFile)) !== FALSE)
			{
                
                $prevQuery = "SELECT * FROM fb_lead_data WHERE student_email = '".$line[13]."'";
                $prevResult = mysql_query($prevQuery);
				$ct=mysql_num_rows($prevResult);
                if($ct > 0){
                    
					
                 mysql_query("update fb_lead_data set enquiry_date='".date('Y-m-d')."',ad_name='".mysql_real_escape_string($line[3])."',ac_year='2018',compain_type='".mysql_real_escape_string($line[7])."',is_organic='".mysql_real_escape_string($line[10])."',
				 student_name='".mysql_real_escape_string($line[14])."',student_email='".mysql_real_escape_string($line[13])."',city='".mysql_real_escape_string($line[15])."',mobile_no='".mysql_real_escape_string($line[12])."' WHERE student_email = '".mysql_real_escape_string($line[13])."'") or (mysql_error());
                }
				else
				{
mysql_query("INSERT INTO fb_lead_data(enquiry_date,ad_name,ac_year,compain_type, is_organic,student_name,student_email,city,mobile_no) VALUES
					 ('".date('Y-m-d')."','".mysql_real_escape_string($line[3])."','2018','".mysql_real_escape_string($line[7])."','".mysql_real_escape_string($line[10])."','".mysql_real_escape_string($line[14])."','".mysql_real_escape_string($line[13])."','".mysql_real_escape_string($line[15])."','".mysql_real_escape_string($line[12])."')") or die(mysql_error());
                     }
            }
            
            //close opened csv file
            fclose($csvFile);

            $qstring = '?status=succ';
        }else{
            $qstring = '?status=err';
        }
    }else{
        $qstring = '?status=invalid_file';
    }
header("Location: Fb_lead.php".$qstring);
}


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Fb Student Data</title>
<script type="text/javascript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
.checkbox label:after, 
.radio label:after {
    content: '';
    display: table;
    clear: both;
}

.checkbox .cr,
.radio .cr {
    position: relative;
    display: inline-block;
    border: 1px solid #a9a9a9;
    border-radius: .25em;
    width: 1.3em;
    height: 1.3em;
    float: left;
    margin-right: .5em;
}

.radio .cr {
    border-radius: 50%;
}

.checkbox .cr .cr-icon,
.radio .cr .cr-icon {
    position: absolute;
    font-size: .8em;
    line-height: 0;
    top: 50%;
    left: 20%;
}

.radio .cr .cr-icon {
    margin-left: 0.04em;
}

.checkbox label input[type="checkbox"],
.radio label input[type="radio"] {
    display: none;
}

.checkbox label input[type="checkbox"] + .cr > .cr-icon,
.radio label input[type="radio"] + .cr > .cr-icon {
    transform: scale(3) rotateZ(-20deg);
    opacity: 0;
    transition: all .3s ease-in;
}

.checkbox label input[type="checkbox"]:checked + .cr > .cr-icon,
.radio label input[type="radio"]:checked + .cr > .cr-icon {
    transform: scale(1) rotateZ(0deg);
    opacity: 1;
}

.checkbox label input[type="checkbox"]:disabled + .cr,
.radio label input[type="radio"]:disabled + .cr {
    opacity: .5;
}
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php

include("header.php");



?>
<link href="https://cdn.datatables.net/1.10.15/css/dataTables.bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/responsive/2.1.1/css/responsive.bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script> 
<script src="https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js"></script> 
<script src="https://cdn.datatables.net/responsive/2.1.1/js/dataTables.responsive.min.js"></script> 
<script src="https://cdn.datatables.net/responsive/2.1.1/js/responsive.bootstrap.min.js"></script> 
<div class="container" >

    <?php if(!empty($statusMsg)){
        echo '<div class="alert '.$statusMsgClass.'">'.$statusMsg.'</div>';
    } ?>
    <div class="panel panel-default">
        <?php if($_SESSION['user_type']=='Admin')
		{?>
        <div class="panel-heading">
            FB Lead data
            <a href="javascript:void(0);" onClick="$('#importFrm').slideToggle();">Import</a>&nbsp;
           <!-- <a href="download_fb_lead.php">Export</a>-->
        </div>
		<?php }?>
        <div class="panel-body">
            <form action="" method="post" enctype="multipart/form-data" id="importFrm" style="display:none;">
                <table><tr><td><input type="file" name="file" /></td>
                <td><input type="submit" class="btn btn-primary" name="importSubmit" value="IMPORT"></td></tr></table>
            </form>
            <table border="0" cellspacing="5" cellpadding="5" align="left">
        <tbody><tr>
            <td><?php if($_SESSION['user_type']=='Admin')
		{?><table style="box-shadow: 3px 3px 5px #888888;border:#EFEFEF solid 1px;border-radius:5px;"><tr><td><div class="checkbox">
          <label>
            <input type="checkbox" value="" id="s_all" onclick="toggle(this);">
            <span class="cr"><i class="cr-icon glyphicon glyphicon-ok"></i></span>
             </label>
        </div></td><td style="cursor:pointer;">
  <div class="dropdown">
  <span data-toggle="dropdown">Select All
  <span class="caret"></span></span>
  <ul class="dropdown-menu">
    <li style="padding:3px;" onclick="delete_all()">Delete All</li>
    </li>
  </ul>
</div>
</td><td style="width:20px;"></td></tr></table><?php }?>
  
</td><td>&nbsp;&nbsp;</td><td>From Date:&nbsp;</td>
            <td><input type="text" id="min" name="min" style="border-radius:5px; padding-left:5px;border:none;height:28px; border:#ccc solid 1px;"></td><td>&nbsp;To Date:&nbsp;</td>
            <td><input type="text" id="max" name="max" style="border-radius:5px;border:none;height:28px; border:#ccc solid 1px; padding-left:5px;"></td><td>&nbsp;<input type="button" value="Date Range Search" class="btn btn-primary" onclick="range_search()"/></td><td>&nbsp;&nbsp;</td>
        </tr>
        <tr><td colspan="8" style="height:25px;"></td></tr>
       
    </tbody></table>
    <br />
            <table id="listitemdata"  class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                <thead>
                    <tr>
                    <th>Sr.No.</th>
                      <th>Enquiry date</th>
                      <th>Student Name</th>
                      <th>Mobile</th>
                       <th>Student Email</th>
                       
                      <th>Reminder</th>
                      <th>Status</th>
                      <th>City</th>
                      <th>Ad Name</th>
                      <th>Ac_Year</th>
                      <th>Campaign Type</th>
                      <th>Is Organic</th>
                       <?php if($_SESSION['user_type']=='Admin')
					   {?><th>Edit</th>
                       <th>Delete</th>
                       <?php }?>
                       
                    </tr>
                </thead>
                <tbody>
                <?php
                    //get records from database
                    $query = mysql_query("SELECT * FROM fb_lead_data ORDER BY enquiry_date DESC");
					$count=mysql_num_rows($query);
                    if($count > 0){
						$i=1; 
                        while($row = mysql_fetch_array($query)){ ?>
                    <tr <?php if($i%2==0){?> style="background-color:#EFEFEF;" <?php }?>>
                      <td>
                       <?php if($_SESSION['user_type']=='Admin')
					   {?>
				<div class="checkbox">
          <label>
            <input type="checkbox" name="chkbox" value="<?php echo $row['id'];?>" id="<?php echo $row['id'];?>">
            <span class="cr"><i class="cr-icon glyphicon glyphicon-ok"></i></span>
             </label>
        </div><?php }?>
			<?php echo $i;$i++;?></td>
                      <td><?php  echo date("d-m-Y",strtotime($row['enquiry_date'])); ?></td>
                       <td><a href="std_follow_ups.php?id=<?php echo $row['id'];?>"><?php echo $row['student_name']; ?></a></td>
                       <td><?php echo $row['mobile_no']; ?></td>
                       <td><?php echo $row['student_email']; ?></td>
                        <td>
                         <?php $st=mysql_fetch_array(mysql_query("select * from fb_std_followups where std_id='".$row['id']."' order by id desc limit 1"));
						 //echo $st['date'].'hghghghg';
						 if($st['date']=='0000-00-00' or $st['date']=='')
					       {
						        echo '--';
					        }
					else{echo date('d-m-Y',strtotime($st['date']));
					}
					echo "&nbsp";
					if($st['time']=='00:00:00'){ echo "--";}else{echo $st['time'];}
						 
						 ?>
                        </td>
                        <td>
                       <?php
						if($st['status']=='')
						{
							echo 'NA';
						}
						else
						{
						echo $st['status'];
						}
						?>
                        </td>
                        <td><?php echo $row['city']; ?></td>
                      <td><?php echo $row['ad_name']; ?></td>
                      <td><?php echo $row['ac_year']; ?></td>
                      <td><?php echo $row['compain_type']; ?></td>
                      <td><?php echo $row['is_organic']; ?></td>
                      <?php if($_SESSION['user_type']=='Admin')
					   {?><td><a href="fb_lead_edit.php?edit_id=<?php echo $row['id'];?>">Edit</a></td>
                       <td><span id="<?php echo $row['id'];?>" onclick="del(this.id)" style="cursor:pointer">Delete</span></td>
                       <?php }?>
                        
                        
                    </tr>
                    <?php } }else{ ?>
                    <tr><td colspan="<?php if($_SESSION['user_type']=='Admin'){ echo '12';} else {echo '10';}?>">No Record found.....</td></tr>
                    <?php } ?>
                </tbody>
            </table>
            <script>
			var id=new Array();
			function toggle(source) {
    var checkboxes = document.querySelectorAll('input[type="checkbox"]');
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i] != source)
            checkboxes[i].checked = source.checked;
    }
}
function delete_all()
{
	var del_id = [];
   $('[name=chkbox]:checked').each(function() {
      del_id.push($(this).val());
   });
		if(del_id.length==0)
		{
			alert('No Row Selected To Perform Action');
		}
		else
		{
			var r = confirm("Do You Want To Remove Records!");
			var action="remove_all";
			if (r == true) {
	            $.ajax({
                type: "POST",
                url: "fb_lead_del.php",
                data: "id="+del_id+"&action="+action, 
                cache: false,
                success: function(data){
			    if(data!='')
                        {
						alert(data);
						location.reload();
						
						 
                        }		
 	                  }
                  });
   
} else {
   alert('Fine')
}

			
		}
}
			$(document).ready(function() {
      var table = $('#listitemdata').DataTable();
 
      // Add event listeners to the two range filtering inputs
      $('#min').keyup( function() { table.draw(); } );
      $('#max').keyup( function() { table.draw(); } );
	  
	  $.fn.dataTableExt.afnFiltering.push(
    function( oSettings, aData, iDataIndex ) {
        var iFini = document.getElementById('min').value;
        var iFfin = document.getElementById('max').value;
        var iStartDateCol = 1;
        var iEndDateCol = 1;
 
        iFini=iFini.substring(6,10) + iFini.substring(3,5)+ iFini.substring(0,2);
        iFfin=iFfin.substring(6,10) + iFfin.substring(3,5)+ iFfin.substring(0,2);
 
        var datofini=aData[iStartDateCol].substring(6,10) + aData[iStartDateCol].substring(3,5)+ aData[iStartDateCol].substring(0,2);
        var datoffin=aData[iEndDateCol].substring(6,10) + aData[iEndDateCol].substring(3,5)+ aData[iEndDateCol].substring(0,2);
 
        if ( iFini === "" && iFfin === "" )
        {
            return true;
        }
        else if ( iFini <= datofini && iFfin === "")
        {
            return true;
        }
        else if ( iFfin >= datoffin && iFini === "")
        {
            return true;
        }
        else if (iFini <= datofini && iFfin >= datoffin)
        {
            return true;
        }
        return false;
    }
);
	  
  } );

function range_search()
{
	var table = $('#listitemdata').DataTable();
	table.draw();
}
function del(v)
{
	var action="remove";
var r = confirm("Do You Want To Remove This Record!");
if (r == true) {
	            $.ajax({
                type: "POST",
                url: "fb_lead_del.php",
                data: "id="+v+"&action="+action, 
                cache: false,
                success: function(data){
			    if(data!='')
                        {
						alert(data);
						location.reload();
						
						 
                        }		
 	                  }
                  });
   
} else {
   alert('Fine')
}
	
}
</script>

<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.2/themes/smoothness/jquery-ui.css"/>
<script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script> 
<script>
$(function()
 {
                $("#min").datepicker({
                   
                    dateFormat: 'dd-mm-yy'
                         });
						  $("#max").datepicker({
                   
                    dateFormat: 'dd-mm-yy'
                         });
				               
            });

</script>        </div>
    </div>
</div>
</body>
</html>