<?php
session_start();
include("connection.php");
if (isset($_POST['submit5']))
{
$school=$_POST['stud_id'];
$emp=$_POST['emp'];


$insert_transfer = "INSERT INTO transferred_lead(stud_id, emp_from_id, emp_to_id, transfer_date, transferred_by_id) VALUES('$school', '".$_SESSION['emp_id']."','$emp' , now(), '".$_SESSION['emp_id']."')";


$res_transfer = mysql_query($insert_transfer) or die(mysql_error());


$sql="UPDATE student SET emp_id='$emp' where stud_id  ='".$_POST['stud_id']."'";
$result8=mysql_query($sql) or die(mysql_error());



$empid=$_SESSION['emp_id'];
$msg='You have been transfered a lead by '.$_SESSION['myusername'].' <a href="11.php?stud_id='.$school.'">Click here to see the Lead</a>';

if ($_SESSION['user_type']=="Project Manager")
{
header("Location:pmhome.php?msg1=Lead Transfer Successfully......");
}
else if ($_SESSION['user_type']=="Tele Caller")
{
header("Location:tchome.php?msg1=Lead Transfer Successfully......");
}

}
?>