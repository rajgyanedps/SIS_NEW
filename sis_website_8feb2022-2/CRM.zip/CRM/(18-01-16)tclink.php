<script type="text/javascript">
function MM_openBrWindow(theURL,winName,features) 
{ 
  window.open(theURL,winName,features);
}
</script>
<div id="topNav">
<ul>
<li><a href="tchome.php" <?php if($_SESSION['this_page']=='tchome.php')echo 'class="hover"'?>><b>Home</b></a></li>
<li><a href="addschool.php" <?php if($_SESSION['this_page']=='addschool.php')echo 'class="hover"'?>><b>Add Student</b></a></li>
<li><a href="walkins.php" <?php if($_SESSION['this_page']=='walkins.php')echo 'class="hover"'?>><b>Walkins</b></a></li>
<li><a href="todaytask.php" <?php if($_SESSION['this_page']=='todaytask.php')echo 'class="hover"'?>><b>Today Task</b></a></li>
<li><a href="monthlyreport.php?mod=Daily&date1=<?= date("Y-m-d")?>"<?php if($_SESSION['this_page']=='monthlyreport.php' && $_GET['mod']=='Daily')echo 'class="hover"'?>><b>Daily Report</b></a></li>
<li><a href="monthlyreport.php?mod=Monthly&month1=<?=date("m")?>"<?php if($_SESSION['this_page']=='monthlyreport.php' && $_GET['mod']=='Monthly')echo 'class="hover"'?>><b>Monthly Report</b></a></li>
<li><a href="usercallrecord.php"><b>Total Call Record</b></a></li>
<li><a href="#" onclick="MM_openBrWindow('userschoolreport.php?stat=Admission','Admission','toolbar=yes,location=yes,scrollbars=yes,resizable=yes,width=1050,height=700')"><b>Admission</b></a></li>
<li><a href="#" onclick="MM_openBrWindow('userschoolreport.php?stat=Paid','Paid','toolbar=yes,location=yes,scrollbars=yes,resizable=yes,width=1050,height=700')"><b>Paid</b></a></li>
<li><a href="#" onclick="MM_openBrWindow('userschoolreport.php?stat=Positive','Positive','toolbar=yes,location=yes,scrollbars=yes,resizable=yes,width=1050,height=700')"><b>+Ve</b></a></li>
<li><a href="#" onclick="MM_openBrWindow('userschoolreport.php?stat=Moderate','Moderate','toolbar=yes,location=yes,scrollbars=yes,resizable=yes,width=1050,height=700')"><b>Mod.</b></a></li>
<li><a href="#" onclick="MM_openBrWindow('userschoolreport.php?stat=Negative','Negative','toolbar=yes,location=yes,scrollbars=yes,resizable=yes,width=1050,height=700')"><b>-Ve</b></a></li>

<li><a href="#" onclick="MM_openBrWindow('userschoolreport.php?stat=NoContact','NoContact','toolbar=yes,location=yes,scrollbars=yes,resizable=yes,width=1050,height=700')"><b>No Contact</b></a></li>

<li><a href="#" onclick="MM_openBrWindow('userschoolreport.php?stat=Session2014-15','Session2014-15','toolbar=yes,location=yes,scrollbars=yes,resizable=yes,width=1050,height=700')"><b>Session(2014-15)</b></a></li>
<li><a href="#" onclick="MM_openBrWindow('userschoolreport.php?stat=Session2015-16','Session2015-16','toolbar=yes,location=yes,scrollbars=yes,resizable=yes,width=1050,height=700')"><b>Session(2015-16)</b></a></li>
<li><a href="taskuser.php" <?php if($_SESSION['this_page']=='taskuser.php')echo 'class="hover"'?>><b>My Tasks</b></a></li>
<li><a href="Logout.php"><b>Logout</b></a></li>
</ul>
</div>