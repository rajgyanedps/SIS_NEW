<?php
error_reporting(0);
ob_start();
session_start();
include("connection.php");

$memeberid=$_REQUEST['memeberid'];
$status=$_REQUEST['status'];
if($memeberid!=""){ 
  
  //echo "update payment set paymentstatus='$status' where memberid='".$memeberid."'";
  
 $query="update payment set paymentstatus='".$status."' where memberid='".$memeberid."'";
$q1=mysql_query($query);  
if($q1){
echo $msg=" Record Updated Succesfully";
}
    }


?>
