<?
session_start();
include("connection.php");
$sid = $_GET['stud_id'];echo"<br>";
if(isset($_GET['stud_id']))
{
$training_delete_query="DELETE FROM student WHERE stud_id = '$sid'";
$training_delete_row=mysql_query($training_delete_query) or die(mysql_error());
}
if($training_delete_row)
{
?>
<script type="text/javascript">
window.location="adminhome.php?stmsg=success";
</script>
<?
}
?>
