<?php
session_start();
error_reporting(0);
date_default_timezone_set('Asia/Calcutta');
include('functions.inc.php');
include("automatic.php");
include("connection.php");
include("upload_header.php"); 

				
if(isset($_POST['upload']))
{
include 'PHPExcel/Classes/PHPExcel/IOFactory.php';
 $file = $_FILES['upload_excel']['name'];
  $ext = pathinfo($file, PATHINFO_EXTENSION);
if($file=='')
{
	 $msg="Kindely Choose Excel File";
	 echo "<br>";
	 echo "<div style='color:#F00;width:100%; text-align:center;' align='center'>".$msg." !!</div>";
}

else if($ext!='xlsx')
{
	$msg="You are trying to upload incorrect file formate , valid File Formate is .xlsx";
	echo "<br>";
	 echo "<div style='color:#F00; width:100%; text-align:center;'>".$msg." !!</div>";
}
else
{
	$inputFileName = $_FILES['upload_excel']['tmp_name'];
	 try {
            $inputFileType = PHPExcel_IOFactory::identify($inputFileName); //Identify the file
            $objReader = PHPExcel_IOFactory::createReader($inputFileType); //Creating the reader
            $objPHPExcel = $objReader->load($inputFileName); //Loading the file
        }
		 catch (Exception $e)
		  {
            die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME) 
            . '": ' . $e->getMessage());
        }
                       $sheet = $objPHPExcel->getSheet(0); 
                       $allDataInSheet = $objPHPExcel->getActiveSheet()->toArray(null,true,true,true);
                       $arrayCount = count($allDataInSheet);  // Here get total count of row in that Excel sheet
                       for($i=2;$i<=$arrayCount;$i++)
					     {
                      $lead_date =explode("T",addslashes(trim($allDataInSheet[$i]["B"])));
					  $l_date=$lead_date[0];
					  $ad_name  = addslashes(trim($allDataInSheet[$i]["D"]));
					  //$is_organic = addslashes(trim($allDataInSheet[$i]["K"]));
					  $student_name = addslashes(trim($allDataInSheet[$i]["L"]));
					  $student_email = addslashes(trim($allDataInSheet[$i]["M"]));
					  $student_city  =addslashes(trim($allDataInSheet[$i]["N"]));
					  $student_mobile_no = explode("+",addslashes(trim($allDataInSheet[$i]["O"])));
					  $s_m_no=$student_mobile_no[1];
					  $uploaded_date=date('Y-m-d');
					  
					  if($lead_date!='')
					    {
							$import ="INSERT INTO `tbl_online_lead`
							(`lead_id`, `lead_date`, `ad_name`,`student_name`, `student_email`, `student_city`, `mobile_no`, `uploaded_date`)
							 VALUES ('','".$l_date."','".$ad_name."','".$student_name."','".$student_email."','".$student_city."','".$s_m_no."','".$uploaded_date."')";
							
						 
						  
		mysql_query($import) or die(mysql_error());
                             //$msg = 'Record has been added.';
                       
					 }
                          
				  }
				  $msg="Add Data Successfully";
				  echo "<br>";
	 echo "<div style='color:#060; width:100%; text-align:center;'>".$msg." !!</div>"; 
			          
                     




}
}
?>
<form name="upload" method="post" action="" enctype="multipart/form-data">
<br><br>
<table width="80%" align="center" border="0" style="border:#CCC solid 1px;border-radius:5px;border-collapse: collapse; background-color:#EFEFEF;">
<tr><td colspan="2">&nbsp;</td></tr>
<tr><td width="41%" align="center" style="font-size:14px;">Upload Excel:</td><td width="59%"><input type="file" name="upload_excel" ></td></tr>
<tr><td colspan="2">&nbsp;</td></tr>
<tr><td align="center" style="font-size:14px;">Excel Format:</td><td style="font-size:12px;"><a href="Sample Format.xlsx"><img src="image/excel.png" height="30" width="30"></a></td></tr>
<tr><td colspan="2">&nbsp;</td></tr>
<tr><td align="center" colspan="2"><input type="submit" name="upload" class="btn btn-primary" value="Upload" style="height:30px; width:140px; cursor:pointer;"></td></tr>
<tr><td colspan="2">&nbsp;</td></tr>
</table>
</form>