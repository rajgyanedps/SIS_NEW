<?php
session_start();
include('functions.inc.php');
include("connection.php");
if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='Project Manager' && $_SESSION['user_type']!='Tele Caller' && $_SESSION['temp_type']!='y'&& $_SESSION['user_type']!='vendor' )
{
  header("Location: index.php");
}
$_SESSION['this_page']='vendor_home.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Student Lead Data</title>
<script type="text/javascript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
.checkbox label:after, 
.radio label:after {
    content: '';
    display: table;
    clear: both;
}

.checkbox .cr,
.radio .cr {
    position: relative;
    display: inline-block;
    border: 1px solid #a9a9a9;
    border-radius: .25em;
    width: 1.3em;
    height: 1.3em;
    float: left;
    margin-right: .5em;
}

.radio .cr {
    border-radius: 50%;
}

.checkbox .cr .cr-icon,
.radio .cr .cr-icon {
    position: absolute;
    font-size: .8em;
    line-height: 0;
    top: 50%;
    left: 20%;
}

.radio .cr .cr-icon {
    margin-left: 0.04em;
}

.checkbox label input[type="checkbox"],
.radio label input[type="radio"] {
    display: none;
}

.checkbox label input[type="checkbox"] + .cr > .cr-icon,
.radio label input[type="radio"] + .cr > .cr-icon {
    transform: scale(3) rotateZ(-20deg);
    opacity: 0;
    transition: all .3s ease-in;
}

.checkbox label input[type="checkbox"]:checked + .cr > .cr-icon,
.radio label input[type="radio"]:checked + .cr > .cr-icon {
    transform: scale(1) rotateZ(0deg);
    opacity: 1;
}

.checkbox label input[type="checkbox"]:disabled + .cr,
.radio label input[type="radio"]:disabled + .cr {
    opacity: .5;
}
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php
include("header.php");
function coordinator_name($emp_id)
{
	$emp=mysql_fetch_array(mysql_query("select * from members where emp_id='".$emp_id."'"));
	return $emp['emp_name']; 
}
?>
<link href="https://cdn.datatables.net/1.10.15/css/dataTables.bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/responsive/2.1.1/css/responsive.bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script> 
<script src="https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js"></script> 
<script src="https://cdn.datatables.net/responsive/2.1.1/js/dataTables.responsive.min.js"></script> 
<script src="https://cdn.datatables.net/responsive/2.1.1/js/responsive.bootstrap.min.js"></script> 
<br />

<div class="container" >

    
    <div class="panel panel-default">
        
        <div class="panel-body" style="background-color:#EFEFEF; width:1175px; border:#CCC solid 1px;" >
            <div align="right"><a href="Logout.php" class="btn btn-primary btn-xs">Log Out</a></div>
            <!--<table border="0" cellspacing="5" cellpadding="5" align="center">
        <tbody><tr>
            <td>
  
</td><td>&nbsp;&nbsp;</td><td>From Date:&nbsp;</td>
            <td><input type="text" id="min" name="min" style="border-radius:5px; padding-left:5px;border:none;height:28px; border:#ccc solid 1px;"></td><td>&nbsp;To Date:&nbsp;</td>
            <td><input type="text" id="max" name="max" style="border-radius:5px;border:none;height:28px; border:#ccc solid 1px; padding-left:5px;"></td><td>&nbsp;<input type="button" value="Date Range Search" class="btn btn-primary btn-sm" onclick="range_search()"/></td><td>&nbsp;&nbsp;</td>
        </tr>
        <tr><td colspan="8" style="height:25px;"></td></tr>
       
    </tbody></table>-->
    <br />
            <table id="listitemdata"  class="table table-striped table-bordered  " cellspacing="0" width="100%" align="left" >
                <thead>
                    <tr>
                      <th>Sr.No.</th>
                      <th>Student Name</th>
                      <th>City</th>
                      <th>State</th>
                      <th>Phone No/Mobile No</th>
                      <th>Status</th>
                      <th>Information Source</th>
                      <th>Coordinator</th>
                      <th>Payment Status</th>
                      <th>Vistor Type</th>
                      <th>View Followups</th>
                      </tr>
                </thead>
                <tbody>
                <?php
                    //get records from database
$query = mysql_query("select * FROM  student   WHERE  date(joined)>='2018-08-08' and project_id!='5' order by joined desc");
					$count=mysql_num_rows($query);
                    if($count > 0){
						$i=1; 
                        while($row = mysql_fetch_array($query)){ ?>
                    <tr <?php if($i%2==0){?> style="background-color:#EFEFEF;" <?php }?>>
                      <td>
                      
			<?php echo $i;$i++;?></td>
                      
                       <td><?php echo $row['stud_name']; ?></td>
                       <td><?php echo $row['city']; ?></td>
                       <td><?php echo $row['state']; ?></td>
                       <td><?php echo $row['phone_code']." ".$row['phone_no'] ?><br />
                       <?php if($row['mobno']!='0') {echo $row['mobno'];} else {echo '-';}
	$check_status=mysql_query("select * from  ordermanagement where memberid='".$row['stud_id']."'");
			  $check_sta=mysql_fetch_array($check_status);
					   
					    ?>
                       </td>
                       <td><?php 
					   switch($row['status'])
					   {
						   case 'Positive':
						   echo 'Positive';
						   break;
						   case 'Not Intrested':
						   echo 'Not Interested';
						   break;
						   case 'Very Positive':
						   echo 'Very Positive';
						   break;
						   case 'Not Eligible':
						   echo 'Not Eligible';
						   break;
						   case 'Admission':
						   echo 'Admission';
						   break;
						   case 'Not Eligible':
						   echo 'Not Eligible';
						   break;
						   case 'Moderate':
						   echo 'Moderate';
						   break;
						   case 'Admission':
						   echo 'Admission';
						   break;
						   case 'NoContact';
						   echo 'No Contract';
						   break;
						   case 'Session2016-17':
						   echo 'Session 2016-2017';
						   break;
						   case 'Session2017-18':
						   echo 'Session 2017-2018';
						   break;
						   case 'Session2018-19':
						   echo 'Session 2018-2019';
						   break;
						   case 'Session2019-20':
						   echo 'Session 2019-2020';
						   break;
						   case 'Session2020-21':
						   echo 'Session 2020-2021';
						   break;
						   case 'NoContact':
						   echo 'No Contact';
						   break;
						 }
					if($row['status']=='Paid' and $check_sta['paymentstatus']=='Paid' )
					 {
						 echo 'Paid';
						 
                     }?>
			  </td>
                       <td><?php echo $row['information_source']; ?>
                       <?php if($row['referral']=='fb') echo " - FB";?><br />
                       <?php echo date('d-M-Y h:i:s A',strtotime($row['joined']));?>
                       </td>
                        <td>
                         <?php echo coordinator_name($row['emp_id']);?>
                        </td>
                       <td> <?php    
			
			//print_r($ress['payment']);die;
			 if($check_sta['paymentstatus']=='pending' ){ echo 'Pending';  }
			 
			 if($check_sta['paymentstatus']=='Paid'){echo 'Paid';} 
			
			 if($check_sta['paymentstatus']=='Underprocess'){ echo 'Underprocess';}
 			
			 if($check_sta['paymentstatus']=='Unsuccessful') { echo 'Unsuccessful';}
			
			 ?></td>
                      <td><?php if($row['PPC']!="" || $row['PKW']!="" || $row['PCA']!=""){echo "paid";}
                else{ echo "Organic";}?></td>
                      <td><span id="<?php echo $row['stud_id'];?>" onClick="call_followups(this.id)" style="cursor:pointer; color:#06F;  font-style:italic;" title="See Followups">View</span> </td>
                     
                      
                        
                        
                    </tr>
                    <?php } }else{ ?>
                    <tr><td colspan="<?php if($_SESSION['user_type']=='Admin'){ echo '12';} else {echo '10';}?>">No Record found.....</td></tr>
                    <?php } ?>
                </tbody>
            </table>
            <script>
			
			function call_followups(id)
			{
				testwindow = window.open("followup_window.php?f_id="+id, "Follow up window", "location=1,status=0,scrollbars=0,width=550,height=550");
    testwindow.moveTo(100,50);

			}
			
			var id=new Array();
			function toggle(source) {
    var checkboxes = document.querySelectorAll('input[type="checkbox"]');
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i] != source)
            checkboxes[i].checked = source.checked;
    }
}
function delete_all()
{
	var del_id = [];
   $('[name=chkbox]:checked').each(function() {
      del_id.push($(this).val());
   });
		if(del_id.length==0)
		{
			alert('No Row Selected To Perform Action');
		}
		else
		{
			var r = confirm("Do You Want To Remove Records!");
			var action="remove_all";
			if (r == true) {
	            $.ajax({
                type: "POST",
                url: "fb_lead_del.php",
                data: "id="+del_id+"&action="+action, 
                cache: false,
                success: function(data){
			    if(data!='')
                        {
						alert(data);
						location.reload();
						
						 
                        }		
 	                  }
                  });
   
} else {
   alert('Fine')
}

			
		}
}
			$(document).ready(function() {
      var table = $('#listitemdata').DataTable();
 
      // Add event listeners to the two range filtering inputs
      $('#min').keyup( function() { table.draw(); } );
      $('#max').keyup( function() { table.draw(); } );
	  
	  $.fn.dataTableExt.afnFiltering.push(
    function( oSettings, aData, iDataIndex ) {
        var iFini = document.getElementById('min').value;
        var iFfin = document.getElementById('max').value;
        var iStartDateCol = 1;
        var iEndDateCol = 1;
 
        iFini=iFini.substring(6,10) + iFini.substring(3,5)+ iFini.substring(0,2);
        iFfin=iFfin.substring(6,10) + iFfin.substring(3,5)+ iFfin.substring(0,2);
		
 
        var datofini=aData[iStartDateCol].substring(6,10) + aData[iStartDateCol].substring(3,5)+ aData[iStartDateCol].substring(0,2);
        var datoffin=aData[iEndDateCol].substring(6,10) + aData[iEndDateCol].substring(3,5)+ aData[iEndDateCol].substring(0,2);
 
        if ( iFini === "" && iFfin === "" )
        {
            return true;
        }
        else if ( iFini <= datofini && iFfin === "")
        {
            return true;
        }
        else if ( iFfin >= datoffin && iFini === "")
        {
            return true;
        }
        else if (iFini <= datofini && iFfin >= datoffin)
        {
            return true;
        }
        return false;
    }
);
	  
  } );

function range_search()
{
	var table = $('#listitemdata').DataTable();
	table.draw();
}

</script>

<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.2/themes/smoothness/jquery-ui.css"/>
<script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script> 
<script>
$(function()
 {
                $("#min").datepicker({
                   
                    dateFormat: 'dd-mm-yy'
                         });
						  $("#max").datepicker({
                   
                    dateFormat: 'dd-mm-yy'
                         });
				               
            });

</script>        </div>
    </div>
</div>
</body>
</html>