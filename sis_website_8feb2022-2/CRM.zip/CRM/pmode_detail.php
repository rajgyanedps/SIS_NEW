<? session_start();?>
<script type="text/javascript">
function valid()
    {
	
if(document.updatedd.DDnumber.value=='')
    {
	var strr = document.updatedd.head.value;
	alert("Please Fill the "+strr);
	document.updatedd.DDnumber.focus();
	return false;	
	}

if(document.updatedd.DDdate.value=='')
    {
	alert("Please Fill the  Date");
	document.updatedd.DDdate.focus();
	return false;	
	}

if(document.updatedd.Bankname.value=='')
    {
	alert("Please Fill the  Bank name");
	document.updatedd.Bankname.focus();
	return false;	
	}
if(document.updatedd.Bankbranch.value=='')
    {
	alert("Please Fill the  Bank branch");
	document.updatedd.Bankbranch.focus();
	return false;	
	}

	}
	
	

</script>
<?php
include("connection.php");

  $query =  mysql_query("select * from ordermanagement where memberid ='".$_GET['reg_id']."'");
  if(isset($_POST['update']))
   {
$update_sql="UPDATE ordermanagement SET  
											Paynumber           = '".$_POST['DDnumber']."',
											Paydate         	= '".$_POST['DDdate']."',
											Bankname       	    = '".$_POST['Bankname']."',
											Bankbranch          = '".$_POST['Bankbranch']."',
											paymentstatus  		= 'Paid',
											Paymode             = '".$_POST['paymode']."'
										    WHERE memberid      ='".$_GET['reg_id']."'";// echo $update_sql;die; 
											mysql_query($update_sql) or die(mysql_error());
											header('location:pmode_detail.php?success=1');
	  }
  
  ?>
  
<link rel="stylesheet" type="text/css" media="all" href="../iit-jee/calendar/calendar-blue.css" title="winter">
 <style type="text/css">
<!--
.paymentNo { font:normal 12px verdana; color:#333333;}
.paymentNo td { padding:2px 2px 2px 7px;}
.textnewF { border:1px solid #999; background:#fefbf3;}
-->
  </style>
<script type="text/javascript" src="../iit-jee/calendar/calendar.js"></script>
<script type="text/javascript" src="../iit-jee/calendar/calendar-en-us.js"></script>
<script type="text/javascript" src="../iit-jee/calendar/calendar-setup.js"></script>
<script type="text/javascript" language="javascript">
var popupCalendar = null;

function showCalendar(id, format, showsTime, showsOtherMonths) {
	var el = document.getElementById(id);
	if (popupCalendar != null) {
		popupCalendar.hide();
	} else {
		var cal = new Calendar(1, null, calSelected, calCloseHandler);
		if (typeof showsTime == "string") {
			cal.showsTime = true;
			cal.time24 = (showsTime == "24");
		}
		if (showsOtherMonths) {
			cal.showsOtherMonths = true;
		}
		popupCalendar = cal;
		cal.setRange(1900, 2070);
		cal.create();
	}
	popupCalendar.setDateFormat(format);
	popupCalendar.parseDate(el.value);
	popupCalendar.sel = el;
	popupCalendar.showAtElement(el, "Br");
	return false;
}

function calSelected(cal, date) {
	cal.sel.value = date;
	if (cal.dateClicked && (cal.sel.id == "opt_due"))
	cal.callCloseHandler();
}

function calCloseHandler(cal) {
	cal.hide();
	popupCalendar = null;
}


function showcon()
  {
 
    var ele = document.getElementById("orderdetails");
	var text = document.getElementById("paymode");
	
	if((text.value=='DD')||(text.value=='Cheque')||(text.value=='BankTransfer')) {
	ele.style.display = "block";
	document.getElementById("head").value = text.value+" "+'No.';
	
   }
   else {
   ele.style.display = "none";
   }
 }
</script>

  
  <?php 
  if($respose = mysql_fetch_array($query))
     {
	 $status      =   $respose['paymentstatus'];
	 $ddnum       =   $respose['Paynumber'];
	 $dddate      =   $respose['Paydate'];
	 $bankname    =   $respose['Bankname'];
	 $bankbranch  =   $respose['Bankbranch'];
	 $mode        =   $respose['Paymode'];
	 }



if(($status =='Paid')&&($ddnum =='')&&($dddate =='0000-00-00')&&($bankname =='')&&($bankbranch ==''))
       {   
  ?>
 
  <table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td bgcolor="#CCCCCC"><table width="100%" border="0" cellspacing="1" cellpadding="2" class="paymentNo">
      <tr>
        <td height="25" colspan="5" align="left" valign="middle" bgcolor="#F0F0F0"><strong>PAYMENT DETAILS:</strong></td>
        </tr>
      <tr>
        <td width="18%" height="25" align="left" valign="middle" bgcolor="#FFFFFF"><strong>Payment mode</strong></td>

      
        <td width="19%" height="25" align="left" valign="middle" bgcolor="#FFFFFF"><strong>Gateway</strong></td>
        <td width="18%" height="25" align="left" valign="middle" bgcolor="#FFFFFF"><strong>OrderNo</strong></td>
          <td width="27%" height="25" align="left" valign="middle" bgcolor="#FFFFFF"><strong>Registration Fee</strong></td>
        <td width="18%" height="25" align="left" valign="middle" bgcolor="#FFFFFF"><strong>Date</strong></td>
      </tr>
      <tr>
        <td height="25" align="left" valign="middle" bgcolor="#FFFFFF" >Online</td>
      
    
        <td align="left" valign="middle" bgcolor="#FFFFFF"  >CC Avenue</td>
        <td align="left" valign="middle" bgcolor="#FFFFFF"   ><?=$respose['ordercode']?></td>     
         <td align="left" valign="middle" bgcolor="#FFFFFF"  > 1000/-</td>
        <td align="left" valign="middle" bgcolor="#FFFFFF"  style="border-bottom:none;border-right:none; "><?=date("d-M-y",strtotime($respose['regidate']."+11 hours"))?></td>
      </tr>

    </table></td>
  </tr> </table>
 <? } elseif(($status =='Paid')&&($ddnum !='')&&($dddate !='0000-00-00')&&($bankname !='')&&($bankbranch !='')) {    ?>
 
<table width="100%" border="0" cellpadding="0" cellspacing="0">
   <tr>
    <td bgcolor="#CCCCCC"><table width="100%" border="0" cellspacing="1" cellpadding="0" class="paymentNo">
      <tr>
        <td height="25" colspan="6" align="left" valign="middle" bgcolor="#F0F0F0"><strong>PAYMENT DETAILS:</strong></td>
        </tr>
      <tr>
        <td width="18%" height="25" align="left" valign="middle" bgcolor="#FFFFFF" ><strong>Payment Mode</strong></td>
        <td width="18%" height="25" align="left" valign="middle" bgcolor="#FFFFFF" ><strong>
      
        <?php echo $mode.'Number';?>
        
        </strong></td>
        <td width="13%" height="25" align="left" valign="middle" bgcolor="#FFFFFF" ><strong>Date</strong></td>
        <td width="25%" height="25" align="left" valign="middle" bgcolor="#FFFFFF" ><strong>Registration Fee</strong></td>
        <td width="26%" height="25" align="left" valign="middle" bgcolor="#FFFFFF" ><strong>Bank Name</strong></td>
        <td width="18%" height="25" align="left" valign="middle" bgcolor="#FFFFFF" ><strong>Branch</strong></td>
      </tr>
      <tr>
         <td height="25" align="left" valign="middle" bgcolor="#FFFFFF"  ><?= $mode;?></td>
        <td height="25" align="left" valign="middle" bgcolor="#FFFFFF"  ><?= $ddnum;?></td>
        <td align="left" valign="middle" bgcolor="#FFFFFF"  ><?= date("d-M-y",strtotime($dddate."+11 hours"));?></td>
        <td align="left" valign="middle" bgcolor="#FFFFFF"  > 1000/-</td>
        <td align="left" valign="middle" bgcolor="#FFFFFF"  ><?= $bankname;?></td>
        <td align="left" valign="middle" bgcolor="#FFFFFF"   style="border-right:none; border-bottom:none;"><?= $bankbranch;?></td>
      </tr>

    </table></td>
  </tr></table> 
 
 <? } else {     ?>
 
 
 <tr>
        <td height="25" colspan="5" align="center" valign="middle" bgcolor="#FFFFFF"><strong><?php if(isset($_GET['success'])){ ?><font color="#009900"><strong>Record Update Successfuly</strong></font><? 
		
		
	echo '<script language="javascript">
		 parent.location.href="tchome.php?info_search=Registration&empid='.$_GET['empid'].'";
</script>
';	
		}
		
		
		?></strong></td>
        </tr>
  <form name="updatedd" method="post" action="" enctype="multipart/form-data" onsubmit="return valid(this);">
<table width="100%" cellspacing="10" > 
<tr>
        <td width="50%" align="right"><strong style="font:bold 14px verdana; color:#b30000">Select Payment Mode</strong></td>
      <td height="25" colspan="4" align="left" valign="middle" bgcolor="#FFFFFF"> 
      <select name="paymode" id="paymode" onchange="javascript:return showcon();">
      <option value="">--Select--</option>
      <option value="DD">By DD </option>
      <option value="Cheque">By Cheque </option>
      <option value="BankTransfer">By Bank Transfer </option>
      </select>      </td>
    </tr></table>
    <div id="orderdetails" style="display:none">
  <table width="100%" border="0" cellpadding="0" cellspacing="0" > 
   <tr>
    <td bgcolor="#ccc"><table width="100%" border="0" cellspacing="1" cellpadding="0" class="paymentNo">
      <tr>
        <td height="25" colspan="5" align="left" valign="middle" bgcolor="#F0F0F0"><strong>PAYMENT DETAILS:</strong></td>
        </tr>
     
      <tr>
        <td width="19%" height="25" align="left" valign="middle" bgcolor="#FFFFFF"><input type="text" name="head" id="head" value="" readonly="readonly"  style="border:hidden; " /></td>
        <td width="21%" height="25" align="left" valign="middle" bgcolor="#FFFFFF"><strong>Date</strong></td>
        <td width="22%" height="25" align="left" valign="middle" bgcolor="#FFFFFF"><strong>Registration Fee</strong></td>
        <td width="19%" height="25" align="left" valign="middle" bgcolor="#FFFFFF"><strong>Bank Name</strong></td>
        <td width="19%" height="25" align="left" valign="middle" bgcolor="#FFFFFF"><strong>Branch</strong></td>
      </tr>
    
      <tr>
        <td height="25" align="left" valign="middle" bgcolor="#FFFFFF"  >
        <input type="text" name="DDnumber" value="" class="textnewF"/>        </td>
        <td align="left" valign="middle" bgcolor="#FFFFFF"  >
        <input type="text" name="DDdate" id="DDdate" value="" readonly="readonly" class="textnewF"   />
        &nbsp;<img src="images/calendar.gif" width="16" height="15" align="absmiddle" style="cursor: pointer;" onclick="return showCalendar('DDdate','%Y-%m-%d');" />        </td>
        <td align="left" valign="middle" bgcolor="#FFFFFF"  > 1000/-</td>
        <td align="left" valign="middle" bgcolor="#FFFFFF"  >
         <input type="text" name="Bankname" value="" class="textnewF"/>        </td>
        <td align="left" valign="middle" bgcolor="#FFFFFF"   style="border-right:none; border-bottom:none;">
        <input type="text" name="Bankbranch" value="" class="textnewF" />        </td>
      </tr>
     
       <tr>
        <td height="35" align="center" valign="middle" bgcolor="#FFFFFF" colspan="5">
          <input type="submit" name="update" value="Update" style=" padding:4px 9px; font:bold 12px verdana;" />        </td>
      </tr>

    </table></td>
  </tr> </table>
  </div>
  </form>
 <? }?>