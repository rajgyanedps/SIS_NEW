<?php 
require_once('connection.php'); 
//$today = date("Y-m-d");
//$thisMonth=date("Y-m%");
//$time = time("H:i:s");
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=School_Status_Report.xls");
header("Pragma: no-cache");
header("Expires: 0");
$now=date("j-n-Y");
echo "\t \t Report ON ".$now."\t";

if(isset($_GET['emp_id']))
	  $sql_model = mysql_query("SELECT last_contact.school_id, last_contact.status, members.emp_id, addschool.school_id, addschool.school_name, addschool.add1,addschool.add2, addschool.city, addschool.phone_code, addschool.phone_no FROM last_contact, addschool, members WHERE emp_id ='".$_GET['emp_id']."' and last_contact.school_id >'".$_GET['emp_id']."' and last_contact.school_id <'".($_GET['emp_id'] + 100000)."' and last_contact.status='".$_GET['stat']."' and addschool.school_id=last_contact.school_id order by last_contact.school_id asc");
	   else
	   $sql_model = mysql_query("SELECT last_contact.school_id, last_contact.status, addschool.school_id, addschool.school_name, addschool.add1,addschool.add2, addschool.city, addschool.phone_code, addschool.phone_no FROM last_contact, addschool WHERE last_contact.status='".$_GET['stat']."' and addschool.school_id=last_contact.school_id order by last_contact.school_id asc");

print("\n");
print("\n");
	    echo "S.No."."\t";
		echo "School Id"."\t";
		echo "School Name"."\t";
		echo "Address 1"."\t";
		echo "Address 2"."\t";
		echo "City"."\t";
		echo "Phone No."."\t";
		print("\n"); 
		$i=1;
 while($row = mysql_fetch_array($sql_model))
    {
        echo $i."\t";
		echo $row['school_id']."\t";
		echo $row['school_name']."\t";
		echo $row['add1']."\t";
		echo $row['add2']."\t";
		echo $row['city']."\t";
		echo $row['phone_code'].", ".$row['phone_no']."\t";
		print "\n";
		$i+=1;		
    }

?>