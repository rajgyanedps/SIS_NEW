<?
session_start();
include("connection.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style>
.mheading{
font-size:12px;
font-family:Arial, Helvetica, sans-serif;
font-weight:bold;
padding:2px;
margin:0;
height:25px;
background-color:#CCCCCC;
}
</style>
<link rel="stylesheet" type="text/css" href="calendar-blue.css">
<script type="text/javascript" src="calendar.js"></script>
<script type="text/javascript" src="calendar-en.js"></script>
<script type="text/javascript" src="calendar-setup.js"></script>
<script language="javascript1.2" src="tabber.js"></script>

<script type="text/javascript">

function showhide(val)
{
if(val.value=='Other')
document.getElementById('divnb2').style.display='block';
else
document.getElementById('divnb2').style.display='none';
}
</script>
</head>
<?
if(isset($_POST['edit_followup']))
{

$sql="UPDATE addcontact SET name='".$_POST['name']."',status='".$_POST['status']."',remarkdate='".$_POST['remarkdate']."',remarktime='".$_POST['remarktime']."',followup='".$_POST['followup']."',other='".$_POST['other']."' WHERE contact_id='".$_POST['contact_id']."'";
$result=mysql_query($sql) or die(mysql_error());
?>
<script language="javascript">
 parent.location.reload();
 </script>
        <?

}
?>
<body style="font:Arial;">
<form name="edit_followup" action="" method="post"  onsubmit="return validate_followup();">
<table border="0" align="center" bgcolor="#f3f7fd" cellpadding="8" cellspacing="0" style="border:solid 1px #71befb;"> 
<tr>
  <td background="butbg.gif" height="10px" style="border-bottom:solid 1px #71befb; font-family:Arial; font-size:13px; color:#064582;">&nbsp;&nbsp;<b>Edit Followup</b></td>
</tr>
<?
$sql_cust = "SELECT * FROM addcontact WHERE contact_id='".$_GET['contact_id']."'";
$result = mysql_query($sql_cust);
$row = mysql_fetch_array($result);

?>

<tr><td>
<table width="95%" border="0" align="center" cellpadding="6" cellspacing="0" style="font-size:13px">

<tr>
      <input type="hidden" name="contact_id" value="<?=$row['contact_id']?>" />
      <td width="62">Person</td>
      <td width="3">:</td>
      <td width="355">
          <?
			$qq3=mysql_query("select * from addperson WHERE school_id='".$_GET['school_id']."' order by joined asc");
		?>
          <select name="name" id="name" style="height:20px; border:solid 1px #92cdfd;font-size:13px; width:100px; color:#0a5095;background-color:#ffffff;">
            <?
			    
				while($p3=mysql_fetch_object($qq3)){
				echo"<option value='".$p3->name."' ".($p3->name==$run['name']?'selected':'').">".$p3->surname."&nbsp;".$p3->name."</option>";
			}
			?>
          </select>
        &nbsp;<font color="#FF0000"><b>*</b></font></td>
    </tr>
    <tr>
      <td>Status</td>
      <td>:</td>
      <td><select name="status" style="height:20px; border:solid 1px #92cdfd;font-size:13px; width:100px; color:#0a5095;background-color:#ffffff;">
          <option value="">--Select--</option>
          <option value="Positive" <? if($row['status']=='Positive') echo "selected";?>>Positive</option>
          <option value="Negative" <? if($row['status']=='Negative') echo "selected";?>>Negative</option>
          <option value="Moderate" <? if($row['status']=='Moderate') echo "selected";?>>Moderate</option>
          <option value="Paid" <? if($row['status']=='Paid') echo "selected";?>>Paid</option>
        </select>
        &nbsp;<font color="#FF0000"><b>*</b></font></td>
    </tr>
    <tr>
      <td>Follow Up</td>
      <td>:</td>
      <td><select name="followup" onchange="showhide(this)" style="height:20px; border:solid 1px #92cdfd;font-size:13px; width:100px; color:#0a5095;background-color:#ffffff;">
          <option value="">--Select--</option>
          <option value="Call" <? if($row['followup']=='Call') echo "selected";?>>Call</option>
          <option value="Meeting" <? if($row['followup']=='Meeting') echo "selected";?>>Meeting</option>
          <option value="Send Brochure" <? if($row['followup']=='Send Brochure') echo "selected";?>>Send Brochure</option>
          <option value="Send Letter" <? if($row['followup']=='Send Letter') echo "selected";?>>Send Letter</option>
          <option value="Send Proposal" <? if($row['followup']=='Send Proposal') echo "selected";?>>Send Proposal</option>
          <option value="Other" <? if($row['followup']=='Other') echo "selected";?>>Other</option>
        </select>
         <input type="text" name="other" size="30" maxlength="2000"  id="divnb2" style="float:left;display:none;"/>
          <font color="#FF0000"><b> &nbsp;* </b></font>

       
       <? if($row['followup']=='Other')
	   {
	   ?>
          <input type="text" name="other" size="30" value="<?=$row['other']?>" maxlength="2000" id="divnb2" style="height:19px; width:194px; border:solid 1px #92cdfd;font-size:13px;color:#0a5095;background-color:#ffffff;"/>
          <font color="#FF0000"><b> &nbsp;* </b></font>
          <?
		  }
		  ?>
                    </td>
    </tr>

    <tr>
      <td>Date-Time</td>
      <td>:</td>
      <td><label>
        <input type="text" name="remarkdate" size="20" id="remarkdate" value="<?=$row['remarkdate']?>" readonly="readonly" style="height:19px; border:solid 1px #92cdfd;font-size:13px; color:#0a5095; width:100px; background-color:#ffffff;"/>
        <img src="CalendarIcon.gif" name="get_stud_date3" width="22" height="23" border="0" align="absmiddle" id="get_stud_date3" style="cursor: pointer;" title="Date selector" onmouseover="this.style.background='red';" onmouseout="this.style.background=''" />
        <script type="text/javascript">
	  	Calendar.setup({
        inputField     :    "remarkdate",     // id of the input field
	    //ifFormat       :    "%Y/%m/%d %l:%M %P",      // format of the input field
	  	//ifFormat       :    "%m-%d-%Y",      // format of the input field
	  	ifFormat       :    "%Y-%m-%d",      // format of the input field
        button         :    "get_stud_date3",  // trigger for the calendar (button ID)
        align          :    "Tl",           // alignment (defaults to "Bl")
        singleClick    :    true,
		showsTime		:	true
    });

        </script>
        </label>
        &nbsp;<font color="#FF0000"><b>*&nbsp;&nbsp;&nbsp;&nbsp;
          <input type="text" name="remarktime" value="<?=$row['remarktime']?>" size="20" style="height:19px; border:solid 1px #92cdfd;font-size:13px; color:#0a5095;background-color:#ffffff;"/>
          &nbsp;<font color="#FF0000"><b>*</b></font></b></font></td>
    </tr>
    <tr><td colspan="3">&nbsp;</td></tr>
    <tr>
     
      <td align="center" colspan="3"><font color="#FF0000">
        <input type="submit" name="edit_followup" value="Save" />
       </font>
              </td>
    </tr><tr><td colspan="4"></td></tr>
</table>
</td></tr></table>
    </form>

</body>
</html>
