<?php
session_start();
include("automatic.php");
include("connection.php");
if($_SESSION['user_type']!='Admin' && $_SESSION['user_type']!='Project Manager' && $_SESSION['user_type']!='Tele Caller' && $_SESSION['user_type']!='School Login')
//if (!isset($_SESSION[myusername]))
{
 header("Location: index.php");
}
?>
<?
$_SESSION['this_page']='walkins.php';

@extract($_GET);

if($expected_date!="")
{	
	$exp_date=date('Y-m-d',strtotime($expected_date));
	$KEYWORD_SEARCH_1=" and expected_date='$exp_date'"; 
}
else
{
	$KEYWORD_SEARCH_1="";
}

if($actual_date!="")
{	
	$act_date=date('Y-m-d',strtotime($actual_date));
	$KEYWORD_SEARCH_2=" and actual_date='$act_date'"; 
}
else
{
	$KEYWORD_SEARCH_2="";
}		


if($order_by!="")
{	
	$KEYWORD_SEARCH_5="ORDER BY $order_by $img_name"; 
}
else
{
	$KEYWORD_SEARCH_5="ORDER BY student.joined DESC, stud_id DESC";
}	




?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Expected Walkins</title>
<link rel="stylesheet" type="text/css" href="calendar-blue.css">
<script type="text/javascript" src="calendar.js"></script>
<script type="text/javascript" src="calendar-en.js"></script>
<script type="text/javascript" src="calendar-setup.js"></script>
<script language="javascript1.2" src="tabber.js"></script>
<link rel="stylesheet" type="text/css" href="jquery.fancybox/jquery.fancybox.css" media="screen" />
<script type="text/javascript" src="jquery.fancybox/jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="jquery.fancybox/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="jquery.fancybox/jquery.fancybox-1.2.1.pack.js"></script>
<script type="text/javascript">
	$(document).ready(function() {

					  $("a.walkin").fancybox({ 'hideOnContentClick': false ,
					  'overlayShow':true  ,
					  'frameWidth':360 ,
					  'frameHeight':270,
					  'overlayOpacity':0.7}); 


	});
		
	</script>
<script type="text/javascript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php
include("header.php");
?>
<div align="center" class="msg">
  <?=$_GET['msg1']; ?>
</div>
<div style="clear:both"></div>
<? 
$sql_cust10 = "SELECT * FROM task inner join members on members.emp_id=task.recipient_id WHERE recipient_id='".$_SESSION['emp_id']."' and status='Pending'";
	
$result10	= mysql_query($sql_cust10) or die(mysql_error());
		$num_rows10 = mysql_num_rows($result10);
		$res10=mysql_fetch_array($result10);
?>
<table align="center" width="100%">
  <tr>
    <td width="100%" height="291"><form action="walkins.php" method="get" name="walkin_search">
        <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#f3f7fd;border:solid 1px #88c9fd;">
          <tr>
            <td height="20" colspan="10" align="center" valign="middle" background="butbg.gif"><marquee behavior="slide" direction="left">
              <font size="4.5" face="Verdana, Arial, Helvetica, sans-serif"><b>Search Walkins</b></font>
              </marquee></td>
          </tr>
          <tr>
            <td width="6%" height="35" valign="middle" style="padding-left:15px"><b>Search By </b></td>
            <td width="1%" valign="middle"><b>:</b></td>
            <td width="7%" valign="middle"><b>Student Name</b></td>
            <td width="15%" valign="middle"><input type="text" name="schoolname1" value="<?=$_GET['schoolname1']?>" size="30" style="border:solid 1px #61b5f8;font-size:12px;width:145px; color:#0a5095;background-color:#ffffff;" /></td>
            <td width="8%" valign="middle"><b>Expected Date</b></td>
<td width="14%" valign="middle"><label>
                    <input type="text" name="expected_date" size="15" id="expected_date" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" />
                    <img src="CalendarIcon.gif" name="get_stud_date33" width="22" height="23" border="0" align="absmiddle" id="get_stud_date33" style="cursor: pointer;" title="Date selector" onmouseover="this.style.background='red';" onmouseout="this.style.background=''" />
                    <script type="text/javascript">
	  	Calendar.setup({
        inputField     :    "expected_date",     // id of the input field
	    //ifFormat       :    "%Y/%m/%d %l:%M %P",      // format of the input field
	  	//ifFormat       :    "%m-%d-%Y",      // format of the input field
	  	ifFormat       :    "%d-%m-%Y",      // format of the input field
        button         :    "get_stud_date33",  // trigger for the calendar (button ID)
        align          :    "Tl",           // alignment (defaults to "Bl")
        singleClick    :    true,
		showsTime		:	true
    });

        </script>
                    </label>
            &nbsp;</td>
            <td width="6%" valign="middle"><b>Actual  Date</b></td>
<td width="14%" valign="middle"><label>
                    <input type="text" name="actual_date" size="15" id="actual_date" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" />
                    <img src="CalendarIcon.gif" name="get_stud_date34" width="22" height="23" border="0" align="absmiddle" id="get_stud_date34" style="cursor: pointer;" title="Date selector" onmouseover="this.style.background='red';" onmouseout="this.style.background=''" />
                    <script type="text/javascript">
	  	Calendar.setup({
        inputField     :    "actual_date",     // id of the input field
	    //ifFormat       :    "%Y/%m/%d %l:%M %P",      // format of the input field
	  	//ifFormat       :    "%m-%d-%Y",      // format of the input field
	  	ifFormat       :    "%d-%m-%Y",      // format of the input field
        button         :    "get_stud_date34",  // trigger for the calendar (button ID)
        align          :    "Tl",           // alignment (defaults to "Bl")
        singleClick    :    true,
		showsTime		:	true
    });

        </script>
            </label></td>
            <td width="29%" valign="middle">&nbsp;<input type="submit" name="submit" value="Search" /></td></tr>
          <tr>
            <td colspan="5"></td>
          </tr>
          <tr>
            <td colspan="5"></td>
          </tr>
        </table>
        <br />
        <table align="center" width="100%">
          <tr>
            <td width="53%" valign="top"><table width="100%" border="0" align="center" cellpadding="5" cellspacing="1" bgcolor="#81cafd" style="font-size:13px">
                <tr bgcolor="#999999" align="center">
                  <td width="3%" height="25" align="left" background="footerbg.jpg" class="whitetxt11"><strong>S.No.</strong></td>
                  <td align="left" background="footerbg.jpg" class="whitetxt11" width="15%"><strong>Student Name&nbsp;</strong></td>
                  <td align="left" background="footerbg.jpg" class="whitetxt11" width="11%"><strong>City</strong></td>
                  <td width="13%" align="left" background="footerbg.jpg" class="whitetxt11"><strong>Expected Walkin Date</strong></td>
                  <td align="left" background="footerbg.jpg" class="whitetxt11" width="15%"><strong>Expected Walkin Time</strong> </td>
                  <td width="15%" align="left" background="footerbg.jpg" class="whitetxt11"><strong>Actual Walkin Date</strong></td>
                  <td width="17%" align="left" background="footerbg.jpg" class="whitetxt11"><strong>Actual Walkin Time</strong></td>
                  <? if($_SESSION['user_type']=='School Login') { ?>
                  <td width="11%" align="center" background="footerbg.jpg" class="whitetxt11"><strong>Edit</strong></td>
                  <? } ?>
                </tr>
                <?php
$sql_cust = "SELECT student.stud_id, student.stud_name,student.information_source, student.city, walkins.expected_date, walkins.expected_time, walkins.actual_date, walkins.actual_time, walkins.walkin_status FROM student inner join walkins ON student.stud_id=walkins.stud_id WHERE stud_name like '".trim($_GET['schoolname1'])."%' $KEYWORD_SEARCH_1 $KEYWORD_SEARCH_2 order by walkins.expected_date DESC";
$result	= mysql_query($sql_cust) or die(mysql_error());
$num_rows 	= mysql_num_rows($result);	
if($num_rows==0)
		{
		echo "<div align=center><font color=red size=+1>No Record Found</font></div>";
		}
		$incr = 1;
		
		if(!$_REQUEST['spageno']){
			$spageno = 1;
		} else {
			$spageno= $_REQUEST['spageno'];
		}
		$spagesize=50;
		$incr = (($spageno-1)*$spagesize)+1;
		$first=$spageno*$spagesize-($spagesize-1);
		$last=$first+$spagesize-1; 
		$temp=($num_rows%$spagesize);
		if ($temp==0)
		$spages=($num_rows/$spagesize);
		else
		$spages=($num_rows/$spagesize)+1;
		settype($spages, "integer"); 

		for($i=1;$i<$first;$i++)
			$row2000=mysql_fetch_row($result);
     
	 
//<?php
//$query="SELECT * FROM addschool";
//$result=mysql_query($query) or die(mysql_error());
while($res=mysql_fetch_array($result) and ($first<=$last))
{

if($i%2==0) {
	           $x = "bgcolor='#e9f5ff'";
	          } else {
	            $x = "bgcolor='#d8effe'";
 	          }
?>
                <tr <? if ((date("Y-M-d",strtotime($res['expected_date']))==date("Y-M-d",strtotime("+1 days")) || date("Y-M-d",strtotime($res['expected_date']))==date("Y-M-d")) and  $res['walkin_status']!=1)
 { echo 'bgcolor="#FFCCCC"'; } else { echo $x; } ?> align="left">
                  <td width="3%"><? echo $i;?>.</td>
                  <td width="15%"><?php echo $res['stud_name'];?></td>
                  <td width="11%"><?php echo $res['city'];?></td>
                  <td width="13%"><?php if($res['expected_date']!='0000-00-00') echo date('d-M-Y',strtotime($res['expected_date'])); else echo '-'; ?></td>
                  <td width="15%" ><?php echo $res['expected_time'];?></td>
                  <td width="15%"><?php if($res['actual_date']!='0000-00-00') echo date('d-M-Y',strtotime($res['actual_date'])); else echo '-'; ?></td>
                  <td width="17%"><?php echo $res['actual_time'];?></td>
                  <? if($_SESSION['user_type']=='School Login') { ?>
                  <td width="11%" align="center"><? if($res['walkin_status']==1){ ?>
                    <img src="images/tick_new.gif" width="14" height="14" border="0" />
                    <? } else { ?>
                    <a href="edit_walkins.php?stud_id=<?=$res['stud_id']?>" id="walkin" class="walkin iframe"><img src="images/edit.png" width="20" height="20" border="0" /></a>
                  <? } ?></td>
                  <? } ?>
                </tr>
                <? 
	 	  $incr++;
	$first++;	
  $i=$i+1;
  } 
	?>
              </table>
              <? if($num_rows > 0){	?>
              <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                <tr>
                  <td colspan="3"><img src="image/spacer.gif" height="3" /></td>
                </tr>
                <tr>
                  <td   height="26"  valign="middle" background="newbar.jpg" class="table_td_heading" style="padding-left:5px;" width="60%"><span class="table_td_heading">Pages:
                    <? if ($spageno==1) { ?>
                    &nbsp;
                    <? } else {?>
                    <a href="walkins.php?spageno=<?=$spageno-1?>&tpageno=<?=$_REQUEST['tpageno']?>&schoolname1=<?= $_GET['schoolname1'] ?>&expected_date=<?= $_GET['expected_date'] ?>&actual_date=<?= $_GET['actual_date'] ?>&keyword=<?=$_GET['keyword']?>&img_name=<?=$_GET['img_name']?>&order_by=<?=$_GET['order_by']?>" class="table_td_heading">Previous</a>
                    <? } 
					for ($i=1; $i<=$spages;$i++)
					{
					if($spageno==$i)	{?>
                    <strong class="table_td_heading"><? echo $i;?></strong>
                    <? }
						else
					{
					if($i%5==0)
{


					
					?>
                    <strong><a class="table_td_heading" href="walkins.php?spageno=<?=$i?>&tpageno=<?=$_REQUEST['tpageno']?>&schoolname1=<?= $_GET['schoolname1'] ?>&expected_date=<?= $_GET['expected_date'] ?>&actual_date=<?= $_GET['actual_date'] ?>&keyword=<?=$_GET['keyword']?>&info_search=<?= $_GET['info_search'] ?>&img_name=<?=$_GET['img_name']?>&order_by=<?=$_GET['order_by']?>">
                    <?=$i?>
                    </a></font></strong>
                    <? 
					}
					}
					}
					?>
                    <? if ($spageno<$spages) { ?>
                    <a href="walkins.php?spageno=<?=$spageno+1?>&tpageno=<?=$_REQUEST['tpageno']?>&schoolname1=<?= $_GET['schoolname1'] ?>&expected_date=<?= $_GET['expected_date'] ?>&actual_date=<?= $_GET['actual_date'] ?>&keyword=<?=$_GET['keyword']?>&img_name=<?=$_GET['img_name']?>&order_by=<?=$_GET['order_by']?>" class="table_td_heading">Next</a>
                    <? } else {?>
                    <? } ?>
                    </span></td>
                  <td width="10%" align="right" valign="middle" background="newbar.jpg" class="data"><!--DWLayoutEmptyCell-->&nbsp;</td>
                  <td width="30%" align="center" valign="middle" background="newbar.jpg" class="data"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td align="right" valign="middle" class="table_td_heading" style="padding-right:5px;" width="100%"><strong>Page</strong>&nbsp;
                          <?=$spageno?>
                          &nbsp;of&nbsp;
                          <?=$spages?>
                        </td>
                      </tr>
                    </table></td>
                </tr>
                <tr>
                  <td colspan="3">&nbsp;</td>
                </tr>
                <tr>
                  <td align="center" valign="middle" colspan="3"><input type="button" name="Back" value="  Back  " onclick="javascript:history.go(-1)" /></td>
                </tr>
              </table></td>
          </tr>
        </table>
        <table align="center" width="100%">
          <tr>
            <td class="footer" width="100%" >&copy; 2009 TeacherSITY. All rights reserved</td>
          </tr>
        </table>
        <? }?>
      </form></td>
  </tr>
</table>
</body>
</html>
