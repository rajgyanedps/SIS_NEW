<?php
include("connection.php");
session_start();
if (isset($_POST['submit']))
{

$sql="INSERT INTO addcontact(school_id,joined,surname,name,status,remarkdate,remarktime,followup,other,nextstep) VALUES ('".$_POST['school_id']."',now(),'".$_POST['surname']."','".$_POST['name']."','".$_POST['status']."','".$_POST['remarkdate']."','".$_POST['remarktime']."','".$_POST['followup']."','".$_POST['other']."','".$_POST['nextstep']."')";
$result=mysql_query($sql) or die(mysql_error());

$q="DELETE FROM last_contact WHERE school_id='".$_POST['school_id']."'";
$d=mysql_query($q) or die(mysql_error());

$a="INSERT INTO last_contact(school_id,joined,status,name,followup) VALUES ('".$_POST['school_id']."',now(),'".$_POST['status']."','".$_POST['name']."','".$_POST['followup']."')";
$x=mysql_query($a) or die(mysql_error());


if ($_SESSION['user_type']=="Project Manager")
{
header("Location: pmhome.php?msg=Contact Details Added Successfully......");
}
else if ($_SESSION['user_type']=="Tele Caller")
{
header("Location: tchome.php?msg=Contact Details Added Successfully......");
}
else
{
header("Location: adminhome.php?msg=Contact Details Added Successfully......");
}
}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Add Contact Details</title>
<link rel="stylesheet" type="text/css" href="calendar-blue.css">
<script type="text/javascript" src="calendar.js"></script>
<script type="text/javascript" src="calendar-en.js"></script>
<script type="text/javascript" src="calendar-setup.js"></script>
<script language="javascript1.2" src="tabber.js"></script>

<script type="text/javascript">
function showhide(val)
{
if(val.value=='Other')
document.getElementById('divnb').style.display='block';
else
document.getElementById('divnb').style.display='none';
}
</script>


<script type="text/javascript">
function ValidateForm()
{
// checking surname field
	  
	  if (document.contactdetails.surname.value=="")
	 {
		alert("The Surname is blank. \nPlease select the surname field in the combo box.");
        document.contactdetails.surname.focus();		
        return false;
      }		
// checking name field
      if (document.contactdetails.name.value=="")
	{
		alert("The Name field is blank. \nPlease enter name in the text box.");
		document.contactdetails.name.focus();
		return false;
      }	  	    
	  
//checking alphabetic values in name

    var iChars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ';
    for (i = 0; i < document.contactdetails.name.value.length; i++) {
      if (iChars.indexOf(document.contactdetails.name.value.charAt(i)) == -1) {
         alert('Please enter letters only in Name field');
         document.contactdetails.name.focus();
         return false;
      }
      }	
// checking status field	  
if (document.contactdetails.status.value=="")
	 {
		alert("The Status is blank. \nPlease select the status field in the combo box.");
        document.contactdetails.status.focus();		
        return false;
      }	
// checking followup field	  
if (document.contactdetails.followup.value=="")
	 {
		alert("The Followup is blank. \nPlease select the followup field in the combo box.");
        document.contactdetails.followup.focus();		
        return false;
      }		  
// checking other in followup (other)
    if (document.contactdetails.followup.value=="Other")
	   {
	   	  if (document.contactdetails.other.value=="")
	 {
		alert("The other field is blank. \nPlease enter the other followup field in the text box.");
        document.contactdetails.other.focus();		
        return false;
      }		
	  }	  
// checking remark date field
      if (document.contactdetails.remarkdate.value=="")
	{
		alert("The remark date field is blank. \nPlease enter remark date in the text box.");
		document.contactdetails.remarkdate.focus();
		return false;
      }	  	
// checking remark time field
      if (document.contactdetails.remarktime.value=="")
	{
		alert("The Remark time field is blank. \nPlease enter remark time in the text box.");
		document.contactdetails.remarktime.focus();
		return false;
      }	  	    	      	  
	  }
</script>
<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css" />
</head>

<body>
<?php
include("header.php");
?>
<br /><br /><br />
<form name="contactdetails" method="post" action="addcontact.php" onsubmit="return ValidateForm();">

<table width="457" border="0" align="center" bgcolor="#f3f7fd" cellpadding="8" cellspacing="0" style="border:solid 1px #71befb;"> 
<tr><td background="butbg.gif" height="10px" style="border-bottom:solid 1px #71befb; font-size:13px; color:#064582;">&nbsp;&nbsp;<b>Add Contact Details</b></td></tr>


<tr><td>
<table width="451" border="0" align="center" cellpadding="4" cellspacing="0" style="font-size:13px">

<tr><td colspan="3"></td></tr>
<tr>
<input type="hidden" name ="school_id" value="<?= $_GET['school_id']?>">
<td>Contact Person</td>
<td>:</td>
<td><select name="surname" style="height:20px; border:solid 1px #92cdfd;font-size:13px; color:#0a5095;background-color:#ffffff;">
<option value="">--Select--</option>
<option value="Mr.">Mr.</option>
<option value="Mrs.">Mrs.</option>
<option value="Miss">Miss</option>
<option value="Dr.">Dr.</option>
<option value="Col.">Col.</option>
<option value="Sis.">Sis.</option>
<option value="Fr.">Fr.</option>
</select>&nbsp;<font color="#FF0000"><b>*</b></font>
&nbsp;<input type="text" name="name" size="30" style="height:18px; border:solid 1px #92cdfd;font-size:13px; color:#0a5095;background-color:#ffffff;" />&nbsp;<font color="#FF0000"><b>*</b></font>
</td>
</tr>
<tr><td>Status</td>
<td>:</td>
<td><select name="status" style="height:20px; border:solid 1px #92cdfd;font-size:13px; color:#0a5095;background-color:#ffffff;">
<option value="">--Select--</option>
<option value="Positive">Positive</option>
<option value="Negative">Negative</option>
<option value="Moderate">Moderate</option>
</select>&nbsp;<font color="#FF0000"><b>*</b></font>
</td>
</tr>

<tr><td>Follow Up</td>
<td>:</td>
<td><select name="followup" onchange="showhide(this)" style="height:20px; border:solid 1px #92cdfd;font-size:13px; color:#0a5095;background-color:#ffffff;">
<option value="">--Select--</option>
<option value="Call">Call</option>
<option value="Meeting">Meeting</option>
<option value="Send Brochure">Send Brochure</option>
<option value="Send Letter">Send Letter</option>
<option value="Send Proposal">Send Proposal</option>
<option value="Other">Other</option>

</select>&nbsp;<font color="#FF0000"><b>*</b></font>
</td></tr>
<tr><td>If Other</td>
<td>:</td>
<td><div id="divnb" style="display:none"><input type="text" name="other" size="45" maxlength="20" />&nbsp;<font color="#FF0000"><b>*</b></font></div></td></tr>
<tr>
<td>Remarks Date</td>
<td>:</td>
<td><label>
<input type="text" name="remarkdate" size="45" id="remarks" onchange="setdt();" readonly="readonly"  style="height:18px; border:solid 1px #92cdfd;font-size:13px; color:#0a5095;background-color:#ffffff;" />
     <img src="CalendarIcon.gif" name="get_stud_date" width="22" height="23" border="0" align="absmiddle" id="get_stud_date" style="cursor: pointer;" title="Date selector" onmouseover="this.style.background='red';" onmouseout="this.style.background=''" />
        <script type="text/javascript">
	  	Calendar.setup({
        inputField     :    "remarks",     // id of the input field
	    //ifFormat       :    "%Y/%m/%d %l:%M %P",      // format of the input field
	  	//ifFormat       :    "%m-%d-%Y",      // format of the input field
	  	ifFormat       :    "%Y-%m-%d",      // format of the input field
        button         :    "get_stud_date",  // trigger for the calendar (button ID)
        align          :    "Tl",           // alignment (defaults to "Bl")
        singleClick    :    true,
		showsTime		:	true
    });

        </script>
        </label>      &nbsp;<font color="#FF0000"><b>*</b></font>  
</td></tr>
<tr>
<td>Remark Time</td>
<td>:</td>
<td><input type="text" name="remarktime" size="45"  style="height:18px; border:solid 1px #92cdfd;font-size:13px; color:#0a5095;background-color:#ffffff;" />&nbsp;<font color="#FF0000"><b>*</b></font></td></tr>

<tr><td>Next Step</td>
<td>:</td>
<td><input type="text" name="nextstep" size="45"  style="height:18px; border:solid 1px #92cdfd;font-size:13px; color:#0a5095;background-color:#ffffff;" /></td></tr>
<tr><td colspan="3"></td></tr>
<tr><td colspan="3"></td></tr><tr><td colspan="3"></td></tr>
<tr><td colspan="3" align="center"><input type="submit" name="submit" value="Submit" /></td></tr>

</table></td></tr></table>
<br /><br />
<table width="95%" border="0" align="center" cellpadding="5" cellspacing="0" style="font-size:13px">
<tr bgcolor="#999999" align="center">

      <td align="left" background="footerbg.jpg" class="whitetxt11" width="5%">S.No.</td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="20%">Date & Time</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="15%">Person</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="10%">Status</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="12%">Follow Up</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="13%">Followup Date</a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="12%">Followup Time </a></td>
      <td align="left" background="footerbg.jpg" class="whitetxt11" width="13%">Next Step</a></td>
    </tr>
<?php
$sql_cust = "SELECT * FROM addcontact WHERE school_id='".$_GET['school_id']."' order by joined asc";
$result = mysql_query($sql_cust);
$count = 0;
while($row = mysql_fetch_array($result))
{
	$count++;
?>
<tr>
        <td valign="top" width="5%"><? echo $count;?>.</td>
             <td width="20%"><?php echo $row['joined'];?></td>
                 <td width="15%"><?php echo $row['name'];?></td>
                     <td width="10%"><?php echo $row['status'];?></td>
                         <td width="12%"><?php echo $row['followup'];?></td>
                             <td width="13%"><?php echo $row['remarkdate'];?></td>
                                 <td width="12%"><?php echo $row['remarktime'];?></td>
                                     <td width="13%"><?php echo $row['nextstep'];?></td>
    </tr>
    <?
}
?>
</table>
</form>
</body>
</html>