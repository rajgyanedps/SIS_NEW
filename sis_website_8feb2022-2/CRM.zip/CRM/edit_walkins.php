<?php

include("connection.php");
session_start();
if (isset($_POST['submit']))
{

$actual_date = date('Y-m-d',strtotime($_POST['actual_date']));
$actual_time = $_POST['actual_time'];
  					
$sql="UPDATE walkins set actual_date='$actual_date', actual_time='$actual_time', walkin_status=1 WHERE stud_id='".$_GET['stud_id']."'";
$result=mysql_query($sql) or die(mysql_error());

?>
		<script language="javascript">
		 parent.location.reload();
		</script>
<?
}
$_SESSION['this_page']='walkins.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Edit Expected Walkins</title>

<link rel="stylesheet" type="text/css" href="calendar-blue.css">
<script type="text/javascript" src="calendar.js"></script>
<script type="text/javascript" src="calendar-en.js"></script>
<script type="text/javascript" src="calendar-setup.js"></script>
<script language="javascript1.2" src="tabber.js"></script>

<style type="text/css">
<!--
body {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	background-color: #FFFFFF;
	background-repeat: no-repeat;
}
a {
	color: #333333;
}
-->
</style>
<link href="msg.css" rel="stylesheet" type="text/css">
</head>
<body>



<table width="350" border="0" align="center" bgcolor="#f3f7fd" cellpadding="8" cellspacing="0" style="border:solid 1px #71befb; font-size:13px; color:#064582;">
  <tr>
    <td background="butbg.gif" height="10px">&nbsp;&nbsp;<b>Update  Walkin</b></td>
  </tr>
  <tr>
    <td><form name="upd_walkin" method="post" action="edit_walkins.php?stud_id=<?=$_GET['stud_id']?>" onsubmit="return ValidateForm();">
    
        <table width="100%" align="center" cellpadding="3" cellspacing="3" border="0" style="font-size:13px">
        <?
        	$sql_walkin = "Select * from walkins where stud_id='".$_GET['stud_id']."'";
			$res_walkin = mysql_query($sql_walkin) or die(mysql_error());
			$row_walkin = mysql_fetch_array($res_walkin);
		
		?>
        
          
            
          <tr>
            <td height="25"><strong>Expected Date</strong></td>
            <td>:</td>
            <td><strong><?=date('d-m-Y', strtotime($row_walkin['expected_date']))?></strong></td>
          </tr>
          <tr>
            <td height="25"><strong>Expected Time</strong></td>
            <td>:</td>
            <td><strong><?=$row_walkin['expected_time']?></strong></td>
          </tr>
          <tr>
            <td height="25"><strong>Actual Date</strong></td>
            <td>:</td>
            <td><label>
                    <input type="text" name="actual_date" size="20" id="actual_date" value="<?=date('d-m-Y', strtotime($row_walkin['expected_date']))?>" style="border:solid 1px #61b5f8; background-color:#FFFFFF;" />
                    <img src="CalendarIcon.gif" name="get_stud_date33" width="22" height="23" border="0" align="absmiddle" id="get_stud_date33" style="cursor: pointer;" title="Date selector" onmouseover="this.style.background='red';" onmouseout="this.style.background=''" />
                    <script type="text/javascript">
	  	Calendar.setup({
        inputField     :    "actual_date",     // id of the input field
	    //ifFormat       :    "%Y/%m/%d %l:%M %P",      // format of the input field
	  	//ifFormat       :    "%m-%d-%Y",      // format of the input field
	  	ifFormat       :    "%d-%m-%Y",      // format of the input field
        button         :    "get_stud_date33",  // trigger for the calendar (button ID)
        align          :    "Tl",           // alignment (defaults to "Bl")
        singleClick    :    true,
		showsTime		:	true
    });

        </script>
                    </label></td>
          </tr>
          <tr height="25">
            <td><strong>Actual Time</strong></td>
            <td>:</td>
            <td><input type="text" name="actual_time" id="actual_time" size="20" value="<?=$row_walkin['expected_time']?>"  style="border:solid 1px #61b5f8; background-color:#FFFFFF;" /></td>
          </tr>
          
                    
          <tr>
            <td colspan="3" align="center">&nbsp;</td>
          </tr>
          
          <tr>
            <td colspan="3" align="center">
            
            <input type="submit" name="submit" value="Submit" /></td>
          </tr>
          <tr>
            <td colspan="3" align="center">&nbsp;</td>
          </tr>
          
        </table>
      </form></td>
  </tr>
</table>
</body>
</html>
