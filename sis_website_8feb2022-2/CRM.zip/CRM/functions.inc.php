<?
//ob_start("ob_gzhandler");
$SCRIPT_START_TIME = getmicrotime();

error_reporting (E_ALL ^ E_NOTICE);
/*
$DB["host"]   = "localhost";
$DB["dbName"] = "test"; 
$DB["user"]   = "root";
$DB["pass"]   = "";


$SITE_TITLE="teachersity.org";	
$website_title="teachersity.org";
$admin_website_title="teachersity.org HR Site";

$ADMIN_EMAIL="admin@teachersity.org";
$INFO_EMAIL="info@teachersity.org";
$SITE_FS_PATH ="http://www.teachersity.org/hr";
$SITE_MAIN_URL ="http://www.teachersity.org";
//include ($SITE_FS_PATH."/includes/image_function.inc.php");
//include($ITE_FS_PATH."/includes/array.inc.php");



$link_db = mysql_connect($DB["host"],$DB["user"],$DB["pass"]) or die(mysql_error());
mysql_select_db($DB["dbName"]);
*/


function din_date_format($date, $seperator='/')
{
	$sql="select date_format('$date','%d-%b-%Y') " ;
	$res = 	getsingleresult($sql);
	return  $res;
}


function photo_date_format($date, $seperator='/')
{
	$sql="select date_format('$date','%m.%d.%y') " ;
	$res = 	getsingleresult($sql);
	return  $res;
}
/*
function date_format($date, $format='us', $seperator='-')
{
	if(strlen($date)>=10)
	{
		if(strtolower($format)=='us')
		{
			return substr($date,5,2).$seperator.substr($date,8,2).$seperator.substr($date,0,4);

		}
		else if(strtolower($format)=='eu')
		{
			return substr($date,8,2).$seperator.substr($date,5,2).$seperator.substr($date,0,4);
		}
	}
	else
	{
		return $s;
	}
}
*/
function datetime_format($date, $format = 'us', $seperator = '-')
{
	global $arr_month_short;
	if (strlen($date) >= 10){
		
		$hour=substr($date, 11, 2);
		if($hour >11){
			$ampm = "PM";
			$hour -= 12;
		}else{
			$ampm = "AM";
		}
		if($hour==0){
			$hour = 12;
		}
		$hour=str_pad($hour, 2, "0", STR_PAD_LEFT);
		if (strtolower($format) == 'us') {
			return $arr_month_short[substr($date, 5, 2)-1] . ' ' . substr($date, 8, 2) . ', ' . substr($date, 0, 4).' '.$hour.':'.substr($date, 14, 2). ' '.$ampm;
		} else if (strtolower($format) == 'eu') {
			return substr($date, 8, 2) . $seperator . substr($date, 5, 2) . $seperator . substr($date, 0, 4).' '.$hour.':'.substr($date, 14, 2). ' '.$ampm;
		} 
	} else {
		return $s;
	} 
}


function executeQuery($sql)
{
	$result = mysql_query($sql) or die(mysql_error(). " : ".$sql);
	return $result;
}

function getSingleResult($sql)
{
	$response="";	
	$result = mysql_query($sql) or die(mysql_error(). " : ".$sql);
	if($line=mysql_fetch_array($result))
	{
		$response=$line[0];
	}
	return $response;
}
function executeUpdate($sql)
{
	mysql_query($sql) or die(mysql_error(). " : ".$sql);
}
function adjustAfterDecimal($param)
{
	if(strpos($param,'.')== "")
	{
		$final_value=$param.".00";
		return  $final_value;
	}
	$after_decimal  = substr($param , strpos($param,'.')+1, strlen($param) );	
	$before_decimal = substr($param,0 ,  strpos($param,'.'));
	if(strlen($after_decimal)<2)
	{
		if(strlen($after_decimal)==1)
		{
			$final_value=$param."0";
		}
		if(strlen($after_decimal)==0)
		{
			$final_value.="$param.00";
		}
	}
	else
	{
		$trim_value = substr($after_decimal,0,2);
		$final_value.=$before_decimal.".".$trim_value;
	}
	return $final_value;
}

function decimal ($p )
{
	$i=strpos($p,".");
	if($i)
	{
		if(strlen(substr($p,$i+1))==1)
		$p.="0";
	}
	else
	{
		$p.=".00";
	}
	return  $p;
}


function ms_print_r($var)
{
	echo "<pre>";
	print_r($var);
	echo "</pre>";
} 

function getOrderID($last_id)
{
	$a= substr($last_id,3,strlen($last_id));
	$a= intval($a)+1;
	
	if($a<10)
	{
		$a="00".$a;
	}
	else if($a<=99)
	{
		$a="0".$a;
	}
	$new_order_id ="ORA".$a;
	return $new_order_id;
}
function qry_str($arr, $skip = '')
{
	$s = "?";
	$i = 0;
	foreach($arr as	$key =>	$value)	{
		if ($key !=	$skip) {
			if (is_array($value)) {
				foreach($value as $value2) {
					if ($i == 0) {
						$s .= $key . '[]=' . $value2;
						$i = 1;
					} else {
						$s .= '&' .	$key . '[]=' . $value2;
					}
				}

			} else {
				if ($i == 0) {
					$s .= "$key=$value";
					$i = 1;
				} else {
					$s .= "&$key=$value";
				}
			}
		}
	}
	return $s;
}

function refine_array(&$array)
{
	$refined_array= array();
	for($i=0;$i<count($array);$i++)
	{
		$element= $array[$i];
		if($element=="") 
		{
			 continue;
	 	}
		else
		{
			$refined_array[count($refined_array)]= $element;
		}
	}
	/////print_r($refined_array);
	$array = $refined_array;
}

function getmicrotime()
{ 
    list($usec, $sec) = explode(" ",microtime()); 
    return ((float)$usec + (float)$sec); 
} 

function get_qry_str($over_write_key, $over_write_value)
{
	global $_GET;
	$m = $_GET;
	if(is_array($over_write_key))	
	{
		$i=0;
		foreach($over_write_key as $key)
		{
			$m[$key] = $over_write_value[$i];
			$i++;
		}
	}
	else
	{
		$m[$over_write_key] = $over_write_value;
	}
	$qry_str = qry_str($m);
	return $qry_str;
} 






function swap (&$v, $i, $j) 
{
	$t = $v[$i];
	$v[$i] = $v[$j];
	$v[$j] = $t;
}
function perm (&$v, $n, $i) 
{
	if ($i == $n) 	
	{
		for ($j=0; $j<$n; $j++) echo($v[$j]);
		echo ("<br>");
	} 
	else
	{
		for ($j=$i; $j<$n; $j++) 
		{
			swap ($v, $i, $j);
			perm ($v, $n, $i+1);
			swap ($v, $i, $j);
		}
	}
}


function display_time($time)
{
$time=explode(":",$time);
$hour=$time[0];
$minute=$time[1];
$am_pm= "AM";

	if($hour > 12 )
	{
		$hour= $hour-12;
		$am_pm= "PM";
	}
	if($hour == 00)
	{
		$hour=12;
		$am_pm="AM";
	}
	if($hour == 12)
	{
		
		$am_pm="PM";
	}
$time=$hour.":".$minute." ".$am_pm;
	return $time;
}
function mm_dd_yy($date='')
{
	$sql=" select date_format('$date','%M-%d-%Y')";
	$res = getsingleresult($sql);
	return $res;
}
function  is_ext_ok($ext)
{
	$is_file_ok =	"no";	
	if($ext!='')
	{
		if($ext=="jpg" || $ext=="jpeg" || $ext=="gif" )
		{
			$is_file_ok	= "yes";
		}
	}
	return $is_file_ok;
}


function get_total_product_in_cart($cart)
{
	foreach($cart->cart  as $key => $item_object)
	{
		  ++$total_product_in_cart;
	}
	return $total_product_in_cart;
}

function get_month_name($month_number)
{	
	$arr_month[0]="January";
	$arr_month[1]="February";
	$arr_month[2]="March";
	$arr_month[3]="April";
	$arr_month[4]="May";
	$arr_month[5]="June";
	$arr_month[6]="July";
	$arr_month[7]="August";
	$arr_month[8]="September";
	$arr_month[9]="October";
	$arr_month[10]="November";
	$arr_month[11]="December";

	return $arr_month[$month_number-1];
}
  
function check_email($str)
{
	 //returns 1 if valid email, 0 if not

	 $paterrn= "^([-a-zA-Z0-9._]+@[-a-zA-Z0-9.]+(\.[-a-zA-Z0-9]+)+)*$";

	 if(ereg($paterrn, $str))
	  return 1;
	 else
	  return 0;
}

//	should allow  - , * # $ !  ? =  an any alpha numerics. 

function is_message_ok($x)
{

	for($j=0;$j<strlen($x);$j++)
	{ 
		$char= substr($x,$j,1);
		$char_code = ord($char);

//|| $char_code==39  -- apostrophe
//|| $char_code==33  -- exclamation		 

	   if(($char_code>=32 && $char_code<=90) ||($char_code>=97 && $char_code<=122) || ($char_code>=48 && $char_code<=57) || $char_code==42 ||  $char_code==44 || $char_code==45 ||$char_code==46 || $char_code==35 ||$char_code==36 ||$char_code==63 ||$char_code==61 || $char_code==10 || $char_code==13  || $char_code==34 ||$char_code==58 )
		{
			
		}
		else
		{
			//echo "This is the character error: " . $char_code;
			return "false";
			break;
		}
	}
}

function is_name_ok($x)
{
	for($j=0;$j<strlen($x);$j++)
	{ 
		$char= substr($x,$j,1);
		$char_code = ord($char);
		if(($char_code>=65 && $char_code<=90) || ($char_code>=97 && $char_code<=122) )
		{
		 
		}
		else
		{
		  return "false";
		  break;
		}
	}
}

function is_name_allowed_space($s)
{
	if(ereg ("^([a-zA-Z0-9_ ]+)$", $s)) 
	{
		return 1;
	}
	else 
	{
		return 0;
	}
}

function isAim($s)
{
////	echo "<br> isAim=($s)  <br>";

	if(ereg ("^([a-zA-Z0-9_]+)$", $s)) 
	{
		return 1;
	}
	else 
	{
		return 0;
	}
}

function isYahoo($s)
{
////	echo "<br> isYahoo= isYahoo()$s  <br>";
	if(ereg ("^([a-zA-Z0-9_]+)$", $s))
	{
		return 1;
	}
	else 
	{
		return 0;
	}
}

function isMSN($s)
{
////	echo "<br> isYahoo= isYahoo()$s  <br>";
	if(ereg ("^([a-zA-Z0-9_]+)$", $s)) 
	{
		return 1;
	}
	else 
	{
		return 0;
	}
}

function isPassword($s)
{
/////	echo "<br> isPassword=isPassword($s)  <br>";

	if(ereg ("^([a-zA-Z0-9]+)$", $s)) 
	{
		return 1;
	}
	else 
	{
		return 0;
	}
}

function isNumeric($s)
{
////	echo "<br> isNumeric($s)  <br>";

	if(ereg ("^([0-9]+)$", $s)) 
	{
		return 1;
	}
	else 
	{
		return 0;
	}
}
function isScreenName($s)
{
//	echo "<br> isScreenName($s)  <br>";

	if(ereg ("^([a-zA-Z0-9_]+)$", $s)) 
	{
		return 1;
	}
	else 
	{
		return 0;
	}
}
function isHomePage($s)
{
	if(ereg ("^([a-zA-Z0-9_:.&?/]+)$", $s)) 
	{
		return 1;
	}
	else 
	{
		return 0;
	}
}

function isturnoffons($s)
{
	$x=$s;
	for($j=0; $j<strlen($x); $j++)
	{ 
		$char_code= ord(substr($x,$j,1));
		 if(($char_code>=33 && $char_code<=90) ||($char_code>=97 && $char_code<=122) || ($char_code>=48 && $char_code<=57) || $char_code==42 ||  $char_code==44 || $char_code==45 ||$char_code==46 || $char_code==35 ||$char_code==36 ||$char_code==63 ||$char_code==61 || $char_code==10 || $char_code==13  || $char_code==34 ||$char_code==58 )

		{

		}else
		{
			return "1";
			break;
		}		
	}
}
function isAlphaNumeric($s)
{
	$x=$s;
	for($j=0; $j<strlen($x); $j++)
	{ 
		$char_code= ord(substr($x,$j,1));
		if($char_code==32 || ($char_code>=65 && $char_code<=90) || ($char_code>=97 && $char_code<=122) || ($char_code>=48 && $char_code<=58) || $char_code==95)
		{
		}
		else
		{
			return "1";
			break;
		}		
	}
}

function isCharacter($s)
{
	$x=$s;
	for($j=0; $j<strlen($x); $j++)
	{ 
		$char_code= ord(substr($x,$j,1));
		//echo "<br> char_code$char_code  <br>";

		if($char_code==32 || ($char_code>=65 && $char_code<=90) || ($char_code>=97 && $char_code<=122))
		{}
		else
		{
			return "0";
			break;
		}
	}
}

function isName($s)
{
	$x=$s;
	for($j=0; $j<strlen($x); $j++)
	{ 
		$char_code= ord(substr($x,$j,1));
		//echo "<br> char_code$char_code  <br>";

		if(($char_code>=65 && $char_code<=90) || ($char_code>=97 && $char_code<=122))
		{}
		else
		{
			return "0";
			break;
		}		
	}
}

 function  is_file_ok($file_name)
{
	$is_file_ok =	"no";
	$ext = strtolower(substr(strrchr($file_name,"."), 1));
	if($ext!='')
	{
		if($ext=="jpg" || $ext=="jpeg" || $ext=="gif" || $ext=="png" || $ext=="bmp")
		{
			$is_file_ok	= "yes";
		}
	}
	return $is_file_ok;
}



$request_uri = $_SERVER['REQUEST_URI'];
function is_login_file($request_uri,$compare_with)
{
	$aee = explode("/",$request_uri);		
	if(strpos($aee[count($aee)-1],"?")===false)
	{
		$length = strlen($aee[count($aee)-1]);				
	}
	else
	{			
		$length = strpos($aee[count($aee)-1],"?") ;
	}
	$substr = substr($aee[count($aee)-1],0,$length);

	if($substr==$compare_with )
	{
		return true;
	}
	else
	{
		return false;
	}
}


	
	function get_key_pos($find='',$unit_type_arr)
	{
		$k=0;
		if(is_array($unit_type_arr))
		{
			foreach($unit_type_arr as $kye=>$value)				
			{
				++$k;
				if($key==$find)
				{
					break;
				}
			}	
		}
		return $k;
	}	
	//print_r($unit_type_arr);
	//print_r($rooms);

function check_admin_login()
{	
	//echo "<br> $adminid <br>";
	$adminid = $_SESSION['id'];
	if($adminid!='')
	{	
	}
	else
	{		
		$msg = "Login to Access Admin Panel";
		$_SESSION['sess_msg'] = $msg ;
		header("Location:index.php");
		exit();	
	}
}

function check_user_login()
{	
	//echo "<br> $adminid <br>";
	$adminid = $_SESSION['id'];
	if($adminid!='')
	{	
	}
	else
	{		
		$msg = "Login to Acess Personal Area";
		$_SESSION['sess_msg'] = $msg ;
		header("Location:login.php");
		exit();	
	}
}

function check_login()
{	
	//echo "<br> $adminid <br>";
	
	$adminid = $_SESSION['id'];
	if($adminid!='')
	{
		$flg='yes';	
		return $flg;
	}
	else
	{		
		$flg='no';
		return $flg;
	}
}



function two_zero($price)
{
	if($price!=''){
		return number_format($price,'2','.','');
	}
}

function ms_redirect($file, $exit=true, $sess_msg='')
{
	header("Location: $file");
	exit();
}
function strip_slashes($param)
{
	return stripslashes($param);
} 

function add_slashes($param)
{
	$k_param = addslashes(stripslashes($param));
	return $k_param;
}	


function date_format_new($date, $format='us', $seperator='/')
{
	if(strlen($date)>=10)
	{
		if(strtolower($format)=='us')
		{
			return substr($date,5,2).$seperator.substr($date,8,2).$seperator.substr($date,0,4);

		}
		else if(strtolower($format)=='eu')
		{
			return substr($date,8,2).$seperator.substr($date,5,2).$seperator.substr($date,0,4);
		}
	}
	else
	{
		return $s;
	}
}

$service_cat_id = 126;

	
function sort_arrows($column)
{	
	$IMAHE="onMouseOut=MM_swapImgRestore() onMouseOver=MM_swapImage('desc','','images/asc1.gif',1)";
	return '<A HREF="'.$_SERVER['PHP_SELF'].get_qry_str(array('order_by','order_by2'), array($column,'desc')).'"><IMG SRC="images/asc.gif" width="9" height="9" BORDER="0"></A> <A HREF="'.$_SERVER['PHP_SELF'].get_qry_str(array('order_by','order_by2'), array($column,'asc')).'"><IMG SRC="images/dsc.gif" width="9" height="9" BORDER="0"></A>';
}

function sort_arrows_site($column,$asc_desc)
{	
	$asc_desc = strtolower($asc_desc);
	///$IMAHE="onMouseOut=MM_swapImgRestore() onMouseOver=MM_swapImage('asc','','../images/asc1.jpg',1)";
 if($asc_desc=="asc")
	{
			
		$asc_image = "asc.gif";
	}
	else
	{
		$asc_image = "asc1.gif";
	}

	////echo "<br>asc_image======== $asc_image <br>";

	if($asc_desc=="desc")
	{
		$dsc_image = "dsc.gif";
	}
	else
	{
		$dsc_image = "dsc1.gif";
	}
 
		
	$path="<A HREF=".$_SERVER['PHP_SELF'].get_qry_str(array('order_by','order_by2'), array($column,'desc'))."><IMG SRC=../images/".$asc_image." width=9 height=9 BORDER=0></A>&nbsp;";
	$path.="<A HREF=".$_SERVER['PHP_SELF'].get_qry_str(array('order_by','order_by2'), array($column,'asc'))."><IMG SRC=../images/".$dsc_image." width=9 height=9 BORDER=0></A>";
	return $path;
	
}





function sort_arrows_site1($column,$asc_desc)
{	
	$asc_desc = strtolower($asc_desc);
	///$IMAHE="onMouseOut=MM_swapImgRestore() onMouseOver=MM_swapImage('asc','','../images/asc1.jpg',1)";
 if($asc_desc=="desc")
	{
			
		$asc_image = "asc.gif";
	}
	else
	{
		$asc_image = "asc1.gif";
	}

	////echo "<br>asc_image======== $asc_image <br>";

	if($asc_desc=="asc")
	{
		$dsc_image = "dsc.gif";
	}
	else
	{
		$dsc_image = "dsc1.gif";
	}
 
	/////echo "<br>asc_image======== $asc_image <br>";
/*
	$asc_image = "asc.jpg";
	$dsc_image = "dsc.jpg";
	if(strtolower($asc_desc)=="asc" )
	{			
		$asc_image = "asc1.jpg";
	}
	else if(strtolower($asc_desc)=="desc")
	{
		$dsc_image = "dsc1.jpg";
	}*/
	
	$path="<A HREF=".$_SERVER['PHP_SELF'].get_qry_str(array('order_by','order_by2'), array($column,'asc'))."><IMG SRC=../images/".$asc_image." width=9 height=9 BORDER=0></A>&nbsp;";
	$path.="<A HREF=".$_SERVER['PHP_SELF'].get_qry_str(array('order_by','order_by2'), array($column,'desc'))."><IMG SRC=../images/".$dsc_image." width=9 height=9 BORDER=0></A>";
	return $path;
	
}

function sort_arrows_status($column)
{	
	$IMAHE="onMouseOut=MM_swapImgRestore() onMouseOver=MM_swapImage('desc','','../images/asc1.gif',1)";
	return '<A HREF="'.$_SERVER['PHP_SELF'].get_qry_str(array('order_by','order_by2'), array($column,'asc')).'"><IMG SRC="../images/asc.gif" width="9" height="9" BORDER="0"></A> <A HREF="'.$_SERVER['PHP_SELF'].get_qry_str(array('order_by','order_by2'), array($column,'desc')).'"><IMG SRC="../images/dsc.gif" width="9" height="9" BORDER="0"></A>';
}


function sort_arrows_shop($column)
{
	return '<A HREF="'.$_SERVER['PHP_SELF'].get_qry_str(array('order_by','order_by2'), array($column,'asc')).'"><IMG SRC="../../images/up_arrow.gif" WIDTH="9" HEIGHT="7" BORDER="0"></A> <A HREF="'.$_SERVER['PHP_SELF'].get_qry_str(array('order_by','order_by2'), array($column,'desc')).'"><IMG SRC="../../images/down_arrow.gif" WIDTH="9" HEIGHT="7" BORDER="0"></A>';
}


function country_combo($sel_country)
{
	$strCountry = "<select name='country'>";
	$strCountry .= "<option value=''>Select a Country</option>";
	$sql="select * from alg_country ";
	$result = executequery($sql);	
	while($line=mysql_fetch_array($result))
	{
		$country_name	= $line['country'];
		$id				= $line['country_id'];

	 $strCountry .= "<option value='$id'";
	 if($sel_country==$id) {
	 $strCountry .= " Selected ";
	 }
	 $strCountry .= ">$country_name</option>";
	}
	$strCountry .= "</select>";
	return $strCountry;
}


	function get_month_max_value($month,$year)
	{
		$month_arr["01"]  = "31";
		$month_arr["02"]  = "28";
		$month_arr["03"]  = "31";
		$month_arr["04"]  = "30";
		$month_arr["05"]  = "31";
		$month_arr["06"]  = "30";
		$month_arr["07"]  = "31";
		$month_arr["08"]  = "31";
		$month_arr["09"]  = "30";
		$month_arr["10"]  = "31";
		$month_arr["11"]  = "30";
		$month_arr["12"]  = "31";
			
		if($year%4==0 && $month=="02")
		{
			return 29;
		}
		else
		{
			return $month_arr[$month];
		}
	}


	function find_next_date($start_date,$end_date)
	{
	echo "<br> start_date --------- $start_date <br>";

	list($start_year,$start_month,$start_day)	=	split("-",$start_date);
	list($end_day,$end_month,$end_year)			=	split("-",$end_date);

	$start_day		=	$start_day;
	$start_month	=	$start_month;
	$start_year		=	$start_year;
	$end_day		=	$end_day;
	$end_month		=	$end_month;
	$end_year		=	$end_year;
		
		$max_day =	$end_day;
		while($start_year<=$end_year)
		{
			while($start_month<=$end_month)
			{				
				while($start_day<=$max_day)
				{
					if(++$start_day>=$max_day)
					{
						$start_month++;
						break;
					}
				}
				$start_month++;
				$max_day = get_month_max_value($start_month,$start_year);
			}
			$start_month=1;
			$start_year++;
		}
		$search_date=$start_year."-".$start_month."-".$start_day;
		echo "<br> Return search_date ---------------- $search_date <br>";
		return $search_date;
	}


function return_star($final_rating, $pre='')
{
	global $url_prefix2;
	//m_echo($final_rating,"final_rating");
	$star="";
	for($i=0;$i<=4;$i++){
		if(($final_rating-$i)>0.5){
			$star.="<img src='../images/".$pre."star.gif' border='0'>";
		}else if(($final_rating-$i)>0 && ($final_rating-$i)<=0.5){
			$star.="<img src='../images/".$pre."half_star.gif' border='0'>";
		}else{
			$star.="<img src='../images/star_white.gif' border='0'>";
		}
	}
	return $star;
}

function return_star_c($final_rating, $pre='')
{
	global $url_prefix2;
	//m_echo($final_rating,"final_rating");
	$star="";
	for($i=0;$i<=4;$i++){
		if(($final_rating-$i)>0.5){
			$star.="<img src='./images/".$pre."new_star.gif' border='0'>";
		}else if(($final_rating-$i)>0 && ($final_rating-$i)<=0.5){
			$star.="<img src='./images/".$pre."new_star_new.gif' border='0'>";
		}else{
			$star.="<img src='./images/new_star2.gif' border='0'>";
		}
	}
	return $star;
}


function return_star_admin($final_rating, $pre='')
{
	global $url_prefix2;
	//m_echo($final_rating,"final_rating");
	$star="";
	for($i=0;$i<=4;$i++){
		if(($final_rating-$i)>0.5){
			$star.="<img src='../images/".$pre."new_star.gif' border='0'>";
		}else if(($final_rating-$i)>0 && ($final_rating-$i)<=0.5){
			$star.="<img src='../images/".$pre."new_star_new.gif' border='0'>";
		}else{
			$star.="<img src='../images/new_star2.gif' border='0'>";
		}
	}
	return $star;
}

function uploadFile($PATH,$FILENAME,$FILEBOX)
{
	$file=$PATH.$FILENAME;
    $uploaded="TRUE";
	global $HTTP_POST_FILES;
    if (! @file_exists($file))
    {
		if ( isset( $HTTP_POST_FILES[$FILEBOX] ) )
        {
			if (is_uploaded_file($HTTP_POST_FILES[$FILEBOX]['tmp_name']))
            {
	            copy($HTTP_POST_FILES[$FILEBOX]['tmp_name'], $PATH.$FILENAME);
            }else{
				$uploaded="FALSE";
            }
        }
    } //end of if @fileexists
	return $uploaded;
}


function page_list($total_records,$page_name,$page_no,$no_of_records)
{
	GLOBAL $VROOT_DIR,$CURRENT_PAGE_LIST,$id;
	$page_no;
	if($no_of_records==""){
		$total_records=ceil($total_records/19);
	}else{
		$total_records=ceil($total_records/$no_of_records);
	}
	if($page_no==''){
		$page_no="1";
	}
	$prev_pageno=$page_no-1;
	$next_pageno=$page_no+1;
	///Prev Page Link
	if($page_no=="1"){
		$PREV_LINK="<span class='style1'>&laquo;&laquo;</span>&nbsp;previous 20&nbsp;&nbsp;<span class='style1'>&nbsp;&laquo;</span>&nbsp;previous&nbsp;&nbsp;&nbsp;";
	}else{
		$PREV_LINK="<span class='style1'>&laquo;&laquo;</span>&nbsp;<a href=\"$VROOT_DIR/$page_name.php?id=$id&page_no=$prev_pageno\" class='orange_txt'>&nbsp;previous 20</a>&nbsp;<span class='style1'>&nbsp;&laquo;</span><a href=\"$VROOT_DIR/$page_name.php?id=$id&page_no=$prev_pageno\" class='orange_txt'>&nbsp;previous</a>&nbsp;";
	}

	///End
	///Next Page Link
	if($total_records=="0")
		$total_records=1;
	if($total_records==$page_no){
		$NEXT_LINK="&nbsp;&nbsp;&nbsp;next&nbsp;<span class='style1'>&raquo;</span>&nbsp;&nbsp;
		next 20&nbsp;<span class='style1'>&raquo;&raquo;</span>
		";
	}else{
		$NEXT_LINK="&nbsp;&nbsp;&nbsp;<a href=\"$VROOT_DIR/$page_name.php?id=$id&page_no=$next_pageno\" class='orange_links'>next</a>&nbsp;<span class='style1'>&raquo;</span>&nbsp;&nbsp;
		<a href=\"$VROOT_DIR/$page_name.php?id=$id&page_no=$next_pageno\" class='orange_links'>next 20</a>&nbsp;<span class='style1'>&raquo;&raquo;</span>
		";
	}
	///End
	for($i=1;$i<=$total_records;$i++){
		if($total_records=="1"){
			$PAGE_LIST .="".$i." ";
		}else{
			if($i==$page_no){
				$PAGE_LIST .="<font class='white_txt'><b>".$i."&nbsp;<span class='style1'>&bull;</span><span class='style1'></span></b></font> ";
			}else{
				$PAGE_LIST .="<a href=\"$VROOT_DIR/$page_name.php?id=$id&page_no=$i\" class='orange_links'>".$i."</a>&nbsp;<span class='style1'>&bull;</span>&nbsp;";
			}
		}
	}
	$PAGE_LIST=$PREV_LINK.$PAGE_LIST.$NEXT_LINK;
	$CURRENT_PAGE_LIST = "[ Page $page_no of $total_records  &nbsp;";
	return $PAGE_LIST;
}



	function correctdate($date)
	{
		//////echo "<br> date =====$date <br>";	
		$date= 		stripslashes($date);
		if($date)
		{
			$dval=explode(" ",$date);
			/////echo "<br> dval[0]".$dval[0]." <br>";	
			list($year,$month,$day )=explode("-",$dval[0]);

			list($hour,$minute)=explode(":",$dval[1]);
			$ndate = "$month-$day-$year";//$hour:$minute
			return $ndate;
		}
	}

function din_date_format1($date, $seperator='/')
{
	 $sql="select date_format('$date','%m-%d-%Y') " ;
	$res = 	getsingleresult($sql);
	return  $res;
}


function din_date_format2($date, $seperator='/')
{
	 $sql="select date_format('$date','%b-%d-%Y') " ;
	$res = 	getsingleresult($sql);
	return  $res;
}

function din_date_form($date, $seperator='/')
{
	 $sql="select date_format('$date','%a, %b %D %Y') " ;
	$res = 	getsingleresult($sql);
	return  $res;
}

function midas_mail($recipiant,$subject,$content,$sender,$mail_type='plain',$cc='',$bcc='')
{
	include('class.Email.php');

	if(trim($sender)=='') $sender="$ADMIN_EMAIL";

	$msg = new Email($recipiant, $sender, $subject);
	$msg->Cc = $cc;
	$msg->Bcc = $bcc;
	$msg->Content = $content;

	if($mail_type=='plain')
	{
		$msg->TextOnly = true;
		$sendsuccess = $msg->Send();
	}
	elseif($mail_type=='html')
	{
		$msg->TextOnly = false;
		//echo "<br>  inside  mail_type====$mail_type <br>";
		$sendsuccess = $msg->Send();
		//$msg->Attach(__FILE__, "text/plain");
	}
	return $sendsuccess;
}

function format_db_value($text,	$nl2br = false)
{
	if (is_array($text)) {
		$tmp_array = Array();
		foreach($text as $key => $value) {
			$tmp_array[$key] = format_db_value($value);
		}
		return $tmp_array;
	} else {
		$text =	htmlspecialchars(stripslashes($text));
		if ($nl2br)	{
			return nl2br($text);
		} else {
			return $text;
		}
	}
}

function mwt_mail($to, $subject, $message, $str_headers = '') {
	$sendmail = sprintf("/usr/sbin/sendmail -i -t DeliveryMode=d -O ", $this->Sendmail);
	//$body ="<b> ietr ewt ewt  </b>";

	if(!@$mail = popen($sendmail, "w"))
	{
		$this->SetError($this->Lang("execute") . $this->Sendmail);
		return false;
	}
	$header ="To: $to\n";
	$header .="Subject: $subject  $i\n";
	if($str_headers =='') {
		$header .= "Content-type: text/plain; charset=iso-8859-1\n"; 
	} else{
		$header .= $str_headers;
	}
	fputs($mail, $header);
	fputs($mail, $message);
	$resp = pclose($mail) >> 8 & 0xFF;

}

function random_string($length) {
	// if you want extended ascii, then add the characters to the array
	$characters = array('0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');
	$random_str = "";
	for ($i = 0; $i < $length; $i++) {
		srand((double)microtime()*1000000);
		$random_chr = round(rand(0, count($characters)-1));
		$random_str .= $characters[$random_chr];
	}
	return ($random_str);
}

function mm_dd_yy_date($date='')
{
	$sql=" select date_format('$date','%d-%M-%Y')";
	$res = getsingleresult($sql);
	return $res;
}

function sort_arrows_one_image($column)
{	
	$order_by1 = $_REQUEST['order_by2'];
	if($order_by1 == 'desc')
	{
		$IMAHE="onMouseOut=MM_swapImgRestore() onMouseOver=MM_swapImage('desc','','images/asc1.gif',1)";
		return '<A HREF="'.$_SERVER['PHP_SELF'].get_qry_str(array('order_by','order_by2'), array($column,'asc')).'"><IMG SRC="image/asc.gif"  BORDER="0"></A>';
	}
	elseif($order_by1 == 'asc')
	{
		$IMAHE="onMouseOut=MM_swapImgRestore() onMouseOver=MM_swapImage('desc','','images/asc1.gif',1)";
		return '<A HREF="'.$_SERVER['PHP_SELF'].get_qry_str(array('order_by','order_by2'), array($column,'desc')).'"><IMG SRC="image/dsc.gif"  BORDER="0"></A>';
	}
	else
	{
		$IMAHE="onMouseOut=MM_swapImgRestore() onMouseOver=MM_swapImage('desc','','images/asc1.gif',1)";
		return '<A HREF="'.$_SERVER['PHP_SELF'].get_qry_str(array('order_by','order_by2'), array($column,'asc')).'"><IMG SRC="image/asc.gif"  BORDER="0"></A>';
	}
	
	
}


?>