<?php session_start();
 $connection =  mysql_connect("localhost","principa_teacher","principa_teacher");
 $Db = mysql_select_db('principa_teacher',$connection);
 
 //$connection =  mysql_connect("localhost","root","");
// $Db = mysql_select_db('principals',$connection);
include("../ccavenue/libfuncs.php3");

if(count($_POST)>0)
{
	  $code    = $_POST['ordercodeforreg']; ;
	  $Amount = 7500;
	 //$Amount = 10;
	  $sum = number_format($Amount,2,".","");
	  $bcname       =   $_REQUEST['pay_name'];
	  $bcaddress    =   $_REQUEST['pay_address'];
	  $bccountry    =   $_REQUEST['pay_country'];
	  $bcphone      =   $_REQUEST['pay_phone'];
	  $bcmail       =   $_REQUEST['pay_email'];
	
	  $billing_cust_name       = $_REQUEST['billing_cust_name'];
	  $billing_cust_address    = $_REQUEST['billing_cust_address'];
	  $billing_cust_country    = $_REQUEST['billing_cust_country'];
	  $billing_cust_state      = $_REQUEST['billing_cust_state'];
	  $billing_cust_city       = $_REQUEST['billing_cust_city'];
	  $billing_zip             = $_REQUEST['billing_zip'];
	  $billing_cust_tel        = $_REQUEST['billing_cust_tel'];
	  $billing_cust_email      = $_REQUEST['billing_cust_email'];
	
	  $delivery_cust_name      = $_REQUEST['delivery_cust_name'];
	  $delivery_cust_address   = $_REQUEST['delivery_cust_address'];
	  $delivery_cust_country   = $_REQUEST['delivery_cust_country'];
	  $delivery_cust_state     = $_REQUEST['delivery_cust_state'];
  	  $delivery_cust_tel       = $_REQUEST['delivery_cust_tel'];
	  $delivery_cust_notes     = $_REQUEST['delivery_cust_notes'];
	
	 $Merchant_Param          = $_REQUEST['Merchant_Param'];
	 $billing_zip_code        = $_REQUEST['billing_zip_code'];
	 $delivery_cust_city      = $_REQUEST['delivery_cust_city'];
	 $delivery_zip_code       = $_REQUEST['delivery_zip_code'];
	 
	  
    $passstring = "?Order_Id=".$code."&Amount=".$sum."&billing_cust_name=".$billing_cust_name."&billing_cust_address=".$billing_cust_address."&billing_cust_country=".                   $billing_cust_country."&billing_cust_state=".$billing_cust_state."&billing_cust_city=".$billing_cust_city."&billing_zip=".$billing_zip;
	$passstring .= "&billing_cust_tel=".$billing_cust_tel."&billing_cust_email=".$billing_cust_email;
	$passstring .= "&Currency=USD&TxnType=A&actionID=TXN&Merchant_Id=M_mrn19886_19886";
    $passstring .= "&delivery_cust_name=".$delivery_cust_name."&delivery_cust_address=".$delivery_cust_address."&delivery_cust_tel=".$delivery_cust_tel."&delivery_cust_country=".                    $delivery_cust_country."&delivery_cust_state=".$delivery_cust_state."&delivery_cust_notes=".$delivery_cust_notes."&delivery_cust_city=".$delivery_cust_city;
   
    $Merchant_Id = "M_mrn19886_19886"; // Tesi
	$Order_Id = $code;
	
	$Redirect_Url="http://www.selaqui.org/iit-jee/principals/thanks.php" ;
	$WorkingKey = "saeqtmi7tvwsm6raqr"  ;
	
	$Checksum = getCheckSum($Merchant_Id,$sum,$Order_Id ,$Redirect_Url,$WorkingKey);
	
	$ccavenue = "https://www.ccavenue.com/shopzone/cc_details.jsp";
	$passstring .="&Checksum=".$Checksum;
	$passstring .="&Redirect_Url=".$Redirect_Url;
	$redirect_page = $ccavenue.$passstring;
	print_r($passstring);die;
echo "<script>window.location.href='$redirect_page'</script>";	
}
?>
