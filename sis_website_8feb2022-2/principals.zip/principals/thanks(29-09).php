<? require("../ccavenue/libfuncs.php3");
 $connection =  mysql_connect("localhost","principa_teacher","principa_teacher");
 $Db = mysql_select_db('principa_teacher',$connection);
  
//$DB["host"]   = "localhost";
//$DB["dbName"] = "principa_teacher"; 
//$DB["user"]   = "principa_teacher";
//$DB["pass"]   = "principa_teacher";

  
  
	$WorkingKey = "saeqtmi7tvwsm6raqr" ; 
	$Merchant_Id= $_REQUEST['Merchant_Id'];
	$Amount= $_REQUEST['Amount'];
	$Order_Id= $_REQUEST['Order_Id'];
	$Merchant_Param= $_REQUEST['Merchant_Param'];
	$Checksum= $_REQUEST['Checksum'];
	$AuthDesc=$_REQUEST['AuthDesc'];
    $Checksum = verifyChecksum($Merchant_Id, $Order_Id , $Amount,$AuthDesc,$Checksum,$WorkingKey);
    // $Checksum =true;
	// $AuthDesc="N";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Principals.in</title>
<link href="css/default.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Bitter|Supermercado+One|Salsa' rel='stylesheet' type='text/css'>
</head>
<body>
<div id="container">
 <div id="topMenu" align="center">
  <div id="topbanner" style="width:999px; margin:0 auto;">
    <div align="center"><img src="header.png" /></div>
  </div>
  
  <div id="midCotainer" align="center" style="background-image:none; width:999px; margin:0px auto;>
  <div style="margin:0 auto; width:700px;">
  
<?php
$orderqry="select user_id,title,name,midname,surname,mobile_no,Email from teacher_profile  where user_id  =(SELECT memberid FROM ordermanagement WHERE ordercode = '".$Order_Id."')"; 
$orderres=mysql_query($orderqry,$Db) or die(mysql_error());
$orderrow=mysql_fetch_array($orderres);
$name=$orderrow['title'].' '.$orderrow['name'].' '.$orderrow['midname'].' '.$orderrow['surname'];
$regno=$orderrow['user_id'];
$curdate=date("d-m-Y", strtotime(date("d-m-Y")));
$mobno=$orderrow['mobile_no'];
if($Checksum=="true" && $AuthDesc=="Y")
   	   {
			 mysql_query("update ordermanagement set paymentstatus = 'Paid' where ordercode = '".$Order_Id."'"); ?>	
             <div id="msgBlack" style=" background:#cccccc;">Transaction Successful!!!<br />Thank You. <br /><br /><br /><br /></div>
                <?
			   $email=$orderrow['Email'];
			   $subject = "Congratulations! Your Registration Has Been Completed Successfully With Principals.in";
			   $txt ='<font family="Calibri,Tahoma,Arial, Helvetica, sans-serif" >
						<table width="700" border="0">
						<tr><td ><p>Dear <strong>'.$name.'</strong>,</p>
						<p>Thank you for your registration from <strong>http://www.Principals.in</strong><br><br>
						Your registration fees has been received. We will be sending you other details after processing of your application.<br><br />
						If you have a question about your Application status, you can contact the counselor directly by 
						e-mail at :  <strong>ncsp@principals.in</strong><br /><br /></p>
						<strong>Registration Details:</strong>
                        </td></tr>
						<tr><td>
						<table width="700" border="1">
						<tr><td><strong>Registration Number:000'.$regno.'</strong></td><td><strong>Fee Received:</strong> '.$curdate.'</td></tr>
						<tr><td colspan="2"><strong>Total Amount :</strong> INR (Indian Rupees) 6000.00</td></tr>
						<tr><td colspan="2"><strong>Student&acute;s Name:</strong> '.$name.'<br /><br />
						<strong>Billing Address :</strong><br />315 / 274, Western Marg,<br />
						Saidulajab
						New Delhi -110 030,<br />
						INDIA<br /><br />
						<strong>Phone Number :</strong> '.$mobno.'<br /><br />
						<strong>E-mail ID :</strong> '.$email.'<br /><br /><br />
						Regards,<br />
						<strong>Team
						Principals.in </strong>
						</td></tr>
						</table>
						</td></tr>
						</table>
						</font>';
						
			   $bcc = "ncsp@principals.in";
			   
			   $headers  = 'MIME-Version: 1.0' . "\r\n";
			   $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
			   $headers .= 'Bcc: $bcc' . "\r\n";
			   $headers .= "From: noreply@selaqui.org". "\r\n";
			   $headers .= "Return-Path: <noreply@principals.in>". "";
			   mail($email,$subject,$txt,$headers);
			   
			   
			   } else if($Checksum=="true" && $AuthDesc=="B"){
			   mysql_query("update ordermanagement set paymentstatus = 'Underprocess'  where ordercode = '".$Order_Id."'"); ?>
			   <div id="msgRed" style=" background:#cccccc;">Transaction In Process!!! We will contact you soon... <br /><br /><br /><br /></div>
			   <?php } else if($Checksum=="true" && $AuthDesc=="N"){
			   mysql_query("update ordermanagement set paymentstatus = 'Unsuccessful'  where ordercode = '".$Order_Id."'"); ?>
			   <div id="msgRed" style=" background:#cccccc;">Transaction Unsuccessful!!! Please Try Again... <br /><br /><br /><br /></div>
			   <?php }  else {
			   echo "<br>Security Error. Illegal access detected";
			   }
?>
</div></div></div>
</div>
</body></html>