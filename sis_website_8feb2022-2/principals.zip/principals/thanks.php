<? require("../ccavenue/libfuncs.php3");
 $connection =  mysql_connect("localhost","principa_teacher","principa_teacher");
 $Db = mysql_select_db('principa_teacher',$connection);
  
//$DB["host"]   = "localhost";
//$DB["dbName"] = "principa_teacher"; 
//$DB["user"]   = "principa_teacher";
//$DB["pass"]   = "principa_teacher";
	$WorkingKey = "saeqtmi7tvwsm6raqr" ; 
	$Merchant_Id= $_REQUEST['Merchant_Id'];
	$Amount= $_REQUEST['Amount'];
	$Order_Id= $_REQUEST['Order_Id'];
	$Merchant_Param= $_REQUEST['Merchant_Param'];
	$Checksum= $_REQUEST['Checksum'];
	$AuthDesc=$_REQUEST['AuthDesc'];
    $Checksum = verifyChecksum($Merchant_Id, $Order_Id , $Amount,$AuthDesc,$Checksum,$WorkingKey);
    // $Checksum =true;
	// $AuthDesc="N";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Principals.in</title>
<link href="css/default.css" rel="stylesheet" type="text/css" />
<link href='http://fonts.googleapis.com/css?family=Bitter|Supermercado+One|Salsa' rel='stylesheet' type='text/css'>
</head>
<body>
<div id="container">
 <div id="topMenu" align="center">
  <div id="topbanner" style="width:999px; margin:0 auto;">
    <div align="center"><img src="header.png" /></div>
  </div>
  
  <div id="midCotainer" align="center" style="background-image:none; width:999px; margin:0px auto;">
  <div style="margin:0 auto; width:700px;">
  
<?php
   $orderqry="select user_id,title,name,midname,surname,mobile_no,Email from teacher_profile  where
               user_id =(SELECT memberid FROM ordermanagement WHERE ordercode = '".$Order_Id."')"; 
   $orderres=mysql_query($orderqry,$Db) or die(mysql_error());
   $orderrow=mysql_fetch_array($orderres);
   $name      =    $orderrow['title'].' '.ucfirst($orderrow['name']).' '.ucfirst($orderrow['midname']).' '.ucfirst($orderrow['surname']);
   $regno     =    $orderrow['user_id'];
   $curdate   =    date("d-m-Y", strtotime(date("d-m-Y")));
   $mobno     =    $orderrow['mobile_no'];

   $Queryforusername = mysql_query("select user_name,email from user where user_id='".$regno."'");
   $results          = mysql_fetch_array($Queryforusername);
   $mailid           =  $results['email'];
   $username         =  $results['user_name'];
   $password         =  $results['user_name'];    

if($Checksum=="true" && $AuthDesc=="Y")
   	   {
			 mysql_query("update ordermanagement set paymentstatus = 'Paid' where ordercode = '".$Order_Id."'"); ?>	
             
            <!-- <div id="msgBlack" style="background:#cccccc;">Transaction Successful!!!<br />Thank You. <br /><br /><br /><br /></div>-->
            <div id="msgBlack" style="background:#eaeaea;"><br /><br /><span class="style1">Transaction Successful!!!</span><br />
               Thank You. <br /> <a href="www.principals.in"><img src="continue.png" width="120" height="30" /></a><br />
                <br /></div>
           
		   <?php
			   $email=$mailid;
			   $subject = "Congratulations! Your Registration Has Been Completed Successfully With Principals.in";
			   $txt ='<font family="Calibri,Tahoma,Arial, Helvetica, sans-serif" >
						<table width="700" border="0">
						<tr><td ><p>Thank you for registering with PrincipalsForum of National Conference of School Principals on 6th and 7th Jan 2017 .</p>
						</td></tr>
						</table>
						</font>';
			   $bcc = "ncsp@principals.in,sandeep.bisht@dpsgs.org";
			   $headers  = 'MIME-Version: 1.0' . "\r\n";
			   $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
			   $headers .= 'Bcc: $bcc' . "\r\n";
			   $headers .= "From: noreply@selaqui.org". "\r\n";
			   $headers .= "Return-Path: <noreply@principals.in>". "";
			   mail($email,$subject,$txt,$headers);
			   } else if($Checksum=="true" && $AuthDesc=="B"){
			   mysql_query("update ordermanagement set paymentstatus = 'Underprocess'  where ordercode = '".$Order_Id."'"); ?>
			  <!-- <div id="msgRed" style=" background:#cccccc;">Transaction In Process!!! We will contact you soon... <br /><br /><br /><br /></div>-->
        <div id="msgRed" style=" background:#eaeaea;"><br /><br /><span class="style1">Transaction In Process!!! We will contact you soon... </span><br />
               <a href="www.principals.in"><img src="continue.png" width="120" height="30" /></a> <br /><br /></div>
			   <?php } else if($Checksum=="true" && $AuthDesc=="N"){
			   mysql_query("update ordermanagement set paymentstatus = 'Unsuccessful'  where ordercode = '".$Order_Id."'"); ?>
			 <!--  <div id="msgRed" style=" background:#cccccc;">Transaction Unsuccessful!!! Please Try Again... <br /><br /><br /><br /></div>-->
               <div id="msgRed" style=" background:#eaeaea;"><br /><br />
			     <span class="style1">Transaction Unsuccessful!!! Please Try Again...</span><br />
                  <a href="www.principals.in"><img src="continue.png" width="120" height="30" /></a><br />
                    <br /><br /></div>
              <?
			   $email=$mailid;
			   $subject = "Congratulations ! Your Login Details For Conference.";
			   $txt  = '
                      <p><strong>Dear '.$name.'</strong>,
				      <br/><br/> PrincipalsForum thanks  you for registering as a </br>
                      delegate for National Conference of School Principals to be held at India Habitat Centre, New Delhi on Jan 6th and 7th , 2017. </br>
                      <p>Your Registration No. is --   <strong>NCSP00'.$regno.'</strong></p>
                      <p><strong>Your Login Details has been given below</strong> </p>
                      <p>Username :&nbsp;' . $username . '<br><br>Password:&nbsp;' . $password . '</p>
                      <p>your registration  is <font color=red>provisional</font>. Kindly make payment to confirm your registration.</p>
                      <p><a href=principals.in/login.php>Pay Now</a> To Complete your Registraion.<br/></p>
                      <p><strong>Organising Committee</strong><br/>
                      <strong>PrincipalsForum</strong></p>'; 
						
			   $bcc = "ncsp@principals.in,sandeep.bisht@dpsgs.org";
			   
			   $headers  = 'MIME-Version: 1.0' . "\r\n";
			   $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
			   $headers .= 'Bcc: $bcc' . "\r\n";
			   $headers .= "From: noreply@selaqui.org". "\r\n";
			   $headers .= "Return-Path: <noreply@principals.in>". "";
			   mail($email,$subject,$txt,$headers);
			   }  else {
			   echo "<br>Security Error. Illegal access detected";
			   }
?>
</div></div></div>
</div>
</body></html>